package query_builder

import (
	"strings"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
)

func TestBuildListQuery_Search_EmitsILike(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.Search = "kilo"

	query, args, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, "divisions.name ILIKE") {
		t.Errorf("expected ILIKE over name, got query:\n%s", query)
	}
	if !strings.Contains(query, "divisions.code ILIKE") {
		t.Errorf("expected ILIKE over code, got query:\n%s", query)
	}
	if len(args) != 2 || args[0] != "%kilo%" || args[1] != "%kilo%" {
		t.Errorf("expected two %%%%kilo%%%% args, got %v", args)
	}
}

func TestBuildListQuery_Search_UnknownColumnDropped(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.Search = "kilo"
	q.Columns = []string{"updatedAt", "unknown"}

	query, _, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if strings.Contains(query, "divisions.updated_at ILIKE") {
		t.Errorf("search must never span dates, got query:\n%s", query)
	}
	if !strings.Contains(query, "divisions.name ILIKE") {
		t.Errorf("expected fallback to the searchable set, got query:\n%s", query)
	}
}

func TestBuildListQuery_UserCountSubqueryProjected(t *testing.T) {
	q := dto.ListDivisionsRequest{}

	query, _, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	// Division augments every list query with the in-use user count subquery.
	if !strings.Contains(query, `(SELECT COUNT(*) FROM users WHERE users.division_id = divisions.id AND users.deleted_at IS NULL) as "userCount"`) {
		t.Errorf("expected userCount COUNT subquery, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_AllowlistApplied(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.SortBy = "name"
	q.SortOrder = 1

	query, _, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, "ORDER BY divisions.name ASC") {
		t.Errorf("expected allowlisted name sort, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_UnknownSortByFallsBackToName(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.SortBy = "id"
	q.SortOrder = 1

	query, _, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, "lower(trim(divisions.name)) ASC") {
		t.Errorf("expected name-sort fallback, got query:\n%s", query)
	}
	if strings.Contains(query, `"id"`) {
		t.Errorf("request key must never be interpolated, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_Descending(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.SortBy = "updatedAt"
	q.SortOrder = -1

	query, _, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, "ORDER BY divisions.updated_at DESC") {
		t.Errorf("expected descending updated_at sort, got query:\n%s", query)
	}
}

func TestBuildListQuery_UpdatedAt_Between(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.UpdatedAt = []int64{1700000000000, 1700003600000}

	query, args, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, `"divisions"."updated_at" BETWEEN`) {
		t.Errorf("expected BETWEEN filter on updated_at, got query:\n%s", query)
	}
	if len(args) != 2 {
		t.Fatalf("expected two BETWEEN args, got %v", args)
	}
}

func TestBuildListQuery_UpdatedAt_SingleBoundIsOpenEnded(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.UpdatedAt = []int64{1700000000000}

	query, args, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, `"divisions"."updated_at" >=`) {
		t.Errorf("expected open-ended >= filter, got query:\n%s", query)
	}
	if len(args) != 1 {
		t.Fatalf("expected one bound arg, got %v", args)
	}
}

func TestBuildListQuery_Unpaginated_HasNoOffset(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.Search = "kilo"

	query, _, err := GetDivisionListQuery(q, false)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if strings.Contains(query, "OFFSET") {
		t.Errorf("unpaginated export must have no OFFSET, got query:\n%s", query)
	}
	if strings.Contains(query, "LIMIT") {
		t.Errorf("unpaginated export must have no LIMIT, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_Code(t *testing.T) {
	q := dto.ListDivisionsRequest{}
	q.SortBy = "code"
	q.SortOrder = 1

	query, _, err := GetDivisionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetDivisionListQuery: %v", err)
	}
	if !strings.Contains(query, "ORDER BY divisions.code ASC") {
		t.Errorf("expected allowlisted code sort, got query:\n%s", query)
	}
}

func TestResolveSortColumn(t *testing.T) {
	if got := resolveSortColumn("name"); got != "divisions.name" {
		t.Errorf("resolveSortColumn(name) = %q", got)
	}
	if got := resolveSortColumn("code"); got != "divisions.code" {
		t.Errorf("resolveSortColumn(code) = %q", got)
	}
	if got := resolveSortColumn("updatedAt"); got != "divisions.updated_at" {
		t.Errorf("resolveSortColumn(updatedAt) = %q", got)
	}
	if got := resolveSortColumn("notAKey"); got != DefaultNameSort {
		t.Errorf("resolveSortColumn(unknown) = %q, want default", got)
	}
}
