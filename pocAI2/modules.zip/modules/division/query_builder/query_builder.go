package query_builder

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

var listColumns = map[string]string{
	"name":      "divisions.name",
	"code":      "divisions.code",
	"updatedAt": "divisions.updated_at",
}

var searchableColumns = map[string]string{
	"name": "divisions.name",
	"code": "divisions.code",
}

var defaultSearchColumns = []string{"divisions.name", "divisions.code"}

const DefaultNameSort = "lower(trim(divisions.name))"

func GetDivisionListQuery(q dto.ListDivisionsRequest, paginate bool) (string, []any, error) {
	builder := sql_query.NewSQLSelectBuilder[dto.DivisionItem]("divisions", "divisions")

	if q.Search != "" {
		builder.Search(q.Search, resolveSearchColumns(q.Columns))
	}

	switch len(q.UpdatedAt) {
	case 1:
		builder.Where(sql_query.WhereQuery{
			"divisions.updated_at": {
				Operator: sql_query.SQLOperatorGTE,
				Value:    time.UnixMilli(q.UpdatedAt[0]),
			},
		})
	case 2:
		builder.Where(sql_query.WhereQuery{
			"divisions.updated_at": {
				Operator: sql_query.SQLOperatorBetween,
				Value:    []time.Time{time.UnixMilli(q.UpdatedAt[0]), time.UnixMilli(q.UpdatedAt[1])},
			},
		})
	}

	if paginate {
		sortOrder := q.SortOrder
		if sortOrder == 0 {
			sortOrder = 1
		}
		builder.Paginate(sql_query.Pagination{
			Page:      q.Page,
			Limit:     q.Limit,
			SortBy:    resolveSortColumn(q.SortBy),
			SortOrder: sortOrder,
		})
	}

	return builder.Build()
}

func resolveSearchColumns(columns []string) []string {
	if len(columns) == 0 {
		return defaultSearchColumns
	}

	out := make([]string, 0, len(columns))
	for _, c := range columns {
		if expr, ok := searchableColumns[c]; ok {
			out = append(out, expr)
		}
	}
	if len(out) == 0 {
		return defaultSearchColumns
	}
	return out
}

func resolveSortColumn(sortBy string) string {
	if expr, ok := listColumns[sortBy]; ok {
		return expr
	}
	return DefaultNameSort
}
