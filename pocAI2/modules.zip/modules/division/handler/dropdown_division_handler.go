package handler

import (
	"github.com/gofiber/fiber/v3"

	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// HandleDropdownDivisions serves POST /v2/iam/divisions/dropdown.
func (h *DivisionHandler) HandleDropdownDivisions(c fiber.Ctx) error {
	clientID, _, _, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	items, err := h.DivisionSvc.Dropdown(c.Context(), clientID)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Data retrieved", items)
}
