package handler

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/service"
)

type DivisionHandler struct {
	DivisionSvc *service.DivisionService
}

func NewDivisionHandler(DivisionSvc *service.DivisionService) *DivisionHandler {
	return &DivisionHandler{DivisionSvc: DivisionSvc}
}
