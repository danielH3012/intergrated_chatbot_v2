package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *DivisionHandler) HandleUpdateDivision(c fiber.Ctx) error {
	clientID, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	divisionID := c.Params("division_id")
	if divisionID == "" {
		return coreEntity.BadRequest("Division ID is required").SendResponse(c)
	}
	id, err := strconv.ParseInt(divisionID, 10, 64)
	if err != nil {
		return coreEntity.BadRequest("Invalid division ID").SendResponse(c)
	}

	var body dto.UpdateDivisionRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	trimmedName := helper.TrimDivisionName(body.Name)
	if trimmedName == "" {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Name must not be empty"}).SendResponse(c)
	}
	if len(trimmedName) > 120 {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Max. 120 characters for attribute 'name'"}).SendResponse(c)
	}
	if helper.HasEmoji(trimmedName) {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Name contains invalid characters"}).SendResponse(c)
	}

	if body.Code != nil {
		if err := helper.ValidateDivisionCode(*body.Code); err != nil {
			return coreEntity.ToHttpError(err).SendResponse(c)
		}
	}

	if err := h.DivisionSvc.Update(c.Context(), service.UpdateDivisionParam{
		ClientID:     clientID,
		ID:           id,
		Name:         trimmedName,
		Code:         body.Code,
		UserID:       strconv.FormatInt(callerID, 10),
		UserFullName: roles.FullName,
	}); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Success, Division has been updated", nil)
}
