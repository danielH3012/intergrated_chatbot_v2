package handler

import (
	"fmt"
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleDeleteDivisions serves DELETE /v2/iam/divisions.
func (h *DivisionHandler) HandleDeleteDivisions(c fiber.Ctx) error {
	clientID, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.DeleteDivisionsRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if len(body.IDs) == 0 {
		return coreEntity.BadRequest("IDs are required").SendResponse(c)
	}

	resp, err := h.DivisionSvc.Delete(c.Context(), service.DeleteDivisionsParam{
		ClientID:     clientID,
		IDs:          body.IDs,
		UserID:       strconv.FormatInt(callerID, 10),
		UserFullName: roles.FullName,
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	deleted, skipped := countDeleteResults(resp.Results)
	if deleted == 1 && skipped == 0 {
		return coreHelper.Success(c, "Success, Division has been deleted.", resp)
	}
	if deleted > 0 && skipped == 0 {
		return coreHelper.Success(c, fmt.Sprintf("Success, %d divisions have been deleted.", deleted), resp)
	}
	msg := fmt.Sprintf("%d deleted, %d skipped (still in use).", deleted, skipped)
	return coreHelper.Success(c, msg, resp)
}

func countDeleteResults(results []dto.DeleteDivisionResult) (deleted, skipped int) {
	for _, r := range results {
		if r.Status == "deleted" {
			deleted++
		} else {
			skipped++
		}
	}
	return
}
