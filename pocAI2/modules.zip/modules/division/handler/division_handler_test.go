package handler_test

import (
	"context"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/service"
	tsEnum "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRepo mirrors the repository interface with func fields; only the read paths
// the handler tests touch are scripted.
type fakeRepo struct {
	listFn    func(ctx context.Context, q dto.ListDivisionsRequest) (*coreDto.PaginationResult[dto.DivisionItem], error)
	listAllFn func(ctx context.Context, q dto.ListDivisionsRequest) ([]dto.DivisionItem, error)
}

func (f *fakeRepo) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Division) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Division, error) {
	return nil, nil
}
func (f *fakeRepo) PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListDivisionsRequest) (*coreDto.PaginationResult[dto.DivisionItem], error) {
	return f.listFn(ctx, q)
}
func (f *fakeRepo) List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
	return f.listAllFn(ctx, q)
}
func (f *fakeRepo) Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error) {
	return nil, nil
}
func (f *fakeRepo) UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Division, error) {
	return nil, nil
}
func (f *fakeRepo) DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error) {
	return false, nil
}
func (f *fakeRepo) ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error) {
	return false, nil
}
func (f *fakeRepo) ExistsByCode(ctx context.Context, svc coreService.PostgreSQLServicer, code string, excludeID *int64) (bool, error) {
	return false, nil
}
func (f *fakeRepo) Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error) {
	return 0, nil
}

// newTestApp builds the app the handler tests hit: the real routes, with the RBAC
// snapshot injected directly (no iam, no Valkey) and the DB factory stubbed.
func newTestApp(t *testing.T, repo *fakeRepo) *fiber.App {
	t.Helper()

	svc := service.NewDivisionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})

	h := handler.NewDivisionHandler(svc)

	read := rbac.Any(rbac.GlobalSettingsSeeAll(), rbac.GlobalSettingsSystemRole(tsMiddleware.PermView, tsEnum.SystemRoleKeyManageUserAndRole))
	create := rbac.GlobalSettingsSystemRole(tsMiddleware.PermCreate, tsEnum.SystemRoleKeyManageUserAndRole)
	update := rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, tsEnum.SystemRoleKeyManageUserAndRole)
	deleteRole := rbac.GlobalSettingsSystemRole(tsMiddleware.PermDelete, tsEnum.SystemRoleKeyManageUserAndRole)

	group := app.Group("/v2/iam/divisions")
	group.Post("/list", h.HandleListDivisions, rbac.Require(read))
	group.Post("/dropdown", h.HandleDropdownDivisions, rbac.Require(read))
	group.Post("/export", h.HandleExportDivisions, rbac.Require(read))
	group.Post("/check-availability", h.HandleCheckAvailability, rbac.Require(read))
	group.Post("/", h.HandleCreateDivision, rbac.Require(create))
	group.Patch("/:division_id", h.HandleUpdateDivision, rbac.Require(update))
	group.Delete("/", h.HandleDeleteDivisions, rbac.Require(deleteRole))

	return app
}

// do sends one request with the given client/user headers and returns status, body
// and content type.
func do(app *fiber.App, method, path, body, clientID, userID string) (int, string, string) {
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	if clientID != "" {
		req.Header.Set("X-Client-ID", clientID)
	}
	if userID != "" {
		req.Header.Set("X-User-ID", userID)
	}
	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	raw, _ := io.ReadAll(res.Body)
	return res.StatusCode, string(raw), res.Header.Get("Content-Type")
}

func TestListDivisions_MalformedJSON_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions/list", `{"page":`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestCreateDivision_MissingName_Returns422(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions", `{}`, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("expected 422, got %d: %s", status, body)
	}
}

func TestCreateDivision_NameTooLong_Returns422(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	longName := strings.Repeat("a", 121)
	payload := `{"name":"` + longName + `"}`

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions", payload, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("expected 422, got %d: %s", status, body)
	}
}

func TestExportDivisions_InvalidFormat_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions/export", `{"format":"pdf"}`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestExportDivisions_CSV_ContentTypeAndHeader(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
			return []dto.DivisionItem{
				{ID: "177013", Name: "Engineering"},
			}, nil
		},
	}
	app := newTestApp(t, repo)

	status, body, contentType := do(app, fiber.MethodPost, "/v2/iam/divisions/export", `{"format":"csv"}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if contentType != "text/csv" {
		t.Errorf("expected text/csv, got %q", contentType)
	}
	if !strings.Contains(body, "Division Name,Code,Last Updated") {
		t.Errorf("expected header row, got %q", body)
	}
	if !strings.Contains(body, "Engineering") {
		t.Errorf("expected data row, got %q", body)
	}
}

func TestExportDivisions_XLSX_ContentType(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
			return []dto.DivisionItem{{ID: "177013", Name: "Engineering"}}, nil
		},
	}
	app := newTestApp(t, repo)

	status, body, contentType := do(app, fiber.MethodPost, "/v2/iam/divisions/export", `{}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if contentType != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" {
		t.Errorf("expected xlsx content type, got %q", contentType)
	}
}

func TestDeleteDivisions_MalformedJSON_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/divisions/", `{"ids":`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestDeleteDivisions_EmptyIDs_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/divisions/", `{"ids":[]}`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestCreateDivision_CodeValidation(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	t.Run("code too long returns 422", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions", `{"name":"HR","code":"VERYLONGCODE123456"}`, "acme", "42")
		if status != fiber.StatusUnprocessableEntity {
			t.Errorf("expected 422, got %d: %s", status, body)
		}
		if !strings.Contains(body, "Max. 15 characters for attribute 'code'") {
			t.Errorf("unexpected error message: %s", body)
		}
	})

	t.Run("code invalid character returns 422", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions", `{"name":"HR","code":"CODE WITH SPACE"}`, "acme", "42")
		if status != fiber.StatusUnprocessableEntity {
			t.Errorf("expected 422, got %d: %s", status, body)
		}
		if !strings.Contains(body, "Code contains invalid characters") {
			t.Errorf("unexpected error message: %s", body)
		}
	})
}

func TestUpdateDivision_CodeValidation(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	t.Run("code too long returns 422", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPatch, "/v2/iam/divisions/1", `{"name":"HR","code":"VERYLONGCODE123456"}`, "acme", "42")
		if status != fiber.StatusUnprocessableEntity {
			t.Errorf("expected 422, got %d: %s", status, body)
		}
		if !strings.Contains(body, "Max. 15 characters for attribute 'code'") {
			t.Errorf("unexpected error message: %s", body)
		}
	})

	t.Run("code invalid character returns 422", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPatch, "/v2/iam/divisions/1", `{"name":"HR","code":"INVALID#CODE"}`, "acme", "42")
		if status != fiber.StatusUnprocessableEntity {
			t.Errorf("expected 422, got %d: %s", status, body)
		}
		if !strings.Contains(body, "Code contains invalid characters") {
			t.Errorf("unexpected error message: %s", body)
		}
	})
}

func TestCheckAvailability_Handler(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	t.Run("malformed json returns 400", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions/check-availability", `{"name":`, "acme", "42")
		if status != fiber.StatusBadRequest {
			t.Errorf("expected 400, got %d: %s", status, body)
		}
	})

	t.Run("success check returns 200", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPost, "/v2/iam/divisions/check-availability", `{"name":"Human Resources","code":"HR"}`, "acme", "42")
		if status != fiber.StatusOK {
			t.Errorf("expected 200, got %d: %s", status, body)
		}
		if !strings.Contains(body, "Availability retrieved") {
			t.Errorf("unexpected response body: %s", body)
		}
		if !strings.Contains(body, `"available":true`) {
			t.Errorf("expected available:true, got %s", body)
		}
	})
}
