package workflow

import (
	"context"
	"testing"

	"github.com/stretchr/testify/suite"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/testsuite"
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	arDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
)

type DivisionWorkflowTestSuite struct {
	suite.Suite
	testsuite.WorkflowTestSuite
}

func TestDivisionWorkflowTestSuite(t *testing.T) {
	suite.Run(t, new(DivisionWorkflowTestSuite))
}

// testEnv wires one workflow under test with stubbed activities and a capturing
// RecordChangeLogsWorkflow child.
type testEnv struct {
	suite   *DivisionWorkflowTestSuite
	env     *testsuite.TestWorkflowEnvironment
	payload []arDto.CreateChangeLogActivityParam
}

func (s *DivisionWorkflowTestSuite) newEnv() *testEnv {
	e := &testEnv{suite: s}
	e.env = s.NewTestWorkflowEnvironment()

	e.env.RegisterWorkflowWithOptions(
		func(ctx workflow.Context, payload arDto.CreateChangeLogActivityParam) error {
			e.payload = append(e.payload, payload)
			return nil
		},
		workflow.RegisterOptions{Name: tsConstant.AnalyticsReportingRecordChangeLogsWorkflow},
	)
	return e
}

func (e *testEnv) stubActivity(name string, fn any) {
	e.env.RegisterActivityWithOptions(fn, activity.RegisterOptions{Name: name})
}

func (e *testEnv) run(wf any, param any) {
	e.env.ExecuteWorkflow(wf, param)
	e.suite.True(e.env.IsWorkflowCompleted())
	e.suite.NoError(e.env.GetWorkflowError())
}

const testTaskQueue = "iam-service"

func (s *DivisionWorkflowTestSuite) Test_CreateDivisionWorkflow_EmitsOneChangelogRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityInsertDivision, func(
		ctx context.Context, param InsertDivisionActivityParam,
	) (InsertDivisionActivityResult, error) {
		return InsertDivisionActivityResult{ID: 177013, Name: "Operations"}, nil
	})
	e.env.RegisterWorkflow(CreateDivisionWorkflow)

	e.run(CreateDivisionWorkflow, CreateDivisionWorkflowParam{
		ClientID:     "acme",
		Name:         "Operations",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	var result CreateDivisionWorkflowResult
	s.NoError(e.env.GetWorkflowResult(&result))
	s.Equal("177013", result.ID)

	s.Len(e.payload, 1, "create emits one child workflow")
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 1, "create emits one changelog row (Name only)")
	s.Equal("acme", e.payload[0].ClientID)
	for _, log := range logs {
		s.Equal("Division", log.LogTable)
		s.Equal(arModel.ChangeLogActionCreate, log.Action)
		s.Equal("177013", *log.ObjectId)
		s.Equal("Operations", *log.ObjectName)
		s.Equal("acme", log.EntityID)
		s.Equal(arModel.EntityTypeClient, log.EntityType)
		s.Equal(arModel.ProductGlobalSettings, *log.Product)
		s.Equal("Division", log.Object)
		s.Equal("42", log.CreatedById)
		s.Equal("Budi", log.CreatedBySnapshot)
	}
	s.Equal("Name", *logs[0].Field)
	s.Equal("-", *logs[0].OldValue)
	s.Equal("Operations", *logs[0].NewValue)
}

func (s *DivisionWorkflowTestSuite) Test_CreateDivisionWorkflow_WithCode_EmitsOneChangelogRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityInsertDivision, func(
		ctx context.Context, param InsertDivisionActivityParam,
	) (InsertDivisionActivityResult, error) {
		return InsertDivisionActivityResult{ID: 177013, Name: "Operations", Code: "OPS"}, nil
	})
	e.env.RegisterWorkflow(CreateDivisionWorkflow)

	e.run(CreateDivisionWorkflow, CreateDivisionWorkflowParam{
		ClientID:     "acme",
		Name:         "Operations",
		Code:         "OPS",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	var result CreateDivisionWorkflowResult
	s.NoError(e.env.GetWorkflowResult(&result))
	s.Equal("177013", result.ID)

	s.Len(e.payload, 1, "create emits one child workflow")
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 1, "create emits one changelog row (Name only)")
	s.Equal("Name", *logs[0].Field)
	s.Equal("-", *logs[0].OldValue)
	s.Equal("Operations", *logs[0].NewValue)
}

func (s *DivisionWorkflowTestSuite) Test_UpdateDivisionWorkflow_ChangedNameEmitsOneRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityUpdateDivision, func(
		ctx context.Context, param UpdateDivisionActivityParam,
	) (UpdateDivisionActivityResult, error) {
		return UpdateDivisionActivityResult{
			OldName: "Operations",
			NewName: "HR Department",
		}, nil
	})
	e.env.RegisterWorkflow(UpdateDivisionWorkflow)

	e.run(UpdateDivisionWorkflow, UpdateDivisionWorkflowParam{
		ClientID:     "acme",
		ID:           177013,
		Name:         "HR Department",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 1)
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 1, "one changed field emits one row")
	s.Equal(arModel.ChangeLogActionEdit, logs[0].Action)
	s.Equal("Name", *logs[0].Field)
	s.Equal("Operations", *logs[0].OldValue)
	s.Equal("HR Department", *logs[0].NewValue)
	s.Equal("177013", *logs[0].ObjectId)
}

func (s *DivisionWorkflowTestSuite) Test_UpdateDivisionWorkflow_ChangedCodeEmitsRow() {
	e := s.newEnv()
	code := "LGST"
	e.stubActivity(constant.ActivityUpdateDivision, func(
		ctx context.Context, param UpdateDivisionActivityParam,
	) (UpdateDivisionActivityResult, error) {
		return UpdateDivisionActivityResult{
			OldName: "Logistics",
			NewName: "Logistics",
			OldCode: "LOG",
			NewCode: "LGST",
		}, nil
	})
	e.env.RegisterWorkflow(UpdateDivisionWorkflow)

	e.run(UpdateDivisionWorkflow, UpdateDivisionWorkflowParam{
		ClientID:     "acme",
		ID:           177013,
		Name:         "Logistics",
		Code:         &code,
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 1)
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 1, "one changed field emits one row")
	s.Equal(arModel.ChangeLogActionEdit, logs[0].Action)
	s.Equal("Code", *logs[0].Field)
	s.Equal("LOG", *logs[0].OldValue)
	s.Equal("LGST", *logs[0].NewValue)
	s.Equal("177013", *logs[0].ObjectId)
}

func (s *DivisionWorkflowTestSuite) Test_UpdateDivisionWorkflow_NoOpEmitsZeroRows() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityUpdateDivision, func(
		ctx context.Context, param UpdateDivisionActivityParam,
	) (UpdateDivisionActivityResult, error) {
		return UpdateDivisionActivityResult{
			OldName: "Operations",
			NewName: "Operations",
		}, nil
	})
	e.env.RegisterWorkflow(UpdateDivisionWorkflow)

	e.run(UpdateDivisionWorkflow, UpdateDivisionWorkflowParam{
		ClientID:     "acme",
		ID:           177013,
		Name:         "Operations",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 0, "no-op edit spawns no changelog child")
}

func (s *DivisionWorkflowTestSuite) Test_DeleteDivisionWorkflow_EmitsOneBatchedChild() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityDeleteDivision, func(
		ctx context.Context, param DeleteDivisionsActivityParam,
	) (DeleteDivisionsActivityResult, error) {
		skipped := "not_found"
		inUse := "in_use"
		return DeleteDivisionsActivityResult{
			Results: []dto.DeleteDivisionResult{
				{ID: "1", Status: "deleted"},
				{ID: "2", Status: "deleted"},
				{ID: "3", Status: "blocked", Reason: &skipped},
				{ID: "4", Status: "blocked", Reason: &inUse},
			},
			Deleted: []DeletedDivision{
				{ID: 1, Name: "Operations"},
				{ID: 2, Name: "Finance"},
			},
		}, nil
	})
	e.env.RegisterWorkflow(DeleteDivisionWorkflow)

	e.run(DeleteDivisionWorkflow, DeleteDivisionWorkflowParam{
		ClientID:     "acme",
		IDs:          []int64{1, 2, 3, 4},
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 1, "bulk delete emits ONE batched child")
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 2, "2 deleted ids × 1 field (Name)")
	for _, log := range logs {
		s.Equal(arModel.ChangeLogActionDelete, log.Action)
		s.Equal("Division", log.LogTable)
		s.Equal("Division", log.Object)
	}
	s.Equal("1", *logs[0].ObjectId)
	s.Equal("Operations", *logs[0].ObjectName)
	s.Equal("Name", *logs[0].Field)
	s.Equal("Operations", *logs[0].OldValue)
	s.Equal("-", *logs[0].NewValue)
	s.Equal("2", *logs[1].ObjectId)
	s.Equal("Finance", *logs[1].OldValue)
}

func (s *DivisionWorkflowTestSuite) Test_DeleteDivisionWorkflow_AllBlockedEmitsNoChild() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityDeleteDivision, func(
		ctx context.Context, param DeleteDivisionsActivityParam,
	) (DeleteDivisionsActivityResult, error) {
		inUse := "in_use"
		return DeleteDivisionsActivityResult{
			Results: []dto.DeleteDivisionResult{
				{ID: "1", Status: "blocked", Reason: &inUse},
			},
			Deleted: nil,
		}, nil
	})
	e.env.RegisterWorkflow(DeleteDivisionWorkflow)

	e.run(DeleteDivisionWorkflow, DeleteDivisionWorkflowParam{
		ClientID:     "acme",
		IDs:          []int64{1},
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 0, "blocked deletes spawn no changelog child")
}
