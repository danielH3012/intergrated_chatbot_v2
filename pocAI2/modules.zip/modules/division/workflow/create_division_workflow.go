package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type InsertDivisionActivityParam struct {
	ClientID string
	Name     string
	Code     string
	UserID   string
}

type InsertDivisionActivityResult struct {
	ID   int64
	Name string
	Code string
}

type CreateDivisionWorkflowParam struct {
	ClientID     string
	Name         string
	Code         string
	UserID       string
	UserFullName string
	TaskQueue    string
}

type CreateDivisionWorkflowResult struct {
	ID string
}

func CreateDivisionWorkflow(ctx workflow.Context, param CreateDivisionWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	compensation := coreService.NewWorkflowCompensation()
	defer func() {
		if err != nil {
			disconnectedCtx, cancel := workflow.NewDisconnectedContext(activityCtx)
			defer cancel()
			compensation.Compensate(disconnectedCtx, false)
		}
	}()

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientID,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    param.TaskQueue,
		}

		var inserted InsertDivisionActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityInsertDivision,
			InsertDivisionActivityParam{
				ClientID: param.ClientID,
				Name:     param.Name,
				Code:     param.Code,
				UserID:   param.UserID,
			},
		).Get(activityCtx, &inserted); err != nil {
			return nil, err
		}

		compensation.AddCompensation(constant.ActivityDeleteDivision, DeleteDivisionsActivityParam{
			ClientID: param.ClientID,
			IDs:      []int64{inserted.ID},
		})

		logs := []arModel.Changelog{
			divisionChangelog(arModel.ChangeLogActionCreate, inserted.ID, inserted.Name, "Name", dash(), inserted.Name, identity),
		}

		spawnChangeLogWorkflow(ctx, identity, logs)

		return CreateDivisionWorkflowResult{ID: strconv.FormatInt(inserted.ID, 10)}, nil
	})
}
