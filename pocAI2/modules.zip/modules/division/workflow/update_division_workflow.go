package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type UpdateDivisionActivityParam struct {
	ClientID string
	ID       int64
	Name     string
	Code     *string
	UserID   string
}

type UpdateDivisionActivityResult struct {
	OldName string
	NewName string
	OldCode string
	NewCode string
}

type UpdateDivisionWorkflowParam struct {
	ClientID     string
	ID           int64
	Name         string
	Code         *string
	UserID       string
	UserFullName string
	TaskQueue    string
}

type UpdateDivisionWorkflowResult struct{}

func UpdateDivisionWorkflow(ctx workflow.Context, param UpdateDivisionWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		var updated UpdateDivisionActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityUpdateDivision,
			UpdateDivisionActivityParam{
				ClientID: param.ClientID,
				ID:       param.ID,
				Name:     param.Name,
				Code:     param.Code,
				UserID:   param.UserID,
			},
		).Get(activityCtx, &updated); err != nil {
			return nil, err
		}

		identity := changelogIdentity{
			ClientID:     param.ClientID,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    param.TaskQueue,
		}

		var logs []arModel.Changelog
		currentName := updated.NewName
		if currentName == "" {
			currentName = updated.OldName
		}
		if updated.OldName != updated.NewName && updated.NewName != "" {
			logs = append(logs, divisionChangelog(arModel.ChangeLogActionEdit, param.ID, currentName, "Name", updated.OldName, updated.NewName, identity))
		}
		if updated.OldCode != updated.NewCode && updated.NewCode != "" {
			logs = append(logs, divisionChangelog(arModel.ChangeLogActionEdit, param.ID, currentName, "Code", updated.OldCode, updated.NewCode, identity))
		}
		spawnChangeLogWorkflow(ctx, identity, logs)

		return UpdateDivisionWorkflowResult{}, nil
	})
}
