package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type DeleteDivisionsActivityParam struct {
	ClientID string
	IDs      []int64
}

type DeleteDivisionsActivityResult struct {
	Results []dto.DeleteDivisionResult
	Deleted []DeletedDivision
}

type DeleteDivisionWorkflowParam struct {
	ClientID     string
	IDs          []int64
	UserID       string
	UserFullName string
	TaskQueue    string
}

type DeleteDivisionWorkflowResult struct {
	Results []dto.DeleteDivisionResult
}

type DeletedDivision struct {
	ID   int64
	Name string
}

func DeleteDivisionWorkflow(ctx workflow.Context, param DeleteDivisionWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		var deleted DeleteDivisionsActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityDeleteDivision,
			DeleteDivisionsActivityParam{
				ClientID: param.ClientID,
				IDs:      param.IDs,
			},
		).Get(activityCtx, &deleted); err != nil {
			return nil, err
		}

		identity := changelogIdentity{
			ClientID:     param.ClientID,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    param.TaskQueue,
		}

		var logs []arModel.Changelog
		for _, d := range deleted.Deleted {
			logs = append(logs,
				divisionChangelog(arModel.ChangeLogActionDelete, d.ID, d.Name, "Name", d.Name, dash(), identity),
			)
		}
		spawnChangeLogWorkflow(ctx, identity, logs)

		return DeleteDivisionWorkflowResult{Results: deleted.Results}, nil
	})
}
