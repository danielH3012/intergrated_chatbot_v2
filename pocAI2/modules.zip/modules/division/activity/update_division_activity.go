package activity

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"go.temporal.io/sdk/temporal"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// UpdateDivisionActivity loads the row and writes only the changed fields plus
// modified_by / updated_at, inside one transaction. The result carries old and new
// values so the workflow can emit one changelog row per changed field; a no-op
// edit returns unchanged values and writes (and logs) nothing.
func (a *Activities) UpdateDivisionActivity(ctx context.Context, param workflow.UpdateDivisionActivityParam) (workflow.UpdateDivisionActivityResult, error) {
	svc := a.tenantSvc(param.ClientID)

	newName := strings.TrimSpace(param.Name)

	result := workflow.UpdateDivisionActivityResult{}

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)

		current, err := a.repo.FindByID(ctx, svc, param.ID)
		if err != nil {
			if errors.Is(err, repository.ErrDivisionNotFound) {
				return nil, temporal.NewNonRetryableApplicationError(
					"Division not found",
					coreEntity.ErrNotFound,
					err,
				)
			}
			return nil, fmt.Errorf("UpdateDivisionActivity: %w", err)
		}

		result.OldName = current.Name
		result.NewName = current.Name
		var currentCode string
		if current.Code != nil {
			currentCode = *current.Code
		}
		result.OldCode = currentCode
		result.NewCode = currentCode

		nameChanged := newName != "" && newName != current.Name

		var codeChanged bool
		var newCode string
		if param.Code != nil {
			newCode = helper.NormalizeDivisionCode(*param.Code)
			if newCode != currentCode {
				codeChanged = true
			}
		}

		if !nameChanged && !codeChanged {
			return nil, nil
		}

		updates := sql_query.UpdateQuery{}

		if nameChanged {
			exists, err := a.repo.ExistsByName(ctx, svc, newName, &param.ID)
			if err != nil {
				return nil, fmt.Errorf("UpdateDivisionActivity: check existsByName: %w", err)
			}
			if exists {
				return nil, temporal.NewNonRetryableApplicationError(
					"Name already exists",
					coreEntity.ErrConflict,
					errors.New("name already exists"),
				)
			}
			updates["name"] = newName
			result.NewName = newName
		}

		if codeChanged {
			exists, err := a.repo.ExistsByCode(ctx, svc, newCode, &param.ID)
			if err != nil {
				return nil, fmt.Errorf("UpdateDivisionActivity: check existsByCode: %w", err)
			}
			if exists {
				return nil, temporal.NewNonRetryableApplicationError(
					"Code already exists",
					coreEntity.ErrConflict,
					errors.New("code already exists"),
				)
			}
			updates["code"] = newCode
			result.NewCode = newCode
		}

		modifiedBy, err := strconv.ParseInt(param.UserID, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("UpdateDivisionActivity: parse modified_by: %w", err)
		}
		updates["modified_by"] = &modifiedBy
		updates["updated_at"] = time.Now()

		if _, err := a.repo.UpdateOne(ctx, svc, param.ID, updates); err != nil {
			return nil, WrapDivisionError("update", err)
		}

		return nil, nil
	})
	return result, err
}
