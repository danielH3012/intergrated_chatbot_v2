package activity

import (
	"context"
	"errors"
	"log/slog"
	"strconv"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/workflow"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// DeleteDivisionsActivity deletes each id sequentially, each in its own
// transaction:
//
//  1. LockForDelete (SELECT ... FOR UPDATE) — a missing row is skipped (reason nil).
//  2. HasActiveReferences — skipped with reason "in_use"; references stays [].
//  3. DeleteByID — the locked row's full values feed the changelog rows.
//
// The guard is re-read INSIDE the transaction, never trusted from the list payload.
func (a *Activities) DeleteDivisionsActivity(ctx context.Context, param workflow.DeleteDivisionsActivityParam) (workflow.DeleteDivisionsActivityResult, error) {
	svc := a.tenantSvc(param.ClientID)

	result := workflow.DeleteDivisionsActivityResult{
		Results: make([]dto.DeleteDivisionResult, 0, len(param.IDs)),
		Deleted: make([]workflow.DeletedDivision, 0, len(param.IDs)),
	}

	for _, id := range param.IDs {
		item, deleted, err := a.deleteOne(ctx, svc, id)
		if err != nil {
			reason := "error"
			item.Reason = &reason
			item.Status = "blocked"
			slog.ErrorContext(ctx, "division: deleteOne failed", "id", id, "error", err)
			result.Results = append(result.Results, item)
			continue
		}
		result.Results = append(result.Results, item)
		if deleted != nil {
			result.Deleted = append(result.Deleted, *deleted)
		}
	}
	return result, nil
}

// deleteOne handles a single id. The skipped outcome (missing row) has no Name:
// the LLD's block dialog keys on status/reason, not on the name of a row that is
// not there.
func (a *Activities) deleteOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (dto.DeleteDivisionResult, *workflow.DeletedDivision, error) {
	item := dto.DeleteDivisionResult{
		ID:     strconv.FormatInt(id, 10),
		Status: "blocked",
	}
	var current *workflow.DeletedDivision

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)

		locked, err := a.repo.LockForDelete(ctx, svc, id)
		if err != nil {
			if errors.Is(err, repository.ErrDivisionNotFound) {
				return nil, nil // skip: row absent
			}
			return nil, WrapDivisionError("delete", err)
		}

		item.ID = strconv.FormatInt(locked.ID, 10)

		hasRefs, err := a.repo.HasActiveReferences(ctx, svc, id)
		if err != nil {
			return nil, WrapDivisionError("delete", err)
		}

		if hasRefs {
			msg := "in_use"
			item.Reason = &msg
			return nil, nil
		}

		if _, err := a.repo.DeleteByID(ctx, svc, id); err != nil {
			return nil, WrapDivisionError("delete", err)
		}

		item.Status = "deleted"
		current = &workflow.DeletedDivision{
			ID:   locked.ID,
			Name: locked.Name,
		}
		return nil, nil
	})

	return item, current, err
}
