package division

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/service"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
)

// SetupRoutes mounts the division routes. Each route is gated per verb on the
// "Manage user and role" system role.
//
// rolesFetcher resolves the caller's RBAC snapshot from iam's own database on a
// Valkey cache miss. It is injected (rather than reached over HTTP) because iam is
// the service that owns the role tables — calling iam's own snapshot endpoint from
// inside iam would be a self-referential network hop (see ts-utils LoadUserRolesFrom).
func SetupRoutes(app *fiber.App, rolesFetcher tsMiddleware.RolesFetcher, svc *service.DivisionService) {
	h := handler.NewDivisionHandler(svc)

	group := app.Group("/divisions")

	// Populate the RBAC snapshot (Locals UserRolesKey) BEFORE the rbac.Require gates
	// and before handlers call tsMiddleware.RequestIdentity. Without this, GetUserRoles
	// finds nothing in Locals and every request is cut short with 401, no matter how
	// valid X-User-ID / X-Client-ID are.
	group.Use(tsMiddleware.LoadUserRolesFrom(rolesFetcher))

	const key = enum.SystemRoleKeyManageUserAndRole

	read := rbac.Any(rbac.GlobalSettingsSeeAll(), rbac.GlobalSettingsSystemRole(tsMiddleware.PermView, key))
	create := rbac.GlobalSettingsSystemRole(tsMiddleware.PermCreate, key)
	update := rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, key)
	deleteRole := rbac.GlobalSettingsSystemRole(tsMiddleware.PermDelete, key)

	group.Post("/list", rbac.Require(read), h.HandleListDivisions)
	group.Post("/dropdown", rbac.Require(read), h.HandleDropdownDivisions)
	group.Post("/export", rbac.Require(read), h.HandleExportDivisions)
	group.Post("/check-availability", rbac.Require(read), h.HandleCheckAvailability)
	group.Post("/", rbac.Require(create), h.HandleCreateDivision)
	group.Patch("/:division_id", rbac.Require(update), h.HandleUpdateDivision)
	group.Delete("/", rbac.Require(deleteRole), h.HandleDeleteDivisions)
}

// SetupInternalRoutes mounts the same surface behind a service token. Internal
// callers carry a service token, not a user, so these routes must be registered
// before the user-auth + RBAC middleware chain.
func SetupInternalRoutes(app *fiber.App, serviceToken string, svc *service.DivisionService) {
	// Will be used by other services if needed, implement later
}
