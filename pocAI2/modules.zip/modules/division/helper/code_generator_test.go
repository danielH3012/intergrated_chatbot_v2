package helper_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
)

func TestGenerateDivisionCode(t *testing.T) {
	tests := []struct {
		name          string
		divisionName  string
		existingCodes map[string]bool
		wantCode      string
	}{
		{
			name:         "Multi-word alphabetic (Human Resources -> HR)",
			divisionName: "Human Resources",
			wantCode:     "HR",
		},
		{
			name:         "Multi-word with numbers (Region 5 -> R5)",
			divisionName: "Region 5",
			wantCode:     "R5",
		},
		{
			name:         "Single word fallback to 6 chars (Finance -> FINANC)",
			divisionName: "Finance",
			wantCode:     "FINANC",
		},
		{
			name:         "Single short word (IT -> IT)",
			divisionName: "IT",
			wantCode:     "IT",
		},
		{
			name:         "Delimiters dash and slash (Global-Settings / Division -> GSD)",
			divisionName: "Global-Settings / Division",
			wantCode:     "GSD",
		},
		{
			name:         "Collision deduplication with suffix 2",
			divisionName: "Human Resources",
			existingCodes: map[string]bool{
				"HR": true,
			},
			wantCode: "HR2",
		},
		{
			name:         "Multiple collision deduplication",
			divisionName: "Human Resources",
			existingCodes: map[string]bool{
				"HR":  true,
				"HR2": true,
				"HR3": true,
			},
			wantCode: "HR4",
		},
		{
			name:         "15 char boundary truncation with suffix",
			divisionName: "A B C D E F G H I J K L M N O P",
			existingCodes: map[string]bool{
				"ABCDEFGHIJKLMNO": true,
			},
			// Base candidate ABCDEFGHIJKLMNO is 15 chars. With suffix "2", base candidate is truncated to 14 chars + "2"
			wantCode: "ABCDEFGHIJKLMN2",
		},
		{
			name:         "Word with symbol (R&D -> RD fallback)",
			divisionName: "R&D",
			wantCode:     "RD",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			isUnique := func(candidate string) (bool, error) {
				if tt.existingCodes != nil && tt.existingCodes[candidate] {
					return false, nil
				}
				return true, nil
			}

			code, err := helper.GenerateDivisionCode(tt.divisionName, isUnique)
			require.NoError(t, err)
			assert.Equal(t, tt.wantCode, code)
			assert.LessOrEqual(t, len(code), 15)
		})
	}
}

func TestValidateDivisionCode(t *testing.T) {
	assert.NoError(t, helper.ValidateDivisionCode("HR"))
	assert.NoError(t, helper.ValidateDivisionCode("FIN_01"))
	assert.NoError(t, helper.ValidateDivisionCode("DIV-1.2"))

	// Boundary > 15 chars
	assert.Error(t, helper.ValidateDivisionCode("1234567890123456"))

	// Invalid characters
	assert.Error(t, helper.ValidateDivisionCode("HR@CORP"))
	assert.Error(t, helper.ValidateDivisionCode("HR#1"))
	assert.Error(t, helper.ValidateDivisionCode("HR 01"))

	// Emoji
	assert.Error(t, helper.ValidateDivisionCode("HR🏢"))
}

func TestNormalizeDivisionCode(t *testing.T) {
	assert.Equal(t, "HR", helper.NormalizeDivisionCode("  hr  "))
	assert.Equal(t, "LGST", helper.NormalizeDivisionCode("lgst"))
}
