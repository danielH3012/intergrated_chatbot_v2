package helper

import (
	"regexp"
	"strings"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"github.com/gofiber/fiber/v3"
)

var emojiRegex = regexp.MustCompile(`[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{1F100}-\x{1F1FF}\x{1F200}-\x{1F2FF}\x{1F780}-\x{1F7FF}\x{1F900}-\x{1F9FF}\x{1FA00}-\x{1FAFF}\x{2300}-\x{23FF}\x{2600}-\x{26FF}\x{2700}-\x{27BF}\x{2B00}-\x{2BFF}\x{2190}-\x{21FF}\x{3200}-\x{32FF}\x{203C}\x{2049}\x{2122}\x{2139}\x{3030}\x{303D}\x{FE0F}]`)

var divisionCodeRegex = regexp.MustCompile(`^[a-zA-Z0-9._-]+$`)

func HasEmoji(s string) bool {
	return emojiRegex.MatchString(s)
}

func TrimDivisionName(name string) string {
	return strings.TrimSpace(name)
}

// NormalizeDivisionCode trims whitespace and converts to uppercase.
func NormalizeDivisionCode(code string) string {
	return strings.ToUpper(strings.TrimSpace(code))
}

// ValidateDivisionCode validates code boundary (<= 15) and whitelist characters.
func ValidateDivisionCode(code string) error {
	trimmed := strings.TrimSpace(code)
	if len(trimmed) > 15 {
		return &coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Max. 15 characters for attribute 'code'"}
	}
	if !divisionCodeRegex.MatchString(trimmed) {
		return &coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Code contains invalid characters"}
	}
	return nil
}
