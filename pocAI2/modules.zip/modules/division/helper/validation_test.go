package helper_test

import (
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
	"github.com/stretchr/testify/assert"
)

func TestHasEmoji(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected bool
	}{
		{"empty string", "", false},
		{"plain ASCII name", "Finance", false},
		{"name with spaces and punctuation", "Human Resources & Dev.", false},
		{"name with accents", "René François", false},
		{"legacy emoji", "Finance 😀", true},
		{"party emoji", "🎉 Events", true},
		{"thumbs up emoji", "Ops 👍", true},
		{"fire emoji", "Marketing 🔥", true},
		{"building emoji", "Building 🏢", true},
		{"compound emoji ZWJ", "Family 👨‍👩‍👧‍👦", true},
		{"flag emoji", "Flag 🇮🇩", true},
		{"modern melting face emoji", "Finance 🫠", true},
		{"modern saluting face emoji", "🫡 Security", true},
		{"modern heart hands emoji", "Care 🫶", true},
		{"bubbles emoji", "Sanitation 🫧", true},
		{"star emoji", "Top ⭐ Division", true},
		{"colored circle emoji", "Division 🟢", true},
		{"hourglass emoji", "Temp ⏳", true},
		{"alarm clock emoji", "Shift ⏰", true},
		{"ok button emoji", "Approvals 🆗", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.expected, helper.HasEmoji(tt.input))
		})
	}
}

func TestTrimDivisionName(t *testing.T) {
	assert.Equal(t, "Finance", helper.TrimDivisionName("   Finance   "))
	assert.Equal(t, "Human Resources", helper.TrimDivisionName("Human Resources"))
}
