package helper

import (
	"fmt"
	"strconv"
	"strings"
	"unicode"
)

// GenerateDivisionCode implements the F-DIV-03 Division Code auto-generation algorithm:
// 1. Tokenize name by splitting on spaces, '-', '_', '/'.
// 2. Per token: alphabetic -> first char uppercase. Pure numeric -> passthrough. Alphanumeric mixed -> first char uppercase.
// 3. Join tokens in original order -> base candidate.
// 4. Fallback: if base candidate is empty or < 2 chars -> take first 6 alphanumeric chars from name (strip whitespace/symbols), uppercase.
// 5. Truncate to max 15 chars.
// 6. Dedup (numeric suffix): check uniqueness via isUnique callback. If taken, append "2", "3", etc. (truncating base candidate if needed so total length <= 15).
func GenerateDivisionCode(name string, isUnique func(candidate string) (bool, error)) (string, error) {
	tokens := strings.FieldsFunc(name, func(r rune) bool {
		return unicode.IsSpace(r) || r == '-' || r == '_' || r == '/'
	})

	var baseBuilder strings.Builder
	for _, token := range tokens {
		trimmedToken := strings.TrimSpace(token)
		if trimmedToken == "" {
			continue
		}

		allAlpha := true
		allDigit := true
		hasAlnum := false

		for _, r := range trimmedToken {
			if unicode.IsLetter(r) {
				allDigit = false
				hasAlnum = true
			} else if unicode.IsDigit(r) {
				allAlpha = false
				hasAlnum = true
			} else {
				allAlpha = false
				allDigit = false
			}
		}

		if !hasAlnum {
			continue
		}

		if allAlpha {
			// Take first character uppercase
			for _, r := range trimmedToken {
				baseBuilder.WriteRune(unicode.ToUpper(r))
				break
			}
		} else if allDigit {
			// Pure numeric -> passthrough full token
			baseBuilder.WriteString(trimmedToken)
		} else {
			// Mixed alphanumeric -> take first alphanumeric character uppercase
			for _, r := range trimmedToken {
				if unicode.IsLetter(r) || unicode.IsDigit(r) {
					baseBuilder.WriteRune(unicode.ToUpper(r))
					break
				}
			}
		}
	}

	baseCandidate := baseBuilder.String()

	// Step 4: Fallback if base candidate is empty or < 2 chars
	if len(baseCandidate) < 2 {
		var fallbackBuilder strings.Builder
		for _, r := range name {
			if unicode.IsLetter(r) || unicode.IsDigit(r) {
				fallbackBuilder.WriteRune(unicode.ToUpper(r))
				if fallbackBuilder.Len() == 6 {
					break
				}
			}
		}
		if fallbackBuilder.Len() > 0 {
			baseCandidate = fallbackBuilder.String()
		} else {
			baseCandidate = "DIV"
		}
	}

	// Step 5: Truncate to max 15 chars
	if len(baseCandidate) > 15 {
		baseCandidate = baseCandidate[:15]
	}

	// Step 6: Dedup (numeric suffix)
	candidate := baseCandidate
	suffix := 2

	for {
		unique, err := isUnique(candidate)
		if err != nil {
			return "", fmt.Errorf("check code uniqueness: %w", err)
		}
		if unique {
			return candidate, nil
		}

		suffixStr := strconv.Itoa(suffix)
		maxBaseLen := 15 - len(suffixStr)
		if maxBaseLen < 1 {
			maxBaseLen = 1
		}

		if len(baseCandidate) > maxBaseLen {
			candidate = baseCandidate[:maxBaseLen] + suffixStr
		} else {
			candidate = baseCandidate + suffixStr
		}
		suffix++
	}
}
