package dto

type UpdateDivisionRequest struct {
	DivisionBody
}
