package dto

import "time"

type DivisionItem struct {
	ID        string     `json:"_id"         column:"divisions.id::text"`
	Name      string     `json:"name"        column:"divisions.name"       export:"Division Name"`
	Code      *string    `json:"code"        column:"divisions.code"       export:"Code"`
	IsDefault bool       `json:"isDefault"   column:"divisions.is_default"`
	UserCount int        `json:"userCount"   column:"(SELECT COUNT(*) FROM users WHERE users.division_id = divisions.id AND users.deleted_at IS NULL)"`
	UpdatedAt *time.Time `json:"updatedAt"   column:"divisions.updated_at" export:"Last Updated"`
}

type DivisionBody struct {
	Name string  `json:"name" validate:"division_name"`
	Code *string `json:"code"`
}
