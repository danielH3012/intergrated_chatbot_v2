package dto

type DropdownItem struct {
	ID   string `json:"_id"`
	Name string `json:"name"`
}

type DivisionDropdownResponse []DropdownItem
