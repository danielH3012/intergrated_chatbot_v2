package dto

type DeleteDivisionsRequest struct {
	IDs []string `json:"ids" validate:"required"`
}

type Reference struct {
	Module string `json:"module"`
	Name   string `json:"name"`
}

type DeleteDivisionResult struct {
	ID     string  `json:"_id"`
	Status string  `json:"status"`
	Reason *string `json:"reason,omitempty"`
}

type DeleteDivisionsResponse struct {
	Results []DeleteDivisionResult `json:"results"`
}
