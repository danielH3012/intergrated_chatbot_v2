package dto

import (
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
)

type ListDivisionsRequest struct {
	coreDto.PaginationQuery
	UpdatedAt []int64 `json:"updatedAt" validate:"omitempty,max=2"`
}

// Defaults fills the pagination defaults (page=1, limit=10).
func (r *ListDivisionsRequest) Defaults() {
	r.PaginationQuery.Defaults()
}
