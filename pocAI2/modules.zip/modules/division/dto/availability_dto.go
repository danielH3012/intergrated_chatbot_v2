package dto

// CheckDivisionAvailabilityRequest is the request body for POST /v2/iam/divisions/check-availability.
type CheckDivisionAvailabilityRequest struct {
	Name *string `json:"name"`
	Code *string `json:"code"`
}

// FieldAvailability reports availability for a single field (true=free, false=taken, null=not checked).
type FieldAvailability struct {
	Available *bool `json:"available"`
}

// CheckDivisionAvailabilityResponse is the data payload for availability response.
type CheckDivisionAvailabilityResponse struct {
	Name *FieldAvailability `json:"name"`
	Code *FieldAvailability `json:"code"`
}
