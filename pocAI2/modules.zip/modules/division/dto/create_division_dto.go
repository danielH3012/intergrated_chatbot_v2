package dto

type CreateDivisionRequest struct {
	DivisionBody
}

type CreateDivisionResponse struct {
	ID string `json:"_id"`
}
