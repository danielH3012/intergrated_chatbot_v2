package dto

type ExportDivisionsRequest struct {
	ListDivisionsRequest
	Format string `json:"format" validate:"omitempty,oneof=csv xlsx"`
}

func (r *ExportDivisionsRequest) Defaults() {
	r.ListDivisionsRequest.Defaults()
	if r.Format == "" {
		r.Format = "xlsx"
	}
}
