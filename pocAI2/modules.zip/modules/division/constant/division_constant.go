package constant

const (
	WorkflowCreateDivision = "CreateDivisionWorkflow"
	WorkflowUpdateDivision = "UpdateDivisionWorkflow"
	WorkflowDeleteDivision = "DeleteDivisionWorkflow"

	ActivityInsertDivision = "InsertDivisionActivity"
	ActivityUpdateDivision = "UpdateDivisionActivity"
	ActivityDeleteDivision = "DeleteDivisionsActivity"
)

const (
	MsgInternalServerError = "Internal server error"
)
