package service

import (
	"context"
	"fmt"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/repository"
	tsDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	notificationClient "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/notification_service/client"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// DivisionService is the use-case layer for division. It delegates DB reads to
// the repository and writes to Temporal workflows.
type DivisionService struct {
	temporalSvc    *coreService.TemporalService
	dbName         string
	arTaskQueue    string
	repo           repository.DivisionRepository
	notifier       *notificationClient.NotificationClient
	settingsClient *client.EnterpriseManagementClient
	makeTenantSvc  func(clientID string) coreService.PostgreSQLServicer
}

func NewDivisionService(dbName string, repo repository.DivisionRepository, temporalSvc *coreService.TemporalService, arTaskQueue string, notifier *notificationClient.NotificationClient, settingsClient *client.EnterpriseManagementClient) *DivisionService {
	return &DivisionService{
		dbName:         dbName,
		repo:           repo,
		temporalSvc:    temporalSvc,
		arTaskQueue:    arTaskQueue,
		notifier:       notifier,
		settingsClient: settingsClient,
	}
}

// tenantSvc routes queries into the client's own schema.
func (s *DivisionService) tenantSvc(clientID string) coreService.PostgreSQLServicer {
	if s.makeTenantSvc != nil {
		return s.makeTenantSvc(clientID)
	}
	return coreService.MakePostgreSQLService(string(tsDb.DBName(s.dbName).CompanyDBName(clientID)))
}

// PaginatedList is a direct DB read.
func (s *DivisionService) PaginatedList(ctx context.Context, clientID string, q dto.ListDivisionsRequest) (*coreDto.PaginationResult[dto.DivisionItem], error) {
	return s.repo.PaginatedList(ctx, s.tenantSvc(clientID), q)
}

// Dropdown is a direct DB read.
func (s *DivisionService) Dropdown(ctx context.Context, clientID string) ([]dto.DropdownItem, error) {
	options, err := s.repo.Dropdown(ctx, s.tenantSvc(clientID))
	if err != nil {
		return nil, err
	}
	items := make([]dto.DropdownItem, 0, len(options))
	for _, opt := range options {
		items = append(items, dto.DropdownItem{
			ID:   fmt.Sprintf("%v", opt.Value),
			Name: fmt.Sprintf("%v", opt.Label),
		})
	}
	return items, nil
}

// SetServiceFactoryForTest replaces the DB factory with a stub so unit tests never
// touch Postgres.
func (s *DivisionService) SetServiceFactoryForTest(factory func(clientID string) coreService.PostgreSQLServicer) {
	s.makeTenantSvc = factory
}
