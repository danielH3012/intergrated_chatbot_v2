package service

import (
	"context"
	"log/slog"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// CheckAvailability verifies whether division name and/or code are available (not taken).
func (s *DivisionService) CheckAvailability(ctx context.Context, clientID string, req dto.CheckDivisionAvailabilityRequest) (*dto.CheckDivisionAvailabilityResponse, error) {
	resp := &dto.CheckDivisionAvailabilityResponse{}

	if req.Name != nil && strings.TrimSpace(*req.Name) != "" {
		trimmedName := strings.TrimSpace(*req.Name)
		exists, err := s.repo.ExistsByName(ctx, s.tenantSvc(clientID), trimmedName, nil)
		if err != nil {
			slog.ErrorContext(ctx, "division.CheckAvailability existsByName failed", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		available := !exists
		resp.Name = &dto.FieldAvailability{Available: &available}
	} else {
		resp.Name = &dto.FieldAvailability{Available: nil}
	}

	if req.Code != nil && strings.TrimSpace(*req.Code) != "" {
		normalizedCode := helper.NormalizeDivisionCode(*req.Code)
		exists, err := s.repo.ExistsByCode(ctx, s.tenantSvc(clientID), normalizedCode, nil)
		if err != nil {
			slog.ErrorContext(ctx, "division.CheckAvailability existsByCode failed", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		available := !exists
		resp.Code = &dto.FieldAvailability{Available: &available}
	} else {
		resp.Code = &dto.FieldAvailability{Available: nil}
	}

	return resp, nil
}
