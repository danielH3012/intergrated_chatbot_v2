package service

import (
	"context"
	"slices"
	"strconv"
	"testing"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRepo implements repository.DivisionRepository with func fields; the read
// paths this suite doesn't exercise are stubbed to nil-return so they panic
// loudly if a service method reaches them unexpectedly.
type fakeRepo struct {
	listFn         func(ctx context.Context, q dto.ListDivisionsRequest) (*coreDto.PaginationResult[dto.DivisionItem], error)
	listAllFn      func(ctx context.Context, q dto.ListDivisionsRequest) ([]dto.DivisionItem, error)
	dropdownFn     func(ctx context.Context) ([]coreDto.InterfaceOptionDTO, error)
	existsByNameFn func(ctx context.Context, name string, excludeID *int64) (bool, error)
	existsByCodeFn func(ctx context.Context, code string, excludeID *int64) (bool, error)
	countFn        func(ctx context.Context) (int64, error)
}

func (f *fakeRepo) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Division) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Division, error) {
	return nil, nil
}
func (f *fakeRepo) PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListDivisionsRequest) (*coreDto.PaginationResult[dto.DivisionItem], error) {
	return f.listFn(ctx, q)
}
func (f *fakeRepo) List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
	return f.listAllFn(ctx, q)
}
func (f *fakeRepo) Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error) {
	return f.dropdownFn(ctx)
}
func (f *fakeRepo) UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Division, error) {
	return nil, nil
}
func (f *fakeRepo) DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error) {
	return false, nil
}
func (f *fakeRepo) ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error) {
	if f.existsByNameFn != nil {
		return f.existsByNameFn(ctx, name, excludeID)
	}
	return false, nil
}
func (f *fakeRepo) ExistsByCode(ctx context.Context, svc coreService.PostgreSQLServicer, code string, excludeID *int64) (bool, error) {
	if f.existsByCodeFn != nil {
		return f.existsByCodeFn(ctx, code, excludeID)
	}
	return false, nil
}
func (f *fakeRepo) Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error) {
	if f.countFn != nil {
		return f.countFn(ctx)
	}
	return 0, nil
}

func newTestService(repo *fakeRepo) *DivisionService {
	svc := NewDivisionService("tagsamurai_iam", repo, nil, "analytics-reporting-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	return svc
}

func TestPaginatedList_PassesThrough(t *testing.T) {
	called := false
	repo := &fakeRepo{
		listFn: func(_ context.Context, q dto.ListDivisionsRequest) (*coreDto.PaginationResult[dto.DivisionItem], error) {
			called = true
			return &coreDto.PaginationResult[dto.DivisionItem]{TotalRecords: 1, Data: []dto.DivisionItem{{ID: "1", Name: "Operations"}}}, nil
		},
	}
	svc := newTestService(repo)

	paged, err := svc.PaginatedList(context.Background(), "acme", dto.ListDivisionsRequest{})
	if err != nil {
		t.Fatalf("PaginatedList: %v", err)
	}
	if !called {
		t.Error("repo.PaginatedList was not called")
	}
	if paged.TotalRecords != 1 || len(paged.Data) != 1 {
		t.Errorf("unexpected result %+v", paged)
	}
}

func TestList_PassesThrough(t *testing.T) {
	called := false
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
			called = true
			return []dto.DivisionItem{{ID: "1", Name: "Operations"}}, nil
		},
	}
	svc := newTestService(repo)

	got, err := svc.List(context.Background(), "acme", dto.ListDivisionsRequest{})
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if !called {
		t.Error("repo.List was not called")
	}
	if len(got) != 1 || got[0].Name != "Operations" {
		t.Errorf("unexpected result %+v", got)
	}
}

func TestDropdown_PassesThrough(t *testing.T) {
	repo := &fakeRepo{
		dropdownFn: func(_ context.Context) ([]coreDto.InterfaceOptionDTO, error) {
			return []coreDto.InterfaceOptionDTO{{Value: "177013", Label: "Operations"}}, nil
		},
	}
	svc := newTestService(repo)

	options, err := svc.Dropdown(context.Background(), "acme")
	if err != nil {
		t.Fatalf("Dropdown: %v", err)
	}
	if len(options) != 1 || options[0].ID != "177013" || options[0].Name != "Operations" {
		t.Errorf("unexpected options %+v", options)
	}
}

func TestExportColumns_ReflectsExportTagsInOrder(t *testing.T) {
	headers, cells := helper.ExportColumns[dto.DivisionItem]()
	wantHeaders := []string{"Division Name", "Code", "Last Updated"}
	if len(headers) != len(wantHeaders) {
		t.Fatalf("expected %v, got %v", wantHeaders, headers)
	}
	for i := range wantHeaders {
		if headers[i] != wantHeaders[i] {
			t.Errorf("header %d = %q, want %q", i, headers[i], wantHeaders[i])
		}
	}

	updatedAt := time.Date(2026, 8, 7, 16, 30, 0, 0, time.UTC)
	code := "OPS"
	row := cells(dto.DivisionItem{ID: "177013", Name: "Operations", Code: &code, UpdatedAt: &updatedAt})
	wantRow := []string{"Operations", "OPS", "2026-08-07 16:30:00"}
	for i := range wantRow {
		if row[i] != wantRow[i] {
			t.Errorf("cell %d = %q, want %q (row %v)", i, row[i], wantRow[i], row)
		}
	}
}

func TestExport_CSV(t *testing.T) {
	code1 := "OPS"
	code2 := "FIN"
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
			return []dto.DivisionItem{
				{ID: "177013", Name: "Operations", Code: &code1},
				{ID: "177014", Name: "Finance", Code: &code2},
			}, nil
		},
	}
	svc := newTestService(repo)

	result, err := svc.Export(context.Background(), ExportDivisionParam{
		ClientID: "acme",
		Format:   "csv",
	})
	if err != nil {
		t.Fatalf("Export: %v", err)
	}
	if result.ContentType != "text/csv" {
		t.Errorf("expected text/csv, got %q", result.ContentType)
	}
	got := string(result.Data)
	if got != "Division Name,Code,Last Updated\nOperations,OPS,\nFinance,FIN,\n" {
		t.Errorf("unexpected csv:\n%q", got)
	}
}

func TestExport_XLSX_IsValidFile(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
			return []dto.DivisionItem{{ID: "177013", Name: "Operations"}}, nil
		},
	}
	svc := newTestService(repo)

	result, err := svc.Export(context.Background(), ExportDivisionParam{
		ClientID: "acme",
		Format:   "xlsx",
	})
	if err != nil {
		t.Fatalf("Export: %v", err)
	}
	if result.ContentType != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" {
		t.Errorf("unexpected content type %q", result.ContentType)
	}
	if len(result.Data) == 0 {
		t.Error("expected non-empty xlsx payload")
	}
	if len(result.Filename) == 0 {
		t.Error("expected a filename")
	}
}

func TestCheckAvailability(t *testing.T) {
	repo := &fakeRepo{
		existsByNameFn: func(_ context.Context, name string, _ *int64) (bool, error) {
			if name == "Existing Name" {
				return true, nil
			}
			return false, nil
		},
		existsByCodeFn: func(_ context.Context, code string, _ *int64) (bool, error) {
			if code == "EXISTING" {
				return true, nil
			}
			return false, nil
		},
	}
	svc := newTestService(repo)

	t.Run("both available", func(t *testing.T) {
		name := "New Division"
		code := "new-div"
		resp, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckDivisionAvailabilityRequest{
			Name: &name,
			Code: &code,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if resp.Name == nil || resp.Name.Available == nil || !*resp.Name.Available {
			t.Errorf("expected name available true, got %+v", resp.Name)
		}
		if resp.Code == nil || resp.Code.Available == nil || !*resp.Code.Available {
			t.Errorf("expected code available true, got %+v", resp.Code)
		}
	})

	t.Run("both taken", func(t *testing.T) {
		name := "Existing Name"
		code := "existing" // auto-uppercased to EXISTING
		resp, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckDivisionAvailabilityRequest{
			Name: &name,
			Code: &code,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if resp.Name == nil || resp.Name.Available == nil || *resp.Name.Available {
			t.Errorf("expected name available false, got %+v", resp.Name)
		}
		if resp.Code == nil || resp.Code.Available == nil || *resp.Code.Available {
			t.Errorf("expected code available false, got %+v", resp.Code)
		}
	})

	t.Run("empty/omitted returns null", func(t *testing.T) {
		emptyStr := ""
		resp, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckDivisionAvailabilityRequest{
			Name: &emptyStr,
			Code: nil,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if resp.Name == nil || resp.Name.Available != nil {
			t.Errorf("expected name available null, got %+v", resp.Name)
		}
		if resp.Code == nil || resp.Code.Available != nil {
			t.Errorf("expected code available null, got %+v", resp.Code)
		}
	})
}

func TestCreate_PreWorkflowValidations(t *testing.T) {
	t.Run("duplicate name returns conflict", func(t *testing.T) {
		repo := &fakeRepo{
			existsByNameFn: func(_ context.Context, name string, _ *int64) (bool, error) {
				return true, nil
			},
		}
		svc := newTestService(repo)
		_, err := svc.Create(context.Background(), CreateDivisionParam{
			ClientID: "acme",
			Name:     "Existing Name",
		})
		if err == nil || err.Error() != "Name already exists" {
			t.Errorf("expected 'Name already exists' error, got %v", err)
		}
	})

	t.Run("duplicate code returns conflict", func(t *testing.T) {
		repo := &fakeRepo{
			existsByNameFn: func(_ context.Context, name string, _ *int64) (bool, error) {
				return false, nil
			},
			existsByCodeFn: func(_ context.Context, code string, _ *int64) (bool, error) {
				return true, nil
			},
		}
		svc := newTestService(repo)
		code := "MKT"
		_, err := svc.Create(context.Background(), CreateDivisionParam{
			ClientID: "acme",
			Name:     "Marketing",
			Code:     &code,
		})
		if err == nil || err.Error() != "Code already exists" {
			t.Errorf("expected 'Code already exists' error, got %v", err)
		}
	})
}

func TestIDsDigest_StableAndBounded(t *testing.T) {
	ids := make([]string, 100)
	for i := range ids {
		ids[i] = strconv.FormatInt(1773248399000+int64(i), 10)
	}
	shuffled := slices.Clone(ids)
	slices.Reverse(shuffled)

	got := idsDigest(ids)
	if got != idsDigest(shuffled) {
		t.Error("digest must not depend on the order ids arrive in")
	}
	if got == idsDigest(ids[:99]) {
		t.Error("a different id set must produce a different digest")
	}
	if wf := "division-delete-acme-" + got; len(wf) > 1000 {
		t.Errorf("workflow id too long: %d bytes", len(wf))
	}
}
