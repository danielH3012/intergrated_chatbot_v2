package service

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"log/slog"
	"slices"
	"strconv"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

// DeleteDivisionsParam is the service-level bulk-delete request.
type DeleteDivisionsParam struct {
	ClientID     string
	IDs          []string
	UserID       string
	UserFullName string
}

// Delete starts the delete workflow and waits for the per-id results.
func (s *DivisionService) Delete(ctx context.Context, param DeleteDivisionsParam) (*dto.DeleteDivisionsResponse, error) {
	ids, err := parseIDs(param.IDs)
	if err != nil {
		return nil, err
	}

	result := &workflow.DeleteDivisionWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowDeleteDivision,
		TemporalService: s.temporalSvc,
		Param: workflow.DeleteDivisionWorkflowParam{
			ClientID:     param.ClientID,
			IDs:          ids,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("division-delete-%s-%s", param.ClientID, idsDigest(param.IDs)),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
	})
	if httpErr != nil {
		return nil, httpErr
	}
	if err := s.notifier.SendSSE(ctx, param.ClientID, []string{}, "division.deleted"); err != nil {
		slog.WarnContext(ctx, "division: sse push failed", "error", err)
	}
	return &dto.DeleteDivisionsResponse{Results: result.Results}, nil
}

// parseIDs converts the string snowflake ids (as carried by the query string) to
// int64. A non-numeric id is a caller bug, not a DB concern: reject it up front.
func parseIDs(raw []string) ([]int64, error) {
	ids := make([]int64, 0, len(raw))
	for _, r := range raw {
		id, err := strconv.ParseInt(r, 10, 64)
		if err != nil {
			return nil, coreEntity.BadRequest(fmt.Sprintf("Invalid division ID: %s", r))
		}
		ids = append(ids, id)
	}
	return ids, nil
}

// idsDigest names an id set in fixed width. The raw ids cannot go in the workflow ID:
// 100 snowflakes joined is ~2KB and Temporal rejects an ID over 1000 bytes. Sorted
// first so the same selection submitted in a different order is the same workflow,
// which is what the double-submit guard wants.
func idsDigest(ids []string) string {
	sorted := slices.Clone(ids)
	slices.Sort(sorted)
	sum := sha256.Sum256([]byte(strings.Join(sorted, ",")))
	return hex.EncodeToString(sum[:8])
}
