package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// ExportDivisionParam is the service-level export request.
type ExportDivisionParam struct {
	ClientID string
	Format   string // "csv" | "xlsx"
	List     dto.ListDivisionsRequest
}

// ExportDivisionResult is the rendered file: bytes ready to stream, plus the
// content type and attachment filename the handler echoes.
type ExportDivisionResult = helper.ExportResult

// Export renders the list rows as csv or xlsx using be-core-utils/helper.Export.
func (s *DivisionService) Export(ctx context.Context, param ExportDivisionParam) (*ExportDivisionResult, error) {
	rows, err := s.List(ctx, param.ClientID, param.List)
	if err != nil {
		return nil, err
	}

	return helper.Export(rows, helper.ExportParam{
		Format:       param.Format,
		FallbackName: "Division-List",
	})
}
