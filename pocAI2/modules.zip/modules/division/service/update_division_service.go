package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/workflow"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

// UpdateDivisionParam is the service-level update request.
type UpdateDivisionParam struct {
	ClientID     string
	ID           int64
	Name         string
	Code         *string
	UserID       string
	UserFullName string
}

// Update starts the update workflow and waits for completion.
func (s *DivisionService) Update(ctx context.Context, param UpdateDivisionParam) error {
	result := &workflow.UpdateDivisionWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowUpdateDivision,
		TemporalService: s.temporalSvc,
		Param: workflow.UpdateDivisionWorkflowParam{
			ClientID:     param.ClientID,
			ID:           param.ID,
			Name:         param.Name,
			Code:         param.Code,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("division-update-%s-%d", param.ClientID, param.ID),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
	})
	if httpErr != nil {
		return httpErr
	}
	if err := s.notifier.SendSSE(ctx, param.ClientID, []string{}, "division.updated"); err != nil {
		slog.WarnContext(ctx, "division: sse push failed", "error", err)
	}
	return nil
}
