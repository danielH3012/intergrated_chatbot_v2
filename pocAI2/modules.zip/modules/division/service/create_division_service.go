package service

import (
	"context"
	"fmt"
	"log/slog"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

type CreateDivisionParam struct {
	ClientID     string
	Name         string
	Code         *string
	UserID       string
	UserFullName string
}

func (s *DivisionService) Create(ctx context.Context, param CreateDivisionParam) (*dto.CreateDivisionResponse, error) {
	if s.settingsClient != nil {
		limit := s.settingsClient.GetMasterDataCountLimit(ctx)
		if limit > 0 {
			count, err := s.repo.Count(ctx, s.tenantSvc(param.ClientID))
			if err != nil {
				slog.ErrorContext(ctx, "division.Create count failed", "err", err)
				return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
			}
			if int(count) >= limit {
				return nil, coreEntity.UnprocessableEntity("You've reached the platform limit of %d divisions. Contact support if you need a higher limit.", limit)
			}
		}
	}

	exists, err := s.repo.ExistsByName(ctx, s.tenantSvc(param.ClientID), param.Name, nil)
	if err != nil {
		slog.ErrorContext(ctx, "division.Create existsByName failed", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if exists {
		return nil, coreEntity.Conflict("Name already exists")
	}

	var finalCode string
	if param.Code == nil || strings.TrimSpace(*param.Code) == "" {
		generated, err := helper.GenerateDivisionCode(param.Name, func(candidate string) (bool, error) {
			codeExists, err := s.repo.ExistsByCode(ctx, s.tenantSvc(param.ClientID), candidate, nil)
			return !codeExists, err
		})
		if err != nil {
			slog.ErrorContext(ctx, "division.Create generate code failed", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		finalCode = generated
	} else {
		finalCode = helper.NormalizeDivisionCode(*param.Code)
		codeExists, err := s.repo.ExistsByCode(ctx, s.tenantSvc(param.ClientID), finalCode, nil)
		if err != nil {
			slog.ErrorContext(ctx, "division.Create existsByCode failed", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		if codeExists {
			return nil, coreEntity.Conflict("Code already exists")
		}
	}

	result := &workflow.CreateDivisionWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowCreateDivision,
		TemporalService: s.temporalSvc,
		Param: workflow.CreateDivisionWorkflowParam{
			ClientID:     param.ClientID,
			Name:         param.Name,
			Code:         finalCode,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("division-create-%s-%s", param.ClientID, param.Name),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return nil, httpErr
	}
	if err := s.notifier.SendSSE(ctx, param.ClientID, []string{}, "division.created"); err != nil {
		slog.WarnContext(ctx, "division: sse push failed", "error", err)
	}
	return &dto.CreateDivisionResponse{ID: result.ID}, nil
}
