package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/dto"
)

// List is the export read: same filters as PaginatedList, unpaginated.
func (s *DivisionService) List(ctx context.Context, clientID string, q dto.ListDivisionsRequest) ([]dto.DivisionItem, error) {
	return s.repo.List(ctx, s.tenantSvc(clientID), q)
}
