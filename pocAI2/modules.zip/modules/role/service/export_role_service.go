package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

type ExportRoleResult = helper.ExportResult

func (s *RoleService) ExportAccessLevelUsers(ctx context.Context, clientID string, product model.Product, req dto.ExportAccessLevelRequest) (*ExportRoleResult, error) {
	rows, err := s.repo.ListAccessLevelUsersAll(ctx, s.tenantSvc(clientID), product, req.AccessLevelListQuery)
	if err != nil {
		return nil, err
	}
	exportRows := make([]dto.AccessLevelExportItem, 0, len(rows))
	for _, row := range rows {
		status := dto.StatusInactive
		if row.IsActive {
			status = dto.StatusActive
		}
		exportRows = append(exportRows, dto.AccessLevelExportItem{
			Name:             row.FullName,
			Position:         row.Position,
			Division:         row.Division,
			Status:           status,
			ActivationStatus: activationStatus(row.ActivationStatus, row.PendingEmail),
			TemporaryUser:    row.TemporaryStatus,
			TemporaryUntil:   row.ActivePeriodUntil,
			Tag:              row.TagCode,
			ModifiedBy:       row.ModifiedBy,
			LastUpdated:      row.UpdatedAt,
		})
	}
	name := "Role-Permission-Read-Only"
	if req.AccessLevel == dto.AccessLevelTotalControl {
		name = "Role-Permission-Total-Control"
	}
	return helper.Export(exportRows, helper.ExportParam{Format: req.Format, FileName: name})
}

func (s *RoleService) ExportCapabilities(ctx context.Context, clientID string, product model.Product, req dto.ExportCapabilitiesRequest) (*ExportRoleResult, error) {
	rows, err := s.repo.ListCapabilitiesAll(ctx, s.tenantSvc(clientID), product, req.CapabilitiesListQuery)
	if err != nil {
		return nil, err
	}
	exportRows := make([]dto.CapabilitiesExportItem, 0, len(rows))
	for _, row := range rows {
		exportRows = append(exportRows, dto.CapabilitiesExportItem{CapabilityName: row.Name, Users: row.TotalUsers})
	}
	return helper.Export(exportRows, helper.ExportParam{Format: req.Format, FileName: "Role-Permission-System"})
}

func (s *RoleService) ExportCapabilityUsers(ctx context.Context, clientID string, product model.Product, req dto.ExportCapabilityUsersRequest) (*ExportRoleResult, error) {
	key := model.SystemRoleKey(req.Key)
	rows, err := s.repo.ListCapabilityUsersAll(ctx, s.tenantSvc(clientID), product, key, req.CapabilityUsersListQuery)
	if err != nil {
		return nil, err
	}
	exportRows := make([]dto.CapabilityUsersExportItem, 0, len(rows))
	for _, row := range rows {
		exportRows = append(exportRows, dto.CapabilityUsersExportItem{
			Name:             row.FullName,
			Position:         row.Position,
			Division:         row.Division,
			Create:           row.Permission.Create,
			Read:             row.Permission.Read,
			Update:           row.Permission.Update,
			Delete:           row.Permission.Delete,
			ActivationStatus: activationStatus(row.ActivationStatus, row.PendingEmail),
			TemporaryUser:    row.TemporaryStatus,
			TemporaryUntil:   row.ActivePeriodUntil,
			Tag:              row.TagCode,
		})
	}
	name := string(model.SystemRoleNameOf(key))
	return helper.Export(exportRows, helper.ExportParam{Format: req.Format, FileName: "Role-Permission-" + name})
}

func activationStatus(status string, pendingEmail *string) string {
	if status == dto.ActivationActivated && pendingEmail != nil {
		return dto.ActivationPendingEmail
	}
	return status
}
