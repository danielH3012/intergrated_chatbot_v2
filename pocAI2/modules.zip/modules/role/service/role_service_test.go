package service

import (
	"context"
	"errors"
	"reflect"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRoleRepo is a stateful in-memory double for RoleRepositor. It
// records every call so a test can assert on the delegation itself, not only
// on the returned envelope. [AI-GENERATED]
type fakeRoleRepo struct {
	product model.Product
	query   dto.CapabilitiesListQuery
	res     *dto.CapabilitiesListResponse
	err     error
}

func (f *fakeRoleRepo) ListCapabilities(_ context.Context, _ coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) (*dto.CapabilitiesListResponse, error) {
	f.product = product
	f.query = q
	if f.err != nil {
		return nil, f.err
	}
	return f.res, nil
}
func (f *fakeRoleRepo) ListCapabilitiesAll(context.Context, coreService.PostgreSQLServicer, model.Product, dto.CapabilitiesListQuery) ([]dto.CapabilitiesListItem, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListAccessLevelUsers(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) (*dto.AccessLevelListResponse, error) {
	panic("not called")
}
func (f *fakeRoleRepo) ListAccessLevelUsersAll(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) ([]dto.AccessLevelListItem, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetAccessLevelOptions(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) (*dto.AccessLevelOptionsResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListCapabilityUsers(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) (*dto.CapabilityUsersListResponse, error) {
	panic("not called")
}
func (f *fakeRoleRepo) ListCapabilityUsersAll(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) ([]dto.CapabilityUsersListItem, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetCapabilityUsersOptions(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) (*dto.CapabilityUsersOptionsResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListAssignableUsers(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AssignableUsersListQuery) (*dto.AssignableUsersListResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetAssignableUsersOptions(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AssignableUsersListQuery) (*dto.AssignableUsersOptionsResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64) (*dto.CapabilityUserRow, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListUserCapabilityRows(context.Context, coreService.PostgreSQLServicer, model.Product, int64) ([]model.UserSystemRole, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetUserAccessLevelRow(context.Context, coreService.PostgreSQLServicer, model.Product, int64) (*model.UserAccessLevel, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetUserAssignmentEligibility(context.Context, coreService.PostgreSQLServicer, model.Product, int64) (*dto.UserAssignmentEligibility, error) {
	panic("not called")
}

func (f *fakeRoleRepo) AddCapabilityUser(context.Context, coreService.PostgreSQLServicer, model.UserSystemRole) error {
	panic("not called")
}

func (f *fakeRoleRepo) PatchCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64, sql_query.UpdateQuery) error {
	panic("not called")
}

func (f *fakeRoleRepo) DeleteUserAccessLevelRow(context.Context, coreService.PostgreSQLServicer, model.Product, int64) error {
	panic("not called")
}

func (f *fakeRoleRepo) UpsertAccessLevel(context.Context, coreService.PostgreSQLServicer, model.UserAccessLevel) error {
	panic("not called")
}

func (f *fakeRoleRepo) UpsertCapabilityRows(context.Context, coreService.PostgreSQLServicer, []model.UserSystemRole) error {
	panic("not called")
}

func (f *fakeRoleRepo) DeleteCapabilityRows(context.Context, coreService.PostgreSQLServicer, model.Product, int64) error {
	panic("not called")
}

func (f *fakeRoleRepo) ListCapabilityUserRows(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, []int64) ([]dto.CapabilityUserRow, error) {
	panic("not called")
}

func (f *fakeRoleRepo) DeleteCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64) error {
	panic("not called")
}

func TestListCapabilitiesDelegates(t *testing.T) {
	want := &dto.CapabilitiesListResponse{
		TotalRecords: 6,
		Data: []dto.CapabilitiesListItem{
			{Key: model.SystemRoleKeyManageUserAndRole, Name: string(model.SystemRoleNameManageUserAndRole), TotalUsers: 2},
		},
	}
	repo := &fakeRoleRepo{res: want}
	svc := NewRoleService("testdb", repo, nil, "", fakeServicerFactory)

	query := dto.CapabilitiesListQuery{Page: 1, Limit: 10, SortBy: "totalUsers", SortOrder: -1}
	got, err := svc.ListCapabilities(context.Background(), "client-1", model.ProductGlobalSettings, query)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if got != want {
		t.Fatalf("response = %+v, want %+v", got, want)
	}
	if repo.product != model.ProductGlobalSettings {
		t.Errorf("product = %q, want %q", repo.product, model.ProductGlobalSettings)
	}
	if !reflect.DeepEqual(repo.query, query) {
		t.Errorf("query = %+v, want %+v", repo.query, query)
	}
}

func TestListCapabilitiesPropagatesRepoError(t *testing.T) {
	wantErr := errBoom
	svc := NewRoleService("testdb", &fakeRoleRepo{err: wantErr}, nil, "", fakeServicerFactory)

	_, err := svc.ListCapabilities(context.Background(), "client-1", model.ProductGlobalSettings, dto.CapabilitiesListQuery{})
	if err != wantErr {
		t.Fatalf("err = %v, want %v", err, wantErr)
	}
}

// fakeServicerFactory swaps the eager pool construction (which dials
// PostgreSQL and log.Fatals) for a no-op servicer the fakes never use.
func fakeServicerFactory(string) coreService.PostgreSQLServicer {
	return &coreService.FakePostgreSQLService{}
}

var errBoom = errors.New("boom")
