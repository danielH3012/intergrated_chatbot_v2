package service

import (
	"context"
	"fmt"
	"strconv"

	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
)

// RoleService is the use-case layer of the IAM Service Role & Permission
// surface. Read endpoints query the tenant schema directly; the write
// endpoints are Temporal workflow dispatchers (the guards and the DB writes
// live in the role activities, run on the iam task queue).
type RoleService struct {
	dbName    string
	repo      repository.RoleRepositor
	tenantSvc func(clientID string) coreService.PostgreSQLServicer

	// temporalSvc dispatches the role write workflows; nil disables the write
	// endpoints (unit tests).
	temporalSvc *coreService.TemporalService
	// arTaskQueue is the task queue the changelog child workflow runs on, in
	// analytics-reporting-service's Temporal worker.
	arTaskQueue string
}

// NewRoleService wires the use-case layer. An optional servicer factory
// override lets tests avoid the real pool (which connects eagerly); nil
// keeps the default clientID:dbName construction. temporalSvc may be nil in
// tests — the write endpoints fail with 500 when absent.
func NewRoleService(dbName string, repo repository.RoleRepositor, temporalSvc *coreService.TemporalService, arTaskQueue string, tenantSvcOverride ...func(clientID string) coreService.PostgreSQLServicer) *RoleService {
	s := &RoleService{dbName: dbName, repo: repo, temporalSvc: temporalSvc, arTaskQueue: arTaskQueue}
	s.tenantSvc = func(clientID string) coreService.PostgreSQLServicer {
		return coreService.MakePostgreSQLService(clientID + ":" + dbName)
	}
	if len(tenantSvcOverride) > 0 && tenantSvcOverride[0] != nil {
		s.tenantSvc = tenantSvcOverride[0]
	}
	return s
}

// ProductModule maps the {product} path enum to the module key the RBAC
// snapshot is keyed by. The scope is read from the path — never from a body or
// query field, which would be a client-chosen scope (OWASP API1:2023). Shared
// by the route gates and the service guards.
func ProductModule(product model.Product) (enum.ModuleAccess, bool) {
	switch product {
	case model.ProductGlobalSettings:
		return enum.ModuleAccessGlobalSettings, true
	case model.ProductAdminConsole:
		return enum.ModuleAccessAdminConsole, true
	case model.ProductFixedAsset:
		return enum.ModuleAccessFixedAsset, true
	default:
		return "", false
	}
}

// ListAccessLevelUsers will return the paginated Total Control / Read Only tab
// list (POST /roles/access-level/list).
func (s *RoleService) ListAccessLevelUsers(ctx context.Context, clientID string, product model.Product, q dto.AccessLevelListQuery) (*dto.AccessLevelListResponse, error) {
	return s.repo.ListAccessLevelUsers(ctx, s.tenantSvc(clientID), product, q)
}

// GetAccessLevelOptions will return the access-level tab filter option lists
// (POST /roles/access-level/options).
func (s *RoleService) GetAccessLevelOptions(ctx context.Context, clientID string, product model.Product, q dto.AccessLevelListQuery) (*dto.AccessLevelOptionsResponse, error) {
	return s.repo.GetAccessLevelOptions(ctx, s.tenantSvc(clientID), product, q)
}

// ListCapabilities returns the fixed capability catalog with the derived
// per-key user counts (POST /roles/capabilities/list).
func (s *RoleService) ListCapabilities(ctx context.Context, clientID string, product model.Product, q dto.CapabilitiesListQuery) (*dto.CapabilitiesListResponse, error) {
	return s.repo.ListCapabilities(ctx, s.tenantSvc(clientID), product, q)
}

// ListCapabilityUsers returns the paginated Detail Capability table
// (POST /roles/capabilities/users/list).
func (s *RoleService) ListCapabilityUsers(ctx context.Context, clientID string, product model.Product, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersListResponse, error) {
	return s.repo.ListCapabilityUsers(ctx, s.tenantSvc(clientID), product, model.SystemRoleKey(q.Key), q)
}

// GetCapabilityUsersOptions returns the Detail Capability filter option lists
// (POST /roles/capabilities/users/options).
func (s *RoleService) GetCapabilityUsersOptions(ctx context.Context, clientID string, product model.Product, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersOptionsResponse, error) {
	return s.repo.GetCapabilityUsersOptions(ctx, s.tenantSvc(clientID), product, model.SystemRoleKey(q.Key), q)
}

// ListAssignableUsers returns the paginated assignable picker pool
// (POST /roles/assignable-users/list).
func (s *RoleService) ListAssignableUsers(ctx context.Context, clientID string, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersListResponse, error) {
	return s.repo.ListAssignableUsers(ctx, s.tenantSvc(clientID), product, q)
}

// GetAssignableUsersOptions returns the picker filter option lists
// (POST /roles/assignable-users/options).
func (s *RoleService) GetAssignableUsersOptions(ctx context.Context, clientID string, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersOptionsResponse, error) {
	return s.repo.GetAssignableUsersOptions(ctx, s.tenantSvc(clientID), product, q)
}

// AddCapabilityUser creates a new global capability assignment with the
// Read-locked baseline (POST /roles/capabilities/users). The insert, its
// guards, and the changelog dispatch all live in AddCapabilityUserWorkflow —
// this method only starts the workflow with a unique ID and waits for its
// result. Guard failures (403/404/400/409) round-trip unchanged from the
// activity; a workflow-level failure surfaces as 500 and the row is never
// written.
func (s *RoleService) AddCapabilityUser(ctx context.Context, clientID string, product model.Product, actorID, userID int64, actorFullName string, body dto.CapabilityUserAddBody) error {
	if s.temporalSvc == nil {
		return coreEntity.InternalServerError("role write path is not configured")
	}
	coreDb.InitSnowflake()
	httpErr := temporal_helper.ExecuteWorkflowWithContext[any](ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowAddCapabilityUser,
		TemporalService: s.temporalSvc,
		Param: workflow.AddCapabilityUserWorkflowParam{
			ClientID:                    clientID,
			Product:                     product,
			ActorID:                     actorID,
			ActorFullName:               actorFullName,
			UserID:                      userID,
			Key:                         model.SystemRoleKey(body.Key),
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, nil, client.StartWorkflowOptions{
		ID: fmt.Sprintf("role-add-capability-user-%s-%d-%d", clientID, userID, coreDb.Node.Generate().Int64()),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return httpErr
	}
	return nil
}

// PatchCapabilityUser updates the C/U/D checkboxes of one capability
// assignment (PATCH /roles/capabilities/users/:user_id). Like the ADD
// endpoint, the guards, the write (including the auto-revert tier delete), and
// the changelog dispatch live in PatchCapabilityUserWorkflow; this method only
// starts the workflow with a unique ID and waits for its result.
func (s *RoleService) PatchCapabilityUser(ctx context.Context, clientID string, product model.Product, userID, actorID int64, actorFullName string, roles tsMiddleware.UserAccessCache, body dto.CapabilityUserPatchBody) (*dto.PatchCapabilityUserResult, error) {
	if s.temporalSvc == nil {
		return nil, coreEntity.InternalServerError("role write path is not configured")
	}
	coreDb.InitSnowflake()
	result := &workflow.PatchCapabilityUserWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowPatchCapabilityUser,
		TemporalService: s.temporalSvc,
		Param: workflow.PatchCapabilityUserWorkflowParam{
			ClientID:                    clientID,
			Product:                     product,
			UserID:                      userID,
			ActorID:                     actorID,
			ActorFullName:               actorFullName,
			Key:                         model.SystemRoleKey(body.Key),
			Roles:                       roles,
			Permission:                  body.Permission,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("role-patch-capability-user-%s-%d-%d", clientID, userID, coreDb.Node.Generate().Int64()),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return nil, httpErr
	}
	return &dto.PatchCapabilityUserResult{AccessLevelAutoReverted: result.AccessLevelAutoReverted}, nil
}

// DeleteCapabilityUsers hard-deletes one capability assignment per requested
// user (DELETE /roles/capabilities/users) — the row action sends one ID, the
// bulk action sends many. The per-row guards, the per-row transactions
// (including the auto-revert tier delete), and the changelog dispatch all live
// in RemoveCapabilityUsersWorkflow; this method only starts the workflow with
// a unique ID and waits for its result. Guard failures (403/404/400/409)
// round-trip unchanged from the activity; the failedUserIds partial-success
// list is returned for the handler to render.
func (s *RoleService) DeleteCapabilityUsers(ctx context.Context, clientID string, product model.Product, actorID int64, actorFullName string, roles tsMiddleware.UserAccessCache, key model.SystemRoleKey, userIDs []int64) (*dto.CapabilityUsersDeleteResult, error) {
	if s.temporalSvc == nil {
		return nil, coreEntity.InternalServerError("role write path is not configured")
	}
	coreDb.InitSnowflake()
	result := &workflow.RemoveCapabilityUsersWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowRemoveCapabilityUsers,
		TemporalService: s.temporalSvc,
		Param: workflow.RemoveCapabilityUsersWorkflowParam{
			ClientID:                    clientID,
			Product:                     product,
			ActorID:                     actorID,
			ActorFullName:               actorFullName,
			Key:                         key,
			UserIDs:                     userIDs,
			Roles:                       roles,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("role-remove-capability-users-%s-%d", clientID, coreDb.Node.Generate().Int64()),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return nil, httpErr
	}
	failed := make([]string, 0, len(result.FailedUserIDs))
	for _, id := range result.FailedUserIDs {
		failed = append(failed, strconv.FormatInt(id, 10))
	}
	return &dto.CapabilityUsersDeleteResult{FailedUserIDs: failed}, nil
}

// AssignAccessLevel assigns a Total Control / Read Only access level to a user
// (POST /roles/access-level), bulk-writing the six capability rows to match
// the tier pattern. The guards, the single-transaction write, and the
// changelog dispatch all live in AssignAccessLevelWorkflow — this method only
// starts the workflow with a unique ID and waits for its result.
func (s *RoleService) AssignAccessLevel(ctx context.Context, clientID string, product model.Product, actorID, userID int64, actorFullName string, accessLevel model.AccessLevel) error {
	if s.temporalSvc == nil {
		return coreEntity.InternalServerError("role write path is not configured")
	}
	coreDb.InitSnowflake()
	httpErr := temporal_helper.ExecuteWorkflowWithContext[any](ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowAssignAccessLevel,
		TemporalService: s.temporalSvc,
		Param: workflow.AssignAccessLevelWorkflowParam{
			ClientID:                    clientID,
			Product:                     product,
			ActorID:                     actorID,
			ActorFullName:               actorFullName,
			UserID:                      userID,
			AccessLevel:                 accessLevel,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, nil, client.StartWorkflowOptions{
		ID: fmt.Sprintf("role-assign-access-level-%s-%d-%d", clientID, userID, coreDb.Node.Generate().Int64()),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return httpErr
	}
	return nil
}

// RemoveAccessLevel removes the access level from one or more users
// (DELETE /roles/access-level): the tier row is deleted and every capability
// row the user holds for the product is hard-deleted too (PRD F-ROLE-05 —
// "user basic", no access assigned), each user in its own transaction. The
// guards and the changelog dispatch live in RemoveAccessLevelWorkflow — this
// method only starts the workflow with a unique ID and waits for its result.
func (s *RoleService) RemoveAccessLevel(ctx context.Context, clientID string, product model.Product, actorID int64, actorFullName string, userIDs []int64, accessLevel model.AccessLevel) error {
	if s.temporalSvc == nil {
		return coreEntity.InternalServerError("role write path is not configured")
	}
	coreDb.InitSnowflake()
	httpErr := temporal_helper.ExecuteWorkflowWithContext[any](ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowRemoveAccessLevel,
		TemporalService: s.temporalSvc,
		Param: workflow.RemoveAccessLevelWorkflowParam{
			ClientID:                    clientID,
			Product:                     product,
			ActorID:                     actorID,
			ActorFullName:               actorFullName,
			UserIDs:                     userIDs,
			AccessLevel:                 accessLevel,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, nil, client.StartWorkflowOptions{
		ID: fmt.Sprintf("role-remove-access-level-%s-%d", clientID, coreDb.Node.Generate().Int64()),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return httpErr
	}
	return nil
}
