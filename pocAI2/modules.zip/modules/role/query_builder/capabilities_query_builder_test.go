package query_builder

import (
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func mustBuildCapabilities(t *testing.T, product model.Product, q dto.CapabilitiesListQuery) (string, []any) {
	t.Helper()
	query, args, err := CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](product, q)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	return query, args
}

func TestCapabilitiesListQueryBuilderDefault(t *testing.T) {
	query, args := mustBuildCapabilities(t, model.ProductGlobalSettings, dto.CapabilitiesListQuery{SortOrder: 1})

	for _, want := range []string{
		"manage_user_and_role", "Manage user and role",
		"manage_master_reference", "Manage master reference",
		"manage_hardware", "Manage hardware",
		"import_data", "Import data",
		"manage_files", "Manage files",
		"manage_tag", "Manage TAG",
	} {
		if !strings.Contains(query, want) {
			t.Errorf("query misses catalog entry %q", want)
		}
	}

	for _, want := range []string{
		"counts AS (",
		"COUNT(*)::int AS total_users",
		"t1 AS (",
		"LEFT JOIN counts ON counts.key = capabilities.key",
		"tend AS (",
		"filtered_ids AS (",
		"totalRecords",
		"total_users",
	} {
		if !strings.Contains(query, want) {
			t.Errorf("query misses %q:\n%s", want, query)
		}
	}

	if !strings.Contains(query, `"user_system_roles"."product" = $`) {
		t.Errorf("query misses product filter:\n%s", query)
	}
	if !strings.Contains(query, `"user_system_roles"."permission_view" = $`) {
		t.Errorf("query misses permission_view filter:\n%s", query)
	}
	if !strings.Contains(query, `"users"."deleted_at" IS NULL`) {
		t.Errorf("query misses deleted_at join filter:\n%s", query)
	}

	if !strings.Contains(query, `ORDER BY tend.name ASC`) {
		t.Errorf("query misses name sort:\n%s", query)
	}

	if !containsArg(args, model.ProductGlobalSettings) || !containsArg(args, true) {
		t.Errorf("args = %v, want product %q and true", args, model.ProductGlobalSettings)
	}
}

func TestCapabilitiesListQueryBuilderSortByTotalUsersDesc(t *testing.T) {
	query, _ := mustBuildCapabilities(t, model.ProductGlobalSettings, dto.CapabilitiesListQuery{
		SortBy:    "totalUsers",
		SortOrder: -1,
	})
	if !strings.Contains(query, "tend.total_users DESC") {
		t.Errorf("query misses totalUsers DESC sort:\n%s", query)
	}
}

func TestCapabilitiesExportQueryBuilderIsUnpaginated(t *testing.T) {
	query, _, err := CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](model.ProductGlobalSettings, dto.CapabilitiesListQuery{
		SortBy:    "totalUsers",
		SortOrder: -1,
	}, false)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	for _, forbidden := range []string{"filtered_ids AS", "totalRecords", "LIMIT ", "OFFSET "} {
		if strings.Contains(query, forbidden) {
			t.Errorf("export query must not contain %q:\n%s", forbidden, query)
		}
	}
	if !strings.Contains(query, "ORDER BY tend.total_users DESC") {
		t.Errorf("export query misses sort:\n%s", query)
	}
}

func TestCapabilitiesListQueryBuilderSearch(t *testing.T) {
	query, args := mustBuildCapabilities(t, model.ProductGlobalSettings, dto.CapabilitiesListQuery{
		Search: "5",
	})
	if !strings.Contains(query, "tend.name ILIKE $") {
		t.Errorf("query misses name search:\n%s", query)
	}
	if !strings.Contains(query, "tend.total_users::text ILIKE $") {
		t.Errorf("query misses total_users search:\n%s", query)
	}
	if !containsArg(args, "%5%") {
		t.Errorf("args = %v, want search pattern %%5%%", args)
	}
}

func TestCapabilitiesListQueryBuilderUnknownSortBy(t *testing.T) {
	_, _, err := CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](model.ProductGlobalSettings, dto.CapabilitiesListQuery{
		SortBy: "bogus",
	})
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok {
		t.Fatalf("err = %v, want *coreEntity.HttpError", err)
	}
	if httpErr.Code != fiber.StatusBadRequest || httpErr.Message != "Unknown sort column" {
		t.Fatalf("err = %+v, want 400 Unknown sort column", httpErr)
	}
	if field := httpErr.Data.(map[string]string)["field"]; field != "sortBy" {
		t.Errorf("field = %v, want sortBy", field)
	}
}

func containsArg(args []any, want any) bool {
	for _, a := range args {
		if a == want {
			return true
		}
	}
	return false
}
