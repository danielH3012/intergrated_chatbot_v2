package query_builder

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query/common_builders"
)

// capabilityUsersSortableColumns maps the spec sortable Detail Capability
// columns onto tend expressions. The CRUD checkbox columns are interactive
// controls, not sortable data, and there is no Status / Modified By / Last
// Updated column on this page.
var capabilityUsersSortableColumns = map[string]string{
	"fullName":            `tend.full_name`,
	"position":            `tend.position`,
	"division":            `tend.division`,
	"activationStatus":    `tend.activation_status`,
	"temporaryStatus":     `tend.temporary_status`,
	"activePeriodUntil":   `tend.active_period_until`,
	"tagCode":             `tend.tag_code`,
	"authenticatorStatus": `tend.authenticator_status`,
}

// capabilityUsersSearchableColumns mirrors the access-level search scope minus
// the columns this page does not have (no Modified By, no Status).
var capabilityUsersSearchableColumns = map[string]string{
	"fullName":            "tend.full_name",
	"pendingEmail":        "tend.pending_email",
	"position":            "tend.position",
	"division":            "tend.division",
	"tagCode":             "tend.tag_code",
	"temporaryStatus":     "tend.temporary_status",
	"authenticatorStatus": "tend.authenticator_status",
}

var defaultCapabilityUsersSearchableColumns = []string{
	"tend.full_name",
	"tend.pending_email",
	"tend.position",
	"tend.division",
	"tend.tag_code",
	"tend.temporary_status",
	"tend.authenticator_status",
}

// CapabilityUsersCommonQueryBuilder returns the shared t1 → tend two-tier CTE
// statement both the list and options builders consume: users holding a
// user_system_roles row for (product, key, global scope), joined to every
// column the Detail Capability table and its filter dropdowns need. The CRUD
// permission tuple is projected as plain t1 columns; the outer struct re-nests
// them into the permission object.
func CapabilityUsersCommonQueryBuilder[T any](product model.Product, key model.SystemRoleKey) (*sql_query.SelectBuilder, error) {
	t1 := sql_query.NewSQLSelectBuilder[any](db.UserSystemRoleTableName).
		Select(
			"users.id",
			"users.full_name",
			"users.profile_picture",
			"users.tag_code",
			"COALESCE(users.is_default, FALSE) AS is_default",
			"CASE WHEN COALESCE(users.is_temporary, FALSE) THEN 'Yes' ELSE 'No' END AS temporary_status",
			"users.active_period_until::timestamptz AS active_period_until",
			"users.activation_status",
			`CASE WHEN users.activation_status = 'Activated' AND EXISTS(SELECT 1 FROM public.user_email_changes uec WHERE uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL) THEN 'Pending Email Confirmation' ELSE users.activation_status END AS activation_status_display`,
			"positions.name AS position",
			"divisions.name AS division",
			"user_system_roles.permission_view",
			"user_system_roles.permission_create",
			"user_system_roles.permission_update",
			"user_system_roles.permission_delete",
			`(SELECT new_email FROM public.user_email_changes uec WHERE uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL) AS pending_email`,
			`CASE WHEN EXISTS(SELECT 1 FROM public.authenticator_enrollments ae WHERE ae.user_id = users.id AND ae.is_active) THEN 'Enrolled' ELSE 'Not Enrolled' END AS authenticator_status`,
		).
		Join(
			db.UserTableName,
			"users.id = user_system_roles.user_id",
			sql_query.WhereQuery{
				"users.deleted_at": {Operator: sql_query.SQLOperatorIsNull},
			},
		).
		LeftJoin(db.PositionTableName, "positions.id = users.position_id").
		LeftJoin(db.DivisionTableName, "divisions.id = users.division_id").
		Where(sql_query.WhereQuery{
			"user_system_roles.product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_system_roles.key":         {Operator: sql_query.SQLOperatorEqual, Value: key},
			"user_system_roles.scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
		}).(*sql_query.SelectBuilder)

	tend := sql_query.NewSQLSelectBuilder[any]("t1").
		Select("t1.*").(*sql_query.SelectBuilder)

	builder := sql_query.NewSQLSelectBuilder[T]("tend").
		WithCTEBuilder("t1", t1.SQLEloquentQuery).
		WithCTEBuilder("tend", tend.SQLEloquentQuery).(*sql_query.SelectBuilder)

	return builder, nil
}

// applyCapabilityUsersFilters applies the Detail Capability filter set to a
// tend-level builder and validates every filter enum — an unknown value is a
// 400 before any SQL runs (spec: filter value sets are validated server-side).
func applyCapabilityUsersFilters(builder *sql_query.SelectBuilder, q dto.CapabilityUsersListQuery) error {
	filters := sql_query.WhereQuery{}
	if len(q.Position) > 0 {
		filters["tend.position"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Position}
	}
	if len(q.Division) > 0 {
		filters["tend.division"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Division}
	}
	if len(q.TemporaryStatus) > 0 {
		for _, v := range q.TemporaryStatus {
			if v != "Yes" && v != "No" {
				return &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown temporary status",
					Data:    map[string]string{"field": "temporaryStatus"},
				}
			}
		}
		filters["tend.temporary_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.TemporaryStatus}
	}
	if len(q.AuthenticatorStatus) > 0 {
		for _, v := range q.AuthenticatorStatus {
			if v != "Enrolled" && v != "Not Enrolled" {
				return &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown authenticator status",
					Data:    map[string]string{"field": "authenticatorStatus"},
				}
			}
		}
		filters["tend.authenticator_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.AuthenticatorStatus}
	}
	if len(q.ActivePeriodUntil) > 0 {
		filters["tend.active_period_until"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorBetween, Value: q.ActivePeriodUntil, IsEpochTime: true}
	}
	builder.Where(filters)

	// The three display values map onto two DB values plus the pending-email
	// sub-state, so this filter is an OR-group instead of a plain IN.
	if len(q.ActivationStatus) > 0 {
		var ors []sql_query.WhereQuery
		for _, v := range q.ActivationStatus {
			switch v {
			case dto.ActivationPendingActivation:
				ors = append(ors, sql_query.WhereQuery{
					"tend.activation_status": {Operator: sql_query.SQLOperatorEqual, Value: dto.ActivationPendingActivation},
				})
			case dto.ActivationActivated:
				ors = append(ors, sql_query.WhereQuery{
					"tend.activation_status": {Operator: sql_query.SQLOperatorEqual, Value: dto.ActivationActivated},
					"tend.pending_email":     {Operator: sql_query.SQLOperatorIsNull},
				})
			case dto.ActivationPendingEmail:
				ors = append(ors, sql_query.WhereQuery{
					"tend.activation_status": {Operator: sql_query.SQLOperatorEqual, Value: dto.ActivationActivated},
					"tend.pending_email":     {Operator: sql_query.SQLOperatorIsNotNull},
				})
			default:
				return &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown activation status",
					Data:    map[string]string{"field": "activationStatus"},
				}
			}
		}
		builder.WhereOr(ors...)
	}

	return nil
}

// CapabilityUsersListQueryBuilder assembles the single paginated Detail
// Capability statement: the shared CTEs + filters + search + the list-only
// sort, wrapped by Paginate's data/totalRecords envelope. Sort columns are
// validated here — unknown is a 400 before any SQL runs.
func CapabilityUsersListQueryBuilder[T any](product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery, paginate ...bool) (string, []any, error) {
	sortBy := capabilityUsersSortableColumns["fullName"]
	if q.SortBy != "" && q.SortBy != "fullName" {
		expr, ok := capabilityUsersSortableColumns[q.SortBy]
		if !ok {
			return "", nil, &coreEntity.HttpError{
				Code:    fiber.StatusBadRequest,
				Message: "Unknown sort column",
				Data:    map[string]string{"field": "sortBy"},
			}
		}
		sortBy = expr
	}

	builder, err := CapabilityUsersCommonQueryBuilder[T](product, key)
	if err != nil {
		return "", nil, err
	}
	if err := applyCapabilityUsersFilters(builder, q); err != nil {
		return "", nil, err
	}

	searchFields := []string{}
	if q.Columns != nil {
		for _, col := range q.Columns {
			if expr, ok := capabilityUsersSearchableColumns[col]; ok {
				searchFields = append(searchFields, expr)
			}
		}
	}
	if len(searchFields) == 0 {
		searchFields = defaultCapabilityUsersSearchableColumns
	}
	builder.Search(q.Search, searchFields)

	usePagination := true
	if len(paginate) > 0 {
		usePagination = paginate[0]
	}
	if usePagination {
		builder.Paginate(sql_query.Pagination{
			Page:      q.Page,
			Limit:     q.Limit,
			SortBy:    sortBy,
			SortOrder: q.SortOrder,
		})
	} else if q.SortOrder != 0 {
		builder.OrderBy([]string{sortBy}, q.SortOrder > 0)
	}

	return builder.Build()
}

// CapabilityUsersOptionsQueryBuilder emits one statement carrying all five
// Detail Capability option lists, computed over the whole (product, key) pool
// — the options body carries no filters, so the dropdowns are not narrowed.
func CapabilityUsersOptionsQueryBuilder[T any](product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (string, []any, error) {
	main, err := CapabilityUsersCommonQueryBuilder[T](product, key)
	if err != nil {
		return "", nil, err
	}

	positionSource, err := CapabilityUsersCommonQueryBuilder[any](product, key)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		positionSource,
		main,
		"positionOptions",
		"tend",
		q.PositionOptions,
		"tend.position",
		"tend.position",
		sql_query.Sort{SortBy: "tend.position", SortOrder: 1},
	)

	divisionSource, err := CapabilityUsersCommonQueryBuilder[any](product, key)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		divisionSource,
		main,
		"divisionOptions",
		"tend",
		q.DivisionOptions,
		"tend.division",
		"tend.division",
		sql_query.Sort{SortBy: "tend.division", SortOrder: 1},
	)

	activationStatusSource, err := CapabilityUsersCommonQueryBuilder[any](product, key)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		activationStatusSource,
		main,
		"activationStatusOptions",
		"tend",
		q.ActivationStatusOptions,
		"tend.activation_status_display",
		"tend.activation_status_display",
		sql_query.Sort{SortBy: "tend.activation_status_display", SortOrder: 1},
	)

	temporaryStatusSource, err := CapabilityUsersCommonQueryBuilder[any](product, key)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		temporaryStatusSource,
		main,
		"temporaryStatusOptions",
		"tend",
		q.TemporaryStatusOptions,
		"tend.temporary_status",
		"tend.temporary_status",
		sql_query.Sort{SortBy: "tend.temporary_status", SortOrder: 1},
	)

	authenticatorStatusSource, err := CapabilityUsersCommonQueryBuilder[any](product, key)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		authenticatorStatusSource,
		main,
		"authenticatorStatusOptions",
		"tend",
		q.AuthenticatorStatusOptions,
		"tend.authenticator_status",
		"tend.authenticator_status",
		sql_query.Sort{SortBy: "tend.authenticator_status", SortOrder: 1},
	)

	return main.Build()
}
