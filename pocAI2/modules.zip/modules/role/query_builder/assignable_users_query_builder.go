package query_builder

import (
	"fmt"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query/common_builders"
)

// AssignableUsersCommonQueryBuilder returns the shared t1 → tend two-tier CTE
// statement both the picker list and its options consume. The base pool is the
// access gate — user_module_status active for the path product — ANDed with
// user status active/pending activation. excludeTier / excludeKey only narrow
// that pool, never widen it; both exclusions land in t1 where `users` lives.
func AssignableUsersCommonQueryBuilder[T any](product model.Product, q dto.AssignableUsersListQuery) (*sql_query.SelectBuilder, error) {
	t1 := sql_query.NewSQLSelectBuilder[any](db.UserTableName).
		Select(
			"users.id",
			"users.full_name",
			"users.profile_picture",
			"users.email",
			"users.employee_id",
			"users.tag_code",
			"users.activation_status",
			"CASE WHEN COALESCE(users.is_temporary, FALSE) THEN 'Yes' ELSE 'No' END AS temporary_status",
			"users.active_period_until::timestamptz AS active_period_until",
			"user_module_status.is_active",
			"CASE WHEN user_module_status.is_active THEN 'Active' ELSE 'Inactive' END AS status",
			"positions.name AS position",
			"divisions.name AS division",
		).
		Join(
			db.UserModuleStatusTableName,
			"user_module_status.user_id = users.id",
			sql_query.WhereQuery{
				"user_module_status.module_key": {Operator: sql_query.SQLOperatorEqual, Value: product},
				"user_module_status.is_active":  {Operator: sql_query.SQLOperatorEqual, Value: true},
			},
		).
		LeftJoin(db.PositionTableName, "positions.id = users.position_id").
		LeftJoin(db.DivisionTableName, "divisions.id = users.division_id").
		Where(sql_query.WhereQuery{
			"users.deleted_at": {Operator: sql_query.SQLOperatorIsNull},
		}).(*sql_query.SelectBuilder)

	// Base state gate: Pending Activation users are still assignable, so the
	// pool keeps both DB values.
	t1.Where(sql_query.WhereQuery{
		"users.activation_status": {
			Operator: sql_query.SQLOperatorIn,
			Value:    []string{dto.ActivationPendingActivation, dto.ActivationActivated},
		},
	})

	if err := applyAssignableExclusions(t1, product, q); err != nil {
		return nil, err
	}

	tend := sql_query.NewSQLSelectBuilder[any]("t1").
		Select("t1.*").(*sql_query.SelectBuilder)

	builder := sql_query.NewSQLSelectBuilder[T]("tend").
		WithCTEBuilder("t1", t1.SQLEloquentQuery).
		WithCTEBuilder("tend", tend.SQLEloquentQuery).(*sql_query.SelectBuilder)

	return builder, nil
}

// applyAssignableExclusions adds the NOT EXISTS guards for the tier and
// capability exclusions. Both values were enum-validated in the handler, so
// the access_level / key literals are pinned code constants, never user input.
func applyAssignableExclusions(builder *sql_query.SelectBuilder, product model.Product, q dto.AssignableUsersListQuery) error {
	var tierValues []string
	switch q.ExcludeTier {
	case "", dto.ExcludeTierTotalControl:
		tierValues = []string{string(model.AccessLevelTotalControl)}
	case dto.ExcludeTierReadOnly:
		tierValues = []string{string(model.AccessLevelReadOnly)}
	case dto.ExcludeTierBoth:
		tierValues = []string{string(model.AccessLevelTotalControl), string(model.AccessLevelReadOnly)}
	case dto.ExcludeTierNone:
		tierValues = nil
	default:
		return &coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown exclude tier",
			Data:    map[string]string{"field": "excludeTier"},
		}
	}

	filters := sql_query.WhereQuery{}
	if len(tierValues) > 0 {
		levels := ""
		for i, v := range tierValues {
			if i > 0 {
				levels += ", "
			}
			levels += fmt.Sprintf("'%s'", v)
		}
		filters["tier_exclusion"] = sql_query.SQLCondition{
			Operator: sql_query.SQLOperatorRaw,
			Value: fmt.Sprintf(
				"NOT EXISTS (SELECT 1 FROM %s ual WHERE ual.user_id = users.id AND ual.product = ? AND ual.access_level IN (%s))",
				db.UserAccessLevelTableName, levels,
			),
			ExtraArgs: []any{product},
		}
	}
	if q.ExcludeKey != "" {
		filters["key_exclusion"] = sql_query.SQLCondition{
			Operator: sql_query.SQLOperatorRaw,
			Value: fmt.Sprintf(
				"NOT EXISTS (SELECT 1 FROM %s usr WHERE usr.user_id = users.id AND usr.product = ? AND usr.key = '%s')",
				db.UserSystemRoleTableName, q.ExcludeKey,
			),
			ExtraArgs: []any{product},
		}
	}

	if len(filters) > 0 {
		builder.Where(filters)
	}
	return nil
}

// AssignableUsersListQueryBuilder assembles the paginated picker statement.
// The picker carries no sortBy — the sort is fixed to fullName ascending.
func AssignableUsersListQueryBuilder[T any](product model.Product, q dto.AssignableUsersListQuery) (string, []any, error) {
	builder, err := AssignableUsersCommonQueryBuilder[T](product, q)
	if err != nil {
		return "", nil, err
	}

	filters := sql_query.WhereQuery{}
	if len(q.Position) > 0 {
		filters["tend.position"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Position}
	}
	if len(q.Division) > 0 {
		filters["tend.division"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Division}
	}
	if len(q.Status) > 0 {
		for _, v := range q.Status {
			if v != dto.StatusActive && v != dto.StatusInactive {
				return "", nil, &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown status",
					Data:    map[string]string{"field": "status"},
				}
			}
		}
		filters["tend.status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Status}
	}
	if len(q.ActivationStatus) > 0 {
		for _, v := range q.ActivationStatus {
			if v != dto.ActivationPendingActivation && v != dto.ActivationActivated {
				return "", nil, &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown activation status",
					Data:    map[string]string{"field": "activationStatus"},
				}
			}
		}
		filters["tend.activation_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.ActivationStatus}
	}
	if len(q.TemporaryStatus) > 0 {
		for _, v := range q.TemporaryStatus {
			if v != "Yes" && v != "No" {
				return "", nil, &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown temporary status",
					Data:    map[string]string{"field": "temporaryStatus"},
				}
			}
		}
		filters["tend.temporary_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.TemporaryStatus}
	}
	if len(q.ActivePeriodUntil) > 0 {
		filters["tend.active_period_until"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorBetween, Value: q.ActivePeriodUntil, IsEpochTime: true}
	}
	builder.Where(filters)

	builder.Search(q.Search, []string{
		"tend.full_name",
		"tend.email",
		"tend.position",
		"tend.division",
	})

	builder.Paginate(sql_query.Pagination{
		Page:      q.Page,
		Limit:     q.Limit,
		SortBy:    "tend.full_name",
		SortOrder: 1,
	})

	return builder.Build()
}

// AssignableUsersOptionsQueryBuilder emits one statement carrying the three
// picker option lists, computed over the same gated and excluded pool as the
// paired list call.
func AssignableUsersOptionsQueryBuilder[T any](product model.Product, q dto.AssignableUsersListQuery) (string, []any, error) {
	main, err := AssignableUsersCommonQueryBuilder[T](product, q)
	if err != nil {
		return "", nil, err
	}

	positionSource, err := AssignableUsersCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		positionSource,
		main,
		"positionOptions",
		"tend",
		q.PositionOptions,
		"tend.position",
		"tend.position",
		sql_query.Sort{SortBy: "tend.position", SortOrder: 1},
	)

	divisionSource, err := AssignableUsersCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		divisionSource,
		main,
		"divisionOptions",
		"tend",
		q.DivisionOptions,
		"tend.division",
		"tend.division",
		sql_query.Sort{SortBy: "tend.division", SortOrder: 1},
	)

	statusSource, err := AssignableUsersCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		statusSource,
		main,
		"statusOptions",
		"tend",
		q.StatusOptions,
		"tend.status",
		"tend.status",
		sql_query.Sort{SortBy: "tend.status", SortOrder: 1},
	)

	activationStatusSource, err := AssignableUsersCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		activationStatusSource,
		main,
		"activationStatusOptions",
		"tend",
		q.ActivationStatusOptions,
		"tend.activation_status",
		"tend.activation_status",
		sql_query.Sort{SortBy: "tend.activation_status", SortOrder: 1},
	)

	temporaryStatusSource, err := AssignableUsersCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		temporaryStatusSource,
		main,
		"temporaryStatusOptions",
		"tend",
		q.TemporaryStatusOptions,
		"tend.temporary_status",
		"tend.temporary_status",
		sql_query.Sort{SortBy: "tend.temporary_status", SortOrder: 1},
	)

	return main.Build()
}
