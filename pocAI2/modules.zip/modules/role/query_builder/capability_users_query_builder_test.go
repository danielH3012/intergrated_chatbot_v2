package query_builder

import (
	"reflect"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func mustBuildCapabilityUsers(t *testing.T, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (string, []any) {
	t.Helper()
	query, args, err := CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](product, key, q)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	return query, args
}

func TestCapabilityUsersListQueryBuilderDefault(t *testing.T) {
	query, args := mustBuildCapabilityUsers(t, model.ProductGlobalSettings, model.SystemRoleKeyManageUserAndRole, dto.CapabilityUsersListQuery{SortOrder: 1})

	for _, want := range []string{
		`"user_system_roles"."product" = $`,
		`"user_system_roles"."key" = $`,
		`"user_system_roles"."scope_level" = $`,
		`"users"."deleted_at" IS NULL`,
		`user_system_roles.permission_view`,
		`user_system_roles.permission_create`,
		`permission`,
		`jsonb_build_object`,
		`'create', "tend"."permission_create"`,
		`'read', "tend"."permission_view"`,
		`tend AS (`,
		`filtered_ids AS (`,
		`totalRecords`,
	} {
		if !strings.Contains(query, want) {
			t.Errorf("query misses %q:\n%s", want, query)
		}
	}
	if !strings.Contains(query, `ORDER BY tend.full_name ASC`) {
		t.Errorf("query misses default fullName sort:\n%s", query)
	}
	if !containsArg(args, model.ProductGlobalSettings) || !containsArg(args, model.SystemRoleKeyManageUserAndRole) {
		t.Errorf("args = %v, want product and key", args)
	}
}

func TestCapabilityUsersListQueryBuilderSortAndFilters(t *testing.T) {
	query, args := mustBuildCapabilityUsers(t, model.ProductGlobalSettings, model.SystemRoleKeyManageTAG, dto.CapabilityUsersListQuery{
		SortBy:              "position",
		SortOrder:           -1,
		Position:            []string{"Staff"},
		ActivationStatus:    []string{dto.ActivationPendingEmail},
		TemporaryStatus:     []string{"Yes"},
		AuthenticatorStatus: []string{"Enrolled"},
	})
	if !strings.Contains(query, "tend.position DESC") {
		t.Errorf("query misses position sort:\n%s", query)
	}
	if !strings.Contains(query, `"tend"."pending_email" IS NOT NULL`) {
		t.Errorf("query misses pending-email OR branch:\n%s", query)
	}
	if !strings.Contains(query, `"tend"."temporary_status" = ANY($`) || !strings.Contains(query, `"tend"."authenticator_status" = ANY($`) {
		t.Errorf("query misses ANY filters:\n%s", query)
	}
	if !containsSliceArg(args, []string{"Staff"}) || !containsSliceArg(args, []string{"Yes"}) || !containsSliceArg(args, []string{"Enrolled"}) {
		t.Errorf("args = %v", args)
	}
}

func TestCapabilityUsersExportQueryBuilderIsUnpaginated(t *testing.T) {
	query, _, err := CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](model.ProductGlobalSettings, model.SystemRoleKeyManageUserAndRole, dto.CapabilityUsersListQuery{
		SortBy:    "position",
		SortOrder: -1,
	}, false)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	for _, forbidden := range []string{"filtered_ids AS", "totalRecords", "LIMIT ", "OFFSET "} {
		if strings.Contains(query, forbidden) {
			t.Errorf("export query must not contain %q:\n%s", forbidden, query)
		}
	}
	if !strings.Contains(query, "ORDER BY tend.position DESC") {
		t.Errorf("export query misses sort:\n%s", query)
	}
}

func containsSliceArg(args []any, want any) bool {
	for _, a := range args {
		if reflect.DeepEqual(a, want) {
			return true
		}
	}
	return false
}

func TestCapabilityUsersListQueryBuilderUnknownSortBy(t *testing.T) {
	_, _, err := CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](model.ProductGlobalSettings, model.SystemRoleKeyManageUserAndRole, dto.CapabilityUsersListQuery{
		SortBy: "bogus",
	})
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != fiber.StatusBadRequest || httpErr.Message != "Unknown sort column" {
		t.Fatalf("err = %+v, want 400 Unknown sort column", err)
	}
}

func TestCapabilityUsersListQueryBuilderUnknownActivationStatus(t *testing.T) {
	_, _, err := CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](model.ProductGlobalSettings, model.SystemRoleKeyManageUserAndRole, dto.CapabilityUsersListQuery{
		ActivationStatus: []string{"bogus"},
	})
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != fiber.StatusBadRequest || httpErr.Message != "Unknown activation status" {
		t.Fatalf("err = %+v, want 400 Unknown activation status", err)
	}
}

func TestCapabilityUsersOptionsQueryBuilder(t *testing.T) {
	query, _, err := CapabilityUsersOptionsQueryBuilder[any](model.ProductGlobalSettings, model.SystemRoleKeyManageUserAndRole, dto.CapabilityUsersListQuery{
		PositionOptions:            true,
		DivisionOptions:            true,
		ActivationStatusOptions:    true,
		TemporaryStatusOptions:     true,
		AuthenticatorStatusOptions: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	for _, want := range []string{
		`position_options AS (`,
		`division_options AS (`,
		`activation_status_options AS (`,
		`temporary_status_options AS (`,
		`authenticator_status_options AS (`,
		`"tend"."activation_status_display"`,
	} {
		if !strings.Contains(query, want) {
			t.Errorf("query misses %q", want)
		}
	}
}

func TestAssignableUsersListQueryBuilderDefault(t *testing.T) {
	query, args := mustBuildAssignable(t, model.ProductGlobalSettings, dto.AssignableUsersListQuery{})

	for _, want := range []string{
		`"user_module_status"."module_key" = $`,
		`"user_module_status"."is_active" = $`,
		`"users"."activation_status" IN ($`,
		`NOT EXISTS (SELECT 1 FROM user_access_levels ual`,
		`access_level IN ('total_control')`,
		`tend AS (`,
		`filtered_ids AS (`,
		`ORDER BY tend.full_name ASC`,
	} {
		if !strings.Contains(query, want) {
			t.Errorf("query misses %q:\n%s", want, query)
		}
	}
	if !containsArg(args, model.ProductGlobalSettings) {
		t.Errorf("args = %v, want product", args)
	}
}

func TestAssignableUsersListQueryBuilderExclusions(t *testing.T) {
	both, _, err := AssignableUsersListQueryBuilder[any](model.ProductGlobalSettings, dto.AssignableUsersListQuery{
		ExcludeTier: dto.ExcludeTierBoth,
		ExcludeKey:  string(model.SystemRoleKeyManageTAG),
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !strings.Contains(both, `access_level IN ('total_control', 'read_only')`) {
		t.Errorf("both exclusion misses the two tiers:\n%s", both)
	}
	if !strings.Contains(both, `NOT EXISTS (SELECT 1 FROM user_system_roles usr`) {
		t.Errorf("key exclusion missing:\n%s", both)
	}
	if !strings.Contains(both, `usr.key = 'manage_tag'`) {
		t.Errorf("key exclusion misses the key:\n%s", both)
	}

	none, _, err := AssignableUsersListQueryBuilder[any](model.ProductGlobalSettings, dto.AssignableUsersListQuery{
		ExcludeTier: dto.ExcludeTierNone,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if strings.Contains(none, "NOT EXISTS") {
		t.Errorf("excludeTier=none must not add exclusions:\n%s", none)
	}
}

func mustBuildAssignable(t *testing.T, product model.Product, q dto.AssignableUsersListQuery) (string, []any) {
	t.Helper()
	query, args, err := AssignableUsersListQueryBuilder[dto.AssignableUsersListItem](product, q)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	return query, args
}

func TestAssignableUsersListQueryBuilderUnknownExcludeTier(t *testing.T) {
	_, _, err := AssignableUsersListQueryBuilder[any](model.ProductGlobalSettings, dto.AssignableUsersListQuery{
		ExcludeTier: "bogus",
	})
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != fiber.StatusBadRequest || httpErr.Message != "Unknown exclude tier" {
		t.Fatalf("err = %+v, want 400 Unknown exclude tier", err)
	}
}

func TestAssignableUsersListQueryBuilderUnknownStatus(t *testing.T) {
	_, _, err := AssignableUsersListQueryBuilder[any](model.ProductGlobalSettings, dto.AssignableUsersListQuery{
		Status: []string{"bogus"},
	})
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != fiber.StatusBadRequest || httpErr.Message != "Unknown status" {
		t.Fatalf("err = %+v, want 400 Unknown status", err)
	}
}

func TestAssignableUsersOptionsQueryBuilder(t *testing.T) {
	query, _, err := AssignableUsersOptionsQueryBuilder[any](model.ProductGlobalSettings, dto.AssignableUsersListQuery{
		PositionOptions: true,
		DivisionOptions: true,
		StatusOptions:   true,
		ExcludeTier:     dto.ExcludeTierTotalControl,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	for _, want := range []string{
		`position_options AS (`,
		`division_options AS (`,
		`status_options AS (`,
		`"tend"."status"`,
	} {
		if !strings.Contains(query, want) {
			t.Errorf("query misses %q", want)
		}
	}
}
