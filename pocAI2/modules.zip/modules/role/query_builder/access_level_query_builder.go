package query_builder

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query/common_builders"
)

var sortableColumns = map[string]string{
	"fullName":            `tend.full_name`,
	"position":            `tend.position`,
	"division":            `tend.division`,
	"modifiedBy":          `tend.modified_by_name`,
	"updatedAt":           `tend.updated_at`,
	"isActive":            `tend.is_active`,
	"activationStatus":    `tend.activation_status`,
	"temporaryStatus":     `tend.temporary_status`,
	"activePeriodUntil":   `tend.active_period_until`,
	"tagCode":             `tend.tag_code`,
	"authenticatorStatus": `tend.authenticator_status`,
}

var searchableColumns = map[string]string{
	"fullName":            "tend.full_name",
	"pendingEmail":        "tend.pending_email",
	"position":            "tend.position",
	"division":            "tend.division",
	"modifiedBy":          "tend.modified_by_name",
	"tagCode":             "tend.tag_code",
	"temporaryStatus":     "tend.temporary_status",
	"authenticatorStatus": "tend.authenticator_status",
}

var defaultSearchableColumns = []string{
	"tend.full_name",
	"tend.pending_email",
	"tend.position",
	"tend.division",
	"tend.modified_by_name",
	"tend.tag_code",
	"tend.temporary_status",
	"tend.authenticator_status",
}

// AccessLevelCommonQueryBuilder returns the shared two-tier CTE statement
// both the list and options builders consume:
//
//	t1   = users holding the access level for the product, joined to the data
//	       every list column and option list needs. Derived display values
//	       live here as plain columns so the option builder never feeds an
//	       expression through EscapeQuoteColumns (which would mangle it).
//	tend = the terminal relation: t1 plus the access level itself as a
//	       literal column.
//
// The builder also carries the filter + search scope of q, so the options
// facets are computed over the same population the list would return.
// Filter enums are validated here: an unknown value is a 400 before any SQL
// runs.
//
// [AI-GENERATED]
func AccessLevelCommonQueryBuilder[T any](product model.Product, q dto.AccessLevelListQuery) (*sql_query.SelectBuilder, error) {
	userType := "'" + q.AccessLevel + "'::text AS user_type"

	t1 := sql_query.NewSQLSelectBuilder[any](db.UserTableName).
		Select(
			"users.id",
			"users.full_name",
			"users.profile_picture",
			"users.tag_code",
			"COALESCE(users.is_default, FALSE) AS is_default",
			"CASE WHEN COALESCE(users.is_temporary, FALSE) THEN 'Yes' ELSE 'No' END AS temporary_status",
			"users.active_period_until::timestamptz AS active_period_until",
			"users.activation_status",
			`CASE WHEN users.activation_status = 'Activated' AND EXISTS(SELECT 1 FROM public.user_email_changes uec WHERE uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL) THEN 'Pending Email Confirmation' ELSE users.activation_status END AS activation_status_display`,
			"positions.name AS position",
			"divisions.name AS division",
			"modifier.full_name AS modified_by_name",
			"user_module_status.is_active AS is_active",
			"CASE WHEN user_module_status.is_active THEN 'Active' ELSE 'Inactive' END AS status",
			"user_access_levels.updated_at",
			`(SELECT new_email FROM public.user_email_changes uec WHERE uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL) AS pending_email`,
			`CASE WHEN EXISTS(SELECT 1 FROM public.authenticator_enrollments ae WHERE ae.user_id = users.id AND ae.is_active) THEN 'Enrolled' ELSE 'Not Enrolled' END AS authenticator_status`,
		).
		Join(
			db.UserAccessLevelTableName,
			"user_access_levels.user_id = users.id",
			sql_query.WhereQuery{
				"user_access_levels.product":      {Operator: sql_query.SQLOperatorEqual, Value: product},
				"user_access_levels.access_level": {Operator: sql_query.SQLOperatorEqual, Value: q.AccessLevel},
			},
		).
		LeftJoin(
			db.UserModuleStatusTableName,
			"user_module_status.user_id = users.id",
			sql_query.WhereQuery{
				"user_module_status.module_key": {Operator: sql_query.SQLOperatorEqual, Value: product},
			},
		).
		LeftJoin(db.PositionTableName, "positions.id = users.position_id").
		LeftJoin(db.DivisionTableName, "divisions.id = users.division_id").
		LeftJoin(db.UserTableName+" modifier", "modifier.id = user_access_levels.modified_by").
		Where(sql_query.WhereQuery{
			"users.deleted_at": {Operator: sql_query.SQLOperatorIsNull},
		}).(*sql_query.SelectBuilder)

	tend := sql_query.NewSQLSelectBuilder[any]("t1").
		Select("t1.*", userType).(*sql_query.SelectBuilder)

	builder := sql_query.NewSQLSelectBuilder[T]("tend").
		WithCTEBuilder("t1", t1.SQLEloquentQuery).
		WithCTEBuilder("tend", tend.SQLEloquentQuery).(*sql_query.SelectBuilder)

	filters := sql_query.WhereQuery{}
	if len(q.Position) > 0 {
		filters["tend.position"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Position}
	}
	if len(q.Division) > 0 {
		filters["tend.division"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Division}
	}
	if len(q.ModifiedBy) > 0 {
		filters["tend.modified_by_name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.ModifiedBy}
	}
	if len(q.Status) > 0 {
		for _, v := range q.Status {
			if v != dto.StatusActive && v != dto.StatusInactive {
				return nil, &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown status",
					Data:    map[string]string{"field": "status"},
				}
			}
		}
		filters["tend.status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.Status}
	}
	if len(q.ActivePeriodUntil) > 0 {
		filters["tend.active_period_until"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorBetween, Value: q.ActivePeriodUntil, IsEpochTime: true}
	}
	if len(q.UpdatedAt) > 0 {
		filters["tend.updated_at"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorBetween, Value: q.UpdatedAt, IsEpochTime: true}
	}

	if len(q.TemporaryStatus) > 0 {
		filters["tend.temporary_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.TemporaryStatus}
	}
	if len(q.AuthenticatorStatus) > 0 {
		filters["tend.authenticator_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorAny, Value: q.AuthenticatorStatus}
	}
	builder.Where(filters)

	// The three display values map onto two DB values plus the pending-email
	// sub-state, so this filter is an OR-group instead of a plain IN.
	if len(q.ActivationStatus) > 0 {
		var ors []sql_query.WhereQuery
		for _, v := range q.ActivationStatus {
			switch v {
			case dto.ActivationPendingActivation:
				ors = append(ors, sql_query.WhereQuery{
					"tend.activation_status": {Operator: sql_query.SQLOperatorEqual, Value: dto.ActivationPendingActivation},
				})
			case dto.ActivationActivated:
				ors = append(ors, sql_query.WhereQuery{
					"tend.activation_status": {Operator: sql_query.SQLOperatorEqual, Value: dto.ActivationActivated},
					"tend.pending_email":     {Operator: sql_query.SQLOperatorIsNull},
				})
			case dto.ActivationPendingEmail:
				ors = append(ors, sql_query.WhereQuery{
					"tend.activation_status": {Operator: sql_query.SQLOperatorEqual, Value: dto.ActivationActivated},
					"tend.pending_email":     {Operator: sql_query.SQLOperatorIsNotNull},
				})
			default:
				return nil, &coreEntity.HttpError{
					Code:    fiber.StatusBadRequest,
					Message: "Unknown activation status",
					Data:    map[string]string{"field": "activationStatus"},
				}
			}
		}
		builder.WhereOr(ors...)
	}

	searchFields := []string{}
	if q.Columns != nil {
		for _, col := range q.Columns {
			if expr, ok := searchableColumns[col]; ok {
				searchFields = append(searchFields, expr)
			}
		}
	}
	if len(searchFields) == 0 {
		searchFields = defaultSearchableColumns
	}
	builder.Search(q.Search, searchFields)

	return builder, nil
}

// AccessLevelListQueryBuilder assembles the single paginated statement: the
// t1 → tend CTEs + filters + search (all from the common builder) + the
// list-only sort, wrapped by Paginate's data/totalRecords CTEs.
//
// [AI-GENERATED]
func AccessLevelListQueryBuilder[T any](product model.Product, q dto.AccessLevelListQuery, paginate ...bool) (string, []any, error) {
	sortBy := sortableColumns["fullName"]
	if q.SortBy != "" && q.SortBy != "fullName" {
		expr, ok := sortableColumns[q.SortBy]
		if !ok {
			return "", nil, &coreEntity.HttpError{
				Code:    fiber.StatusBadRequest,
				Message: "Unknown sort column",
				Data:    map[string]string{"field": "sortBy"},
			}
		}
		sortBy = expr
	}

	builder, err := AccessLevelCommonQueryBuilder[T](product, q)
	if err != nil {
		return "", nil, err
	}

	usePagination := true
	if len(paginate) > 0 {
		usePagination = paginate[0]
	}
	if usePagination {
		builder.Paginate(sql_query.Pagination{
			Page:      q.Page,
			Limit:     q.Limit,
			SortBy:    sortBy,
			SortOrder: q.SortOrder,
		})
	} else if q.SortOrder != 0 {
		builder.OrderBy([]string{sortBy}, q.SortOrder > 0)
	}

	return builder.Build()
}

// AccessLevelOptionsQueryBuilder emits one statement carrying all seven
// option lists
func AccessLevelOptionsQueryBuilder[T any](product model.Product, q dto.AccessLevelListQuery) (string, []any, error) {
	main, err := AccessLevelCommonQueryBuilder[T](product, q)
	if err != nil {
		return "", nil, err
	}

	// Each option list gets a fresh source from the common builder: it carries
	// the same filters + search as the list, so every facet's DISTINCT pass
	// runs over the same pool. GenerateCTEOption mutates the source it gets.
	//
	// [AI-GENERATED]
	positionSource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		positionSource,
		main,
		"positionOptions",
		"tend",
		q.PositionOptions,
		"tend.position",
		"tend.position",
		sql_query.Sort{SortBy: "tend.position", SortOrder: 1},
	)

	divisionSource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		divisionSource,
		main,
		"divisionOptions",
		"tend",
		q.DivisionOptions,
		"tend.division",
		"tend.division",
		sql_query.Sort{SortBy: "tend.division", SortOrder: 1},
	)

	modifiedBySource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		modifiedBySource,
		main,
		"modifiedByOptions",
		"tend",
		q.ModifiedByOptions,
		"tend.modified_by_name",
		"tend.modified_by_name",
		sql_query.Sort{SortBy: "tend.modified_by_name", SortOrder: 1},
	)

	statusSource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		statusSource,
		main,
		"statusOptions",
		"tend",
		q.StatusOptions,
		"tend.status",
		"tend.status",
		sql_query.Sort{SortBy: "tend.status", SortOrder: 1},
	)

	activationStatusSource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		activationStatusSource,
		main,
		"activationStatusOptions",
		"tend",
		q.ActivationStatusOptions,
		"tend.activation_status_display",
		"tend.activation_status_display",
		sql_query.Sort{SortBy: "tend.activation_status_display", SortOrder: 1},
	)

	isTemporarySource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		isTemporarySource,
		main,
		"temporaryStatusOptions",
		"tend",
		q.TemporaryStatusOptions,
		"tend.temporary_status",
		"tend.temporary_status",
		sql_query.Sort{SortBy: "tend.temporary_status", SortOrder: 1},
	)

	authenticatorStatusSource, err := AccessLevelCommonQueryBuilder[any](product, q)
	if err != nil {
		return "", nil, err
	}
	common_builders.GenerateCTEOption(
		authenticatorStatusSource,
		main,
		"authenticatorStatusOptions",
		"tend",
		q.AuthenticatorStatusOptions,
		"tend.authenticator_status",
		"tend.authenticator_status",
		sql_query.Sort{SortBy: "tend.authenticator_status", SortOrder: 1},
	)

	return main.Build()
}
