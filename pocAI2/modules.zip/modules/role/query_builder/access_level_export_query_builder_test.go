package query_builder

import (
	"strings"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
)

func TestAccessLevelExportQueryBuilderIsUnpaginated(t *testing.T) {
	query, _, err := AccessLevelListQueryBuilder[dto.AccessLevelListItem](model.ProductGlobalSettings, dto.AccessLevelListQuery{
		AccessLevel: dto.AccessLevelTotalControl,
		SortBy:      "updatedAt",
		SortOrder:   -1,
	}, false)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	for _, forbidden := range []string{"filtered_ids AS", "totalRecords", "LIMIT ", "OFFSET "} {
		if strings.Contains(query, forbidden) {
			t.Errorf("export query must not contain %q:\n%s", forbidden, query)
		}
	}
	if !strings.Contains(query, "ORDER BY tend.updated_at DESC") {
		t.Errorf("export query misses sort:\n%s", query)
	}
}
