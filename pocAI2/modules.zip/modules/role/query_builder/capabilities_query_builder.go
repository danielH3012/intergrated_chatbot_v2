package query_builder

import (
	"fmt"
	"strings"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// capabilitySortableColumns maps the spec sortable columns onto tend
// expressions
var capabilitySortableColumns = map[string]string{
	"name":       `tend.name`,
	"totalUsers": `tend.total_users`,
}

// CapabilitiesListQueryBuilder assembles the single paginated capabilities
// statement: a counts CTE over user_system_roles (permission_view = true,
// user not soft-deleted) LEFT JOINed into the fixed VALUES catalog, then the
// access-level tend + Paginate envelope. Sort columns are validated here —
// unknown is a 400 before any SQL runs.
func CapabilitiesListQueryBuilder[T any](product model.Product, q dto.CapabilitiesListQuery, paginate ...bool) (string, []any, error) {
	sortBy := capabilitySortableColumns["name"]
	if q.SortBy != "" && q.SortBy != "name" {
		expr, ok := capabilitySortableColumns[q.SortBy]
		if !ok {
			return "", nil, &coreEntity.HttpError{
				Code:    fiber.StatusBadRequest,
				Message: "Unknown sort column",
				Data:    map[string]string{"field": "sortBy"},
			}
		}
		sortBy = expr
	}

	counts := sql_query.NewSQLSelectBuilder[any](db.UserSystemRoleTableName).
		Select(
			"user_system_roles.key",
			"COUNT(*)::int AS total_users",
		).
		Join(db.UserTableName, "users.id = user_system_roles.user_id", sql_query.WhereQuery{
			"users.deleted_at": {Operator: sql_query.SQLOperatorIsNull},
		}).
		Where(sql_query.WhereQuery{
			"user_system_roles.product":         {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_system_roles.permission_view": {Operator: sql_query.SQLOperatorEqual, Value: true},
		}).
		GroupBy("user_system_roles.key").(*sql_query.SelectBuilder)

	// Paginate joins filtered_ids back on id, hence the ordinal (1..6).
	t1 := sql_query.NewSQLSelectBuilder[any](capabilitiesValuesSQL()).
		Select(
			"capabilities.id",
			"capabilities.key",
			"capabilities.name",
			"COALESCE(counts.total_users, 0) AS total_users",
		).
		LeftJoin("counts", "counts.key = capabilities.key").(*sql_query.SelectBuilder)

	tend := sql_query.NewSQLSelectBuilder[any]("t1").
		Select("t1.*").(*sql_query.SelectBuilder)

	builder := sql_query.NewSQLSelectBuilder[T]("tend").
		WithCTEBuilder("counts", counts.SQLEloquentQuery).
		WithCTEBuilder("t1", t1.SQLEloquentQuery).
		WithCTEBuilder("tend", tend.SQLEloquentQuery).(*sql_query.SelectBuilder)

	builder.Search(q.Search, []string{
		"tend.name",
		"tend.total_users::text",
	})

	usePagination := true
	if len(paginate) > 0 {
		usePagination = paginate[0]
	}
	if usePagination {
		builder.Paginate(sql_query.Pagination{
			Page:      q.Page,
			Limit:     q.Limit,
			SortBy:    sortBy,
			SortOrder: q.SortOrder,
		})
	} else if q.SortOrder != 0 {
		builder.OrderBy([]string{sortBy}, q.SortOrder > 0)
	}

	return builder.Build()
}

// capabilitiesValuesSQL renders the model.SystemRoleCatalog as a VALUES
// relation, e.g. (VALUES (1, 'manage_user_and_role', 'Manage user and role'),
// ...) AS capabilities(id, key, name). Values are single-quoted model enum
// constants — no user input ever reaches this string.
func capabilitiesValuesSQL() string {
	rows := make([]string, 0, len(model.SystemRoleCatalog))
	for i, c := range model.SystemRoleCatalog {
		rows = append(rows, fmt.Sprintf("(%d, '%s', '%s')", i+1, c.Key, c.Name))
	}
	return fmt.Sprintf("(VALUES %s) AS capabilities(id, key, name)", strings.Join(rows, ", "))
}
