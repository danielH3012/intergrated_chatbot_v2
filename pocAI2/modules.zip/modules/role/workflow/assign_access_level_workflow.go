package workflow

import (
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

// AssignAccessLevelWorkflowParam carries the ASSIGN request plus the identity
// recorded on the changelog row.
type AssignAccessLevelWorkflowParam struct {
	ClientID                    string
	Product                     model.Product
	ActorID                     int64
	ActorFullName               string
	UserID                      int64
	AccessLevel                 model.AccessLevel
	AnalyticsReportingTaskQueue string
}

// AssignAccessLevelActivityParam is the input of AssignAccessLevelActivity.
type AssignAccessLevelActivityParam struct {
	ClientID    string
	Product     model.Product
	ActorID     int64
	UserID      int64
	AccessLevel model.AccessLevel
}

// AssignAccessLevelActivityResult feeds the changelog step: the target's full
// name, snapshotted as the row's objectName, and the tier the target held
// before this assign (nil on a first assign — the changelog's oldValue).
type AssignAccessLevelActivityResult struct {
	UserID              int64
	UserFullName        string
	PreviousAccessLevel *model.AccessLevel
}

// AssignAccessLevelWorkflow writes the tier row plus the six capability rows
// in one transaction, then emits a single Assign / Access Level changelog row
// through the analytics-reporting RecordChangeLogsWorkflow child (same child
// semantics as AddCapabilityUserWorkflow).
func AssignAccessLevelWorkflow(ctx workflow.Context, param AssignAccessLevelWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (any, error) {
		var assigned AssignAccessLevelActivityResult
		if err := workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityAssignAccessLevel,
			AssignAccessLevelActivityParam{
				ClientID:    param.ClientID,
				Product:     param.Product,
				ActorID:     param.ActorID,
				UserID:      param.UserID,
				AccessLevel: param.AccessLevel,
			},
		).Get(activityCtx, &assigned); err != nil {
			return nil, err
		}

		// The tier/capability rows committed — drop the target's stale RBAC
		// snapshot before the best-effort changelog dispatch.
		invalidateUserRoles(activityCtx, param.ClientID, []int64{assigned.UserID})

		identity := changelogIdentity{
			ClientID:   param.ClientID,
			ActorID:    param.ActorID,
			ActorName:  param.ActorFullName,
			TargetID:   assigned.UserID,
			TargetName: assigned.UserFullName,
			Product:    arModel.Product(param.Product),
			TaskQueue:  param.AnalyticsReportingTaskQueue,
		}
		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{
			accessLevelAssignChangelog(identity, param.AccessLevel, assigned.PreviousAccessLevel),
		})
		return nil, nil
	})
}
