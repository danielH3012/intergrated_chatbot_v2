package workflow

import (
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

// AddCapabilityUserWorkflowParam carries the ADD request plus the identity
// recorded on the changelog row.
type AddCapabilityUserWorkflowParam struct {
	ClientID                    string
	Product                     model.Product
	ActorID                     int64
	ActorFullName               string
	UserID                      int64
	Key                         model.SystemRoleKey
	AnalyticsReportingTaskQueue string
}

// AddCapabilityUserActivityParam is the input of AddCapabilityUserActivity.
type AddCapabilityUserActivityParam struct {
	ClientID string
	Product  model.Product
	ActorID  int64
	UserID   int64
	Key      model.SystemRoleKey
}

// AddCapabilityUserActivityResult feeds the changelog step: the target's full
// name, snapshotted as the row's objectName.
type AddCapabilityUserActivityResult struct {
	UserID       int64
	UserFullName string
}

// AddCapabilityUserWorkflow inserts the capability row, then emits the Assign
// changelog row through the analytics-reporting RecordChangeLogsWorkflow child.
//
// The child workflow runs on the AR task queue with ABANDON parent-close
// policy and its own unbounded retry, so the parent commits the insert even
// when AR is down; the changelog still lands when AR returns (at-least-once).
// Failing to spawn only logs — the insert must not roll back because the audit
// sink is down.
func AddCapabilityUserWorkflow(ctx workflow.Context, param AddCapabilityUserWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (any, error) {
		var inserted AddCapabilityUserActivityResult
		if err := workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityAddCapabilityUser,
			AddCapabilityUserActivityParam{
				ClientID: param.ClientID,
				Product:  param.Product,
				ActorID:  param.ActorID,
				UserID:   param.UserID,
				Key:      param.Key,
			},
		).Get(activityCtx, &inserted); err != nil {
			return nil, err
		}

		// The row committed — drop the target's stale RBAC snapshot.
		invalidateUserRoles(activityCtx, param.ClientID, []int64{inserted.UserID})

		identity := changelogIdentity{
			ClientID:   param.ClientID,
			ActorID:    param.ActorID,
			ActorName:  param.ActorFullName,
			TargetID:   inserted.UserID,
			TargetName: inserted.UserFullName,
			Product:    arModel.Product(param.Product),
			TaskQueue:  param.AnalyticsReportingTaskQueue,
		}
		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{
			capabilityAssignChangelog(identity, model.SystemRoleNameOf(param.Key)),
		})
		return nil, nil
	})
}
