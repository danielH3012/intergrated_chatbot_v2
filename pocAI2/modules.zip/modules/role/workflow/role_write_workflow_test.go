package workflow

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/suite"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
)

type RoleWriteWorkflowTestSuite struct {
	RoleWorkflowTestSuite
}

func TestRoleWriteWorkflowTestSuite(t *testing.T) {
	suite.Run(t, new(RoleWriteWorkflowTestSuite))
}

func assignWorkflowParam() AssignAccessLevelWorkflowParam {
	return AssignAccessLevelWorkflowParam{
		ClientID:                    "9001",
		Product:                     model.ProductGlobalSettings,
		ActorID:                     7,
		ActorFullName:               "Budi Santoso",
		UserID:                      42,
		AccessLevel:                 model.AccessLevelTotalControl,
		AnalyticsReportingTaskQueue: "analytics-reporting-service",
	}
}

func (s *RoleWriteWorkflowTestSuite) TestAssignAccessLevelWorkflowSpawnsAssignRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAssignAccessLevel, func(ctx context.Context, param AssignAccessLevelActivityParam) (AssignAccessLevelActivityResult, error) {
		return AssignAccessLevelActivityResult{UserID: param.UserID, UserFullName: "Mike Tan"}, nil
	})
	e.run(AssignAccessLevelWorkflow, assignWorkflowParam())

	s.Require().Len(e.payload, 1)
	rows := e.payload[0].ChangeLogs
	s.Require().Len(rows, 1)
	row := rows[0]
	s.Equal(arModel.ChangeLogActionAssign, row.Action)
	s.Equal("Access Level", *row.Field)
	s.Equal("-", *row.OldValue)
	s.Equal("Total Control", *row.NewValue)
	s.Equal("Mike Tan", *row.ObjectName)
	s.Equal("Total Control", row.LogTable)
	s.Equal("Role & Permission > Total Control", row.Object)
	s.Equal("Budi Santoso", row.CreatedBySnapshot)
}

func (s *RoleWriteWorkflowTestSuite) TestAssignAccessLevelWorkflowUpgradeOldValue() {
	e := s.newEnv()
	previous := model.AccessLevelReadOnly
	e.stubActivity(constant.ActivityAssignAccessLevel, func(ctx context.Context, param AssignAccessLevelActivityParam) (AssignAccessLevelActivityResult, error) {
		return AssignAccessLevelActivityResult{UserID: param.UserID, UserFullName: "Mike Tan", PreviousAccessLevel: &previous}, nil
	})
	e.run(AssignAccessLevelWorkflow, assignWorkflowParam())

	row := e.payload[0].ChangeLogs[0]
	s.Equal("Read Only", *row.OldValue)
	s.Equal("Total Control", *row.NewValue)
}

func (s *RoleWriteWorkflowTestSuite) TestAssignAccessLevelWorkflowActivityFailureSpawnsNothing() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAssignAccessLevel, func(ctx context.Context, param AssignAccessLevelActivityParam) (AssignAccessLevelActivityResult, error) {
		return AssignAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("You cannot change your own access level."), true)
	})

	e.env.ExecuteWorkflow(AssignAccessLevelWorkflow, assignWorkflowParam())
	s.True(e.env.IsWorkflowCompleted())
	s.Error(e.env.GetWorkflowError())
	s.Empty(e.payload)
	s.Empty(e.invalidated, "a failed write must not invalidate")
}

// TestAssignAccessLevelWorkflowInvalidatesTarget: after the tier/capability
// write commits, the workflow drops the target's RBAC snapshot so their next
// request rebuilds from the role tables instead of the stale cache entry.
func (s *RoleWriteWorkflowTestSuite) TestAssignAccessLevelWorkflowInvalidatesTarget() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAssignAccessLevel, func(ctx context.Context, param AssignAccessLevelActivityParam) (AssignAccessLevelActivityResult, error) {
		return AssignAccessLevelActivityResult{UserID: param.UserID, UserFullName: "Mike Tan"}, nil
	})
	e.run(AssignAccessLevelWorkflow, assignWorkflowParam())

	s.Equal([][]int64{{42}}, e.invalidated)
}

// TestInvalidationFailureDoesNotFailWrite: the cache is fail-soft and the TTL
// is the backstop — an invalidation failure must not turn a committed write
// into an error response or drop the changelog row.
func (s *RoleWriteWorkflowTestSuite) TestInvalidationFailureDoesNotFailWrite() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAssignAccessLevel, func(ctx context.Context, param AssignAccessLevelActivityParam) (AssignAccessLevelActivityResult, error) {
		return AssignAccessLevelActivityResult{UserID: param.UserID, UserFullName: "Mike Tan"}, nil
	})
	e.stubActivity(constant.ActivityInvalidateUserRoles, func(ctx context.Context, param InvalidateUserRolesActivityParam) error {
		return errors.New("valkey unavailable")
	})
	e.run(AssignAccessLevelWorkflow, assignWorkflowParam())

	s.Require().Len(e.payload, 1)
	s.Require().Len(e.payload[0].ChangeLogs, 1)
}

func removeWorkflowParam() RemoveAccessLevelWorkflowParam {
	return RemoveAccessLevelWorkflowParam{
		ClientID:                    "9001",
		Product:                     model.ProductGlobalSettings,
		ActorID:                     7,
		ActorFullName:               "Budi Santoso",
		UserIDs:                     []int64{42, 43},
		AccessLevel:                 model.AccessLevelTotalControl,
		AnalyticsReportingTaskQueue: "analytics-reporting-service",
	}
}

func (s *RoleWriteWorkflowTestSuite) TestRemoveAccessLevelWorkflowSpawnsOneRowPerUser() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveAccessLevel, func(ctx context.Context, param RemoveAccessLevelActivityParam) (RemoveAccessLevelActivityResult, error) {
		return RemoveAccessLevelActivityResult{Removed: []AccessLevelRemoveOutcome{
			{UserID: 42, UserFullName: "Mike Tan", RemovedAccessLevel: model.AccessLevelTotalControl},
			{UserID: 43, UserFullName: "Sari Dewi", RemovedAccessLevel: model.AccessLevelTotalControl},
		}}, nil
	})
	e.run(RemoveAccessLevelWorkflow, removeWorkflowParam())

	s.Require().Len(e.payload, 1)
	rows := e.payload[0].ChangeLogs
	s.Require().Len(rows, 2)
	s.Equal(arModel.ChangeLogActionRemove, rows[0].Action)
	s.Equal("Access Level", *rows[0].Field)
	s.Equal("Total Control", *rows[0].OldValue)
	s.Equal("-", *rows[0].NewValue)
	s.Equal("Mike Tan", *rows[0].ObjectName)
	s.Equal("Sari Dewi", *rows[1].ObjectName)
}

func (s *RoleWriteWorkflowTestSuite) TestRemoveAccessLevelWorkflowActivityFailureSpawnsNothing() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveAccessLevel, func(ctx context.Context, param RemoveAccessLevelActivityParam) (RemoveAccessLevelActivityResult, error) {
		return RemoveAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Conflict("User does not have this access level"), true)
	})

	e.env.ExecuteWorkflow(RemoveAccessLevelWorkflow, removeWorkflowParam())
	s.True(e.env.IsWorkflowCompleted())
	s.Error(e.env.GetWorkflowError())
	s.Empty(e.payload)
	s.Empty(e.invalidated, "a failed removal must not invalidate")
}

// TestRemoveAccessLevelWorkflowInvalidatesOnlyRemovedUsers: a user whose
// removal was a no-op (no tier row) never had their snapshot drop.
func (s *RoleWriteWorkflowTestSuite) TestRemoveAccessLevelWorkflowInvalidatesOnlyRemovedUsers() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveAccessLevel, func(ctx context.Context, param RemoveAccessLevelActivityParam) (RemoveAccessLevelActivityResult, error) {
		return RemoveAccessLevelActivityResult{Removed: []AccessLevelRemoveOutcome{
			{UserID: 42, UserFullName: "Mike Tan", RemovedAccessLevel: model.AccessLevelTotalControl},
		}}, nil
	})
	e.run(RemoveAccessLevelWorkflow, removeWorkflowParam())

	s.Equal([][]int64{{42}}, e.invalidated)
}

func removeCapabilityWorkflowParam() RemoveCapabilityUsersWorkflowParam {
	return RemoveCapabilityUsersWorkflowParam{
		ClientID:                    "9001",
		Product:                     model.ProductGlobalSettings,
		ActorID:                     7,
		ActorFullName:               "Budi Santoso",
		Key:                         model.SystemRoleKeyManageFiles,
		UserIDs:                     []int64{42, 43},
		AnalyticsReportingTaskQueue: "analytics-reporting-service",
	}
}

func (s *RoleWriteWorkflowTestSuite) TestRemoveCapabilityUsersWorkflowSpawnsRemoveAndAutoRevertRows() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveCapabilityUsers, func(ctx context.Context, param RemoveCapabilityUsersActivityParam) (RemoveCapabilityUsersActivityResult, error) {
		return RemoveCapabilityUsersActivityResult{Removed: []RemoveCapabilityUserOutcome{
			{UserID: 42, UserFullName: "Mike Tan"},
			{UserID: 43, UserFullName: "Sari Dewi", AccessLevelAutoReverted: true, RevertedAccessLevel: model.AccessLevelReadOnly},
		}}, nil
	})
	e.env.ExecuteWorkflow(RemoveCapabilityUsersWorkflow, removeCapabilityWorkflowParam())
	s.True(e.env.IsWorkflowCompleted())
	s.NoError(e.env.GetWorkflowError())

	s.Require().Len(e.payload, 1)
	rows := e.payload[0].ChangeLogs
	s.Require().Len(rows, 3)

	remove1, remove2, revert := rows[0], rows[1], rows[2]
	s.Equal(arModel.ChangeLogActionRemove, remove1.Action)
	s.Equal("Access", *remove1.Field)
	s.Equal("Assigned", *remove1.OldValue)
	s.Equal("-", *remove1.NewValue)
	s.Equal("Manage files — Mike Tan", *remove1.ObjectName)

	s.Equal(arModel.ChangeLogActionRemove, remove2.Action)
	s.Equal("Access", *remove2.Field)
	s.Equal("Manage files — Sari Dewi", *remove2.ObjectName)

	s.Equal(arModel.ChangeLogAction("Auto-Revert Read Only"), revert.Action)
	s.Equal("Access Level", *revert.Field)
	s.Equal("Read Only", *revert.OldValue)
	s.Equal("-", *revert.NewValue)
	s.Equal("Sari Dewi", *revert.ObjectName)
}

func (s *RoleWriteWorkflowTestSuite) TestRemoveCapabilityUsersWorkflowReturnsFailedUserIds() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveCapabilityUsers, func(ctx context.Context, param RemoveCapabilityUsersActivityParam) (RemoveCapabilityUsersActivityResult, error) {
		return RemoveCapabilityUsersActivityResult{
			Removed:       []RemoveCapabilityUserOutcome{{UserID: 42, UserFullName: "Mike Tan"}},
			FailedUserIDs: []int64{43},
		}, nil
	})

	var result RemoveCapabilityUsersWorkflowResult
	e.env.ExecuteWorkflow(RemoveCapabilityUsersWorkflow, removeCapabilityWorkflowParam())
	s.True(e.env.IsWorkflowCompleted())
	s.NoError(e.env.GetWorkflowError())
	s.NoError(e.env.GetWorkflowResult(&result))
	s.Equal([]int64{43}, result.FailedUserIDs)
}

func (s *RoleWriteWorkflowTestSuite) TestRemoveCapabilityUsersWorkflowActivityFailureSpawnsNothing() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveCapabilityUsers, func(ctx context.Context, param RemoveCapabilityUsersActivityParam) (RemoveCapabilityUsersActivityResult, error) {
		return RemoveCapabilityUsersActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("The requested users could not be removed"), true)
	})

	e.env.ExecuteWorkflow(RemoveCapabilityUsersWorkflow, removeCapabilityWorkflowParam())
	s.True(e.env.IsWorkflowCompleted())
	s.Error(e.env.GetWorkflowError())
	s.Empty(e.payload)
	s.Empty(e.invalidated, "a failed removal must not invalidate")
}

// TestRemoveCapabilityUsersWorkflowInvalidatesOnlyRemovedUsers: failed and
// guard-rejected rows leave the user's access untouched, so only the removed
// rows invalidate.
func (s *RoleWriteWorkflowTestSuite) TestRemoveCapabilityUsersWorkflowInvalidatesOnlyRemovedUsers() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityRemoveCapabilityUsers, func(ctx context.Context, param RemoveCapabilityUsersActivityParam) (RemoveCapabilityUsersActivityResult, error) {
		return RemoveCapabilityUsersActivityResult{
			Removed:       []RemoveCapabilityUserOutcome{{UserID: 42, UserFullName: "Mike Tan"}},
			FailedUserIDs: []int64{43},
		}, nil
	})
	e.env.ExecuteWorkflow(RemoveCapabilityUsersWorkflow, removeCapabilityWorkflowParam())
	s.True(e.env.IsWorkflowCompleted())
	s.NoError(e.env.GetWorkflowError())

	s.Equal([][]int64{{42}}, e.invalidated)
}
