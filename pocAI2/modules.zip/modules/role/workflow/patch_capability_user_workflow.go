package workflow

import (
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
)

// PatchCapabilityUserWorkflowParam carries the PATCH request, the actor's RBAC
// snapshot (the tier guard needs the actor's module tier), and the identity
// recorded on the changelog rows.
type PatchCapabilityUserWorkflowParam struct {
	ClientID                    string
	Product                     model.Product
	UserID                      int64
	ActorID                     int64
	ActorFullName               string
	Key                         model.SystemRoleKey
	Roles                       tsMiddleware.UserAccessCache
	Permission                  *dto.CapabilityPermissionPatch
	AnalyticsReportingTaskQueue string
}

// PatchCapabilityUserActivityParam is the input of PatchCapabilityUserActivity.
type PatchCapabilityUserActivityParam struct {
	ClientID   string
	Product    model.Product
	UserID     int64
	ActorID    int64
	Key        model.SystemRoleKey
	Roles      tsMiddleware.UserAccessCache
	Permission *dto.CapabilityPermissionPatch
}

// PatchCapabilityUserActivityResult feeds the changelog step: the pre-patch
// row (only its values that actually changed produce Edit rows) plus whether
// the tier row was deleted as an auto-revert side-effect and which tier.
type PatchCapabilityUserActivityResult struct {
	Before                  dto.CapabilityUserRow
	AccessLevelAutoReverted bool
	RevertedAccessLevel     model.AccessLevel
}

// PatchCapabilityUserWorkflowResult is the data payload of the PATCH response.
type PatchCapabilityUserWorkflowResult struct {
	AccessLevelAutoReverted bool
}

// PatchCapabilityUserWorkflow updates the C/U/D flags, then emits one
// changelog row per changed CRUD column — plus an Auto-Revert row when the
// tier row was deleted — through the analytics-reporting
// RecordChangeLogsWorkflow child (same child semantics as
// AddCapabilityUserWorkflow).
func PatchCapabilityUserWorkflow(ctx workflow.Context, param PatchCapabilityUserWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (any, error) {
		var updated PatchCapabilityUserActivityResult
		if err := workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityPatchCapabilityUser,
			PatchCapabilityUserActivityParam{
				ClientID:   param.ClientID,
				Product:    param.Product,
				UserID:     param.UserID,
				ActorID:    param.ActorID,
				Key:        param.Key,
				Roles:      param.Roles,
				Permission: param.Permission,
			},
		).Get(activityCtx, &updated); err != nil {
			return nil, err
		}

		// The patch (and any auto-revert) committed — drop the target's stale
		// RBAC snapshot.
		invalidateUserRoles(activityCtx, param.ClientID, []int64{param.UserID})

		identity := changelogIdentity{
			ClientID:   param.ClientID,
			ActorID:    param.ActorID,
			ActorName:  param.ActorFullName,
			TargetID:   param.UserID,
			TargetName: updated.Before.FullName,
			Product:    arModel.Product(param.Product),
			TaskQueue:  param.AnalyticsReportingTaskQueue,
		}
		logs := capabilityEditChangelogs(identity, model.SystemRoleNameOf(param.Key), updated.Before, param.Permission)
		if updated.AccessLevelAutoReverted {
			logs = append(logs, autoRevertChangelog(identity, updated.RevertedAccessLevel))
		}
		spawnChangeLogWorkflow(ctx, identity, logs)

		return PatchCapabilityUserWorkflowResult{
			AccessLevelAutoReverted: updated.AccessLevelAutoReverted,
		}, nil
	})
}
