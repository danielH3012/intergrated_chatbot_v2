package workflow

import (
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
)

// InvalidateUserRolesActivityParam names the tenant and the users whose RBAC
// snapshots a committed write invalidated. UserIDs is empty when the write was
// a no-op (e.g. Remove on a user with no tier row) — the step is skipped.
type InvalidateUserRolesActivityParam struct {
	ClientID string
	UserIDs  []int64
}

// invalidateUserRoles runs the cache-invalidation step after a write activity
// committed. Failing to invalidate must not turn a successful write into an
// error response — the cache package is fail-soft and the snapshot TTL is the
// backstop — so the failure is logged and the workflow continues; the write
// result and the changelog spawn are unaffected.
func invalidateUserRoles(ctx workflow.Context, clientID string, userIDs []int64) {
	if len(userIDs) == 0 {
		return
	}
	if err := workflow.ExecuteActivity(
		ctx,
		constant.ActivityInvalidateUserRoles,
		InvalidateUserRolesActivityParam{ClientID: clientID, UserIDs: userIDs},
	).Get(ctx, nil); err != nil {
		workflow.GetLogger(ctx).Error("failed to invalidate user roles snapshot", "error", err)
	}
}
