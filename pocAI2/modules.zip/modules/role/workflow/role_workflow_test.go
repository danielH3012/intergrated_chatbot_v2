package workflow

import (
	"context"
	"testing"

	"github.com/stretchr/testify/suite"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/testsuite"
	"go.temporal.io/sdk/workflow"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	arDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
)

type RoleWorkflowTestSuite struct {
	suite.Suite
	testsuite.WorkflowTestSuite
}

func TestRoleWorkflowTestSuite(t *testing.T) {
	suite.Run(t, new(RoleWorkflowTestSuite))
}

// testEnv wires one workflow under test with stubbed activities and a
// capturing RecordChangeLogsWorkflow child.
type testEnv struct {
	suite       *RoleWorkflowTestSuite
	env         *testsuite.TestWorkflowEnvironment
	payload     []arDto.CreateChangeLogActivityParam
	invalidated [][]int64
}

func (s *RoleWorkflowTestSuite) newEnv() *testEnv {
	e := &testEnv{suite: s}
	e.env = s.NewTestWorkflowEnvironment()

	// Every write workflow runs the post-commit cache invalidation step; the
	// default stub records it. A test can re-register the name to fail it.
	e.env.RegisterActivityWithOptions(
		func(_ context.Context, param InvalidateUserRolesActivityParam) error {
			e.invalidated = append(e.invalidated, param.UserIDs)
			return nil
		},
		activity.RegisterOptions{Name: constant.ActivityInvalidateUserRoles},
	)

	e.env.RegisterWorkflowWithOptions(
		func(ctx workflow.Context, payload arDto.CreateChangeLogActivityParam) error {
			e.payload = append(e.payload, payload)
			return nil
		},
		workflow.RegisterOptions{Name: tsConstant.AnalyticsReportingRecordChangeLogsWorkflow},
	)
	return e
}

func (e *testEnv) stubActivity(name string, fn any) {
	e.env.RegisterActivityWithOptions(fn, activity.RegisterOptions{Name: name})
}

func (e *testEnv) run(wf any, param any) {
	e.env.ExecuteWorkflow(wf, param)
	e.suite.True(e.env.IsWorkflowCompleted())
	e.suite.NoError(e.env.GetWorkflowError())
}

func addParam() AddCapabilityUserWorkflowParam {
	return AddCapabilityUserWorkflowParam{
		ClientID:                    "9001",
		Product:                     model.ProductGlobalSettings,
		ActorID:                     7,
		ActorFullName:               "Budi Santoso",
		UserID:                      42,
		Key:                         model.SystemRoleKeyManageTAG,
		AnalyticsReportingTaskQueue: "analytics-reporting-service",
	}
}

// TestAddCapabilityUserWorkflowSpawnsAssignRow: after the insert activity
// succeeds, the workflow spawns exactly one Assign changelog row with the
// target's identity and the capability name.
func (s *RoleWorkflowTestSuite) TestAddCapabilityUserWorkflowSpawnsAssignRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAddCapabilityUser, func(ctx context.Context, param AddCapabilityUserActivityParam) (AddCapabilityUserActivityResult, error) {
		return AddCapabilityUserActivityResult{UserID: param.UserID, UserFullName: "Mike Tan"}, nil
	})
	e.run(AddCapabilityUserWorkflow, addParam())

	s.Require().Len(e.payload, 1)
	rows := e.payload[0].ChangeLogs
	s.Require().Len(rows, 1)
	row := rows[0]
	s.Equal(arModel.ChangeLogActionAssign, row.Action)
	s.Equal("Access", *row.Field)
	s.Equal("-", *row.OldValue)
	s.Equal("Assigned", *row.NewValue)
	s.Equal("Manage TAG", row.LogTable)
	s.Equal("Role & Permission > System Role", row.Object)
	s.Equal("7", row.CreatedById)
	s.Equal("Budi Santoso", row.CreatedBySnapshot)
	s.Equal("42", *row.ObjectId)
	s.Equal("Manage TAG — Mike Tan", *row.ObjectName)
}

// TestAddCapabilityUserWorkflowActivityFailureSpawnsNothing: a guard failure in
// the activity fails the workflow and no changelog child is spawned.
func (s *RoleWorkflowTestSuite) TestAddCapabilityUserWorkflowActivityFailureSpawnsNothing() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAddCapabilityUser, func(ctx context.Context, param AddCapabilityUserActivityParam) (AddCapabilityUserActivityResult, error) {
		return AddCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("You cannot edit your own permissions"), true)
	})

	e.env.ExecuteWorkflow(AddCapabilityUserWorkflow, addParam())
	s.True(e.env.IsWorkflowCompleted())
	s.Error(e.env.GetWorkflowError())
	s.Empty(e.payload)
	s.Empty(e.invalidated, "a failed write must not invalidate")
}

// TestAddCapabilityUserWorkflowInvalidatesTarget: after the insert commits,
// the target's stale RBAC snapshot is dropped.
func (s *RoleWorkflowTestSuite) TestAddCapabilityUserWorkflowInvalidatesTarget() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityAddCapabilityUser, func(ctx context.Context, param AddCapabilityUserActivityParam) (AddCapabilityUserActivityResult, error) {
		return AddCapabilityUserActivityResult{UserID: param.UserID, UserFullName: "Mike Tan"}, nil
	})
	e.run(AddCapabilityUserWorkflow, addParam())

	s.Equal([][]int64{{42}}, e.invalidated)
}

func patchParam() PatchCapabilityUserWorkflowParam {
	return PatchCapabilityUserWorkflowParam{
		ClientID:                    "9001",
		Product:                     model.ProductGlobalSettings,
		UserID:                      42,
		ActorID:                     7,
		ActorFullName:               "Budi Santoso",
		Key:                         model.SystemRoleKeyManageFiles,
		Permission:                  &dto.CapabilityPermissionPatch{Create: ptr(false), Update: ptr(true)},
		AnalyticsReportingTaskQueue: "analytics-reporting-service",
	}
}

// TestPatchCapabilityUserWorkflowSpawnsEditAndAutoRevertRows: changed columns
// produce one Edit row each, and an auto-revert adds the Access Level row.
func (s *RoleWorkflowTestSuite) TestPatchCapabilityUserWorkflowSpawnsEditAndAutoRevertRows() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityPatchCapabilityUser, func(ctx context.Context, param PatchCapabilityUserActivityParam) (PatchCapabilityUserActivityResult, error) {
		return PatchCapabilityUserActivityResult{
			Before: dto.CapabilityUserRow{
				UserID:           42,
				FullName:         "Mike Tan",
				PermissionCreate: true,
				PermissionUpdate: false,
				PermissionDelete: true,
			},
			AccessLevelAutoReverted: true,
			RevertedAccessLevel:     model.AccessLevelTotalControl,
		}, nil
	})
	e.run(PatchCapabilityUserWorkflow, patchParam())

	s.Require().Len(e.payload, 1)
	rows := e.payload[0].ChangeLogs
	s.Require().Len(rows, 3)

	create, update, revert := rows[0], rows[1], rows[2]
	s.Equal(arModel.ChangeLogActionEdit, create.Action)
	s.Equal("Create", *create.Field)
	s.Equal("Active", *create.OldValue)
	s.Equal("Inactive", *create.NewValue)

	s.Equal(arModel.ChangeLogActionEdit, update.Action)
	s.Equal("Update", *update.Field)
	s.Equal("Inactive", *update.OldValue)
	s.Equal("Active", *update.NewValue)

	s.Equal(arModel.ChangeLogAction("Auto-Revert Total Control"), revert.Action)
	s.Equal("Access Level", *revert.Field)
	s.Equal("Total Control", *revert.OldValue)
	s.Equal("-", *revert.NewValue)

	s.Equal("Manage files — Mike Tan", *create.ObjectName)
	s.Equal("Manage files — Mike Tan", *update.ObjectName)
	s.Equal("Mike Tan", *revert.ObjectName)
	s.Equal("Manage files", create.LogTable)
	s.Equal("Manage files", update.LogTable)
	s.Equal("Total Control", revert.LogTable)
	for _, row := range rows {
		s.Empty(row.EntityID)
		s.Empty(row.EntityType)
		s.Equal("Budi Santoso", row.CreatedBySnapshot)
	}

	// The patch (and the auto-revert) committed — the target's snapshot drops.
	s.Equal([][]int64{{42}}, e.invalidated)
}

// TestPatchCapabilityUserWorkflowUnchangedColumnsSpawnNothing: a patch that
// changes nothing produces no rows and no child spawn.
func (s *RoleWorkflowTestSuite) TestPatchCapabilityUserWorkflowUnchangedColumnsSpawnNothing() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityPatchCapabilityUser, func(ctx context.Context, param PatchCapabilityUserActivityParam) (PatchCapabilityUserActivityResult, error) {
		return PatchCapabilityUserActivityResult{
			Before: dto.CapabilityUserRow{
				UserID:           42,
				FullName:         "Mike Tan",
				PermissionCreate: false,
				PermissionUpdate: true,
			},
		}, nil
	})
	e.run(PatchCapabilityUserWorkflow, patchParam())

	s.Empty(e.payload)
	// No CRUD cell changed, but the write still bumped modified_by/updated_at,
	// so the target's snapshot is still stale until it drops.
	s.Equal([][]int64{{42}}, e.invalidated)
}
