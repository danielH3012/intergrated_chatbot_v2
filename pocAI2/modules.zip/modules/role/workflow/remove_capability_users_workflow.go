package workflow

import (
	"go.temporal.io/sdk/workflow"

	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
)

// RemoveCapabilityUsersWorkflowParam carries the DELETE /capabilities/users
// request — one key, many user IDs (the row action sends one, the bulk action
// sends many) — plus the actor's RBAC snapshot (the tier guard needs the
// actor's module tier) and the identity recorded on the changelog rows.
type RemoveCapabilityUsersWorkflowParam struct {
	ClientID                    string
	Product                     model.Product
	ActorID                     int64
	ActorFullName               string
	Key                         model.SystemRoleKey
	UserIDs                     []int64
	Roles                       tsMiddleware.UserAccessCache
	AnalyticsReportingTaskQueue string
}

// RemoveCapabilityUsersActivityParam is the input of
// RemoveCapabilityUsersActivity.
type RemoveCapabilityUsersActivityParam struct {
	ClientID string
	Product  model.Product
	ActorID  int64
	Key      model.SystemRoleKey
	UserIDs  []int64
	Roles    tsMiddleware.UserAccessCache
}

// RemoveCapabilityUserOutcome is one row the activity actually deleted: the
// target identity for the changelog row plus whether the deletion also
// auto-reverted the target's access level (and which tier).
type RemoveCapabilityUserOutcome struct {
	UserID                  int64
	UserFullName            string
	AccessLevelAutoReverted bool
	RevertedAccessLevel     model.AccessLevel
}

// RemoveCapabilityUsersActivityResult reports what happened per row: the
// removed rows and the user IDs whose row could not be removed (already
// deleted, or a guard rejected them) — the FE keeps those selected for retry.
type RemoveCapabilityUsersActivityResult struct {
	Removed       []RemoveCapabilityUserOutcome
	FailedUserIDs []int64
}

// RemoveCapabilityUsersWorkflowResult is the data payload of the DELETE
// response.
type RemoveCapabilityUsersWorkflowResult struct {
	FailedUserIDs []int64
}

// RemoveCapabilityUsersWorkflow hard-deletes one capability assignment per
// requested user (each in its own transaction; a tier-holder deletion also
// auto-reverts the tier row), then emits one Remove / Access changelog row per
// removed row — plus one Auto-Revert row per reverted user — through the
// analytics-reporting RecordChangeLogsWorkflow child.
func RemoveCapabilityUsersWorkflow(ctx workflow.Context, param RemoveCapabilityUsersWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (any, error) {
		var removed RemoveCapabilityUsersActivityResult
		if err := workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityRemoveCapabilityUsers,
			RemoveCapabilityUsersActivityParam{
				ClientID: param.ClientID,
				Product:  param.Product,
				ActorID:  param.ActorID,
				Key:      param.Key,
				UserIDs:  param.UserIDs,
				Roles:    param.Roles,
			},
		).Get(activityCtx, &removed); err != nil {
			return nil, err
		}

		// Only rows actually deleted changed their user's access — a failed or
		// guard-rejected row is not invalidated.
		removedUserIDs := make([]int64, 0, len(removed.Removed))
		for _, outcome := range removed.Removed {
			removedUserIDs = append(removedUserIDs, outcome.UserID)
		}
		invalidateUserRoles(activityCtx, param.ClientID, removedUserIDs)

		var logs []arModel.Changelog
		for _, outcome := range removed.Removed {
			identity := changelogIdentity{
				ClientID:   param.ClientID,
				ActorID:    param.ActorID,
				ActorName:  param.ActorFullName,
				TargetID:   outcome.UserID,
				TargetName: outcome.UserFullName,
				Product:    arModel.Product(param.Product),
				TaskQueue:  param.AnalyticsReportingTaskQueue,
			}
			logs = append(logs, capabilityRemoveChangelog(identity, model.SystemRoleNameOf(param.Key)))
			if outcome.AccessLevelAutoReverted {
				logs = append(logs, autoRevertChangelog(identity, outcome.RevertedAccessLevel))
			}
		}
		spawnChangeLogWorkflow(ctx, changelogIdentity{
			ClientID:  param.ClientID,
			Product:   arModel.Product(param.Product),
			TaskQueue: param.AnalyticsReportingTaskQueue,
		}, logs)

		return RemoveCapabilityUsersWorkflowResult{FailedUserIDs: removed.FailedUserIDs}, nil
	})
}
