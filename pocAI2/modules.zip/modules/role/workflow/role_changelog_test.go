package workflow

import (
	"testing"

	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
)

var testIdentity = changelogIdentity{
	ClientID:   "9001",
	ActorID:    7,
	ActorName:  "Budi Santoso",
	TargetID:   42,
	TargetName: "Mike Tan",
	Product:    arModel.ProductGlobalSettings,
	TaskQueue:  "analytics-reporting-service",
}

func ptr(v bool) *bool { return &v }

// TestCapabilityAssignChangelog pins the [+ Add User] row (role/01-overview.md
// §9.4): Action=Assign, Field=Access, "—"→"Assigned", objectName carrying the
// combined "[Capability] — [User Name]" stored identifier, on the capability's
// System Role Name logTable so the modal surfaces can filter it.
func TestCapabilityAssignChangelog(t *testing.T) {
	row := capabilityAssignChangelog(testIdentity, model.SystemRoleNameManageTAG)

	if row.Action != arModel.ChangeLogActionAssign {
		t.Fatalf("action = %q, want %q", row.Action, arModel.ChangeLogActionAssign)
	}
	if row.Field == nil || *row.Field != "Access" {
		t.Fatalf("field = %v, want %q", row.Field, "Access")
	}
	if row.OldValue == nil || *row.OldValue != "-" {
		t.Fatalf("oldValue = %v, want %q", row.OldValue, "-")
	}
	if row.NewValue == nil || *row.NewValue != "Assigned" {
		t.Fatalf("newValue = %v, want %q", row.NewValue, "Assigned")
	}
	assertRoleRowCommon(t, row, "Role & Permission > System Role", "Manage TAG", "Manage TAG — Mike Tan")
}

// TestCapabilityEditChangelogs pins the Edit rows: exactly one per changed
// CRUD column, literals Active/Inactive, unchanged columns silent.
func TestCapabilityEditChangelogs(t *testing.T) {
	before := dto.CapabilityUserRow{
		UserID:           42,
		PermissionCreate: true,
		PermissionUpdate: false,
		PermissionDelete: true,
	}
	patch := &dto.CapabilityPermissionPatch{
		Create: ptr(false), // changed: Active -> Inactive
		Update: ptr(true),  // changed: Inactive -> Active
		Delete: ptr(true),  // unchanged
		Read:   ptr(true),  // locked no-op, never a row
	}

	logs := capabilityEditChangelogs(testIdentity, model.SystemRoleNameManageFiles, before, patch)
	if len(logs) != 2 {
		t.Fatalf("got %d rows, want 2: %+v", len(logs), logs)
	}

	create := logs[0]
	if create.Action != arModel.ChangeLogActionEdit || create.Field == nil ||
		*create.Field != "Create" {
		t.Fatalf("create row: action=%q field=%v", create.Action, create.Field)
	}
	if create.OldValue == nil || *create.OldValue != "Active" || create.NewValue == nil || *create.NewValue != "Inactive" {
		t.Fatalf("create row values: %v -> %v", create.OldValue, create.NewValue)
	}

	update := logs[1]
	if update.Field == nil || *update.Field != "Update" ||
		update.OldValue == nil || *update.OldValue != "Inactive" || update.NewValue == nil || *update.NewValue != "Active" {
		t.Fatalf("update row: field=%v %v -> %v", update.Field, update.OldValue, update.NewValue)
	}

	assertRoleRowCommon(t, create, "Role & Permission > System Role", "Manage files", "Manage files — Mike Tan")
	assertRoleRowCommon(t, update, "Role & Permission > System Role", "Manage files", "Manage files — Mike Tan")
}

func TestCapabilityEditChangelogsNilPatch(t *testing.T) {
	if logs := capabilityEditChangelogs(testIdentity, model.SystemRoleNameManageFiles, dto.CapabilityUserRow{}, nil); logs != nil {
		t.Fatalf("nil patch produced %d rows, want none", len(logs))
	}
}

// TestAutoRevertChangelog pins the tier-drop side-effect row (§9.1/§9.2):
// Action=Auto-Revert <Tier>, Field=Access Level, tier → "—". The actor is the
// admin who made the edit, carried on the common fields.
func TestAutoRevertChangelog(t *testing.T) {
	for _, tc := range []struct {
		level  model.AccessLevel
		action string
		old    string
	}{
		{model.AccessLevelTotalControl, "Auto-Revert Total Control", "Total Control"},
		{model.AccessLevelReadOnly, "Auto-Revert Read Only", "Read Only"},
	} {
		row := autoRevertChangelog(testIdentity, tc.level)
		if string(row.Action) != tc.action {
			t.Fatalf("%s: action = %q, want %q", tc.level, row.Action, tc.action)
		}
		if row.Field == nil || *row.Field != "Access Level" {
			t.Fatalf("%s: field = %v, want %q", tc.level, row.Field, "Access Level")
		}
		if row.OldValue == nil || *row.OldValue != tc.old || row.NewValue == nil || *row.NewValue != "-" {
			t.Fatalf("%s: values = %v -> %v", tc.level, row.OldValue, row.NewValue)
		}
		assertRoleRowCommon(t, row, "Role & Permission > "+tc.old, tc.old, "Mike Tan")
	}
}

// assertRoleRowCommon pins the fields every Role & Permission row shares: the
// per-row logTable and object, the empty entity
// fields, and the actor/target snapshots (role/API/low-level-design.md §4
// audit write).
func assertRoleRowCommon(t *testing.T, row arModel.Changelog, wantObject, wantLogTable, wantObjectName string) {
	t.Helper()

	if row.LogTable != wantLogTable {
		t.Errorf("logTable = %q, want %q", row.LogTable, wantLogTable)
	}
	if row.Object != wantObject {
		t.Errorf("object = %q, want %q", row.Object, wantObject)
	}
	if row.CreatedById != "7" {
		t.Errorf("createdById = %q, want %q", row.CreatedById, "7")
	}
	if row.CreatedBySnapshot != "Budi Santoso" {
		t.Errorf("createdBySnapshot = %q, want %q", row.CreatedBySnapshot, "Budi Santoso")
	}
	if row.EntityID != "" {
		t.Errorf("entityId = %q, want empty (deliberately unset)", row.EntityID)
	}
	if row.EntityType != "" {
		t.Errorf("entityType = %q, want empty (deliberately unset)", row.EntityType)
	}
	if row.Product == nil || *row.Product != arModel.ProductGlobalSettings {
		t.Errorf("product = %v, want %q", row.Product, arModel.ProductGlobalSettings)
	}
	if row.ObjectId == nil || *row.ObjectId != "42" {
		t.Errorf("objectId = %v, want %q", row.ObjectId, "42")
	}
	if row.ObjectName == nil || *row.ObjectName != wantObjectName {
		t.Errorf("objectName = %v, want %q", row.ObjectName, wantObjectName)
	}
	if row.ObjectType != nil {
		t.Errorf("objectType = %v, want nil (GS rows do not scope by it)", row.ObjectType)
	}
}
