package workflow

import (
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

// RemoveAccessLevelWorkflowParam carries the REMOVE request plus the identity
// recorded on the changelog rows.
type RemoveAccessLevelWorkflowParam struct {
	ClientID                    string
	Product                     model.Product
	ActorID                     int64
	ActorFullName               string
	UserIDs                     []int64
	AccessLevel                 model.AccessLevel
	AnalyticsReportingTaskQueue string
}

// RemoveAccessLevelActivityParam is the input of RemoveAccessLevelActivity.
type RemoveAccessLevelActivityParam struct {
	ClientID    string
	Product     model.Product
	ActorID     int64
	UserIDs     []int64
	AccessLevel model.AccessLevel
}

// AccessLevelRemoveOutcome is one user the activity actually removed: the
// target identity for the changelog row plus the tier that was deleted.
type AccessLevelRemoveOutcome struct {
	UserID             int64
	UserFullName       string
	RemovedAccessLevel model.AccessLevel
}

// RemoveAccessLevelActivityResult lists the removed users — a user with no
// tier row is a no-op and never appears here.
type RemoveAccessLevelActivityResult struct {
	Removed []AccessLevelRemoveOutcome
}

// RemoveAccessLevelWorkflow deletes the tier row and bulk-resets the six
// capability rows per removed user (each in its own transaction), then emits
// one Remove / Access Level changelog row per removed user through the
// analytics-reporting RecordChangeLogsWorkflow child.
func RemoveAccessLevelWorkflow(ctx workflow.Context, param RemoveAccessLevelWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (any, error) {
		var removed RemoveAccessLevelActivityResult
		if err := workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityRemoveAccessLevel,
			RemoveAccessLevelActivityParam{
				ClientID:    param.ClientID,
				Product:     param.Product,
				ActorID:     param.ActorID,
				UserIDs:     param.UserIDs,
				AccessLevel: param.AccessLevel,
			},
		).Get(activityCtx, &removed); err != nil {
			return nil, err
		}

		// Only the users actually removed (every other request entry is a no-op
		// or a guard rejection) had their rows changed — invalidate those.
		removedUserIDs := make([]int64, 0, len(removed.Removed))
		for _, outcome := range removed.Removed {
			removedUserIDs = append(removedUserIDs, outcome.UserID)
		}
		invalidateUserRoles(activityCtx, param.ClientID, removedUserIDs)

		var logs []arModel.Changelog
		for _, outcome := range removed.Removed {
			identity := changelogIdentity{
				ClientID:   param.ClientID,
				ActorID:    param.ActorID,
				ActorName:  param.ActorFullName,
				TargetID:   outcome.UserID,
				TargetName: outcome.UserFullName,
				Product:    arModel.Product(param.Product),
				TaskQueue:  param.AnalyticsReportingTaskQueue,
			}
			logs = append(logs, accessLevelRemoveChangelog(identity, outcome.RemovedAccessLevel))
		}
		spawnChangeLogWorkflow(ctx, changelogIdentity{
			ClientID:  param.ClientID,
			Product:   arModel.Product(param.Product),
			TaskQueue: param.AnalyticsReportingTaskQueue,
		}, logs)
		return nil, nil
	})
}
