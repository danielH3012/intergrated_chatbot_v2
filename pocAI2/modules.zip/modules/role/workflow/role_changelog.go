package workflow

import (
	"strconv"

	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	arDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
)

// Changelog row constants for the Role & Permission surface. One shared
// change_logs row is read by every audit surface: the Role & Permission modals
// filter logTable, Changelog: User filters objectId (role/01-overview.md §9.7,
// user/01-overview.md §8.7) — no row is ever duplicated.
const (
	roleChangelogObjectPrefix     = "Role & Permission > "
	roleChangelogObjectSystemRole = "System Role"

	// roleChangelogSeparator joins the capability and user names in the stored
	// objectName identifier (role/01-overview.md §9.4: the combined
	// "[Capability] — [User Name]" column is the stored identifier shared by
	// §9.3 and §9.4 — "kolom log ini memakai identifier tersimpan yang sama").
	roleChangelogSeparator = " — "

	// roleChangelogDash is the absent side of a value pair — "no previous
	// value" on create/assign, "no longer any value" on remove/auto-revert
	// (role/API/low-level-design.md §4 audit-write values).
	roleChangelogDash = "-"
)

// changelogIdentity is the subset of a workflow param the changelog child
// needs: which tenant the logs belong to, who changed it, which user it
// changed, and which product the rows belong to.
type changelogIdentity struct {
	ClientID   string
	ActorID    int64
	ActorName  string
	TargetID   int64
	TargetName string
	Product    arModel.Product
	TaskQueue  string
}

// baseChangelogRow fills the fields every Role & Permission row shares: the
// dynamic object and log table, the actor snapshot (never modified later by a rename),
// and the affected user as objectId/objectName. objectName is explicit because
// capability rows carry the combined "[Capability] — [User Name]" identifier
// while tier rows carry the user name alone. EntityID/EntityType are
// deliberately left empty on Role & Permission rows.
func baseChangelogRow(identity changelogIdentity, action arModel.ChangeLogAction, object, logTable, field, oldValue, newValue, objectName string) arModel.Changelog {
	objectID := strconv.FormatInt(identity.TargetID, 10)
	product := identity.Product
	return arModel.Changelog{
		Action:            action,
		Field:             &field,
		OldValue:          &oldValue,
		NewValue:          &newValue,
		LogTable:          logTable,
		CreatedById:       strconv.FormatInt(identity.ActorID, 10),
		CreatedBySnapshot: identity.ActorName,
		EntityID:          "",
		EntityType:        "",
		Product:           &product,
		Object:            roleChangelogObjectPrefix + object,
		ObjectId:          &objectID,
		ObjectName:        &objectName,
	}
}

// capabilityUserLabel builds the stored objectName of a capability row — the
// combined "[Capability] — [User Name]" identifier (role/01-overview.md §9.4).
// The capability display name is snapshotted at write time, so a later rename
// of the enum never rewrites history.
func capabilityUserLabel(capability model.SystemRoleName, userName string) string {
	return string(capability) + roleChangelogSeparator + userName
}

// displayPermission renders one CRUD flag with the changelog display literals
// — "Active"/"Inactive", never booleans (role/API/low-level-design.md §4).
func displayPermission(v bool) string {
	if v {
		return "Active"
	}
	return "Inactive"
}

// capabilityAssignChangelog is the [+ Add User] row (F-ROLE-03): exactly one
// Field=Access entry, "—" → "Assigned" (role/01-overview.md §9.4). A Read-locked
// create has no CRUD column that moved, so there is never an accompanying Edit
// row from this endpoint. The objectName carries the combined capability —
// user identifier.
func capabilityAssignChangelog(identity changelogIdentity, capability model.SystemRoleName) arModel.Changelog {
	return baseChangelogRow(identity, arModel.ChangeLogActionAssign,
		roleChangelogObjectSystemRole, string(capability), "Access", roleChangelogDash, "Assigned",
		capabilityUserLabel(capability, identity.TargetName))
}

// capabilityRemoveChangelog is the row-remove entry (F-ROLE-07): exactly one
// Field=Access entry, "Assigned" → "—", one per removed row (role/01-overview.md
// §9.4). The objectName carries the combined capability — user identifier, the
// same stored identifier the Assign row uses.
func capabilityRemoveChangelog(identity changelogIdentity, capability model.SystemRoleName) arModel.Changelog {
	return baseChangelogRow(identity, arModel.ChangeLogActionRemove,
		roleChangelogObjectSystemRole, string(capability), "Access", "Assigned", roleChangelogDash,
		capabilityUserLabel(capability, identity.TargetName))
}

// capabilityEditChangelogs builds one Edit row per CRUD column a PATCH
// actually changed (role/01-overview.md §9.3/§9.4: every changed CRUD column
// = 1 entry). Read is locked for the lifetime of the row — a supplied read
// flag is silently ignored (PRD Edge Case D5) — so it can never produce a row
// and is deliberately not compared.
func capabilityEditChangelogs(identity changelogIdentity, capability model.SystemRoleName, before dto.CapabilityUserRow, patch *dto.CapabilityPermissionPatch) []arModel.Changelog {
	if patch == nil {
		return nil
	}
	objectName := capabilityUserLabel(capability, identity.TargetName)
	var logs []arModel.Changelog
	check := func(permission string, before bool, after *bool) {
		if after != nil && *after != before {
			logs = append(logs, baseChangelogRow(identity, arModel.ChangeLogActionEdit,
				roleChangelogObjectSystemRole, string(capability), permission,
				displayPermission(before), displayPermission(*after),
				objectName))
		}
	}
	check("Create", before.PermissionCreate, patch.Create)
	check("Update", before.PermissionUpdate, patch.Update)
	check("Delete", before.PermissionDelete, patch.Delete)
	return logs
}

// accessLevelAssignChangelog is the assign entry (F-ROLE-04): exactly one
// Field=Access Level row per assign — not one per capability touched
// (role/API/low-level-design.md §4: "One row, not seven."). oldValue is "—"
// on a first assign, or the previous tier on an upgrade (Read Only → Total
// Control is one transition, not two actions). roleName is null — an access
// level is not a capability — so the objectName carries the user name alone.
func accessLevelAssignChangelog(identity changelogIdentity, level model.AccessLevel, previous *model.AccessLevel) arModel.Changelog {
	oldValue := roleChangelogDash
	if previous != nil {
		oldValue = accessLevelDisplay(*previous)
	}
	return baseChangelogRow(identity, arModel.ChangeLogActionAssign,
		accessLevelDisplay(level), accessLevelDisplay(level), "Access Level", oldValue, accessLevelDisplay(level),
		identity.TargetName)
}

// accessLevelRemoveChangelog is the remove entry (F-ROLE-05): exactly one
// Field=Access Level row per removed user, old = the tier being removed,
// new = "—" (role/API/low-level-design.md §4).
func accessLevelRemoveChangelog(identity changelogIdentity, level model.AccessLevel) arModel.Changelog {
	display := accessLevelDisplay(level)
	return baseChangelogRow(identity, arModel.ChangeLogActionRemove,
		display, display, "Access Level", display, roleChangelogDash,
		identity.TargetName)
}

// accessLevelDisplay is the changelog literal of a tier ("Total Control" /
// "Read Only"), used as both the action suffix and the old value.
func accessLevelDisplay(level model.AccessLevel) string {
	switch level {
	case model.AccessLevelTotalControl:
		return "Total Control"
	case model.AccessLevelReadOnly:
		return "Read Only"
	default:
		return string(level)
	}
}

// autoRevertChangelog is the tier-row deletion side-effect of an Edit that no
// longer matches the held tier's pattern (F-ROLE-06): 1 entry Field=Access
// Level, Old = the tier, New = "—", surfaced at §9.1/§9.2 and Changelog: User —
// not at §9.3/§9.4 (§9.7). Modified By is the admin who made the edit, never
// "System". The objectName is the user name alone — the §9.1/§9.2 tables have
// no Capability column.
func autoRevertChangelog(identity changelogIdentity, level model.AccessLevel) arModel.Changelog {
	display := accessLevelDisplay(level)
	return baseChangelogRow(identity,
		arModel.ChangeLogAction("Auto-Revert "+display),
		display, display, "Access Level", display, roleChangelogDash,
		identity.TargetName)
}

// spawnChangeLogWorkflow hands the rows to the analytics-reporting
// RecordChangeLogsWorkflow child without waiting for it. The child is spawned
// with ABANDON parent-close policy and runs on the AR task queue, where its
// own unbounded retry (see analytics-reporting's RecordChangeLogsWorkflow)
// delivers the rows at-least-once even across an AR outage. Failing to spawn
// logs and returns — the DB write must not roll back because the audit sink is
// down (role/API/low-level-design.md §4: audit write does not roll back the
// assignment).
func spawnChangeLogWorkflow(ctx workflow.Context, identity changelogIdentity, logs []arModel.Changelog) {
	if len(logs) == 0 {
		return
	}
	opts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, "", identity.TaskQueue)
	childCtx := workflow.WithChildOptions(ctx, opts)
	future := workflow.ExecuteChildWorkflow(
		childCtx,
		tsConstant.AnalyticsReportingRecordChangeLogsWorkflow,
		arDto.CreateChangeLogActivityParam{
			ClientID:   identity.ClientID,
			ChangeLogs: logs,
		},
	)
	var childExecution workflow.Execution
	if err := future.GetChildWorkflowExecution().Get(ctx, &childExecution); err != nil {
		workflow.GetLogger(ctx).Error("failed to spawn changelog child workflow", "error", err)
	}
}
