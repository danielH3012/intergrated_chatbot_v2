package role

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/service"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
)

func SetupRoutes(app *fiber.App, svc *service.RoleService) {
	h := handler.NewRoleHandler(svc)
	group := app.Group("/products/:product/roles")

	group.Post("/access-level/list", rbac.Require(productSeeAll()), h.HandleListAccessLevelUsers)
	group.Post("/access-level/export", rbac.Require(productSeeAll()), h.HandleExportAccessLevelUsers)
	group.Post("/access-level/options", rbac.Require(productSeeAll()), h.HandleGetAccessLevelOptions)
	group.Post("/capabilities/list", rbac.Require(productSeeAll()), h.HandleListCapabilities)
	group.Post("/capabilities/export", rbac.Require(productSeeAll()), h.HandleExportCapabilities)
	group.Post("/capabilities/users/list", rbac.Require(productSeeAll()), h.HandleListCapabilityUsers)
	group.Post("/capabilities/users/export", rbac.Require(productSeeAll()), h.HandleExportCapabilityUsers)
	group.Post("/capabilities/users/options", rbac.Require(productSeeAll()), h.HandleGetCapabilityUsersOptions)
	group.Post("/assignable-users/list", rbac.Require(productSeeAll()), h.HandleListAssignableUsers)
	group.Post("/assignable-users/options", rbac.Require(productSeeAll()), h.HandleGetAssignableUsersOptions)

	group.Post("/capabilities/users", rbac.Require(productRoleCreate()), h.HandleAddCapabilityUser)
	group.Patch("/capabilities/users/:user_id", rbac.Require(productRoleEdit()), h.HandlePatchCapabilityUser)
	group.Delete("/capabilities/users", rbac.Require(productRoleEdit()), h.HandleDeleteCapabilityUsers)

	group.Post("/access-level", rbac.Require(productTotalControl()), h.HandleAssignAccessLevel)
	group.Delete("/access-level", rbac.Require(productTotalControl()), h.HandleRemoveAccessLevel)
}

// productModule maps the {product} path enum to the module key the RBAC
// snapshot is keyed by. The scope is read from the path — never from a body or
// query field, which would be a client-chosen scope (OWASP API1:2023).
func productModule(product string) (enum.ModuleAccess, bool) {
	return service.ProductModule(model.Product(product))
}

// productSeeAll passes for total-control, read-only, and "Manage user and
// role" view holders of the product (PRD §2.4 — the module is visible to all
// three).
func productSeeAll() rbac.Rule {
	return func(c fiber.Ctx, roles tsMiddleware.UserAccessCache) (bool, error) {
		module, ok := productModule(c.Params("product"))
		if !ok {
			return false, nil
		}
		return roles.IsTotalControl(module) ||
			roles.IsReadOnly(module) ||
			hasManageUserAndRole(roles, module, tsMiddleware.PermView), nil
	}
}

// productTotalControl passes for a total-control admin only — the access-level
// assign/remove surface, which no capability holder may touch. [AI-GENERATED]
func productTotalControl() rbac.Rule {
	return func(c fiber.Ctx, roles tsMiddleware.UserAccessCache) (bool, error) {
		module, ok := productModule(c.Params("product"))
		if !ok {
			return false, nil
		}
		return roles.IsTotalControl(module), nil
	}
}

// productRoleCreate passes for the capability-user ADD surface: total
// control, or a "Manage user and role" holder with Create.
func productRoleCreate() rbac.Rule {
	return func(c fiber.Ctx, roles tsMiddleware.UserAccessCache) (bool, error) {
		module, ok := productModule(c.Params("product"))
		if !ok {
			return false, nil
		}
		if roles.IsTotalControl(module) {
			return true, nil
		}
		return hasManageUserAndRole(roles, module, tsMiddleware.PermCreate), nil
	}
}

// productRoleEdit passes for the capability-user edit surface: total control,
// or a "Manage user and role" holder with Update.
func productRoleEdit() rbac.Rule {
	return func(c fiber.Ctx, roles tsMiddleware.UserAccessCache) (bool, error) {
		module, ok := productModule(c.Params("product"))
		if !ok {
			return false, nil
		}
		if roles.IsTotalControl(module) {
			return true, nil
		}
		return hasManageUserAndRole(roles, module, tsMiddleware.PermEdit), nil
	}
}

// hasManageUserAndRole evaluates the "Manage user and role" capability within
// the module keyed to the path product — a fixed-asset grant can never satisfy
// a global-settings gate.
func hasManageUserAndRole(roles tsMiddleware.UserAccessCache, module enum.ModuleAccess, verb tsMiddleware.PermissionVerb) bool {
	switch module {
	case enum.ModuleAccessGlobalSettings:
		return roles.HasGlobalSettingsPermission(enum.SystemRoleKeyManageUserAndRole, verb)
	case enum.ModuleAccessAdminConsole:
		return roles.HasSystemPermissionAdminConsole(enum.SystemRoleKeyManageUserAndRole, verb)
	case enum.ModuleAccessFixedAsset:
		return roles.HasSystemPermissionFixedAsset(enum.SystemRoleKeyManageUserAndRole, verb)
	default:
		return false
	}
}
