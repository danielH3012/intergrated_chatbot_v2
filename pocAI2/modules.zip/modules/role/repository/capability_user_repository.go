package repository

import (
	"context"
	"errors"
	"fmt"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/query_builder"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"github.com/jackc/pgx/v5"
)

// ListCapabilityUsers returns the paginated Detail Capability table.
func (r *RoleRepository) ListCapabilityUsers(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersListResponse, error) {
	query, args, err := query_builder.CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](product, key, q)
	if err != nil {
		return nil, err
	}

	var result []dto.CapabilityUsersListResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListCapabilityUsers: %w", err)
	}

	return new(coreHelper.FormatPaginationResult(result)), nil
}

func (r *RoleRepository) ListCapabilityUsersAll(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) ([]dto.CapabilityUsersListItem, error) {
	query, args, err := query_builder.CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](product, key, q, false)
	if err != nil {
		return nil, err
	}
	rows := []dto.CapabilityUsersListItem{}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListCapabilityUsersAll: %w", err)
	}
	return rows, nil
}

// GetCapabilityUsersOptions returns the five Detail Capability option lists.
func (r *RoleRepository) GetCapabilityUsersOptions(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersOptionsResponse, error) {
	query, args, err := query_builder.CapabilityUsersOptionsQueryBuilder[any](product, key, q)
	if err != nil {
		return nil, err
	}

	var result []dto.CapabilityUsersOptionsResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.GetCapabilityUsersOptions: %w", err)
	}
	if len(result) > 0 {
		return &result[0], nil
	}
	return &dto.CapabilityUsersOptionsResponse{
		PositionOptions:            []util_dto.InterfaceOptionDTO{},
		DivisionOptions:            []util_dto.InterfaceOptionDTO{},
		ActivationStatusOptions:    []util_dto.InterfaceOptionDTO{},
		TemporaryStatusOptions:     []util_dto.InterfaceOptionDTO{},
		AuthenticatorStatusOptions: []util_dto.InterfaceOptionDTO{},
	}, nil
}

// GetCapabilityUserRow is the PATCH's guard read: the assignment row joined to
// the user facts the guards need (is_default, full_name).
func (r *RoleRepository) GetCapabilityUserRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userID int64) (*dto.CapabilityUserRow, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[dto.CapabilityUserRow](db.UserSystemRoleTableName).
		Join(db.UserTableName, "users.id = user_system_roles.user_id").
		Where(sql_query.WhereQuery{
			"user_system_roles.product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_system_roles.key":         {Operator: sql_query.SQLOperatorEqual, Value: key},
			"user_system_roles.user_id":     {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"user_system_roles.scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row dto.CapabilityUserRow
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.GetCapabilityUserRow: %w", err)
	}
	return &row, nil
}

// ListUserCapabilityRows returns the target's global capability rows for the
// product — the six-row set the tier-pattern check runs over. Rows are absent
// for capabilities the user never received; absence means non-matching.
func (r *RoleRepository) ListUserCapabilityRows(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) ([]model.UserSystemRole, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.UserSystemRole](db.UserSystemRoleTableName).
		Where(sql_query.WhereQuery{
			"user_system_roles.product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_system_roles.user_id":     {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"user_system_roles.scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
		}).
		Build()
	if err != nil {
		return nil, err
	}

	var rows []model.UserSystemRole
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListUserCapabilityRows: %w", err)
	}
	return rows, nil
}

// GetUserAccessLevelRow returns the target's tier row for the product, if any.
func (r *RoleRepository) GetUserAccessLevelRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) (*model.UserAccessLevel, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.UserAccessLevel](db.UserAccessLevelTableName).
		Where(sql_query.WhereQuery{
			"user_access_levels.product": {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_access_levels.user_id": {Operator: sql_query.SQLOperatorEqual, Value: userID},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.UserAccessLevel
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, err
		}
		return nil, fmt.Errorf("role.GetUserAccessLevelRow: %w", err)
	}
	return &row, nil
}

// GetUserAssignmentEligibility is the ADD endpoint's pool re-validation: the
// user row plus whether access for the product exists.
func (r *RoleRepository) GetUserAssignmentEligibility(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) (*dto.UserAssignmentEligibility, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[dto.UserAssignmentEligibility](db.UserTableName).
		LeftJoin(db.UserModuleStatusTableName, "user_module_status.user_id = users.id", sql_query.WhereQuery{
			"user_module_status.module_key": {Operator: sql_query.SQLOperatorEqual, Value: product},
		}).
		Where(sql_query.WhereQuery{
			"users.id":         {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"users.deleted_at": {Operator: sql_query.SQLOperatorIsNull},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row dto.UserAssignmentEligibility
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.GetUserAssignmentEligibility: %w", err)
	}
	return &row, nil
}

// AddCapabilityUser inserts the new user_system_roles row. The caller maps a
// unique violation to 409.
func (r *RoleRepository) AddCapabilityUser(ctx context.Context, svc coreService.PostgreSQLServicer, row model.UserSystemRole) error {
	if _, err := svc.InsertOneWithData(ctx, db.UserSystemRoleTableName, row); err != nil {
		return fmt.Errorf("role.AddCapabilityUser: %w", err)
	}
	return nil
}

// PatchCapabilityUserRow updates the assignment row with the supplied column
// set. The body always carries modified_by and updated_at.
func (r *RoleRepository) PatchCapabilityUserRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userID int64, body sql_query.UpdateQuery) error {
	if _, err := svc.UpdateOneWithData(
		ctx,
		db.UserSystemRoleTableName,
		sql_query.WhereQuery{
			"product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"key":         {Operator: sql_query.SQLOperatorEqual, Value: key},
			"user_id":     {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
		},
		body,
	); err != nil {
		return fmt.Errorf("role.PatchCapabilityUserRow: %w", err)
	}
	return nil
}

// DeleteUserAccessLevelRow removes the target's tier row — the auto-revert. [AI-GENERATED]
func (r *RoleRepository) DeleteUserAccessLevelRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) error {
	if _, err := svc.DeleteManyWithFilter(
		ctx,
		db.UserAccessLevelTableName,
		sql_query.WhereQuery{
			"product": {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_id": {Operator: sql_query.SQLOperatorEqual, Value: userID},
		},
	); err != nil {
		return fmt.Errorf("role.DeleteUserAccessLevelRow: %w", err)
	}
	return nil
}
