package repository

import (
	"context"
	"fmt"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/query_builder"
	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// ListAssignableUsers returns the paginated assignable picker pool.
func (r *RoleRepository) ListAssignableUsers(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersListResponse, error) {
	query, args, err := query_builder.AssignableUsersListQueryBuilder[dto.AssignableUsersListItem](product, q)
	if err != nil {
		return nil, err
	}

	var result []dto.AssignableUsersListResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListAssignableUsers: %w", err)
	}

	return new(coreHelper.FormatPaginationResult(result)), nil
}

// GetAssignableUsersOptions returns the three picker option lists over the
// same gated and excluded pool as the paired list call.
func (r *RoleRepository) GetAssignableUsersOptions(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersOptionsResponse, error) {
	query, args, err := query_builder.AssignableUsersOptionsQueryBuilder[any](product, q)
	if err != nil {
		return nil, err
	}

	var result []dto.AssignableUsersOptionsResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.GetAssignableUsersOptions: %w", err)
	}
	if len(result) > 0 {
		return &result[0], nil
	}
	return &dto.AssignableUsersOptionsResponse{
		PositionOptions:         []util_dto.InterfaceOptionDTO{},
		DivisionOptions:         []util_dto.InterfaceOptionDTO{},
		StatusOptions:           []util_dto.InterfaceOptionDTO{},
		ActivationStatusOptions: []util_dto.InterfaceOptionDTO{},
		TemporaryStatusOptions:  []util_dto.InterfaceOptionDTO{},
	}, nil
}
