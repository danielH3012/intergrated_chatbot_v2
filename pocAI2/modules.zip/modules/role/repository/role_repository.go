package repository

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// RoleRepositor abstracts the Role & Permission queries, grouped by surface:
// access-level tabs, the Detail Capability table, and the assignable picker.
//
// [AI-GENERATED]
type RoleRepositor interface {
	ListAccessLevelUsers(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AccessLevelListQuery) (*dto.AccessLevelListResponse, error)
	ListAccessLevelUsersAll(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AccessLevelListQuery) ([]dto.AccessLevelListItem, error)
	GetAccessLevelOptions(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AccessLevelListQuery) (*dto.AccessLevelOptionsResponse, error)
	ListCapabilities(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) (*dto.CapabilitiesListResponse, error)
	ListCapabilitiesAll(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) ([]dto.CapabilitiesListItem, error)

	// Detail Capability surface (POST /capabilities/users/list + /options).
	ListCapabilityUsers(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersListResponse, error)
	ListCapabilityUsersAll(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) ([]dto.CapabilityUsersListItem, error)
	GetCapabilityUsersOptions(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersOptionsResponse, error)

	// Assignable picker surface (POST /assignable-users/list + /options).
	ListAssignableUsers(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersListResponse, error)
	GetAssignableUsersOptions(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersOptionsResponse, error)

	// Write surface (POST + PATCH /capabilities/users).
	GetCapabilityUserRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userID int64) (*dto.CapabilityUserRow, error)
	ListUserCapabilityRows(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) ([]model.UserSystemRole, error)
	GetUserAccessLevelRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) (*model.UserAccessLevel, error)
	GetUserAssignmentEligibility(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) (*dto.UserAssignmentEligibility, error)
	AddCapabilityUser(ctx context.Context, svc coreService.PostgreSQLServicer, row model.UserSystemRole) error
	PatchCapabilityUserRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userID int64, body sql_query.UpdateQuery) error
	DeleteUserAccessLevelRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) error

	// Access-level assign/remove surface (POST + DELETE /access-level).
	UpsertAccessLevel(ctx context.Context, svc coreService.PostgreSQLServicer, row model.UserAccessLevel) error
	UpsertCapabilityRows(ctx context.Context, svc coreService.PostgreSQLServicer, rows []model.UserSystemRole) error
	DeleteCapabilityRows(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) error

	// Capability remove surface (DELETE /capabilities/users).
	ListCapabilityUserRows(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userIDs []int64) ([]dto.CapabilityUserRow, error)
	DeleteCapabilityUserRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userID int64) error
}

var _ RoleRepositor = (*RoleRepository)(nil)

type RoleRepository struct{}

func NewRoleRepository() *RoleRepository {
	return &RoleRepository{}
}
