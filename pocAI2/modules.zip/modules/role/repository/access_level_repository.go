// Package repository constructs and executes the Role & Permission queries.
package repository

import (
	"context"
	"fmt"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/query_builder"
	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *RoleRepository) ListAccessLevelUsers(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AccessLevelListQuery) (*dto.AccessLevelListResponse, error) {
	query, args, err := query_builder.AccessLevelListQueryBuilder[dto.AccessLevelListItem](product, q)
	if err != nil {
		return nil, err
	}

	var result []dto.AccessLevelListResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListAccessLevelUsers: %w", err)
	}

	return new(coreHelper.FormatPaginationResult(result)), nil
}

func (r *RoleRepository) ListAccessLevelUsersAll(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AccessLevelListQuery) ([]dto.AccessLevelListItem, error) {
	query, args, err := query_builder.AccessLevelListQueryBuilder[dto.AccessLevelListItem](product, q, false)
	if err != nil {
		return nil, err
	}
	rows := []dto.AccessLevelListItem{}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListAccessLevelUsersAll: %w", err)
	}
	return rows, nil
}

func (r *RoleRepository) ListCapabilities(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) (*dto.CapabilitiesListResponse, error) {
	query, args, err := query_builder.CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](product, q)
	if err != nil {
		return nil, err
	}

	var result []dto.CapabilitiesListResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListCapabilities: %w", err)
	}

	return new(coreHelper.FormatPaginationResult(result)), nil
}

func (r *RoleRepository) ListCapabilitiesAll(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) ([]dto.CapabilitiesListItem, error) {
	query, args, err := query_builder.CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](product, q, false)
	if err != nil {
		return nil, err
	}
	rows := []dto.CapabilitiesListItem{}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListCapabilitiesAll: %w", err)
	}
	return rows, nil
}

func (r *RoleRepository) GetAccessLevelOptions(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, q dto.AccessLevelListQuery) (*dto.AccessLevelOptionsResponse, error) {
	query, args, err := query_builder.AccessLevelOptionsQueryBuilder[any](product, q)
	if err != nil {
		return nil, err
	}

	var result []dto.AccessLevelOptionsResponse
	if err := svc.SelectMany(&result, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.GetAccessLevelOptions: %w", err)
	}
	if len(result) > 0 {
		return &result[0], nil
	}
	return &dto.AccessLevelOptionsResponse{
		PositionOptions:            []util_dto.InterfaceOptionDTO{},
		DivisionOptions:            []util_dto.InterfaceOptionDTO{},
		ModifiedByOptions:          []util_dto.InterfaceOptionDTO{},
		StatusOptions:              []util_dto.InterfaceOptionDTO{},
		ActivationStatusOptions:    []util_dto.InterfaceOptionDTO{},
		TemporaryStatusOptions:     []util_dto.InterfaceOptionDTO{},
		AuthenticatorStatusOptions: []util_dto.InterfaceOptionDTO{},
	}, nil
}
