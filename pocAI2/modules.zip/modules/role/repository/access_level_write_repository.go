package repository

import (
	"context"
	"fmt"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// UpsertAccessLevel writes the target's tier row for the product, creating it
// on first assign and updating it on re-assign (ON CONFLICT (user_id,
// product)). The unique pair is the tier grain — one row per user per product.
func (r *RoleRepository) UpsertAccessLevel(ctx context.Context, svc coreService.PostgreSQLServicer, row model.UserAccessLevel) error {
	query := `INSERT INTO user_access_levels (id, user_id, product, access_level, modified_by, created_at, updated_at)
VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
ON CONFLICT (user_id, product) DO UPDATE SET
    access_level = EXCLUDED.access_level,
    modified_by = EXCLUDED.modified_by,
    updated_at = NOW()
RETURNING id`
	if _, err := svc.InsertOne(ctx, query, row.ID, row.UserID, row.Product, row.AccessLevel, row.ModifiedBy); err != nil {
		return fmt.Errorf("role.UpsertAccessLevel: %w", err)
	}
	return nil
}

// UpsertCapabilityRows bulk-writes the six tier-pattern capability rows. Rows
// that already exist are updated in place (their Snowflake id is preserved);
// rows that do not are inserted. The conflict target mirrors the
// user_system_roles_grant_uniq constraint — (user_id, product, key, both group
// columns) — with NULLS NOT DISTINCT semantics, which is exactly how the
// constraint treats the NULL group columns of a global row.
func (r *RoleRepository) UpsertCapabilityRows(ctx context.Context, svc coreService.PostgreSQLServicer, rows []model.UserSystemRole) error {
	if len(rows) == 0 {
		return nil
	}
	var sb strings.Builder
	sb.WriteString(`INSERT INTO user_system_roles (id, user_id, product, scope_level, key, permission_view, permission_create, permission_update, permission_delete, fixed_asset_group_id, admin_console_group_id, modified_by, created_at, updated_at) VALUES `)
	args := make([]any, 0, len(rows)*12)
	for i, row := range rows {
		if i > 0 {
			sb.WriteString(", ")
		}
		n := len(args)
		fmt.Fprintf(&sb, "($%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, NOW(), NOW())",
			n+1, n+2, n+3, n+4, n+5, n+6, n+7, n+8, n+9, n+10, n+11, n+12)
		args = append(args,
			row.ID, row.UserID, row.Product, row.ScopeLevel, row.Key,
			row.PermissionView, row.PermissionCreate, row.PermissionUpdate, row.PermissionDelete,
			row.FixedAssetGroupID, row.AdminConsoleGroupID, row.ModifiedBy,
		)
	}
	sb.WriteString(` ON CONFLICT (user_id, product, key, fixed_asset_group_id, admin_console_group_id) DO UPDATE SET
    permission_view = EXCLUDED.permission_view,
    permission_create = EXCLUDED.permission_create,
    permission_update = EXCLUDED.permission_update,
    permission_delete = EXCLUDED.permission_delete,
    modified_by = EXCLUDED.modified_by,
    updated_at = NOW()`)
	if _, err := svc.InsertMany(ctx, sb.String(), args...); err != nil {
		return fmt.Errorf("role.UpsertCapabilityRows: %w", err)
	}
	return nil
}

// DeleteCapabilityRows bulk-deletes every global capability row of the target
// for the product — the Remove access level side-effect that turns the user
// into "user basic" (no Global Settings access at all, PRD F-ROLE-05: the rows
// are deleted, not reset). The audit trail lives in the change_logs row written
// right after; the deleted rows carry no modified_by of their own.
func (r *RoleRepository) DeleteCapabilityRows(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, userID int64) error {
	if _, err := svc.DeleteManyWithFilter(
		ctx,
		db.UserSystemRoleTableName,
		sql_query.WhereQuery{
			"product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_id":     {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
		},
	); err != nil {
		return fmt.Errorf("role.DeleteCapabilityRows: %w", err)
	}
	return nil
}

// ListCapabilityUserRows returns the assignment rows of the remove surface for
// a set of target users: the row joined to the user facts the per-row guards
// need (full_name for the changelog snapshot, is_default for the default-user
// guard). Users without a row for this key are simply absent from the result.
func (r *RoleRepository) ListCapabilityUserRows(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userIDs []int64) ([]dto.CapabilityUserRow, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[dto.CapabilityUserRow](db.UserSystemRoleTableName).
		Join(db.UserTableName, "users.id = user_system_roles.user_id").
		Where(sql_query.WhereQuery{
			"user_system_roles.product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"user_system_roles.key":         {Operator: sql_query.SQLOperatorEqual, Value: key},
			"user_system_roles.scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
			"user_system_roles.user_id":     {Operator: sql_query.SQLOperatorIn, Value: userIDs},
		}).
		Build()
	if err != nil {
		return nil, err
	}

	var rows []dto.CapabilityUserRow
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, fmt.Errorf("role.ListCapabilityUserRows: %w", err)
	}
	return rows, nil
}

// DeleteCapabilityUserRow hard-deletes one global capability assignment — the
// only way to release a capability (Read is locked while the row exists).
func (r *RoleRepository) DeleteCapabilityUserRow(ctx context.Context, svc coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, userID int64) error {
	if _, err := svc.DeleteManyWithFilter(
		ctx,
		db.UserSystemRoleTableName,
		sql_query.WhereQuery{
			"product":     {Operator: sql_query.SQLOperatorEqual, Value: product},
			"key":         {Operator: sql_query.SQLOperatorEqual, Value: key},
			"user_id":     {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"scope_level": {Operator: sql_query.SQLOperatorEqual, Value: model.ScopeLevelGlobal},
		},
	); err != nil {
		return fmt.Errorf("role.DeleteCapabilityUserRow: %w", err)
	}
	return nil
}
