// Package constant holds the Temporal workflow/activity names the Role &
// Permission module dispatches by. The method names are the names the worker
// registers and the workflows execute by, so they must not change without
// re-registering both sides.
package constant

const (
	// Workflows run on the iam-service task queue.
	WorkflowAddCapabilityUser     = "AddCapabilityUserWorkflow"
	WorkflowPatchCapabilityUser   = "PatchCapabilityUserWorkflow"
	WorkflowAssignAccessLevel     = "AssignAccessLevelWorkflow"
	WorkflowRemoveAccessLevel     = "RemoveAccessLevelWorkflow"
	WorkflowRemoveCapabilityUsers = "RemoveCapabilityUsersWorkflow"

	// Activities run on the iam-service task queue.
	ActivityAddCapabilityUser     = "AddCapabilityUserActivity"
	ActivityPatchCapabilityUser   = "PatchCapabilityUserActivity"
	ActivityAssignAccessLevel     = "AssignAccessLevelActivity"
	ActivityRemoveAccessLevel     = "RemoveAccessLevelActivity"
	ActivityRemoveCapabilityUsers = "RemoveCapabilityUsersActivity"

	// ActivityInvalidateUserRoles drops the RBAC snapshots of the users a
	// write workflow just changed — every role write runs it after its write
	// activity committed (24h TTL is only the backstop).
	ActivityInvalidateUserRoles = "InvalidateUserRolesActivity"
)
