package dto

import "time"

type ExportAccessLevelRequest struct {
	AccessLevelListQuery
	Format string `json:"format" validate:"omitempty,oneof=csv xlsx"`
}

func (r *ExportAccessLevelRequest) Defaults() {
	if r.Page == 0 {
		r.Page = 1
	}
	if r.Format == "" {
		r.Format = "xlsx"
	}
}

type ExportCapabilitiesRequest struct {
	CapabilitiesListQuery
	Format string `json:"format" validate:"omitempty,oneof=csv xlsx"`
}

func (r *ExportCapabilitiesRequest) Defaults() {
	if r.Format == "" {
		r.Format = "xlsx"
	}
}

type ExportCapabilityUsersRequest struct {
	CapabilityUsersListQuery
	Format string `json:"format" validate:"omitempty,oneof=csv xlsx"`
}

func (r *ExportCapabilityUsersRequest) Defaults() {
	if r.Format == "" {
		r.Format = "xlsx"
	}
}

// Export rows deliberately contain only the columns exposed by the role UI.
type AccessLevelExportItem struct {
	Name             string     `export:"Name"`
	Position         *string    `export:"Position"`
	Division         *string    `export:"Division"`
	Status           string     `export:"Status"`
	ActivationStatus string     `export:"Activation Status"`
	TemporaryUser    string     `export:"Temporary User"`
	TemporaryUntil   *time.Time `export:"Temporary Until"`
	Tag              *string    `export:"TAG"`
	ModifiedBy       *string    `export:"Modified By"`
	LastUpdated      *time.Time `export:"Last Updated"`
}

type CapabilitiesExportItem struct {
	CapabilityName string `export:"Capability Name"`
	Users          int    `export:"Users"`
}

type CapabilityUsersExportItem struct {
	Name             string     `export:"Name"`
	Position         *string    `export:"Position"`
	Division         *string    `export:"Division"`
	Create           bool       `export:"Create"`
	Read             bool       `export:"Read"`
	Update           bool       `export:"Update"`
	Delete           bool       `export:"Delete"`
	ActivationStatus string     `export:"Activation Status"`
	TemporaryUser    string     `export:"Temporary User"`
	TemporaryUntil   *time.Time `export:"Temporary Until"`
	Tag              *string    `export:"TAG"`
}
