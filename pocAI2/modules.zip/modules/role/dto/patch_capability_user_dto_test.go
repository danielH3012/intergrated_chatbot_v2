package dto

import "testing"

// TestCapabilityPermissionPatchLockRead pins the read-lock contract: the
// effective read flag is always true once LockRead runs, whatever the payload
// carried (PRD Edge Case Matrix D5 / TC-GS-ROLE-34).
func TestCapabilityPermissionPatchLockRead(t *testing.T) {
	readFalse := false
	readTrue := true
	create := false

	cases := []struct {
		name  string
		patch *CapabilityPermissionPatch
		want  *bool // expected Read after LockRead
	}{
		{"false supplied is forced to true", &CapabilityPermissionPatch{Read: &readFalse}, &readTrue},
		{"true stays true", &CapabilityPermissionPatch{Read: &readTrue}, &readTrue},
		{"absent stays absent", &CapabilityPermissionPatch{}, nil},
		{"nil patch is a no-op", nil, nil},
		{"C/U/D flags untouched", &CapabilityPermissionPatch{Read: &readFalse, Create: &create}, &readTrue},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			tc.patch.LockRead()
			if tc.patch == nil {
				return
			}
			if tc.want == nil {
				if tc.patch.Read != nil {
					t.Fatalf("Read = %v, want nil", *tc.patch.Read)
				}
				return
			}
			if tc.patch.Read == nil || *tc.patch.Read != *tc.want {
				t.Fatalf("Read = %v, want %v", tc.patch.Read, *tc.want)
			}
		})
	}

	if create != false {
		t.Fatal("LockRead must not touch the C/U/D flags")
	}
}
