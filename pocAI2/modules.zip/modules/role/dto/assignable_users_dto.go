package dto

import (
	"time"

	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
)

// Assignable tier exclusion values accepted by the picker endpoints. The
// exclusion is evaluated against user_access_levels for the {product} in the
// path; it never widens the base pool gate.
const (
	ExcludeTierTotalControl = "total_control"
	ExcludeTierReadOnly     = "read_only"
	ExcludeTierBoth         = "both"
	ExcludeTierNone         = "none"
)

// AssignableUsersListQuery is the request of
// POST /products/:product/roles/assignable-users/list.
type AssignableUsersListQuery struct {
	Page        int      `json:"page"        transform:"int" validate:"omitempty,min=1"`
	Limit       int      `json:"limit"       transform:"int" validate:"omitempty,min=0,max=100"`
	Search      string   `json:"search"      transform:"string"`
	Position    []string `json:"position"    transform:"array"`
	Division    []string `json:"division"    transform:"array"`
	Status      []string `json:"status"      transform:"array"`
	ExcludeTier string   `json:"excludeTier" transform:"string"`
	ExcludeKey  string   `json:"excludeKey"  transform:"string"`

	ActivationStatus  []string `json:"activationStatus"  transform:"array"`
	TemporaryStatus   []string `json:"temporaryStatus"   transform:"array"`
	ActivePeriodUntil []int64  `json:"activePeriodUntil" transform:"array"`

	// Options flags — the options endpoint reuses this DTO's exclusions.
	PositionOptions         bool `json:"positionOptions"         transform:"bool"`
	DivisionOptions         bool `json:"divisionOptions"         transform:"bool"`
	StatusOptions           bool `json:"statusOptions"           transform:"bool"`
	ActivationStatusOptions bool `json:"activationStatusOptions" transform:"bool"`
	TemporaryStatusOptions  bool `json:"temporaryStatusOptions"  transform:"bool"`
}

// AssignableUsersListItem is one row of the [+ Assign] / [+ Add User] picker.
type AssignableUsersListItem struct {
	ID                string     `json:"_id"              column:"tend.id::text"`
	FullName          string     `json:"fullName"         column:"tend.full_name"`
	ProfilePicture    *string    `json:"profilePicture"   column:"tend.profile_picture"`
	Email             string     `json:"email"            column:"tend.email"`
	EmployeeID        *string    `json:"employeeId"       column:"tend.employee_id"`
	Position          *string    `json:"position"         column:"tend.position"`
	Division          *string    `json:"division"         column:"tend.division"`
	IsActive          bool       `json:"isActive"          column:"tend.is_active"`
	ActivationStatus  string     `json:"activationStatus"  column:"tend.activation_status"`
	TemporaryStatus   string     `json:"temporaryStatus"   column:"tend.temporary_status"`
	ActivePeriodUntil *time.Time `json:"activePeriodUntil" column:"tend.active_period_until"`
	TagCode           *string    `json:"tagCode"           column:"tend.tag_code"`
}

// AssignableUsersListResponse is the paginated envelope of the picker list.
type AssignableUsersListResponse = util_dto.PaginationResult[AssignableUsersListItem]

// AssignableUsersOptionsResponse carries the three picker filter option lists.
type AssignableUsersOptionsResponse struct {
	PositionOptions         []util_dto.InterfaceOptionDTO `json:"positionOptions"`
	DivisionOptions         []util_dto.InterfaceOptionDTO `json:"divisionOptions"`
	StatusOptions           []util_dto.InterfaceOptionDTO `json:"statusOptions"`
	ActivationStatusOptions []util_dto.InterfaceOptionDTO `json:"activationStatusOptions"`
	TemporaryStatusOptions  []util_dto.InterfaceOptionDTO `json:"temporaryStatusOptions"`
}
