// Package dto carries the wire shapes of the Role & Permission surface.
package dto

import (
	"time"

	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
)

// Access level values accepted by the Total Control / Read Only tabs.
const (
	AccessLevelTotalControl = "total_control"
	AccessLevelReadOnly     = "read_only"
)

// Display values for the curated Status column (backed by
// user_module_status.is_active) and its filter dropdown.
const (
	StatusActive   = "Active"
	StatusInactive = "Inactive"
)

// Display values for the curated Activation Status column and its filter
// dropdown. Pending Email Confirmation is not a fourth users.activation_status
// value — it is the sub-state "Activated with a live pending email change".
//
// [AI-GENERATED]
const (
	ActivationPendingActivation = "Pending Activation"
	ActivationActivated         = "Activated"
	ActivationPendingEmail      = "Pending Email Confirmation"
)

// AccessLevelListQuery is the request of POST /products/:product/roles/access-level/list.
type AccessLevelListQuery struct {
	Page                       int      `json:"page"                           transform:"int" validate:"min=1"`
	Limit                      int      `json:"limit"                          transform:"int" validate:"min=0,max=100"`
	Search                     string   `json:"search"                         transform:"string"`
	SortBy                     string   `json:"sortBy"                         transform:"string"`
	SortOrder                  int      `json:"sortOrder"                      transform:"int"`
	Columns                    []string `json:"columns"                        transform:"array"`
	UpdatedAt                  []int64  `json:"updatedAt"                      transform:"array"`
	Position                   []string `json:"position"                       transform:"array"`
	Division                   []string `json:"division"                       transform:"array"`
	ModifiedBy                 []string `json:"modifiedBy"                     transform:"array"`
	Status                     []string `json:"status"                         transform:"array"`
	ActivationStatus           []string `json:"activationStatus"               transform:"array"`
	TemporaryStatus            []string `json:"temporaryStatus"                transform:"array"`
	AuthenticatorStatus        []string `json:"authenticatorStatus"            transform:"array"`
	ActivePeriodUntil          []int64  `json:"activePeriodUntil"              transform:"array"`
	AccessLevel                string   `json:"accessLevel"                    transform:"string"`
	PositionOptions            bool     `json:"positionOptions"                transform:"bool"`
	DivisionOptions            bool     `json:"divisionOptions"                transform:"bool"`
	ModifiedByOptions          bool     `json:"modifiedByOptions"              transform:"bool"`
	StatusOptions              bool     `json:"statusOptions"                  transform:"bool"`
	ActivationStatusOptions    bool     `json:"activationStatusOptions"        transform:"bool"`
	TemporaryStatusOptions     bool     `json:"temporaryStatusOptions"         transform:"bool"`
	AuthenticatorStatusOptions bool     `json:"authenticatorStatusOptions"     transform:"bool"`
}

// AccessLevelListItem is one row of the Total Control / Read Only tab.
type AccessLevelListItem struct {
	ID                  string     `json:"_id"                     column:"tend.id::text"`
	FullName            string     `json:"fullName"                column:"tend.full_name"`
	ProfilePicture      *string    `json:"profilePicture"          column:"tend.profile_picture"`
	Position            *string    `json:"position"                column:"tend.position"`
	Division            *string    `json:"division"                column:"tend.division"`
	IsActive            bool       `json:"isActive"                column:"tend.is_active"`
	PendingEmail        *string    `json:"pendingEmail"            column:"tend.pending_email"`
	IsDefault           bool       `json:"isDefault"               column:"tend.is_default"`
	ModifiedBy          *string    `json:"modifiedBy"              column:"tend.modified_by_name"`
	UpdatedAt           *time.Time `json:"updatedAt"               column:"tend.updated_at"`
	UserType            string     `json:"userType"                column:"tend.user_type"`
	ActivationStatus    string     `json:"activationStatus"        column:"tend.activation_status"`
	TemporaryStatus     string     `json:"temporaryStatus"         column:"tend.temporary_status"`
	ActivePeriodUntil   *time.Time `json:"activePeriodUntil"       column:"tend.active_period_until"`
	TagCode             *string    `json:"tagCode"                 column:"tend.tag_code"`
	AuthenticatorStatus string     `json:"authenticatorStatus"     column:"tend.authenticator_status"`
}

// AccessLevelListResponse is the paginated envelope of the list endpoint.
type AccessLevelListResponse = util_dto.PaginationResult[AccessLevelListItem]

type AccessLevelOptionsResponse struct {
	PositionOptions            []util_dto.InterfaceOptionDTO `json:"positionOptions"`
	DivisionOptions            []util_dto.InterfaceOptionDTO `json:"divisionOptions"`
	ModifiedByOptions          []util_dto.InterfaceOptionDTO `json:"modifiedByOptions"`
	StatusOptions              []util_dto.InterfaceOptionDTO `json:"statusOptions"`
	ActivationStatusOptions    []util_dto.InterfaceOptionDTO `json:"activationStatusOptions"`
	TemporaryStatusOptions     []util_dto.InterfaceOptionDTO `json:"temporaryStatusOptions"`
	AuthenticatorStatusOptions []util_dto.InterfaceOptionDTO `json:"authenticatorStatusOptions"`
}
