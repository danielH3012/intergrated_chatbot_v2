package dto

// CapabilityUsersDeleteBody is the request of
// DELETE /products/:product/roles/capabilities/users. One ID serves the row
// action; many serve the bulk action — the same endpoint, the same guards.
type CapabilityUsersDeleteBody struct {
	Key string   `json:"key" transform:"string" validate:"required"`
	IDs []string `json:"ids" transform:"array" validate:"required,min=1"`
}

// CapabilityUsersDeleteResult is the data payload of the DELETE response: the
// user IDs whose row could not be removed (already deleted by another admin,
// or a guard rejected them). Empty on full success.
type CapabilityUsersDeleteResult struct {
	FailedUserIDs []string `json:"failedUserIds"`
}
