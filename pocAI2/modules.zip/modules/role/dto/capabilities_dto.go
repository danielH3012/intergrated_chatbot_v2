package dto

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
)

// CapabilitiesListQuery is the request of POST /products/:product/roles/capabilities/list.
type CapabilitiesListQuery struct {
	Page      int      `json:"page"      transform:"int" validate:"omitempty,min=1"`
	Limit     int      `json:"limit"     transform:"int" validate:"omitempty,min=0,max=100"`
	SortBy    string   `json:"sortBy"    transform:"string"`
	SortOrder int      `json:"sortOrder" transform:"int"`
	Search    string   `json:"search"    transform:"string"`
	Columns   []string `json:"columns"   transform:"array"`
}

type CapabilitiesListItem struct {
	Key        model.SystemRoleKey `json:"key"        column:"tend.key"`
	Name       string              `json:"name"       column:"tend.name"`
	TotalUsers int                 `json:"totalUsers" column:"tend.total_users"`
}

type CapabilitiesListResponse = util_dto.PaginationResult[CapabilitiesListItem]
