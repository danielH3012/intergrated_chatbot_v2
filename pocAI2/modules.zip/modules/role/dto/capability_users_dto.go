package dto

import (
	"time"

	util_dto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
)

// CapabilityUsersListQuery is the request of
// POST /products/:product/roles/capabilities/users/list.
type CapabilityUsersListQuery struct {
	Key                 string   `json:"key"                 transform:"string" validate:"required"`
	Page                int      `json:"page"                transform:"int"    validate:"omitempty,min=1"`
	Limit               int      `json:"limit"               transform:"int"    validate:"omitempty,min=0,max=100"`
	Search              string   `json:"search"              transform:"string"`
	SortBy              string   `json:"sortBy"              transform:"string"`
	SortOrder           int      `json:"sortOrder"           transform:"int"`
	Columns             []string `json:"columns"             transform:"array"`
	Position            []string `json:"position"            transform:"array"`
	Division            []string `json:"division"            transform:"array"`
	ActivationStatus    []string `json:"activationStatus"    transform:"array"`
	TemporaryStatus     []string `json:"temporaryStatus"     transform:"array"`
	AuthenticatorStatus []string `json:"authenticatorStatus" transform:"array"`
	ActivePeriodUntil   []int64  `json:"activePeriodUntil"   transform:"array"`

	// Options flags — the options endpoint reuses this DTO's key.
	PositionOptions            bool `json:"positionOptions"            transform:"bool"`
	DivisionOptions            bool `json:"divisionOptions"            transform:"bool"`
	ActivationStatusOptions    bool `json:"activationStatusOptions"    transform:"bool"`
	TemporaryStatusOptions     bool `json:"temporaryStatusOptions"     transform:"bool"`
	AuthenticatorStatusOptions bool `json:"authenticatorStatusOptions" transform:"bool"`
}

// CapabilityPermission is the CRUD checkbox tuple of one capability row.
type CapabilityPermission struct {
	Create bool `json:"create" column:"tend.permission_create"`
	Read   bool `json:"read"   column:"tend.permission_view"`
	Update bool `json:"update" column:"tend.permission_update"`
	Delete bool `json:"delete" column:"tend.permission_delete"`
}

// CapabilityUsersListItem is one row of the Detail Capability table. Every
// field is returned on every response; `columns` curation is browser-side.
type CapabilityUsersListItem struct {
	ID                  string               `json:"_id"                 column:"tend.id::text"`
	FullName            string               `json:"fullName"            column:"tend.full_name"`
	ProfilePicture      *string              `json:"profilePicture"      column:"tend.profile_picture"`
	Position            *string              `json:"position"            column:"tend.position"`
	Division            *string              `json:"division"            column:"tend.division"`
	Permission          CapabilityPermission `json:"permission"`
	ActivationStatus    string               `json:"activationStatus"    column:"tend.activation_status"`
	PendingEmail        *string              `json:"pendingEmail"        column:"tend.pending_email"`
	TemporaryStatus     string               `json:"temporaryStatus"     column:"tend.temporary_status"`
	ActivePeriodUntil   *time.Time           `json:"activePeriodUntil"   column:"tend.active_period_until"`
	TagCode             *string              `json:"tagCode"             column:"tend.tag_code"`
	AuthenticatorStatus string               `json:"authenticatorStatus" column:"tend.authenticator_status"`
	IsDefault           bool                 `json:"isDefault"           column:"tend.is_default"`
}

// CapabilityUsersListResponse is the paginated envelope of the list endpoint.
type CapabilityUsersListResponse = util_dto.PaginationResult[CapabilityUsersListItem]

// CapabilityUsersOptionsResponse carries the five Detail Capability filter
// option lists.
type CapabilityUsersOptionsResponse struct {
	PositionOptions            []util_dto.InterfaceOptionDTO `json:"positionOptions"`
	DivisionOptions            []util_dto.InterfaceOptionDTO `json:"divisionOptions"`
	ActivationStatusOptions    []util_dto.InterfaceOptionDTO `json:"activationStatusOptions"`
	TemporaryStatusOptions     []util_dto.InterfaceOptionDTO `json:"temporaryStatusOptions"`
	AuthenticatorStatusOptions []util_dto.InterfaceOptionDTO `json:"authenticatorStatusOptions"`
}
