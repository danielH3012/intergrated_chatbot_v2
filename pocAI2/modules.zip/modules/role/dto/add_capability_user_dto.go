package dto

// CapabilityUserAddBody is the request of POST /products/:product/roles/capabilities/users.
type CapabilityUserAddBody struct {
	Key    string `json:"key"    transform:"string" validate:"required"`
	UserID string `json:"userId" transform:"string" validate:"required"`
}

// UserAssignmentEligibility is the ADD endpoint's read of the target user: does
// the user exist, does access for the product exist, and in which activation
// state. ModuleActive is nil when no user_module_status row exists. FullName
// feeds the changelog row's objectName snapshot.
type UserAssignmentEligibility struct {
	UserID           int64  `json:"userId"           column:"users.id"`
	FullName         string `json:"fullName"         column:"users.full_name"`
	ActivationStatus string `json:"activationStatus" column:"users.activation_status"`
	ModuleActive     *bool  `json:"moduleActive"     column:"user_module_status.is_active"`
	IsDefault        *bool  `json:"isDefault"        column:"users.is_default"`
}
