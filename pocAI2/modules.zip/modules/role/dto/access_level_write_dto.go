package dto

// AccessLevelPostBody is the request of POST /products/:product/roles/access-level.
type AccessLevelPostBody struct {
	UserID      string `json:"userId"      transform:"string" validate:"required"`
	AccessLevel string `json:"accessLevel" transform:"string" validate:"required"`
}

// AccessLevelRemoveBody is the request of DELETE /products/:product/roles/access-level.
type AccessLevelRemoveBody struct {
	IDs         []string `json:"ids"         transform:"array"  validate:"required,min=1"`
	AccessLevel string   `json:"accessLevel" transform:"string" validate:"required"`
}
