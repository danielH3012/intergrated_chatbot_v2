package dto

// CapabilityUserPatchBody is the request of
// PATCH /products/:product/roles/capabilities/users/:user_id.
type CapabilityUserPatchBody struct {
	Key        string                     `json:"key" transform:"string" validate:"required"`
	Permission *CapabilityPermissionPatch `json:"permission"`
}

// CapabilityPermissionPatch carries the optional CRUD flags of a PATCH. Pointer
// fields distinguish "not supplied" from "false".
type CapabilityPermissionPatch struct {
	Create *bool `json:"create"`
	Read   *bool `json:"read"`
	Update *bool `json:"update"`
	Delete *bool `json:"delete"`
}

// LockRead forces the effective read flag to true. Read is locked for the
// lifetime of the row — only DELETE can release a capability — so whatever the
// payload carried, the value that reaches the write path is always true (PRD
// Edge Case Matrix D5 / TC-GS-ROLE-34). C/U/D flags are untouched.
func (p *CapabilityPermissionPatch) LockRead() {
	if p != nil && p.Read != nil && !*p.Read {
		*p.Read = true
	}
}

// PatchCapabilityUserResult is the data payload of the PATCH response.
type PatchCapabilityUserResult struct {
	AccessLevelAutoReverted bool `json:"accessLevelAutoReverted"`
}

// CapabilityUserRow is the PATCH's read of the target assignment row, joined to
// the user facts the guards need.
type CapabilityUserRow struct {
	UserID           int64  `json:"userId"           column:"user_system_roles.user_id"`
	FullName         string `json:"fullName"         column:"users.full_name"`
	IsDefault        bool   `json:"isDefault"        column:"users.is_default"`
	PermissionView   bool   `json:"permissionView"   column:"user_system_roles.permission_view"`
	PermissionCreate bool   `json:"permissionCreate" column:"user_system_roles.permission_create"`
	PermissionUpdate bool   `json:"permissionUpdate" column:"user_system_roles.permission_update"`
	PermissionDelete bool   `json:"permissionDelete" column:"user_system_roles.permission_delete"`
}
