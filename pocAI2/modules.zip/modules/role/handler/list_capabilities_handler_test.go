package handler

import (
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/query_builder"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/service"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRoleRepo is a stateful in-memory double for RoleRepositor: the
// real query builder runs (its validation errors must surface through the
// handler), only the rows are canned.
type fakeRoleRepo struct {
	dto.CapabilitiesListResponse
}

func (f *fakeRoleRepo) ListCapabilities(_ context.Context, _ coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) (*dto.CapabilitiesListResponse, error) {
	if _, _, err := query_builder.CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](product, q); err != nil {
		return nil, err
	}
	res := f.CapabilitiesListResponse
	return &res, nil
}
func (f *fakeRoleRepo) ListCapabilitiesAll(_ context.Context, _ coreService.PostgreSQLServicer, product model.Product, q dto.CapabilitiesListQuery) ([]dto.CapabilitiesListItem, error) {
	if _, _, err := query_builder.CapabilitiesListQueryBuilder[dto.CapabilitiesListItem](product, q, false); err != nil {
		return nil, err
	}
	return f.CapabilitiesListResponse.Data, nil
}

func (f *fakeRoleRepo) ListAccessLevelUsers(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) (*dto.AccessLevelListResponse, error) {
	panic("not called")
}
func (f *fakeRoleRepo) ListAccessLevelUsersAll(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) ([]dto.AccessLevelListItem, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetAccessLevelOptions(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) (*dto.AccessLevelOptionsResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListCapabilityUsers(_ context.Context, _ coreService.PostgreSQLServicer, product model.Product, key model.SystemRoleKey, q dto.CapabilityUsersListQuery) (*dto.CapabilityUsersListResponse, error) {
	if _, _, err := query_builder.CapabilityUsersListQueryBuilder[dto.CapabilityUsersListItem](product, key, q); err != nil {
		return nil, err
	}
	return &dto.CapabilityUsersListResponse{}, nil
}
func (f *fakeRoleRepo) ListCapabilityUsersAll(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) ([]dto.CapabilityUsersListItem, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetCapabilityUsersOptions(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) (*dto.CapabilityUsersOptionsResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListAssignableUsers(_ context.Context, _ coreService.PostgreSQLServicer, product model.Product, q dto.AssignableUsersListQuery) (*dto.AssignableUsersListResponse, error) {
	if _, _, err := query_builder.AssignableUsersListQueryBuilder[dto.AssignableUsersListItem](product, q); err != nil {
		return nil, err
	}
	return &dto.AssignableUsersListResponse{}, nil
}

func (f *fakeRoleRepo) GetAssignableUsersOptions(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AssignableUsersListQuery) (*dto.AssignableUsersOptionsResponse, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64) (*dto.CapabilityUserRow, error) {
	panic("not called")
}

func (f *fakeRoleRepo) ListUserCapabilityRows(context.Context, coreService.PostgreSQLServicer, model.Product, int64) ([]model.UserSystemRole, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetUserAccessLevelRow(context.Context, coreService.PostgreSQLServicer, model.Product, int64) (*model.UserAccessLevel, error) {
	panic("not called")
}

func (f *fakeRoleRepo) GetUserAssignmentEligibility(context.Context, coreService.PostgreSQLServicer, model.Product, int64) (*dto.UserAssignmentEligibility, error) {
	panic("not called")
}

func (f *fakeRoleRepo) AddCapabilityUser(context.Context, coreService.PostgreSQLServicer, model.UserSystemRole) error {
	panic("not called")
}

func (f *fakeRoleRepo) PatchCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64, sql_query.UpdateQuery) error {
	panic("not called")
}

func (f *fakeRoleRepo) DeleteUserAccessLevelRow(context.Context, coreService.PostgreSQLServicer, model.Product, int64) error {
	panic("not called")
}

func (f *fakeRoleRepo) UpsertAccessLevel(context.Context, coreService.PostgreSQLServicer, model.UserAccessLevel) error {
	panic("not called")
}

func (f *fakeRoleRepo) UpsertCapabilityRows(context.Context, coreService.PostgreSQLServicer, []model.UserSystemRole) error {
	panic("not called")
}

func (f *fakeRoleRepo) DeleteCapabilityRows(context.Context, coreService.PostgreSQLServicer, model.Product, int64) error {
	panic("not called")
}

func (f *fakeRoleRepo) ListCapabilityUserRows(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, []int64) ([]dto.CapabilityUserRow, error) {
	panic("not called")
}

func (f *fakeRoleRepo) DeleteCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64) error {
	panic("not called")
}

func newCapabilitiesApp() *fiber.App {
	repo := &fakeRoleRepo{CapabilitiesListResponse: dto.CapabilitiesListResponse{
		TotalRecords: 6,
		Data: []dto.CapabilitiesListItem{
			{Key: model.SystemRoleKeyManageUserAndRole, Name: "Manage user and role", TotalUsers: 3},
		},
	}}
	h := NewRoleHandler(service.NewRoleService("testdb", repo, nil, "", func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	}))
	app := fiber.New()
	app.Post("/products/:product/roles/capabilities/list", h.HandleListCapabilities)
	app.Post("/products/:product/roles/capabilities/export", h.HandleExportCapabilities)
	return app
}

func doCapabilitiesRequest(t *testing.T, app *fiber.App, body string) (int, map[string]any) {
	t.Helper()
	req := httptest.NewRequest(fiber.MethodPost, "/products/global_settings/roles/capabilities/list", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	var envelope map[string]any
	if err := json.NewDecoder(res.Body).Decode(&envelope); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	return res.StatusCode, envelope
}

func TestHandleListCapabilitiesOK(t *testing.T) {
	app := newCapabilitiesApp()
	status, envelope := doCapabilitiesRequest(t, app, `{"page":1,"limit":10}`)

	if status != fiber.StatusOK {
		t.Fatalf("status = %d, want 200: %v", status, envelope)
	}
	if envelope["message"] != "Capabilities retrieved" {
		t.Errorf("message = %v, want %q", envelope["message"], "Capabilities retrieved")
	}
	data, ok := envelope["data"].(map[string]any)
	if !ok {
		t.Fatalf("data = %v, want object", envelope["data"])
	}
	if data["totalRecords"] != float64(6) {
		t.Errorf("totalRecords = %v, want 6", data["totalRecords"])
	}
	rows, ok := data["data"].([]any)
	if !ok || len(rows) != 1 {
		t.Fatalf("data.data = %v, want 1 row", data["data"])
	}
	row := rows[0].(map[string]any)
	if row["key"] != string(model.SystemRoleKeyManageUserAndRole) || row["name"] != "Manage user and role" || row["totalUsers"] != float64(3) {
		t.Errorf("row = %v", row)
	}
}

func TestHandleListCapabilitiesUnknownSortOrder(t *testing.T) {
	app := newCapabilitiesApp()
	status, envelope := doCapabilitiesRequest(t, app, `{"sortOrder":2}`)

	if status != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400: %v", status, envelope)
	}
	if envelope["message"] != "Unknown sort order" {
		t.Errorf("message = %v, want %q", envelope["message"], "Unknown sort order")
	}
}

func TestHandleListCapabilitiesUnknownSortBy(t *testing.T) {
	app := newCapabilitiesApp()
	status, envelope := doCapabilitiesRequest(t, app, `{"sortBy":"bogus"}`)

	if status != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400: %v", status, envelope)
	}
	if envelope["message"] != "Unknown sort column" {
		t.Errorf("message = %v, want %q", envelope["message"], "Unknown sort column")
	}
}

func TestHandleListCapabilitiesInvalidBody(t *testing.T) {
	app := newCapabilitiesApp()
	status, envelope := doCapabilitiesRequest(t, app, `{not json`)

	if status != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400: %v", status, envelope)
	}
	if envelope["message"] != "Invalid request body" {
		t.Errorf("message = %v, want %q", envelope["message"], "Invalid request body")
	}
}

func TestHandleListCapabilitiesUnknownProduct(t *testing.T) {
	app := newCapabilitiesApp()
	req := httptest.NewRequest(fiber.MethodPost, "/products/bogus/roles/capabilities/list", strings.NewReader(`{}`))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400", res.StatusCode)
	}
}

func TestHandleExportCapabilitiesCSV(t *testing.T) {
	app := newCapabilitiesApp()
	req := httptest.NewRequest(fiber.MethodPost, "/products/global_settings/roles/capabilities/export", strings.NewReader(`{"format":"csv","sortOrder":1}`))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")

	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()
	body, err := io.ReadAll(res.Body)
	if err != nil {
		t.Fatalf("read response: %v", err)
	}
	if res.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200: %s", res.StatusCode, body)
	}
	if got := res.Header.Get("Content-Type"); got != "text/csv" {
		t.Errorf("content type = %q, want text/csv", got)
	}
	if got := res.Header.Get("Content-Disposition"); !strings.Contains(got, `Role-Permission-System.csv`) {
		t.Errorf("content disposition = %q", got)
	}
	if got := string(body); !strings.Contains(got, "Capability Name,Users") || !strings.Contains(got, "Manage user and role,3") {
		t.Errorf("csv = %q", got)
	}
}
