package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleAssignAccessLevel serves POST /products/:product/roles/access-level.
func (h *RoleHandler) HandleAssignAccessLevel(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	actorID, err := tsMiddleware.CallerID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.AccessLevelPostBody
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if body.AccessLevel != dto.AccessLevelTotalControl && body.AccessLevel != dto.AccessLevelReadOnly {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown access level",
			Data:    map[string]string{"field": "accessLevel"},
		}).SendResponse(c)
	}
	userID, err := strconv.ParseInt(body.UserID, 10, 64)
	if err != nil {
		return coreEntity.BadRequest("Invalid user id").SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	roles, ok := tsMiddleware.GetUserRoles(c)
	if !ok {
		return coreEntity.Unauthorized("You are not authenticated!").SendResponse(c)
	}

	if err := h.svc.AssignAccessLevel(c.Context(), clientID, product, actorID, userID, roles.FullName, model.AccessLevel(body.AccessLevel)); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	message := "Success, Total Control has been assigned."
	if body.AccessLevel == dto.AccessLevelReadOnly {
		message = "Success, Read Only has been assigned."
	}
	return coreHelper.Success(c, message, nil)
}
