package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleGetAssignableUsersOptions serves POST /products/:product/roles/assignable-users/options.
func (h *RoleHandler) HandleGetAssignableUsersOptions(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.AssignableUsersListQuery
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if err := validateAssignableExclusions(body.ExcludeTier, body.ExcludeKey); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	res, err := h.svc.GetAssignableUsersOptions(c.Context(), clientID, product, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Assignable users options retrieved", res)
}
