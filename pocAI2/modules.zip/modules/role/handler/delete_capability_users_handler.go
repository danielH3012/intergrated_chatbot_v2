package handler

import (
	"fmt"
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleDeleteCapabilityUsers serves DELETE /products/:product/roles/capabilities/users —
// the row action (one ID) and the bulk action (many IDs) share this endpoint.
func (h *RoleHandler) HandleDeleteCapabilityUsers(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	actorID, err := tsMiddleware.CallerID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.CapabilityUsersDeleteBody
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if model.SystemRoleNameOf(model.SystemRoleKey(body.Key)) == "" {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown capability key",
			Data:    map[string]string{"field": "key"},
		}).SendResponse(c)
	}
	userIDs := make([]int64, 0, len(body.IDs))
	for _, id := range body.IDs {
		parsed, err := strconv.ParseInt(id, 10, 64)
		if err != nil {
			return coreEntity.BadRequest("Invalid user id").SendResponse(c)
		}
		userIDs = append(userIDs, parsed)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	roles, ok := tsMiddleware.GetUserRoles(c)
	if !ok {
		return coreEntity.Unauthorized("You are not authenticated!").SendResponse(c)
	}

	res, err := h.svc.DeleteCapabilityUsers(c.Context(), clientID, product, actorID, roles.FullName, roles, model.SystemRoleKey(body.Key), userIDs)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	failed := res.FailedUserIDs
	if failed == nil {
		failed = []string{}
	}
	message := "Success, users have been removed."
	if len(failed) > 0 {
		message = fmt.Sprintf("%d removed, %d failed.", len(userIDs)-len(failed), len(failed))
	}
	return coreHelper.Success(c, message, map[string]any{"failedUserIds": failed})
}
