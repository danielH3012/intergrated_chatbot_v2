package handler

import (
	"testing"

	"github.com/gofiber/fiber/v3"

	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

// testActorRoles is the minimum snapshot the write handlers need — the
// actor's display name for the changelog snapshot.
func testActorRoles() tsMiddleware.UserAccessCache {
	return tsMiddleware.UserAccessCache{FullName: "Budi Santoso"}
}

func TestHandleAssignAccessLevelUnknownLevel(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/access-level", h.HandleAssignAccessLevel)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/access-level",
		`{"userId":"1773248399000","accessLevel":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown access level" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown access level", status, envelope["message"])
	}
}

func TestHandleAssignAccessLevelInvalidUserID(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/access-level", h.HandleAssignAccessLevel)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/access-level",
		`{"userId":"not-a-number","accessLevel":"total_control"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Invalid user id" {
		t.Fatalf("status/message = %d/%v, want 400 Invalid user id", status, envelope["message"])
	}
}

func TestHandleAssignAccessLevelWritePath(t *testing.T) {
	// A valid body passes validation and reaches the service — with no Temporal
	// wiring (test service) the write path reports itself unconfigured (500),
	// proving the request was not silently swallowed.
	app := newRoleTestApp(withRoles(testActorRoles()), func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/access-level", h.HandleAssignAccessLevel)
	})
	status, _ := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/access-level",
		`{"userId":"1773248399000","accessLevel":"total_control"}`, "1")

	if status != fiber.StatusInternalServerError {
		t.Fatalf("status = %d, want 500 (write path not configured in tests)", status)
	}
}

func TestHandleRemoveAccessLevelUnknownLevel(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Delete("/products/:product/roles/access-level", h.HandleRemoveAccessLevel)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodDelete, "/products/global_settings/roles/access-level",
		`{"ids":["1773248399000"],"accessLevel":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown access level" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown access level", status, envelope["message"])
	}
}

func TestHandleRemoveAccessLevelInvalidUserID(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Delete("/products/:product/roles/access-level", h.HandleRemoveAccessLevel)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodDelete, "/products/global_settings/roles/access-level",
		`{"ids":["abc"],"accessLevel":"total_control"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Invalid user id" {
		t.Fatalf("status/message = %d/%v, want 400 Invalid user id", status, envelope["message"])
	}
}

func TestHandleRemoveAccessLevelWritePath(t *testing.T) {
	app := newRoleTestApp(withRoles(testActorRoles()), func(h *RoleHandler, app *fiber.App) {
		app.Delete("/products/:product/roles/access-level", h.HandleRemoveAccessLevel)
	})
	status, _ := doRoleRequest(t, app, fiber.MethodDelete, "/products/global_settings/roles/access-level",
		`{"ids":["1773248399000"],"accessLevel":"total_control"}`, "1")

	if status != fiber.StatusInternalServerError {
		t.Fatalf("status = %d, want 500 (write path not configured in tests)", status)
	}
}

func TestHandleDeleteCapabilityUsersUnknownKey(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Delete("/products/:product/roles/capabilities/users", h.HandleDeleteCapabilityUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodDelete, "/products/global_settings/roles/capabilities/users",
		`{"key":"bogus","ids":["1773248399000"]}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown capability key" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown capability key", status, envelope["message"])
	}
}

func TestHandleDeleteCapabilityUsersInvalidUserID(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Delete("/products/:product/roles/capabilities/users", h.HandleDeleteCapabilityUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodDelete, "/products/global_settings/roles/capabilities/users",
		`{"key":"manage_user_and_role","ids":["abc"]}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Invalid user id" {
		t.Fatalf("status/message = %d/%v, want 400 Invalid user id", status, envelope["message"])
	}
}

func TestHandleDeleteCapabilityUsersWritePath(t *testing.T) {
	app := newRoleTestApp(withRoles(testActorRoles()), func(h *RoleHandler, app *fiber.App) {
		app.Delete("/products/:product/roles/capabilities/users", h.HandleDeleteCapabilityUsers)
	})
	status, _ := doRoleRequest(t, app, fiber.MethodDelete, "/products/global_settings/roles/capabilities/users",
		`{"key":"manage_user_and_role","ids":["1773248399000"]}`, "1")

	if status != fiber.StatusInternalServerError {
		t.Fatalf("status = %d, want 500 (write path not configured in tests)", status)
	}
}
