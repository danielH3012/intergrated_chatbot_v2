package handler

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func newRoleTestApp(routes ...func(h *RoleHandler, app *fiber.App)) *fiber.App {
	h := NewRoleHandler(service.NewRoleService("testdb", &fakeRoleRepo{}, nil, "", func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	}))
	app := fiber.New()
	for _, r := range routes {
		r(h, app)
	}
	return app
}

func doRoleRequest(t *testing.T, app *fiber.App, method, url, body string, userID string) (int, map[string]any) {
	t.Helper()
	req := httptest.NewRequest(method, url, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", userID)
	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	var envelope map[string]any
	if err := json.NewDecoder(res.Body).Decode(&envelope); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	return res.StatusCode, envelope
}

func withRoles(roles tsMiddleware.UserAccessCache) func(h *RoleHandler, app *fiber.App) {
	return func(_ *RoleHandler, app *fiber.App) {
		app.Use(func(c fiber.Ctx) error {
			c.Locals(tsMiddleware.UserRolesKey, roles)
			return c.Next()
		})
	}
}

func TestHandleListCapabilityUsersOK(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/capabilities/users/list", h.HandleListCapabilityUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/capabilities/users/list",
		`{"key":"manage_user_and_role","page":1,"limit":10}`, "1")

	if status != fiber.StatusOK {
		t.Fatalf("status = %d, want 200: %v", status, envelope)
	}
	if envelope["message"] != "Capability users retrieved" {
		t.Errorf("message = %v", envelope["message"])
	}
}

func TestHandleListCapabilityUsersUnknownKey(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/capabilities/users/list", h.HandleListCapabilityUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/capabilities/users/list",
		`{"key":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown capability key" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown capability key", status, envelope["message"])
	}
}

func TestHandleListCapabilityUsersUnknownSortOrder(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/capabilities/users/list", h.HandleListCapabilityUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/capabilities/users/list",
		`{"key":"manage_user_and_role","sortOrder":2}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown sort order" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown sort order", status, envelope["message"])
	}
}

func TestHandleListCapabilityUsersUnknownSortBy(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/capabilities/users/list", h.HandleListCapabilityUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/capabilities/users/list",
		`{"key":"manage_user_and_role","sortBy":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown sort column" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown sort column", status, envelope["message"])
	}
}

func TestHandleListAssignableUsersOK(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/assignable-users/list", h.HandleListAssignableUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/assignable-users/list",
		`{"page":1,"limit":10,"excludeTier":"total_control"}`, "1")

	if status != fiber.StatusOK {
		t.Fatalf("status = %d, want 200: %v", status, envelope)
	}
	if envelope["message"] != "Assignable users retrieved" {
		t.Errorf("message = %v", envelope["message"])
	}
}

func TestHandleListAssignableUsersUnknownExcludeTier(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/assignable-users/list", h.HandleListAssignableUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/assignable-users/list",
		`{"excludeTier":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown exclude tier" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown exclude tier", status, envelope["message"])
	}
}

func TestHandleListAssignableUsersUnknownExcludeKey(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/assignable-users/list", h.HandleListAssignableUsers)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/assignable-users/list",
		`{"excludeKey":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown capability key" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown capability key", status, envelope["message"])
	}
}

func TestHandlePatchCapabilityUserReadIsSilentlyIgnored(t *testing.T) {
	app := newRoleTestApp(withRoles(tsMiddleware.UserAccessCache{}), func(h *RoleHandler, app *fiber.App) {
		app.Patch("/products/:product/roles/capabilities/users/:user_id", h.HandlePatchCapabilityUser)
	})
	// read:false must not 400 (PRD Edge Case D5 / TC-GS-ROLE-34): the flag is
	// ignored and the payload proceeds. In this harness the service layer is
	// unconfigured, so reaching it surfaces its 500 rather than a read rejection.
	status, envelope := doRoleRequest(t, app, fiber.MethodPatch, "/products/global_settings/roles/capabilities/users/42",
		`{"key":"manage_user_and_role","permission":{"read":false}}`, "1")

	if status == fiber.StatusBadRequest && envelope["message"] == "Read cannot be unchecked" {
		t.Fatal("read:false must be silently ignored, not rejected with 400")
	}
	if status != fiber.StatusInternalServerError || envelope["message"] != "role write path is not configured" {
		t.Fatalf("status/message = %d/%v, want the payload to reach the service layer", status, envelope["message"])
	}
}

func TestHandlePatchCapabilityUserUnknownKey(t *testing.T) {
	app := newRoleTestApp(withRoles(tsMiddleware.UserAccessCache{}), func(h *RoleHandler, app *fiber.App) {
		app.Patch("/products/:product/roles/capabilities/users/:user_id", h.HandlePatchCapabilityUser)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPatch, "/products/global_settings/roles/capabilities/users/42",
		`{"key":"bogus"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown capability key" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown capability key", status, envelope["message"])
	}
}

func TestHandleAddCapabilityUserUnknownKey(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/capabilities/users", h.HandleAddCapabilityUser)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/capabilities/users",
		`{"key":"bogus","userId":"42"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Unknown capability key" {
		t.Fatalf("status/message = %d/%v, want 400 Unknown capability key", status, envelope["message"])
	}
}

func TestHandleAddCapabilityUserInvalidUserID(t *testing.T) {
	app := newRoleTestApp(func(h *RoleHandler, app *fiber.App) {
		app.Post("/products/:product/roles/capabilities/users", h.HandleAddCapabilityUser)
	})
	status, envelope := doRoleRequest(t, app, fiber.MethodPost, "/products/global_settings/roles/capabilities/users",
		`{"key":"manage_user_and_role","userId":"abc"}`, "1")

	if status != fiber.StatusBadRequest || envelope["message"] != "Invalid user id" {
		t.Fatalf("status/message = %d/%v, want 400 Invalid user id", status, envelope["message"])
	}
}
