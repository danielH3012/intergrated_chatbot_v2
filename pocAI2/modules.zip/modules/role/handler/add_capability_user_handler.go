package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleAddCapabilityUser serves POST /products/:product/roles/capabilities/users.
func (h *RoleHandler) HandleAddCapabilityUser(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	actorID, err := tsMiddleware.CallerID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.CapabilityUserAddBody
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if model.SystemRoleNameOf(model.SystemRoleKey(body.Key)) == "" {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown capability key",
			Data:    map[string]string{"field": "key"},
		}).SendResponse(c)
	}
	userID, err := strconv.ParseInt(body.UserID, 10, 64)
	if err != nil {
		return coreEntity.BadRequest("Invalid user id").SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	// The actor's full name is snapshotted onto the changelog row's
	// createdBySnapshot. The route gate (rbac.Require) already 401s when the
	// snapshot is missing, so this re-check is defense-in-depth — fail closed
	// rather than silently writing an empty actor name to the audit trail.
	roles, ok := tsMiddleware.GetUserRoles(c)
	if !ok {
		return coreEntity.Unauthorized("You are not authenticated!").SendResponse(c)
	}

	if err := h.svc.AddCapabilityUser(c.Context(), clientID, product, actorID, userID, roles.FullName, body); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Created(c, "User added to capability", nil)
}
