package handler

import (
	"fmt"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *RoleHandler) HandleExportAccessLevelUsers(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	var body dto.ExportAccessLevelRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	body.Defaults()
	if err := validateAccessLevelExport(body); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest("Validation failed", validator.ParseValidationErrors(err)).SendResponse(c)
	}
	file, err := h.svc.ExportAccessLevelUsers(c.Context(), clientID, product, body)
	return sendRoleExport(c, file, err)
}

func (h *RoleHandler) HandleExportCapabilities(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	var body dto.ExportCapabilitiesRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	body.Defaults()
	if body.SortOrder != 0 && body.SortOrder != 1 && body.SortOrder != -1 {
		return coreEntity.ToHttpError(unknownRoleValue("sortOrder", "Unknown sort order")).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest("Validation failed", validator.ParseValidationErrors(err)).SendResponse(c)
	}
	file, err := h.svc.ExportCapabilities(c.Context(), clientID, product, body)
	return sendRoleExport(c, file, err)
}

func (h *RoleHandler) HandleExportCapabilityUsers(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	var body dto.ExportCapabilityUsersRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	body.Defaults()
	if model.SystemRoleNameOf(model.SystemRoleKey(body.Key)) == "" {
		return coreEntity.ToHttpError(unknownRoleValue("key", "Unknown capability key")).SendResponse(c)
	}
	if body.SortOrder != 0 && body.SortOrder != 1 && body.SortOrder != -1 {
		return coreEntity.ToHttpError(unknownRoleValue("sortOrder", "Unknown sort order")).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest("Validation failed", validator.ParseValidationErrors(err)).SendResponse(c)
	}
	file, err := h.svc.ExportCapabilityUsers(c.Context(), clientID, product, body)
	return sendRoleExport(c, file, err)
}

func validateAccessLevelExport(body dto.ExportAccessLevelRequest) error {
	if body.AccessLevel != dto.AccessLevelTotalControl && body.AccessLevel != dto.AccessLevelReadOnly {
		return unknownRoleValue("accessLevel", "Unknown access level")
	}
	if body.SortOrder != 0 && body.SortOrder != 1 && body.SortOrder != -1 {
		return unknownRoleValue("sortOrder", "Unknown sort order")
	}
	return nil
}

func unknownRoleValue(field, message string) error {
	return &coreEntity.HttpError{Code: fiber.StatusBadRequest, Message: message, Data: map[string]string{"field": field}}
}

func sendRoleExport(c fiber.Ctx, file *service.ExportRoleResult, err error) error {
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	c.Set("Content-Type", file.ContentType)
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, file.Filename))
	return c.Send(file.Data)
}
