package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandlePatchCapabilityUser serves PATCH /products/:product/roles/capabilities/users/:user_id.
func (h *RoleHandler) HandlePatchCapabilityUser(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	userID, err := strconv.ParseInt(c.Params("user_id"), 10, 64)
	if err != nil {
		return coreEntity.BadRequest("Invalid user id").SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	actorID, err := tsMiddleware.CallerID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	roles, ok := tsMiddleware.GetUserRoles(c)
	if !ok {
		return coreEntity.Unauthorized("You are not authenticated!").SendResponse(c)
	}

	var body dto.CapabilityUserPatchBody
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if model.SystemRoleNameOf(model.SystemRoleKey(body.Key)) == "" {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown capability key",
			Data:    map[string]string{"field": "key"},
		}).SendResponse(c)
	}

	// Read is locked for the lifetime of the row: only DELETE can release a
	// capability, so a payload's read flag is forced to true, whatever the
	// client supplied (PRD Edge Case Matrix D5 / TC-GS-ROLE-34). The C/U/D
	// changes in the same payload are still applied.
	body.Permission.LockRead()

	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	res, err := h.svc.PatchCapabilityUser(c.Context(), clientID, product, userID, actorID, roles.FullName, roles, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Permissions updated", res)
}
