package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleListCapabilityUsers serves POST /products/:product/roles/capabilities/users/list.
func (h *RoleHandler) HandleListCapabilityUsers(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.CapabilityUsersListQuery
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	// key is required and spec-pinned: an unknown capability key is a 400,
	// never a silently-ignored filter.
	if model.SystemRoleNameOf(model.SystemRoleKey(body.Key)) == "" {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown capability key",
			Data:    map[string]string{"field": "key"},
		}).SendResponse(c)
	}
	if body.SortOrder != 0 && body.SortOrder != 1 && body.SortOrder != -1 {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown sort order",
			Data:    map[string]string{"field": "sortOrder"},
		}).SendResponse(c)
	}

	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	res, err := h.svc.ListCapabilityUsers(c.Context(), clientID, product, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Capability users retrieved", res)
}
