package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleListAssignableUsers serves POST /products/:product/roles/assignable-users/list. [AI-GENERATED]
func (h *RoleHandler) HandleListAssignableUsers(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.AssignableUsersListQuery
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if err := validateAssignableExclusions(body.ExcludeTier, body.ExcludeKey); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	res, err := h.svc.ListAssignableUsers(c.Context(), clientID, product, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Assignable users retrieved", res)
}

// validateAssignableExclusions enforces the two picker enums: excludeTier and
// excludeKey are both spec-pinned — an unknown value is a 400, never a
// silently-ignored exclusion.
func validateAssignableExclusions(excludeTier, excludeKey string) error {
	switch excludeTier {
	case "", dto.ExcludeTierTotalControl, dto.ExcludeTierReadOnly, dto.ExcludeTierBoth, dto.ExcludeTierNone:
	default:
		return &coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown exclude tier",
			Data:    map[string]string{"field": "excludeTier"},
		}
	}
	if excludeKey != "" && model.SystemRoleNameOf(model.SystemRoleKey(excludeKey)) == "" {
		return &coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown capability key",
			Data:    map[string]string{"field": "excludeKey"},
		}
	}
	return nil
}
