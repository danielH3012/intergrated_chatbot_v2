package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleListAccessLevelUsers serves POST /products/:product/roles/access-level/list.
func (h *RoleHandler) HandleListAccessLevelUsers(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	clientID, err := tsMiddleware.ClientID(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.AccessLevelListQuery
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	// accessLevel is required (the tab the caller asks for) and its enum is
	// spec-pinned: unknown is a 400, never a silent default.
	//
	// [AI-GENERATED]
	if body.AccessLevel != dto.AccessLevelTotalControl && body.AccessLevel != dto.AccessLevelReadOnly {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown access level",
			Data:    map[string]string{"field": "accessLevel"},
		}).SendResponse(c)
	}
	if body.SortOrder != 0 && body.SortOrder != 1 && body.SortOrder != -1 {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusBadRequest,
			Message: "Unknown sort order",
			Data:    map[string]string{"field": "sortOrder"},
		}).SendResponse(c)
	}

	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	res, err := h.svc.ListAccessLevelUsers(c.Context(), clientID, product, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Access level list retrieved", res)
}
