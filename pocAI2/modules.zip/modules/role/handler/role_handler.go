package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/service"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// RoleHandler serves the IAM Service - Role & Permission surface.
type RoleHandler struct {
	svc *service.RoleService
}

func NewRoleHandler(svc *service.RoleService) *RoleHandler {
	return &RoleHandler{svc: svc}
}

// productFromPath resolves the {product} path segment. The spec pins it to
// three products, and it doubles as the authorization scope — an unknown value
// is a 400 before any row is touched, never a client-chosen scope (OWASP
// API1:2023).
func productFromPath(c fiber.Ctx) (model.Product, error) {
	product := model.Product(c.Params("product"))
	switch product {
	case model.ProductGlobalSettings, model.ProductAdminConsole, model.ProductFixedAsset:
		return product, nil
	default:
		return "", coreEntity.BadRequest("Unknown product")
	}
}
