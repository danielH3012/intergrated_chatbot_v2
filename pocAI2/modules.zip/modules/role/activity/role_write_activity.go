package activity

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// AssignAccessLevelActivity assigns a Total Control / Read Only access level to
// a target user, bulk-writing the six capability rows to match the tier
// pattern in the same transaction. Guards, in order: the target must exist and
// sit inside the same pool the assignable picker serves; self-assign is
// blocked for every actor; the default user is permanently Total Control and
// can never be assigned; assigning a level the target already holds is a
// conflict (idempotent reject). The previous tier (nil on a first assign) is
// returned for the changelog's oldValue.
func (a *RoleActivities) AssignAccessLevelActivity(ctx context.Context, param workflow.AssignAccessLevelActivityParam) (workflow.AssignAccessLevelActivityResult, error) {
	if param.ActorID == param.UserID {
		return workflow.AssignAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("You cannot change your own access level."), true)
	}

	svc := a.tenantSvc(param.ClientID)

	elig, err := a.repo.GetUserAssignmentEligibility(ctx, svc, param.Product, param.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return workflow.AssignAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.NotFound("This user is no longer available."), true)
		}
		return workflow.AssignAccessLevelActivityResult{}, fmt.Errorf("role.AssignAccessLevel eligibility: %w", err)
	}
	if elig.ModuleActive == nil || !*elig.ModuleActive ||
		(elig.ActivationStatus != dto.ActivationPendingActivation && elig.ActivationStatus != dto.ActivationActivated) {
		return workflow.AssignAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.BadRequest("User is not eligible for this assignment"), true)
	}
	if elig.IsDefault != nil && *elig.IsDefault {
		return workflow.AssignAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("Default User must always have Total Control"), true)
	}

	previous, err := a.repo.GetUserAccessLevelRow(ctx, svc, param.Product, param.UserID)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return workflow.AssignAccessLevelActivityResult{}, fmt.Errorf("role.AssignAccessLevel tier: %w", err)
	}
	if previous != nil && previous.AccessLevel == param.AccessLevel {
		return workflow.AssignAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Conflict("User already has this access level"), true)
	}

	coreDb.InitSnowflake()
	rows := tierPatternRows(param.Product, param.UserID, param.AccessLevel, param.ActorID)
	if _, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		svc.SetTransaction(tx)
		if err := a.repo.UpsertAccessLevel(ctx, svc, model.UserAccessLevel{
			ID:          coreDb.Node.Generate().Int64(),
			UserID:      param.UserID,
			Product:     param.Product,
			AccessLevel: param.AccessLevel,
			ModifiedBy:  &param.ActorID,
		}); err != nil {
			return struct{}{}, err
		}
		return struct{}{}, a.repo.UpsertCapabilityRows(ctx, svc, rows)
	}); err != nil {
		svc.SetTransaction(nil)
		return workflow.AssignAccessLevelActivityResult{}, fmt.Errorf("role.AssignAccessLevel: %w", err)
	}
	svc.SetTransaction(nil)

	var previousLevel *model.AccessLevel
	if previous != nil {
		level := previous.AccessLevel
		previousLevel = &level
	}
	return workflow.AssignAccessLevelActivityResult{
		UserID:              param.UserID,
		UserFullName:        elig.FullName,
		PreviousAccessLevel: previousLevel,
	}, nil
}

// RemoveAccessLevelActivity removes the access level from one or more users:
// the user_access_levels row is deleted and all capability rows the target
// holds for the product are hard-deleted too — "user basic", no Global
// Settings access at all (PRD F-ROLE-05). Each user runs in its own
// transaction. Guards, per user, in order: the default user may never be
// removed (structurally the permanent Total Control), nobody may remove their
// own access level, and the user's current tier must match the requested one
// (409 on mismatch). A user with no tier row is a no-op — idempotent. Only
// users actually removed appear in the result.
func (a *RoleActivities) RemoveAccessLevelActivity(ctx context.Context, param workflow.RemoveAccessLevelActivityParam) (workflow.RemoveAccessLevelActivityResult, error) {
	svc := a.tenantSvc(param.ClientID)
	result := workflow.RemoveAccessLevelActivityResult{}

	for _, userID := range param.UserIDs {
		elig, err := a.repo.GetUserAssignmentEligibility(ctx, svc, param.Product, userID)
		if err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return workflow.RemoveAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.NotFound("This user is no longer available."), true)
			}
			return workflow.RemoveAccessLevelActivityResult{}, fmt.Errorf("role.RemoveAccessLevel eligibility: %w", err)
		}
		if elig.IsDefault != nil && *elig.IsDefault {
			return workflow.RemoveAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("Default User must always have Total Control"), true)
		}
		if param.ActorID == userID {
			return workflow.RemoveAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("You cannot change your own access level."), true)
		}

		tier, err := a.repo.GetUserAccessLevelRow(ctx, svc, param.Product, userID)
		if err != nil && !errors.Is(err, pgx.ErrNoRows) {
			return workflow.RemoveAccessLevelActivityResult{}, fmt.Errorf("role.RemoveAccessLevel tier: %w", err)
		}
		if tier == nil {
			continue // no tier row — idempotent no-op
		}
		if tier.AccessLevel != param.AccessLevel {
			return workflow.RemoveAccessLevelActivityResult{}, coreEntity.WrapHttpError(coreEntity.Conflict("User does not have this access level"), true)
		}

		// Per-user transaction: one failure blocks that user, it does not roll
		// back the others.
		if _, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
			svc.SetTransaction(tx)
			if err := a.repo.DeleteUserAccessLevelRow(ctx, svc, param.Product, userID); err != nil {
				return struct{}{}, err
			}
			return struct{}{}, a.repo.DeleteCapabilityRows(ctx, svc, param.Product, userID)
		}); err != nil {
			svc.SetTransaction(nil)
			return workflow.RemoveAccessLevelActivityResult{}, fmt.Errorf("role.RemoveAccessLevel: %w", err)
		}
		svc.SetTransaction(nil)

		result.Removed = append(result.Removed, workflow.AccessLevelRemoveOutcome{
			UserID:             userID,
			UserFullName:       elig.FullName,
			RemovedAccessLevel: tier.AccessLevel,
		})
	}
	return result, nil
}

// RemoveCapabilityUsersActivity hard-deletes the user_system_roles row of one
// key for each requested user — the row action sends one ID, the bulk action
// sends many. Guards are re-validated server-side per row (defense-in-depth):
// self-edit, the default user, and a non-Total-Control actor touching a
// tier-holder are rejected and reported under failedUserIds — an already
// deleted row is equally reported, idempotent per row. An eligible tier-holder
// deletion also deletes the user_access_levels row in the same transaction
// (auto-revert; the user's other capability rows are left as-is). Each row is
// its own transaction. If every requested row was guard-rejected the request
// fails 403; a mix of removed and failed is 200 with failedUserIds.
func (a *RoleActivities) RemoveCapabilityUsersActivity(ctx context.Context, param workflow.RemoveCapabilityUsersActivityParam) (workflow.RemoveCapabilityUsersActivityResult, error) {
	svc := a.tenantSvc(param.ClientID)

	module, ok := ProductModule(param.Product)
	if !ok {
		return workflow.RemoveCapabilityUsersActivityResult{}, coreEntity.WrapHttpError(coreEntity.BadRequest("Unknown product"), true)
	}

	rows, err := a.repo.ListCapabilityUserRows(ctx, svc, param.Product, param.Key, param.UserIDs)
	if err != nil {
		return workflow.RemoveCapabilityUsersActivityResult{}, fmt.Errorf("role.RemoveCapabilityUsers rows: %w", err)
	}
	byUser := make(map[int64]dto.CapabilityUserRow, len(rows))
	for _, r := range rows {
		byUser[r.UserID] = r
	}

	result := workflow.RemoveCapabilityUsersActivityResult{}
	var failed, guardRejected []int64

	for _, userID := range param.UserIDs {
		row, ok := byUser[userID]
		if !ok {
			failed = append(failed, userID) // already deleted — idempotent per row, not an error
			continue
		}
		if userID == param.ActorID {
			guardRejected = append(guardRejected, userID)
			continue
		}
		if row.IsDefault {
			guardRejected = append(guardRejected, userID)
			continue
		}

		tier, err := a.repo.GetUserAccessLevelRow(ctx, svc, param.Product, userID)
		if err != nil && !errors.Is(err, pgx.ErrNoRows) {
			return workflow.RemoveCapabilityUsersActivityResult{}, fmt.Errorf("role.RemoveCapabilityUsers tier: %w", err)
		}
		if tier != nil && !param.Roles.IsTotalControl(module) {
			guardRejected = append(guardRejected, userID)
			continue
		}

		// Per-row transaction: one failure blocks that user, it does not roll
		// back the others.
		if _, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
			svc.SetTransaction(tx)
			if err := a.repo.DeleteCapabilityUserRow(ctx, svc, param.Product, param.Key, userID); err != nil {
				return struct{}{}, err
			}
			if tier != nil {
				return struct{}{}, a.repo.DeleteUserAccessLevelRow(ctx, svc, param.Product, userID)
			}
			return struct{}{}, nil
		}); err != nil {
			svc.SetTransaction(nil)
			failed = append(failed, userID)
			continue
		}
		svc.SetTransaction(nil)

		outcome := workflow.RemoveCapabilityUserOutcome{UserID: userID, UserFullName: row.FullName}
		if tier != nil {
			outcome.AccessLevelAutoReverted = true
			outcome.RevertedAccessLevel = tier.AccessLevel
		}
		result.Removed = append(result.Removed, outcome)
	}

	result.FailedUserIDs = append(failed, guardRejected...)
	if len(result.Removed) == 0 && len(guardRejected) > 0 {
		return workflow.RemoveCapabilityUsersActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("The requested users could not be removed"), true)
	}
	return result, nil
}

// tierPatternRows builds the six capability rows the tier pattern of an access
// level prescribes (F-ROLE-04): Total Control = every applicable CRUD column
// true; Read Only = Read true, everything else false. The applicable columns
// come from the code catalog (PRD §2.1) — Import data has no Update/Delete,
// Manage files no Create/Update, Manage TAG no Create/Delete. Every row is a
// global grant with a fresh Snowflake id; UPSERT leaves an existing row's id
// untouched.
func tierPatternRows(product model.Product, userID int64, level model.AccessLevel, modifiedBy int64) []model.UserSystemRole {
	rows := make([]model.UserSystemRole, 0, len(model.SystemRoleCatalog))
	for _, c := range model.SystemRoleCatalog {
		row := model.UserSystemRole{
			ID:         coreDb.Node.Generate().Int64(),
			UserID:     userID,
			Product:    product,
			ScopeLevel: model.ScopeLevelGlobal,
			Key:        c.Key,
			ModifiedBy: &modifiedBy,
		}
		for _, col := range model.SystemRoleApplicablePermissions(c.Key) {
			value := level == model.AccessLevelTotalControl ||
				(level == model.AccessLevelReadOnly && col == model.PermissionColumnRead)
			switch col {
			case model.PermissionColumnCreate:
				row.PermissionCreate = value
			case model.PermissionColumnRead:
				row.PermissionView = value
			case model.PermissionColumnUpdate:
				row.PermissionUpdate = value
			case model.PermissionColumnDelete:
				row.PermissionDelete = value
			}
		}
		rows = append(rows, row)
	}
	return rows
}
