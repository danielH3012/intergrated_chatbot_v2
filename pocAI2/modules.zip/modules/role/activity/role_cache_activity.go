package activity

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
)

// InvalidateUserRolesActivity drops the RBAC snapshots of the users a write
// workflow just changed, so their next request rebuilds the snapshot from the
// role tables instead of serving the stale Valkey entry for up to the 24h TTL
// (the TTL is only a backstop).
//
// It runs after the write activity committed — the workflow schedules it as a
// separate activity, so a worker crash between commit and invalidation is
// recovered on replay instead of being lost. Deletion is idempotent (a
// repeated delete is a no-op) and fail-soft (the cache package logs and
// swallows Valkey errors), so the activity always succeeds; a cache outage
// leaves the TTL as the backstop rather than failing a write that already
// committed.
func (a *RoleActivities) InvalidateUserRolesActivity(ctx context.Context, param workflow.InvalidateUserRolesActivityParam) error {
	if a.invalidator == nil || len(param.UserIDs) == 0 {
		return nil
	}
	for _, userID := range param.UserIDs {
		a.invalidator.InvalidateUserRoles(ctx, userID)
	}
	slog.InfoContext(ctx, "role: RBAC snapshots invalidated",
		"clientId", param.ClientID,
		"count", len(param.UserIDs),
	)
	return nil
}
