// Package activity implements the Role & Permission Temporal activities, run
// on the iam-service worker.
package activity

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// uniqueViolationCode is Postgres' SQLSTATE for a unique index conflict. The
// ADD activity maps it to 409 — the row already exists.
const uniqueViolationCode = "23505"

// UserRolesInvalidator drops the cached RBAC snapshots of users whose role
// assignments changed. *cache.Cache implements it (InvalidateUserRoles drops
// both the roles snapshot and the me-permissions payload); nil disables
// invalidation, which is all unit tests need.
type UserRolesInvalidator interface {
	InvalidateUserRoles(ctx context.Context, userID int64)
}

// RoleActivities holds the dependencies for the Role & Permission write
// activities.
//
// It holds dbName, not a PostgreSQLService instance: that struct carries
// per-instance transaction state, so a single shared instance would race
// across concurrently-executing activities. Each method builds its own
// service via tenantSvc().
type RoleActivities struct {
	dbName string
	repo   repository.RoleRepositor
	// invalidator drops the target's RBAC snapshot after a committed write.
	invalidator UserRolesInvalidator
	// makeTenantSvc swaps the eager pool construction in tests.
	makeTenantSvc func(clientID string) coreService.PostgreSQLServicer
}

// NewRoleActivities wires the write activities. invalidator may be nil — the
// write activities never touch the cache themselves; only
// InvalidateUserRolesActivity consumes it.
func NewRoleActivities(dbName string, repo repository.RoleRepositor, invalidator UserRolesInvalidator) *RoleActivities {
	return &RoleActivities{dbName: dbName, repo: repo, invalidator: invalidator}
}

// tenantSvc opens the tenant's own schema for the activity's client.
func (a *RoleActivities) tenantSvc(clientID string) coreService.PostgreSQLServicer {
	if a.makeTenantSvc != nil {
		return a.makeTenantSvc(clientID)
	}
	return coreService.MakePostgreSQLService(clientID + ":" + a.dbName)
}

// AddCapabilityUserActivity creates a new global capability assignment with
// the Read-locked baseline: permission_view=true, Create/Update/Delete=false.
// Guards, in order: self-add is blocked for every actor; the target must be
// inside the same pool the assignable picker serves — access for the product
// plus an active or pending-activation user; and a duplicate (user, product,
// key, scope) row is a conflict. Guard failures are non-retryable so the
// workflow surfaces them as-is instead of retrying into the same failure.
func (a *RoleActivities) AddCapabilityUserActivity(ctx context.Context, param workflow.AddCapabilityUserActivityParam) (workflow.AddCapabilityUserActivityResult, error) {
	if param.ActorID == param.UserID {
		return workflow.AddCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("You cannot edit your own permissions"), true)
	}

	svc := a.tenantSvc(param.ClientID)

	elig, err := a.repo.GetUserAssignmentEligibility(ctx, svc, param.Product, param.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return workflow.AddCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.NotFound("This user is no longer available."), true)
		}
		return workflow.AddCapabilityUserActivityResult{}, fmt.Errorf("role.AddCapabilityUser eligibility: %w", err)
	}
	if elig.ModuleActive == nil || !*elig.ModuleActive ||
		(elig.ActivationStatus != dto.ActivationPendingActivation && elig.ActivationStatus != dto.ActivationActivated) {
		return workflow.AddCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.BadRequest("User is not eligible for this assignment"), true)
	}

	coreDb.InitSnowflake()
	modifiedBy := param.ActorID
	row := model.UserSystemRole{
		ID:             coreDb.Node.Generate().Int64(),
		UserID:         param.UserID,
		Product:        param.Product,
		ScopeLevel:     model.ScopeLevelGlobal,
		Key:            param.Key,
		PermissionView: true,
		ModifiedBy:     &modifiedBy,
	}
	if err := a.repo.AddCapabilityUser(ctx, svc, row); err != nil {
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == uniqueViolationCode {
			return workflow.AddCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Conflict("User already has this capability"), true)
		}
		return workflow.AddCapabilityUserActivityResult{}, fmt.Errorf("role.AddCapabilityUser: %w", err)
	}
	return workflow.AddCapabilityUserActivityResult{UserID: param.UserID, UserFullName: elig.FullName}, nil
}

// PatchCapabilityUserActivity updates the C/U/D checkboxes of one capability
// assignment. Guards, in order: the row must still exist; the actor may not
// edit themself; a target holding an access level may only be edited by a
// Total Control actor; and a Default User may never be reverted away from
// Total Control. When the resulting six-row set no longer matches the tier
// pattern of the held access level the tier row is deleted in the same
// transaction (auto-revert). Guard failures are non-retryable; the tier-revert
// flag and reverted tier are returned so the workflow can build the
// changelog rows.
func (a *RoleActivities) PatchCapabilityUserActivity(ctx context.Context, param workflow.PatchCapabilityUserActivityParam) (workflow.PatchCapabilityUserActivityResult, error) {
	svc := a.tenantSvc(param.ClientID)

	row, err := a.repo.GetCapabilityUserRow(ctx, svc, param.Product, param.Key, param.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return workflow.PatchCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.NotFound("This user is no longer available."), true)
		}
		return workflow.PatchCapabilityUserActivityResult{}, fmt.Errorf("role.PatchCapabilityUser row: %w", err)
	}

	if param.ActorID == row.UserID {
		return workflow.PatchCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("You cannot edit your own permissions"), true)
	}

	module, ok := ProductModule(param.Product)
	if !ok {
		return workflow.PatchCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.BadRequest("Unknown product"), true)
	}

	tier, err := a.repo.GetUserAccessLevelRow(ctx, svc, param.Product, param.UserID)
	if err != nil {
		if !errors.Is(err, pgx.ErrNoRows) {
			return workflow.PatchCapabilityUserActivityResult{}, fmt.Errorf("role.PatchCapabilityUser tier: %w", err)
		}
		tier = nil
	}
	if tier != nil && !param.Roles.IsTotalControl(module) {
		return workflow.PatchCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("Only Total Control can edit access level assignments"), true)
	}

	update := sql_query.UpdateQuery{}
	if param.Permission != nil {
		if param.Permission.Create != nil {
			update["permission_create"] = *param.Permission.Create
		}
		if param.Permission.Update != nil {
			update["permission_update"] = *param.Permission.Update
		}
		if param.Permission.Delete != nil {
			update["permission_delete"] = *param.Permission.Delete
		}
	}
	update["modified_by"] = param.ActorID
	update["updated_at"] = time.Now()

	revert := false
	if tier != nil {
		rows, err := a.repo.ListUserCapabilityRows(ctx, svc, param.Product, param.UserID)
		if err != nil {
			return workflow.PatchCapabilityUserActivityResult{}, fmt.Errorf("role.PatchCapabilityUser rows: %w", err)
		}
		revert = !matchesTierPattern(rows, model.AccessLevel(tier.AccessLevel), param.Key, param.Permission)
		if revert && row.IsDefault {
			return workflow.PatchCapabilityUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("Default User must always have Total Control"), true)
		}
	}

	result := workflow.PatchCapabilityUserActivityResult{
		Before: *row,
	}
	if revert {
		// The flag edit and the tier delete must land atomically — a crash
		// between them would leave a badge that no longer matches the rows.
		if _, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
			svc.SetTransaction(tx)
			if err := a.repo.PatchCapabilityUserRow(ctx, svc, param.Product, param.Key, param.UserID, update); err != nil {
				return struct{}{}, err
			}
			return struct{}{}, a.repo.DeleteUserAccessLevelRow(ctx, svc, param.Product, param.UserID)
		}); err != nil {
			return workflow.PatchCapabilityUserActivityResult{}, fmt.Errorf("role.PatchCapabilityUser revert: %w", err)
		}
		result.AccessLevelAutoReverted = true
		result.RevertedAccessLevel = model.AccessLevel(tier.AccessLevel)
	} else {
		if err := a.repo.PatchCapabilityUserRow(ctx, svc, param.Product, param.Key, param.UserID, update); err != nil {
			return workflow.PatchCapabilityUserActivityResult{}, fmt.Errorf("role.PatchCapabilityUser: %w", err)
		}
	}
	return result, nil
}

// ProductModule maps the {product} enum to the module key the RBAC snapshot is
// keyed by — the same mapping the route gates use, needed by the tier guard.
func ProductModule(product model.Product) (enum.ModuleAccess, bool) {
	switch product {
	case model.ProductGlobalSettings:
		return enum.ModuleAccessGlobalSettings, true
	case model.ProductAdminConsole:
		return enum.ModuleAccessAdminConsole, true
	case model.ProductFixedAsset:
		return enum.ModuleAccessFixedAsset, true
	default:
		return "", false
	}
}

// matchesTierPattern reports whether the target's six capability rows, after
// the pending patch is applied, still match the tier pattern of the access
// level they hold. Only the capability's applicable columns (PRD §2.1)
// participate; a missing capability row never matches.
func matchesTierPattern(rows []model.UserSystemRole, tier model.AccessLevel, patchKey model.SystemRoleKey, patch *dto.CapabilityPermissionPatch) bool {
	byKey := make(map[model.SystemRoleKey]model.UserSystemRole, len(rows))
	for _, r := range rows {
		byKey[r.Key] = r
	}

	for _, c := range model.SystemRoleCatalog {
		r, ok := byKey[c.Key]
		if !ok {
			return false
		}
		for _, col := range model.SystemRoleApplicablePermissions(c.Key) {
			val := permissionValue(r, col)
			if patch != nil && c.Key == patchKey {
				val = patchedPermissionValue(val, col, patch)
			}
			switch tier {
			case model.AccessLevelTotalControl:
				if !val {
					return false
				}
			case model.AccessLevelReadOnly:
				if col == model.PermissionColumnRead {
					if !val {
						return false
					}
				} else if val {
					return false
				}
			}
		}
	}
	return true
}

// permissionValue reads one CRUD column of a capability row.
func permissionValue(r model.UserSystemRole, col model.PermissionColumn) bool {
	switch col {
	case model.PermissionColumnCreate:
		return r.PermissionCreate
	case model.PermissionColumnUpdate:
		return r.PermissionUpdate
	case model.PermissionColumnDelete:
		return r.PermissionDelete
	default:
		return r.PermissionView
	}
}

// patchedPermissionValue overlays the pending patch onto a column value. Read
// is locked: a supplied read flag is silently ignored (PRD Edge Case D5) —
// permission_view stays true while the row exists, so the tier pattern is
// evaluated against the unchanged row value.
func patchedPermissionValue(current bool, col model.PermissionColumn, patch *dto.CapabilityPermissionPatch) bool {
	switch col {
	case model.PermissionColumnCreate:
		if patch.Create != nil {
			return *patch.Create
		}
	case model.PermissionColumnUpdate:
		if patch.Update != nil {
			return *patch.Update
		}
	case model.PermissionColumnDelete:
		if patch.Delete != nil {
			return *patch.Delete
		}
	}
	return current
}
