package activity

import (
	"context"
	"errors"
	"testing"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"go.temporal.io/sdk/temporal"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// writeFakeRepo is a stateful in-memory double for the Role & Permission write
// surface: canned rows/tiers in, captured UpdateQuery / insert / tier delete
// out.
type writeFakeRepo struct {
	row            *dto.CapabilityUserRow
	rowErr         error
	capabilityRows []model.UserSystemRole
	tier           *model.UserAccessLevel
	tierErr        error
	eligibility    *dto.UserAssignmentEligibility
	eligErr        error
	addErr         error

	added       *model.UserSystemRole
	updated     *sql_query.UpdateQuery
	deletedTier bool

	// Access-level assign/remove surface.
	upsertedLevel *model.UserAccessLevel
	upsertedRows  []model.UserSystemRole
	deletedRows   []int64

	// Per-user canned reads — consulted before the single-row fallbacks.
	tiers         map[int64]*model.UserAccessLevel
	eligibilities map[int64]*dto.UserAssignmentEligibility

	// Capability remove surface.
	removeRows             []dto.CapabilityUserRow
	deletedCapabilityUsers []int64
}

func (f *writeFakeRepo) UpsertAccessLevel(_ context.Context, _ coreService.PostgreSQLServicer, row model.UserAccessLevel) error {
	f.upsertedLevel = &row
	return nil
}

func (f *writeFakeRepo) UpsertCapabilityRows(_ context.Context, _ coreService.PostgreSQLServicer, rows []model.UserSystemRole) error {
	f.upsertedRows = rows
	return nil
}

func (f *writeFakeRepo) DeleteCapabilityRows(_ context.Context, _ coreService.PostgreSQLServicer, _ model.Product, userID int64) error {
	f.deletedRows = append(f.deletedRows, userID)
	return nil
}

func (f *writeFakeRepo) ListCapabilityUserRows(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, []int64) ([]dto.CapabilityUserRow, error) {
	return f.removeRows, nil
}

func (f *writeFakeRepo) DeleteCapabilityUserRow(_ context.Context, _ coreService.PostgreSQLServicer, _ model.Product, _ model.SystemRoleKey, userID int64) error {
	f.deletedCapabilityUsers = append(f.deletedCapabilityUsers, userID)
	return nil
}

func (f *writeFakeRepo) GetCapabilityUserRow(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, int64) (*dto.CapabilityUserRow, error) {
	return f.row, f.rowErr
}

func (f *writeFakeRepo) ListUserCapabilityRows(context.Context, coreService.PostgreSQLServicer, model.Product, int64) ([]model.UserSystemRole, error) {
	return f.capabilityRows, nil
}

func (f *writeFakeRepo) GetUserAccessLevelRow(_ context.Context, _ coreService.PostgreSQLServicer, _ model.Product, userID int64) (*model.UserAccessLevel, error) {
	if f.tierErr != nil {
		return nil, f.tierErr
	}
	if f.tiers != nil {
		if t, ok := f.tiers[userID]; ok {
			return t, nil
		}
		return nil, pgx.ErrNoRows
	}
	if f.tier == nil {
		return nil, pgx.ErrNoRows
	}
	return f.tier, nil
}

func (f *writeFakeRepo) GetUserAssignmentEligibility(_ context.Context, _ coreService.PostgreSQLServicer, _ model.Product, userID int64) (*dto.UserAssignmentEligibility, error) {
	if f.eligErr != nil {
		return nil, f.eligErr
	}
	if f.eligibilities != nil {
		if e, ok := f.eligibilities[userID]; ok {
			return e, nil
		}
		return nil, pgx.ErrNoRows
	}
	return f.eligibility, nil
}

func (f *writeFakeRepo) AddCapabilityUser(_ context.Context, _ coreService.PostgreSQLServicer, row model.UserSystemRole) error {
	f.added = &row
	return f.addErr
}

func (f *writeFakeRepo) PatchCapabilityUserRow(_ context.Context, _ coreService.PostgreSQLServicer, _ model.Product, _ model.SystemRoleKey, _ int64, body sql_query.UpdateQuery) error {
	f.updated = &body
	return nil
}

func (f *writeFakeRepo) DeleteUserAccessLevelRow(_ context.Context, _ coreService.PostgreSQLServicer, _ model.Product, _ int64) error {
	f.deletedTier = true
	return nil
}

func (f *writeFakeRepo) ListCapabilities(context.Context, coreService.PostgreSQLServicer, model.Product, dto.CapabilitiesListQuery) (*dto.CapabilitiesListResponse, error) {
	panic("not called")
}
func (f *writeFakeRepo) ListCapabilitiesAll(context.Context, coreService.PostgreSQLServicer, model.Product, dto.CapabilitiesListQuery) ([]dto.CapabilitiesListItem, error) {
	panic("not called")
}

func (f *writeFakeRepo) ListAccessLevelUsers(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) (*dto.AccessLevelListResponse, error) {
	panic("not called")
}
func (f *writeFakeRepo) ListAccessLevelUsersAll(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) ([]dto.AccessLevelListItem, error) {
	panic("not called")
}

func (f *writeFakeRepo) GetAccessLevelOptions(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AccessLevelListQuery) (*dto.AccessLevelOptionsResponse, error) {
	panic("not called")
}

func (f *writeFakeRepo) ListCapabilityUsers(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) (*dto.CapabilityUsersListResponse, error) {
	panic("not called")
}
func (f *writeFakeRepo) ListCapabilityUsersAll(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) ([]dto.CapabilityUsersListItem, error) {
	panic("not called")
}

func (f *writeFakeRepo) GetCapabilityUsersOptions(context.Context, coreService.PostgreSQLServicer, model.Product, model.SystemRoleKey, dto.CapabilityUsersListQuery) (*dto.CapabilityUsersOptionsResponse, error) {
	panic("not called")
}

func (f *writeFakeRepo) ListAssignableUsers(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AssignableUsersListQuery) (*dto.AssignableUsersListResponse, error) {
	panic("not called")
}

func (f *writeFakeRepo) GetAssignableUsersOptions(context.Context, coreService.PostgreSQLServicer, model.Product, dto.AssignableUsersListQuery) (*dto.AssignableUsersOptionsResponse, error) {
	panic("not called")
}

var _ repository.RoleRepositor = (*writeFakeRepo)(nil)

// fakeServicerFactory swaps the eager pool construction (which dials
// PostgreSQL and log.Fatals) for a no-op servicer the fakes never use.
func fakeServicerFactory(string) coreService.PostgreSQLServicer {
	return &coreService.FakePostgreSQLService{}
}

// totalControlRoles builds a snapshot whose global-settings module is Total
// Control; withTC=false the actor holds no module access at all.
func totalControlRoles(withTC bool) tsMiddleware.UserAccessCache {
	module := map[enum.ModuleAccess]tsMiddleware.ModuleFlags{}
	if withTC {
		module[enum.ModuleAccessGlobalSettings] = tsMiddleware.ModuleFlags{IsTotalControl: true}
	}
	return tsMiddleware.UserAccessCache{ID: 1, ModuleAccess: module}
}

func fullCRUDRows() []model.UserSystemRole {
	var rows []model.UserSystemRole
	for _, c := range model.SystemRoleCatalog {
		rows = append(rows, model.UserSystemRole{
			Key:              c.Key,
			PermissionView:   true,
			PermissionCreate: true,
			PermissionUpdate: true,
			PermissionDelete: true,
		})
	}
	return rows
}

func readOnlyRows() []model.UserSystemRole {
	var rows []model.UserSystemRole
	for _, c := range model.SystemRoleCatalog {
		rows = append(rows, model.UserSystemRole{Key: c.Key, PermissionView: true})
	}
	return rows
}

func newRoleActivities(repo *writeFakeRepo) *RoleActivities {
	acts, _ := newRoleActivitiesWithInvalidator(repo)
	return acts
}

// newRoleActivitiesWithInvalidator returns the activities plus the recording
// invalidator, so tests can assert which users' RBAC snapshots were dropped.
func newRoleActivitiesWithInvalidator(repo *writeFakeRepo) (*RoleActivities, *recordingInvalidator) {
	inv := &recordingInvalidator{}
	acts := NewRoleActivities("testdb", repo, inv)
	acts.makeTenantSvc = fakeServicerFactory
	return acts, inv
}

// recordingInvalidator captures the user IDs InvalidateUserRolesActivity
// dropped the RBAC snapshot for.
type recordingInvalidator struct {
	invalidated []int64
}

func (f *recordingInvalidator) InvalidateUserRoles(_ context.Context, userID int64) {
	f.invalidated = append(f.invalidated, userID)
}

// appErr asserts the activity failed with a non-retryable ApplicationError —
// guard failures must never be retried into the same failure — and returns it.
func appErr(t *testing.T, err error) *temporal.ApplicationError {
	t.Helper()
	var appErr *temporal.ApplicationError
	if !errors.As(err, &appErr) {
		t.Fatalf("err = %v, want temporal.ApplicationError", err)
	}
	if !appErr.NonRetryable() {
		t.Fatalf("err = %v, want non-retryable", err)
	}
	return appErr
}

func patchParam(repo *writeFakeRepo, userID, actorID int64, roles tsMiddleware.UserAccessCache, body dto.CapabilityUserPatchBody) workflow.PatchCapabilityUserActivityParam {
	return workflow.PatchCapabilityUserActivityParam{
		ClientID:   "client-1",
		Product:    model.ProductGlobalSettings,
		UserID:     userID,
		ActorID:    actorID,
		Key:        model.SystemRoleKey(body.Key),
		Roles:      roles,
		Permission: body.Permission,
	}
}

func TestPatchCapabilityUserSelfEdit(t *testing.T) {
	repo := &writeFakeRepo{row: &dto.CapabilityUserRow{UserID: 42, IsDefault: false}}
	acts := newRoleActivities(repo)

	_, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 42, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key: string(model.SystemRoleKeyManageUserAndRole),
	}))
	e := appErr(t, err)
	if e.Type() != "Forbidden" || e.Message() != "You cannot edit your own permissions" {
		t.Fatalf("err = %+v, want 403 self-edit", e)
	}
}

func TestPatchCapabilityUserRowMissing(t *testing.T) {
	repo := &writeFakeRepo{rowErr: pgx.ErrNoRows}
	acts := newRoleActivities(repo)

	_, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key: string(model.SystemRoleKeyManageUserAndRole),
	}))
	if e := appErr(t, err); e.Type() != "NotFound" {
		t.Fatalf("err = %+v, want 404", e)
	}
}

func TestPatchCapabilityUserTargetTierNonTotalControl(t *testing.T) {
	repo := &writeFakeRepo{
		row:  &dto.CapabilityUserRow{UserID: 42},
		tier: &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
	}
	acts := newRoleActivities(repo)

	_, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(false), dto.CapabilityUserPatchBody{
		Key: string(model.SystemRoleKeyManageUserAndRole),
	}))
	e := appErr(t, err)
	if e.Type() != "Forbidden" || e.Message() != "Only Total Control can edit access level assignments" {
		t.Fatalf("err = %+v, want 403 tier guard", e)
	}
}

func TestPatchCapabilityUserDefaultUserCannotRevert(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42, IsDefault: true},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
		capabilityRows: fullCRUDRows(),
	}
	acts := newRoleActivities(repo)

	create := false
	_, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key:        string(model.SystemRoleKeyManageUserAndRole),
		Permission: &dto.CapabilityPermissionPatch{Create: &create},
	}))
	e := appErr(t, err)
	if e.Type() != "Forbidden" || e.Message() != "Default User must always have Total Control" {
		t.Fatalf("err = %+v, want 403 default-user guard", e)
	}
}

func TestPatchCapabilityUserDefaultUserBenignEditPasses(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42, IsDefault: true},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
		capabilityRows: fullCRUDRows(),
	}
	acts := newRoleActivities(repo)

	// Re-checking a flag that is already true keeps the TC pattern.
	create := true
	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key:        string(model.SystemRoleKeyManageUserAndRole),
		Permission: &dto.CapabilityPermissionPatch{Create: &create},
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.AccessLevelAutoReverted {
		t.Fatal("benign edit must not auto-revert")
	}
	if repo.deletedTier {
		t.Fatal("benign edit must not delete the tier row")
	}
	if repo.updated == nil || (*repo.updated)["permission_create"] != true {
		t.Fatalf("updated = %+v, want permission_create=true", repo.updated)
	}
}

func TestPatchCapabilityUserReadIsSilentlyIgnored(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
		capabilityRows: fullCRUDRows(),
	}
	acts := newRoleActivities(repo)

	// read:false in the payload is ignored (PRD Edge Case D5 / TC-GS-ROLE-34):
	// permission_view stays true for the tier-pattern check, and the C/U/D
	// change in the same payload is still applied.
	create := true
	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key: string(model.SystemRoleKeyManageUserAndRole),
		Permission: &dto.CapabilityPermissionPatch{
			Create: &create,
			Read:   boolPtr(false),
		},
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.AccessLevelAutoReverted || repo.deletedTier {
		t.Fatal("read:false must not break the TC tier pattern")
	}
	if repo.updated == nil || (*repo.updated)["permission_create"] != true {
		t.Fatalf("updated = %+v, want permission_create=true", repo.updated)
	}
	if _, hasView := (*repo.updated)["permission_view"]; hasView {
		t.Fatalf("updated = %+v, PATCH must never write permission_view", repo.updated)
	}
}

func TestPatchCapabilityUserRevertsTier(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
		capabilityRows: fullCRUDRows(),
	}
	acts := newRoleActivities(repo)

	create := false
	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key:        string(model.SystemRoleKeyManageUserAndRole),
		Permission: &dto.CapabilityPermissionPatch{Create: &create},
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !res.AccessLevelAutoReverted {
		t.Fatal("pattern-breaking edit must auto-revert")
	}
	if res.RevertedAccessLevel != model.AccessLevelTotalControl {
		t.Fatalf("revertedAccessLevel = %q, want total_control", res.RevertedAccessLevel)
	}
	if !repo.deletedTier {
		t.Fatal("tier row must be deleted")
	}
	if repo.updated == nil || (*repo.updated)["permission_create"] != false || (*repo.updated)["modified_by"] != int64(1) {
		t.Fatalf("updated = %+v, want permission_create=false + modified_by", repo.updated)
	}
}

func TestPatchCapabilityUserReadOnlyReverts(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelReadOnly},
		capabilityRows: readOnlyRows(),
	}
	acts := newRoleActivities(repo)

	create := true
	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key:        string(model.SystemRoleKeyImportData),
		Permission: &dto.CapabilityPermissionPatch{Create: &create},
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !res.AccessLevelAutoReverted || !repo.deletedTier {
		t.Fatalf("res = %+v deletedTier=%v, want revert", res, repo.deletedTier)
	}
	if res.RevertedAccessLevel != model.AccessLevelReadOnly {
		t.Fatalf("revertedAccessLevel = %q, want read_only", res.RevertedAccessLevel)
	}
}

func TestPatchCapabilityUserKeepsTierNoChange(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
		capabilityRows: fullCRUDRows(),
	}
	acts := newRoleActivities(repo)

	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key: string(model.SystemRoleKeyManageUserAndRole),
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.AccessLevelAutoReverted || repo.deletedTier {
		t.Fatal("no-op edit must not auto-revert")
	}
}

func TestPatchCapabilityUserNoTierNoRevert(t *testing.T) {
	repo := &writeFakeRepo{row: &dto.CapabilityUserRow{UserID: 42}, tierErr: pgx.ErrNoRows}
	acts := newRoleActivities(repo)

	create := false
	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key:        string(model.SystemRoleKeyManageUserAndRole),
		Permission: &dto.CapabilityPermissionPatch{Create: &create},
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.AccessLevelAutoReverted || repo.deletedTier {
		t.Fatal("tierless user cannot auto-revert")
	}
}

func TestPatchCapabilityUserMissingCapabilityRowReverts(t *testing.T) {
	repo := &writeFakeRepo{
		row:            &dto.CapabilityUserRow{UserID: 42},
		tier:           &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
		capabilityRows: fullCRUDRows()[:5], // one capability row missing
	}
	acts := newRoleActivities(repo)

	res, err := acts.PatchCapabilityUserActivity(context.Background(), patchParam(repo, 42, 1, totalControlRoles(true), dto.CapabilityUserPatchBody{
		Key: string(model.SystemRoleKeyManageUserAndRole),
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !res.AccessLevelAutoReverted {
		t.Fatal("a missing capability row must break the tier pattern")
	}
}

func TestAddCapabilityUserSelfAdd(t *testing.T) {
	repo := &writeFakeRepo{}
	acts := newRoleActivities(repo)

	_, err := acts.AddCapabilityUserActivity(context.Background(), workflow.AddCapabilityUserActivityParam{
		ClientID: "client-1",
		Product:  model.ProductGlobalSettings,
		ActorID:  42,
		UserID:   42,
		Key:      model.SystemRoleKeyManageUserAndRole,
	})
	if e := appErr(t, err); e.Type() != "Forbidden" {
		t.Fatalf("err = %+v, want 403 self-add", e)
	}
	if repo.added != nil {
		t.Fatal("self-add must not insert")
	}
}

func TestAddCapabilityUserMissingUser(t *testing.T) {
	repo := &writeFakeRepo{eligErr: pgx.ErrNoRows}
	acts := newRoleActivities(repo)

	_, err := acts.AddCapabilityUserActivity(context.Background(), workflow.AddCapabilityUserActivityParam{
		ClientID: "client-1",
		Product:  model.ProductGlobalSettings,
		ActorID:  1,
		UserID:   42,
		Key:      model.SystemRoleKeyManageUserAndRole,
	})
	if e := appErr(t, err); e.Type() != "NotFound" {
		t.Fatalf("err = %+v, want 404", e)
	}
}

func TestAddCapabilityUserNotEligible(t *testing.T) {
	cases := []*dto.UserAssignmentEligibility{
		{UserID: 42, ActivationStatus: "Activated"}, // no module access row
		{UserID: 42, ActivationStatus: "Activated", ModuleActive: boolPtr(false)},
		{UserID: 42, ActivationStatus: "Inactive", ModuleActive: boolPtr(true)},
	}
	for _, elig := range cases {
		repo := &writeFakeRepo{eligibility: elig}
		acts := newRoleActivities(repo)

		_, err := acts.AddCapabilityUserActivity(context.Background(), workflow.AddCapabilityUserActivityParam{
			ClientID: "client-1",
			Product:  model.ProductGlobalSettings,
			ActorID:  1,
			UserID:   42,
			Key:      model.SystemRoleKeyManageUserAndRole,
		})
		if e := appErr(t, err); e.Type() != "BadRequest" {
			t.Fatalf("elig %+v: err = %+v, want 400", elig, e)
		}
		if repo.added != nil {
			t.Fatalf("elig %+v: must not insert", elig)
		}
	}
}

func TestAddCapabilityUserDuplicate(t *testing.T) {
	repo := &writeFakeRepo{
		eligibility: &dto.UserAssignmentEligibility{UserID: 42, ActivationStatus: "Activated", ModuleActive: boolPtr(true)},
		addErr:      &pgconn.PgError{Code: uniqueViolationCode},
	}
	acts := newRoleActivities(repo)

	_, err := acts.AddCapabilityUserActivity(context.Background(), workflow.AddCapabilityUserActivityParam{
		ClientID: "client-1",
		Product:  model.ProductGlobalSettings,
		ActorID:  1,
		UserID:   42,
		Key:      model.SystemRoleKeyManageUserAndRole,
	})
	if e := appErr(t, err); e.Type() != "Conflict" {
		t.Fatalf("err = %+v, want 409", e)
	}
}

func TestAddCapabilityUserInsertsReadBaseline(t *testing.T) {
	repo := &writeFakeRepo{
		eligibility: &dto.UserAssignmentEligibility{UserID: 42, FullName: "Mike Tan", ActivationStatus: "Pending Activation", ModuleActive: boolPtr(true)},
	}
	acts := newRoleActivities(repo)

	res, err := acts.AddCapabilityUserActivity(context.Background(), workflow.AddCapabilityUserActivityParam{
		ClientID: "client-1",
		Product:  model.ProductGlobalSettings,
		ActorID:  1,
		UserID:   42,
		Key:      model.SystemRoleKeyManageUserAndRole,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if repo.added == nil {
		t.Fatal("row must be inserted")
	}
	if repo.added.UserID != 42 || repo.added.Key != model.SystemRoleKeyManageUserAndRole || repo.added.Product != model.ProductGlobalSettings {
		t.Fatalf("row = %+v", repo.added)
	}
	if repo.added.ScopeLevel != model.ScopeLevelGlobal {
		t.Errorf("scopeLevel = %q, want global", repo.added.ScopeLevel)
	}
	if !repo.added.PermissionView || repo.added.PermissionCreate || repo.added.PermissionUpdate || repo.added.PermissionDelete {
		t.Errorf("row = %+v, want read=true baseline with C/U/D false", repo.added)
	}
	if repo.added.ModifiedBy == nil || *repo.added.ModifiedBy != 1 {
		t.Errorf("modifiedBy = %v, want actor 1", repo.added.ModifiedBy)
	}
	if repo.added.ID == 0 {
		t.Error("snowflake id must be set")
	}
	if res.UserID != 42 || res.UserFullName != "Mike Tan" {
		t.Fatalf("result = %+v, want target identity for the changelog row", res)
	}
}

func TestMatchesTierPattern(t *testing.T) {
	rows := fullCRUDRows()
	create := false
	patch := &dto.CapabilityPermissionPatch{Create: &create}

	if !matchesTierPattern(rows, model.AccessLevelTotalControl, model.SystemRoleKeyManageUserAndRole, nil) {
		t.Fatal("full CRUD rows must match the TC pattern")
	}
	if matchesTierPattern(rows, model.AccessLevelTotalControl, model.SystemRoleKeyManageUserAndRole, patch) {
		t.Fatal("unchecked create must break the TC pattern")
	}
	if !matchesTierPattern(readOnlyRows(), model.AccessLevelReadOnly, model.SystemRoleKeyManageUserAndRole, nil) {
		t.Fatal("view-only rows must match the RO pattern")
	}
	// Non-applicable columns are ignored: import_data has no Update/Delete.
	importRow := fullCRUDRows()
	importRow[3].PermissionUpdate = false
	importRow[3].PermissionDelete = false
	if !matchesTierPattern(importRow, model.AccessLevelTotalControl, model.SystemRoleKeyManageUserAndRole, nil) {
		t.Fatal("non-applicable columns must not break the TC pattern")
	}
	if matchesTierPattern(rows[:5], model.AccessLevelTotalControl, model.SystemRoleKeyManageUserAndRole, nil) {
		t.Fatal("missing capability row must not match the TC pattern")
	}
	enable := true
	roRows := readOnlyRows()
	if matchesTierPattern(roRows, model.AccessLevelReadOnly, model.SystemRoleKeyImportData, &dto.CapabilityPermissionPatch{Create: &enable}) {
		t.Fatal("enabled create must break the RO pattern")
	}
}

func boolPtr(b bool) *bool { return &b }
