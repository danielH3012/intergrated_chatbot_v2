package activity

import (
	"context"
	"testing"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
)

// eligible builds the assign/remove guard read: module access granted and the
// user activated, no default-user flag.
func eligible(userID int64, fullName string) *dto.UserAssignmentEligibility {
	return &dto.UserAssignmentEligibility{
		UserID:           userID,
		FullName:         fullName,
		ActivationStatus: dto.ActivationActivated,
		ModuleActive:     boolPtr(true),
	}
}

func assignParam(userID, actorID int64, level model.AccessLevel) workflow.AssignAccessLevelActivityParam {
	return workflow.AssignAccessLevelActivityParam{
		ClientID:    "client-1",
		Product:     model.ProductGlobalSettings,
		UserID:      userID,
		ActorID:     actorID,
		AccessLevel: level,
	}
}

// assertTierPattern verifies the six upserted rows match the prescribed tier
// pattern: TC = every applicable CRUD column true, RO = Read true only.
func assertTierPattern(t *testing.T, rows []model.UserSystemRole, level model.AccessLevel) {
	t.Helper()
	if len(rows) != len(model.SystemRoleCatalog) {
		t.Fatalf("rows = %d, want %d", len(rows), len(model.SystemRoleCatalog))
	}
	for _, row := range rows {
		if row.ScopeLevel != model.ScopeLevelGlobal {
			t.Errorf("row %s: scopeLevel = %q, want global", row.Key, row.ScopeLevel)
		}
		if row.ModifiedBy == nil || *row.ModifiedBy != 1 {
			t.Errorf("row %s: modifiedBy = %v, want actor 1", row.Key, row.ModifiedBy)
		}
		for _, col := range model.SystemRoleApplicablePermissions(row.Key) {
			want := level == model.AccessLevelTotalControl ||
				(level == model.AccessLevelReadOnly && col == model.PermissionColumnRead)
			var got bool
			switch col {
			case model.PermissionColumnCreate:
				got = row.PermissionCreate
			case model.PermissionColumnRead:
				got = row.PermissionView
			case model.PermissionColumnUpdate:
				got = row.PermissionUpdate
			case model.PermissionColumnDelete:
				got = row.PermissionDelete
			}
			if got != want {
				t.Errorf("row %s col %s = %v, want %v (tier %s)", row.Key, col, got, want, level)
			}
		}
	}
}

func TestAssignAccessLevelSelfAssign(t *testing.T) {
	repo := &writeFakeRepo{}
	acts := newRoleActivities(repo)

	_, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 42, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "Forbidden" || e.Message() != "You cannot change your own access level." {
		t.Fatalf("err = %+v, want 403 self-assign", e)
	}
	if repo.upsertedLevel != nil || repo.upsertedRows != nil {
		t.Fatal("self-assign must not write")
	}
}

func TestAssignAccessLevelMissingUser(t *testing.T) {
	repo := &writeFakeRepo{eligErr: pgx.ErrNoRows}
	acts := newRoleActivities(repo)

	_, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "NotFound" {
		t.Fatalf("err = %+v, want 404", e)
	}
}

func TestAssignAccessLevelNotEligible(t *testing.T) {
	cases := []*dto.UserAssignmentEligibility{
		{UserID: 42, ActivationStatus: dto.ActivationActivated},
		{UserID: 42, ActivationStatus: dto.ActivationActivated, ModuleActive: boolPtr(false)},
		{UserID: 42, ActivationStatus: "Inactive", ModuleActive: boolPtr(true)},
	}
	for _, elig := range cases {
		repo := &writeFakeRepo{eligibility: elig}
		acts := newRoleActivities(repo)

		_, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelTotalControl))
		if e := appErr(t, err); e.Type() != "BadRequest" {
			t.Fatalf("elig %+v: err = %+v, want 400", elig, e)
		}
	}
}

func TestAssignAccessLevelDefaultUser(t *testing.T) {
	repo := &writeFakeRepo{eligibility: &dto.UserAssignmentEligibility{
		UserID: 42, ActivationStatus: dto.ActivationActivated, ModuleActive: boolPtr(true), IsDefault: boolPtr(true),
	}}
	acts := newRoleActivities(repo)

	_, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "Forbidden" || e.Message() != "Default User must always have Total Control" {
		t.Fatalf("err = %+v, want 403 default-user guard", e)
	}
}

func TestAssignAccessLevelAlreadyAssigned(t *testing.T) {
	repo := &writeFakeRepo{
		eligibility: eligible(42, "Mike Tan"),
		tier:        &model.UserAccessLevel{AccessLevel: model.AccessLevelTotalControl},
	}
	acts := newRoleActivities(repo)

	_, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "Conflict" {
		t.Fatalf("err = %+v, want 409 already assigned", e)
	}
	if repo.upsertedLevel != nil {
		t.Fatal("idempotent reject must not write")
	}
}

func TestAssignAccessLevelTotalControlHappyPath(t *testing.T) {
	repo := &writeFakeRepo{eligibility: eligible(42, "Mike Tan")}
	acts := newRoleActivities(repo)

	res, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelTotalControl))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if repo.upsertedLevel == nil {
		t.Fatal("tier row must be upserted")
	}
	if repo.upsertedLevel.UserID != 42 || repo.upsertedLevel.Product != model.ProductGlobalSettings ||
		repo.upsertedLevel.AccessLevel != model.AccessLevelTotalControl {
		t.Fatalf("level = %+v", repo.upsertedLevel)
	}
	if repo.upsertedLevel.ModifiedBy == nil || *repo.upsertedLevel.ModifiedBy != 1 {
		t.Errorf("modifiedBy = %v, want actor 1", repo.upsertedLevel.ModifiedBy)
	}
	assertTierPattern(t, repo.upsertedRows, model.AccessLevelTotalControl)
	if res.PreviousAccessLevel != nil {
		t.Fatalf("first assign must report no previous tier, got %v", res.PreviousAccessLevel)
	}
	if res.UserID != 42 || res.UserFullName != "Mike Tan" {
		t.Fatalf("result = %+v, want target identity", res)
	}
}

func TestAssignAccessLevelUpgradeReportsPrevious(t *testing.T) {
	repo := &writeFakeRepo{
		eligibility: eligible(42, "Mike Tan"),
		tier:        &model.UserAccessLevel{AccessLevel: model.AccessLevelReadOnly},
	}
	acts := newRoleActivities(repo)

	res, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelTotalControl))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.PreviousAccessLevel == nil || *res.PreviousAccessLevel != model.AccessLevelReadOnly {
		t.Fatalf("previousAccessLevel = %v, want read_only", res.PreviousAccessLevel)
	}
	assertTierPattern(t, repo.upsertedRows, model.AccessLevelTotalControl)
}

func TestAssignAccessLevelReadOnlyPattern(t *testing.T) {
	repo := &writeFakeRepo{eligibility: eligible(42, "Mike Tan")}
	acts := newRoleActivities(repo)

	if _, err := acts.AssignAccessLevelActivity(context.Background(), assignParam(42, 1, model.AccessLevelReadOnly)); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	assertTierPattern(t, repo.upsertedRows, model.AccessLevelReadOnly)
}

func removeParam(userIDs []int64, actorID int64, level model.AccessLevel) workflow.RemoveAccessLevelActivityParam {
	return workflow.RemoveAccessLevelActivityParam{
		ClientID:    "client-1",
		Product:     model.ProductGlobalSettings,
		UserIDs:     userIDs,
		ActorID:     actorID,
		AccessLevel: level,
	}
}

func TestRemoveAccessLevelDefaultUser(t *testing.T) {
	repo := &writeFakeRepo{eligibilities: map[int64]*dto.UserAssignmentEligibility{
		42: {UserID: 42, FullName: "Default", ActivationStatus: dto.ActivationActivated, ModuleActive: boolPtr(true), IsDefault: boolPtr(true)},
	}}
	acts := newRoleActivities(repo)

	_, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42}, 1, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "Forbidden" || e.Message() != "Default User must always have Total Control" {
		t.Fatalf("err = %+v, want 403 default-user guard", e)
	}
	if len(repo.deletedRows) != 0 {
		t.Fatal("guard failure must not delete capability rows")
	}
}

func TestRemoveAccessLevelSelfRemove(t *testing.T) {
	repo := &writeFakeRepo{eligibilities: map[int64]*dto.UserAssignmentEligibility{
		42: eligible(42, "Mike Tan"),
	}}
	acts := newRoleActivities(repo)

	_, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42}, 42, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "Forbidden" || e.Message() != "You cannot change your own access level." {
		t.Fatalf("err = %+v, want 403 self-remove", e)
	}
}

func TestRemoveAccessLevelLevelMismatch(t *testing.T) {
	repo := &writeFakeRepo{
		eligibilities: map[int64]*dto.UserAssignmentEligibility{42: eligible(42, "Mike Tan")},
		tiers:         map[int64]*model.UserAccessLevel{42: {AccessLevel: model.AccessLevelReadOnly}},
	}
	acts := newRoleActivities(repo)

	_, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42}, 1, model.AccessLevelTotalControl))
	if e := appErr(t, err); e.Type() != "Conflict" {
		t.Fatalf("err = %+v, want 409 level mismatch", e)
	}
}

func TestRemoveAccessLevelNoRowNoOp(t *testing.T) {
	repo := &writeFakeRepo{eligibilities: map[int64]*dto.UserAssignmentEligibility{
		42: eligible(42, "Mike Tan"),
	}}
	acts := newRoleActivities(repo)

	res, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42}, 1, model.AccessLevelTotalControl))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(res.Removed) != 0 {
		t.Fatalf("removed = %+v, want no-op", res.Removed)
	}
	if len(repo.deletedRows) != 0 || repo.deletedTier {
		t.Fatal("no-tier user must not touch any row")
	}
}

func TestRemoveAccessLevelHappyPath(t *testing.T) {
	repo := &writeFakeRepo{
		eligibilities: map[int64]*dto.UserAssignmentEligibility{
			42: eligible(42, "Mike Tan"),
			43: eligible(43, "Sari Dewi"),
		},
		tiers: map[int64]*model.UserAccessLevel{
			42: {AccessLevel: model.AccessLevelTotalControl},
			43: {AccessLevel: model.AccessLevelTotalControl},
		},
	}
	acts := newRoleActivities(repo)

	res, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42, 43}, 1, model.AccessLevelTotalControl))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(res.Removed) != 2 {
		t.Fatalf("removed = %+v, want both users", res.Removed)
	}
	if res.Removed[0].RemovedAccessLevel != model.AccessLevelTotalControl {
		t.Errorf("removedAccessLevel = %q, want total_control", res.Removed[0].RemovedAccessLevel)
	}
	if len(repo.deletedRows) != 2 {
		t.Fatalf("deletedRows = %v, want both users deleted", repo.deletedRows)
	}
}

func TestRemoveAccessLevelMixedLevels(t *testing.T) {
	repo := &writeFakeRepo{
		eligibilities: map[int64]*dto.UserAssignmentEligibility{
			42: eligible(42, "Mike Tan"),
			43: eligible(43, "Sari Dewi"),
		},
		tiers: map[int64]*model.UserAccessLevel{
			42: {AccessLevel: model.AccessLevelTotalControl},
			43: {AccessLevel: model.AccessLevelReadOnly},
		},
	}
	acts := newRoleActivities(repo)

	// User 42 holds total_control but the request removes read_only → the whole
	// request is a 409 level mismatch (the FE only sends users of one tab).
	_, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42, 43}, 1, model.AccessLevelReadOnly))
	if e := appErr(t, err); e.Type() != "Conflict" {
		t.Fatalf("err = %+v, want 409 level mismatch", e)
	}
	if len(repo.deletedRows) != 0 {
		t.Fatal("level mismatch must not touch any row")
	}
}

func TestRemoveAccessLevelMultiUserWithNoOp(t *testing.T) {
	repo := &writeFakeRepo{
		eligibilities: map[int64]*dto.UserAssignmentEligibility{
			42: eligible(42, "Mike Tan"),
			43: eligible(43, "Sari Dewi"),
		},
		tiers: map[int64]*model.UserAccessLevel{
			42: {AccessLevel: model.AccessLevelTotalControl}, // 43 has no tier row
		},
	}
	acts := newRoleActivities(repo)

	res, err := acts.RemoveAccessLevelActivity(context.Background(), removeParam([]int64{42, 43}, 1, model.AccessLevelTotalControl))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(res.Removed) != 1 || res.Removed[0].UserID != 42 {
		t.Fatalf("removed = %+v, want only user 42 (43 has no tier row)", res.Removed)
	}
	if len(repo.deletedRows) != 1 || repo.deletedRows[0] != 42 {
		t.Fatalf("deletedRows = %v, want [42]", repo.deletedRows)
	}
}

func removeCapabilityParam(userIDs []int64, actorID int64, withTC bool) workflow.RemoveCapabilityUsersActivityParam {
	return workflow.RemoveCapabilityUsersActivityParam{
		ClientID: "client-1",
		Product:  model.ProductGlobalSettings,
		ActorID:  actorID,
		Key:      model.SystemRoleKeyManageUserAndRole,
		UserIDs:  userIDs,
		Roles:    totalControlRoles(withTC),
	}
}

func TestRemoveCapabilityUsersAlreadyDeletedIsFailedNotError(t *testing.T) {
	repo := &writeFakeRepo{} // no rows at all
	acts := newRoleActivities(repo)

	res, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42}, 1, true))
	if err != nil {
		t.Fatalf("already-deleted rows must not fail the request: %v", err)
	}
	if len(res.Removed) != 0 || len(res.FailedUserIDs) != 1 || res.FailedUserIDs[0] != 42 {
		t.Fatalf("res = %+v, want user 42 failed (already deleted)", res)
	}
}

func TestRemoveCapabilityUsersSelfEditAllRejected(t *testing.T) {
	repo := &writeFakeRepo{removeRows: []dto.CapabilityUserRow{{UserID: 42, FullName: "Mike Tan"}}}
	acts := newRoleActivities(repo)

	_, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42}, 42, true))
	if e := appErr(t, err); e.Type() != "Forbidden" {
		t.Fatalf("err = %+v, want 403 (every row guard-rejected)", e)
	}
	if len(repo.deletedCapabilityUsers) != 0 {
		t.Fatal("self-edit must not delete")
	}
}

func TestRemoveCapabilityUsersDefaultUserRejected(t *testing.T) {
	repo := &writeFakeRepo{removeRows: []dto.CapabilityUserRow{{UserID: 42, FullName: "Default", IsDefault: true}}}
	acts := newRoleActivities(repo)

	_, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42}, 1, true))
	if e := appErr(t, err); e.Type() != "Forbidden" {
		t.Fatalf("err = %+v, want 403 default-user guard", e)
	}
}

func TestRemoveCapabilityUsersNonTCTierHolderRejected(t *testing.T) {
	repo := &writeFakeRepo{
		removeRows: []dto.CapabilityUserRow{{UserID: 42, FullName: "Mike Tan"}},
		tiers:      map[int64]*model.UserAccessLevel{42: {AccessLevel: model.AccessLevelTotalControl}},
	}
	acts := newRoleActivities(repo)

	_, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42}, 1, false))
	if e := appErr(t, err); e.Type() != "Forbidden" {
		t.Fatalf("err = %+v, want 403 tier guard", e)
	}
	if len(repo.deletedCapabilityUsers) != 0 {
		t.Fatal("guard failure must not delete")
	}
}

func TestRemoveCapabilityUsersRegularTargetRemoved(t *testing.T) {
	repo := &writeFakeRepo{removeRows: []dto.CapabilityUserRow{{UserID: 42, FullName: "Mike Tan"}}}
	acts := newRoleActivities(repo)

	res, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42}, 1, false))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(res.Removed) != 1 || res.Removed[0].UserID != 42 || res.Removed[0].UserFullName != "Mike Tan" {
		t.Fatalf("removed = %+v, want user 42", res.Removed)
	}
	if res.Removed[0].AccessLevelAutoReverted {
		t.Fatal("tierless target must not auto-revert")
	}
	if len(repo.deletedCapabilityUsers) != 1 || repo.deletedCapabilityUsers[0] != 42 {
		t.Fatalf("deleted = %v, want [42]", repo.deletedCapabilityUsers)
	}
	if repo.deletedTier {
		t.Fatal("tier row must not be deleted for a tierless target")
	}
}

func TestRemoveCapabilityUsersTierHolderAutoReverts(t *testing.T) {
	repo := &writeFakeRepo{
		removeRows: []dto.CapabilityUserRow{{UserID: 42, FullName: "Mike Tan"}},
		tiers:      map[int64]*model.UserAccessLevel{42: {AccessLevel: model.AccessLevelTotalControl}},
	}
	acts := newRoleActivities(repo)

	res, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42}, 1, true))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(res.Removed) != 1 || !res.Removed[0].AccessLevelAutoReverted {
		t.Fatalf("removed = %+v, want auto-revert", res.Removed)
	}
	if res.Removed[0].RevertedAccessLevel != model.AccessLevelTotalControl {
		t.Errorf("revertedAccessLevel = %q, want total_control", res.Removed[0].RevertedAccessLevel)
	}
	if !repo.deletedTier {
		t.Fatal("tier row must be deleted alongside the capability row")
	}
}

func TestRemoveCapabilityUsersBulkMixed(t *testing.T) {
	repo := &writeFakeRepo{
		removeRows: []dto.CapabilityUserRow{
			{UserID: 42, FullName: "Mike Tan"},
			{UserID: 43, FullName: "Sari Dewi"},
			{UserID: 44, FullName: "Default", IsDefault: true},
		},
		tiers: map[int64]*model.UserAccessLevel{
			43: {AccessLevel: model.AccessLevelReadOnly},
		},
	}
	acts := newRoleActivities(repo)

	res, err := acts.RemoveCapabilityUsersActivity(context.Background(), removeCapabilityParam([]int64{42, 43, 44}, 1, true))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(res.Removed) != 2 {
		t.Fatalf("removed = %+v, want users 42 and 43", res.Removed)
	}
	// 44 is default user → guard-rejected; 42 is tierless → removed without revert.
	if len(res.FailedUserIDs) != 1 || res.FailedUserIDs[0] != 44 {
		t.Fatalf("failedUserIds = %v, want [44]", res.FailedUserIDs)
	}
	if len(repo.deletedCapabilityUsers) != 2 {
		t.Fatalf("deleted = %v, want 2 rows", repo.deletedCapabilityUsers)
	}
}
