package activity

import (
	"context"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/role/workflow"
)

// TestInvalidateUserRolesActivityDropsEachUser: the activity drops the RBAC
// snapshot of every user a write workflow changed, including duplicates (the
// delete is idempotent).
func TestInvalidateUserRolesActivityDropsEachUser(t *testing.T) {
	acts, inv := newRoleActivitiesWithInvalidator(&writeFakeRepo{})

	if err := acts.InvalidateUserRolesActivity(context.Background(), workflow.InvalidateUserRolesActivityParam{
		ClientID: "client-1",
		UserIDs:  []int64{42, 43, 42},
	}); err != nil {
		t.Fatalf("err = %v, want nil", err)
	}
	if len(inv.invalidated) != 3 || inv.invalidated[0] != 42 || inv.invalidated[1] != 43 || inv.invalidated[2] != 42 {
		t.Fatalf("invalidated = %v, want [42 43 42]", inv.invalidated)
	}
}

// TestInvalidateUserRolesActivityEmptyListIsNoOp: a no-op write (nothing
// removed) never touches the cache.
func TestInvalidateUserRolesActivityEmptyListIsNoOp(t *testing.T) {
	acts, inv := newRoleActivitiesWithInvalidator(&writeFakeRepo{})

	if err := acts.InvalidateUserRolesActivity(context.Background(), workflow.InvalidateUserRolesActivityParam{
		ClientID: "client-1",
	}); err != nil {
		t.Fatalf("err = %v, want nil", err)
	}
	if len(inv.invalidated) != 0 {
		t.Fatalf("invalidated = %v, want none", inv.invalidated)
	}
}

// TestInvalidateUserRolesActivityNilInvalidator: activities constructed without
// a cache (tests, or a service where the cache is optional) are a no-op.
func TestInvalidateUserRolesActivityNilInvalidator(t *testing.T) {
	acts := NewRoleActivities("testdb", &writeFakeRepo{}, nil)

	if err := acts.InvalidateUserRolesActivity(context.Background(), workflow.InvalidateUserRolesActivityParam{
		ClientID: "client-1",
		UserIDs:  []int64{42},
	}); err != nil {
		t.Fatalf("err = %v, want nil", err)
	}
}
