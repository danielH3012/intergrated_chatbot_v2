package service

import (
	"context"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// Heartbeat checks the session's status and, if still active, slides the idle
// window. Returns status=expired with the stored expires_at when the session
// has already expired — performing no write.
func (s *AuthService) Heartbeat(ctx context.Context, sessionID int64) (*dto.HeartbeatResponse, error) {
	publicSvc := s.publicSvc()

	session, err := s.sessionRepo.GetByID(ctx, publicSvc, sessionID)
	if err != nil {
		slog.ErrorContext(ctx, "heartbeat: sessionRepo.GetByID", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if session.Status != constant.SessionStatusActive || time.Now().After(session.ExpiresAt) {
		return &dto.HeartbeatResponse{
			Status:    constant.SessionStatusExpired,
			ExpiresAt: session.ExpiresAt,
		}, nil
	}

	idleTimeout := s.generalSettingsClient.GetSessionIdleTimeout(ctx, session.ClientCode)
	now := time.Now()
	if err := s.sessionRepo.Touch(ctx, publicSvc, session.ID, now, idleTimeout); err != nil {
		slog.WarnContext(ctx, "heartbeat: sessionRepo.Touch failed", "sessionId", session.ID, "err", err)
	}

	newExpiresAt := now.Add(idleTimeout)
	return &dto.HeartbeatResponse{
		Status:             constant.SessionStatusActive,
		ExpiresAt:          newExpiresAt,
		IdleTimeoutMinutes: int(idleTimeout.Minutes()),
	}, nil
}
