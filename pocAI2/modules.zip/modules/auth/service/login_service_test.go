package service

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

const goodPassword = "C0rrectPassw0rd!"

// loginFixture wires a login that succeeds, so each test only has to change
// the one thing it is about.
type loginFixture struct {
	svc      *AuthService
	cred     *fakeCredRepo
	user     *fakeUserRepo
	lock     *fakeLockRepo
	sessions *fakeSessionRepo
	preAuth  *fakePreAuthRepo
	consent  *fakeConsentRepo
	captcha  *fakeCaptcha
	db       *fakeDBFactory
}

func newLoginFixture(t *testing.T) *loginFixture {
	t.Helper()

	yesterday := time.Now().Add(-24 * time.Hour)
	f := &loginFixture{
		cred: &fakeCredRepo{cred: &model.UserCredential{
			ID: 3, ClientCode: "acme", PasswordHash: ptr("hashed"),
		}},
		user: &fakeUserRepo{user: &userDto.UserListItem{
			ID:               7,
			Email:            "bob@example.com",
			IsActive:         true,
			ActivationStatus: constant.ActivationStatusActivated,
			// Has logged in before and consented to the live version, so
			// neither the agreement gate nor MFA fires by default.
			FirstLoginAt: &yesterday,
		}},
		lock:     &fakeLockRepo{},
		sessions: &fakeSessionRepo{},
		preAuth:  &fakePreAuthRepo{},
		consent:  &fakeConsentRepo{row: &model.UserPrivacyConsent{AcceptedVersion: new("2")}},
		captcha:  &fakeCaptcha{ok: true},
		db:       &fakeDBFactory{},
	}

	f.svc = &AuthService{
		credRepo:              f.cred,
		userRepo:              f.user,
		lockRepo:              f.lock,
		sessionRepo:           f.sessions,
		preAuthRepo:           f.preAuth,
		consentRepo:           f.consent,
		password:              &fakePassword{correct: goodPassword},
		captcha:               f.captcha,
		generalSettingsClient: policyClient(t, 2),
	}
	f.svc.SetServiceFactoryForTest(f.db.factory())
	return f
}

func webLogin() LoginParam {
	return LoginParam{
		Email:          "bob@example.com",
		Password:       goodPassword,
		RecaptchaToken: "token",
		Platform:       constant.PlatformWeb,
		DeviceID:       "device-1",
		IPAddress:      "127.0.0.1",
	}
}

// loginErrData unwraps the LoginResponse a 422 carries in its Data field.
func loginErrData(err error) *dto.LoginResponse {
	var httpErr *coreEntity.HttpError
	if !errors.As(err, &httpErr) {
		return nil
	}
	resp, _ := httpErr.Data.(*dto.LoginResponse)
	return resp
}

func TestLogin_Success(t *testing.T) {
	f := newLoginFixture(t)

	resp, err := f.svc.Login(context.Background(), webLogin())
	if err != nil {
		t.Fatalf("Login() err = %v, want nil", err)
	}
	if resp.Outcome != constant.OutcomeSuccess {
		t.Fatalf("outcome = %q, want %q", resp.Outcome, constant.OutcomeSuccess)
	}
	if resp.SessionID == nil || *resp.SessionID == "" {
		t.Fatal("success must return the raw session token")
	}
	if len(f.sessions.inserted) != 1 {
		t.Fatalf("sessions inserted = %d, want 1", len(f.sessions.inserted))
	}
	if got := f.sessions.inserted[0]; got.UserID != 7 || got.ClientCode != "acme" {
		t.Errorf("session row = %+v, want userID 7 in acme", got)
	}
	// The raw token is never stored — only its hash.
	if f.sessions.inserted[0].TokenHash == *resp.SessionID {
		t.Error("stored token_hash equals the raw token")
	}
	if f.lock.resetToday != 1 {
		t.Errorf("ResetToday calls = %d, want 1 — a success must clear today's counter", f.lock.resetToday)
	}
	if !f.db.sawSchema("acme") {
		t.Error("tenant reads must go to the credential's client schema")
	}
}

func TestLogin_EmailValidation(t *testing.T) {
	cases := []struct {
		name      string
		email     string
		wantCode  string
		wantField string
	}{
		{"empty", "   ", constant.ErrorCodeEmailEmpty, constant.CaptionFieldEmail},
		{"malformed", "not-an-email", constant.ErrorCodeEmailFormat, constant.CaptionFieldEmail},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newLoginFixture(t)
			param := webLogin()
			param.Email = tc.email

			_, err := f.svc.Login(context.Background(), param)
			if httpStatus(err) != fiber.StatusUnprocessableEntity {
				t.Fatalf("status = %d, want 422 (err %v)", httpStatus(err), err)
			}
			data := loginErrData(err)
			if data == nil || data.ErrorCode == nil || *data.ErrorCode != tc.wantCode {
				t.Fatalf("errorCode = %+v, want %q", data, tc.wantCode)
			}
			if *data.CaptionField != tc.wantField {
				t.Errorf("captionField = %q, want %q", *data.CaptionField, tc.wantField)
			}
			if len(f.sessions.inserted) != 0 {
				t.Error("a rejected email must not create a session")
			}
		})
	}
}

// An unknown email must answer exactly like a known one with a bad password
// would at the credential stage — and never reach the tenant schema.
func TestLogin_UnknownEmail(t *testing.T) {
	f := newLoginFixture(t)
	f.cred.err = pgx.ErrNoRows

	_, err := f.svc.Login(context.Background(), webLogin())
	if httpStatus(err) != fiber.StatusUnprocessableEntity {
		t.Fatalf("status = %d, want 422", httpStatus(err))
	}
	data := loginErrData(err)
	if data == nil || *data.ErrorCode != constant.ErrorCodeEmailNotRegistered {
		t.Fatalf("errorCode = %+v, want %q", data, constant.ErrorCodeEmailNotRegistered)
	}
}

func TestLogin_AccountStateGates(t *testing.T) {
	cases := []struct {
		name     string
		mutate   func(f *loginFixture)
		wantCode string
	}{
		{"not activated", func(f *loginFixture) {
			f.user.user.ActivationStatus = constant.ActivationStatusPending
		}, constant.ErrorCodeNotActivated},
		{"inactive", func(f *loginFixture) { f.user.user.IsActive = false }, constant.ErrorCodeInactive},
		// The invite leaves a password-less credential row so login can resolve
		// the tenant at all. Reaching the hash compare with it would answer
		// "incorrect password" and count a lockout attempt against an account
		// that has no password to get wrong.
		{"activated but never set a password", func(f *loginFixture) {
			f.cred.cred.PasswordHash = nil
		}, constant.ErrorCodeNotActivated},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newLoginFixture(t)
			tc.mutate(f)

			resp, err := f.svc.Login(context.Background(), webLogin())
			if err != nil {
				t.Fatalf("Login() err = %v, want a failed outcome, not an error", err)
			}
			if resp.Outcome != constant.OutcomeFailed || *resp.ErrorCode != tc.wantCode {
				t.Fatalf("got outcome %q code %v, want failed/%s", resp.Outcome, resp.ErrorCode, tc.wantCode)
			}
			if len(f.sessions.inserted) != 0 {
				t.Error("a gated account must not get a session")
			}
			if len(f.lock.upserted) != 0 {
				t.Error("a gated account must not burn a lockout attempt")
			}
		})
	}
}

func TestLogin_CaptchaAndEmptyPassword(t *testing.T) {
	t.Run("web captcha failure", func(t *testing.T) {
		f := newLoginFixture(t)
		f.captcha.ok = false

		resp, err := f.svc.Login(context.Background(), webLogin())
		if err != nil {
			t.Fatalf("Login() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeFailed || *resp.ErrorCode != constant.ErrorCodeCaptchaEmpty {
			t.Fatalf("got %q/%v, want failed/CAPTCHA_EMPTY", resp.Outcome, resp.ErrorCode)
		}
		if !resp.CaptchaRequired {
			t.Error("web logins must report captchaRequired")
		}
	})

	t.Run("mobile skips captcha entirely", func(t *testing.T) {
		f := newLoginFixture(t)
		f.captcha.ok = false
		param := webLogin()
		param.Platform = constant.PlatformMobile

		resp, err := f.svc.Login(context.Background(), param)
		if err != nil {
			t.Fatalf("Login() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeSuccess {
			t.Fatalf("outcome = %q, want success — mobile has no captcha", resp.Outcome)
		}
		if resp.CaptchaRequired {
			t.Error("mobile must not report captchaRequired")
		}
	})

	t.Run("empty password is its own failure, never a hash compare", func(t *testing.T) {
		f := newLoginFixture(t)
		param := webLogin()
		param.Password = ""

		resp, err := f.svc.Login(context.Background(), param)
		if err != nil {
			t.Fatalf("Login() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeFailed || *resp.ErrorCode != constant.ErrorCodePasswordEmpty {
			t.Fatalf("got %q/%v, want failed/PASSWORD_EMPTY", resp.Outcome, resp.ErrorCode)
		}
		if len(f.lock.upserted) != 0 {
			t.Error("an empty password must not touch the lock counters")
		}
	})
}

// A wrong password escalates the counter, and the level the ladder reaches
// decides between an ordinary failure and a lock.
func TestLogin_WrongPassword(t *testing.T) {
	t.Run("below the threshold is a plain failure", func(t *testing.T) {
		f := newLoginFixture(t)
		param := webLogin()
		param.Password = "wrong"

		resp, err := f.svc.Login(context.Background(), param)
		if err != nil {
			t.Fatalf("Login() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeFailed || *resp.ErrorCode != constant.ErrorCodeIncorrect {
			t.Fatalf("got %q/%v, want failed/INCORRECT", resp.Outcome, resp.ErrorCode)
		}
		if len(f.lock.upserted) != 1 {
			t.Fatalf("UpsertToday calls = %d, want 1", len(f.lock.upserted))
		}
		if got := f.lock.upserted[0]; got.UserID != 7 || got.ClientCode != "acme" {
			t.Errorf("counter row = %+v, want user 7 / acme", got)
		}
	})

	t.Run("crossing the threshold locks the account", func(t *testing.T) {
		f := newLoginFixture(t)
		// Two failures already today: the third trips the 15-minute lock.
		f.lock.daily = &model.LoginAttemptLock{
			UserID: 7, ClientCode: "acme", Platform: constant.PlatformWeb,
			AttemptDate: time.Now(), FailedCount: constant.LockWarnAt - 1,
		}
		param := webLogin()
		param.Password = "wrong"

		resp, err := f.svc.Login(context.Background(), param)
		if err != nil {
			t.Fatalf("Login() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeLocked {
			t.Fatalf("outcome = %q, want locked", resp.Outcome)
		}
		if resp.LockLevel == nil || *resp.LockLevel != constant.LockLevel15m {
			t.Fatalf("lockLevel = %v, want %q", resp.LockLevel, constant.LockLevel15m)
		}
		if resp.LockUntil == nil || !resp.LockUntil.After(time.Now()) {
			t.Errorf("lockUntil = %v, want a future instant", resp.LockUntil)
		}
	})
}

// A locked account is answered before the password is ever compared, so it is
// not password-probeable — and the in-window attempt is invisible: no counter
// write at all.
func TestLogin_LockShortCircuit(t *testing.T) {
	f := newLoginFixture(t)
	until := time.Now().Add(10 * time.Minute)
	f.lock.daily = &model.LoginAttemptLock{
		UserID: 7, ClientCode: "acme", Platform: constant.PlatformWeb,
		AttemptDate: time.Now(), FailedCount: constant.LockWarnAt,
		LockLevel: constant.LockLevel15m, LockUntil: &until,
	}

	resp, err := f.svc.Login(context.Background(), webLogin())
	if err != nil {
		t.Fatalf("Login() err = %v", err)
	}
	if resp.Outcome != constant.OutcomeLocked {
		t.Fatalf("outcome = %q, want locked even though the password is correct", resp.Outcome)
	}
	if len(f.lock.upserted) != 0 {
		t.Error("an in-window attempt must not touch the counters")
	}
	if len(f.sessions.inserted) != 0 {
		t.Error("a locked account must not get a session")
	}
}

// The agreement gate runs after factor-1 and before MFA, and hands the client
// a pre-auth token rather than a session.
func TestLogin_AgreementGate(t *testing.T) {
	f := newLoginFixture(t)
	f.consent.row = &model.UserPrivacyConsent{AcceptedVersion: ptr("1.0")} // stale

	resp, err := f.svc.Login(context.Background(), webLogin())
	if err != nil {
		t.Fatalf("Login() err = %v", err)
	}
	if resp.Outcome != constant.OutcomeAgreementRequired {
		t.Fatalf("outcome = %q, want %q", resp.Outcome, constant.OutcomeAgreementRequired)
	}
	if resp.PreAuthToken == nil || *resp.PreAuthToken == "" {
		t.Fatal("the gate must hand back a pre-auth token")
	}
	if resp.PrivacyPolicyVersion == nil || *resp.PrivacyPolicyVersion != "2" {
		t.Fatalf("privacyPolicyVersion = %v, want the live version", resp.PrivacyPolicyVersion)
	}
	if len(f.sessions.inserted) != 0 {
		t.Error("no session may exist while consent is pending")
	}

	if len(f.preAuth.inserted) != 1 {
		t.Fatalf("pre-auth rows = %d, want 1", len(f.preAuth.inserted))
	}
	row := f.preAuth.inserted[0]
	if row.Purpose != constant.PreAuthPurposeAgreement || !row.AgreementPending {
		t.Errorf("row purpose/pending = %q/%v, want agreement/true", row.Purpose, row.AgreementPending)
	}
	if row.ShownPolicyVersion == nil || *row.ShownPolicyVersion != "2" {
		t.Errorf("shownPolicyVersion = %v, want the version the screen renders", row.ShownPolicyVersion)
	}
	if row.Factor1Method == nil || *row.Factor1Method != constant.Factor1MethodPassword {
		t.Errorf("factor1Method = %v, want password", row.Factor1Method)
	}
	if row.ExpiresAt.After(time.Now().Add(constant.PreAuthTTL + time.Minute)) {
		t.Errorf("expiresAt = %v, want within the pre-auth TTL", row.ExpiresAt)
	}
}

// A never-logged-in user fires the gate on trigger (a) even with a current
// consent row on file.
func TestLogin_AgreementGateOnFirstLogin(t *testing.T) {
	f := newLoginFixture(t)
	f.user.user.FirstLoginAt = nil

	resp, err := f.svc.Login(context.Background(), webLogin())
	if err != nil {
		t.Fatalf("Login() err = %v", err)
	}
	if resp.Outcome != constant.OutcomeAgreementRequired {
		t.Fatalf("outcome = %q, want agreement_required", resp.Outcome)
	}
}

func TestLogin_InfraFailureIs500(t *testing.T) {
	f := newLoginFixture(t)
	f.cred.err = errors.New("connection refused")

	_, err := f.svc.Login(context.Background(), webLogin())
	if httpStatus(err) != fiber.StatusInternalServerError {
		t.Fatalf("status = %d, want 500 — a DB outage is not a credential failure", httpStatus(err))
	}
}
