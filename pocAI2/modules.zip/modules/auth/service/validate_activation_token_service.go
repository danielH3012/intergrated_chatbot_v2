package service

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
)

// ValidateActivationToken backs GET /auth/activation/:token. A consumed token
// returns the MsgActivationUsed 404; unknown, expired, superseded, or
// otherwise invalid links return the generic MsgActivationExpired 404. A
// genuine infra error returns 500, not 404, so the client does not render a
// dead link for a transient outage.
func (s *AuthService) ValidateActivationToken(ctx context.Context, rawToken string) (*dto.ValidateActivationTokenResponse, error) {
	_, user, err := s.validateUserActivationToken(ctx, s.publicSvc(), helper.HashToken(rawToken))
	if err != nil {
		if !isActivationValidationError(err) {
			slog.ErrorContext(ctx, "activation.ValidateToken: validateUserActivationToken", "err", err)
		}
		return nil, validateActivationErr(err)
	}

	return &dto.ValidateActivationTokenResponse{Valid: true, Email: user.Email}, nil
}
