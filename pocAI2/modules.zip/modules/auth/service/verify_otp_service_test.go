package service

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type stubOtpCodeRepo struct {
	rows        []*model.OtpCode
	consumedIDs []int64
}

func (s *stubOtpCodeRepo) GetOneByHashForUpdate(_ context.Context, _ coreService.PostgreSQLServicer, email, clientCode, codeHash, purpose string) (*model.OtpCode, error) {
	for _, r := range s.rows {
		if r.Email == email && r.ClientCode == clientCode && r.CodeHash == codeHash && r.Purpose == purpose {
			return r, nil
		}
	}
	return nil, pgx.ErrNoRows
}

func (s *stubOtpCodeRepo) GetLatestByHashAndClient(_ context.Context, _ coreService.PostgreSQLServicer, clientCode, codeHash, purpose string) (*model.OtpCode, error) {
	var latest *model.OtpCode
	for _, r := range s.rows {
		if r.ClientCode == clientCode && r.CodeHash == codeHash && r.Purpose == purpose {
			if latest == nil || r.CreatedAt.After(latest.CreatedAt) {
				latest = r
			}
		}
	}
	if latest != nil {
		return latest, nil
	}
	return nil, pgx.ErrNoRows
}

func (s *stubOtpCodeRepo) GetLatestInSession(context.Context, coreService.PostgreSQLServicer, string, string, int64) (*model.OtpCode, error) {
	panic("not called by verifyOtpRow")
}

func (s *stubOtpCodeRepo) InvalidateActive(context.Context, coreService.PostgreSQLServicer, string, string, string) error {
	panic("not called by verifyOtpRow")
}

func (s *stubOtpCodeRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.OtpCode) (int64, error) {
	panic("not called by verifyOtpRow")
}

func (s *stubOtpCodeRepo) Consume(_ context.Context, _ coreService.PostgreSQLServicer, id int64) error {
	s.consumedIDs = append(s.consumedIDs, id)
	for _, r := range s.rows {
		if r.ID == id {
			now := time.Now()
			r.ConsumedAt = &now
		}
	}
	return nil
}

func (s *stubOtpCodeRepo) DeleteCreatedBefore(context.Context, coreService.PostgreSQLServicer, time.Time) (int64, error) {
	panic("not called by verifyOtpRow")
}

func otpVerifyHttpCode(err error) int {
	var httpErr *coreEntity.HttpError
	if !errors.As(err, &httpErr) {
		return 0
	}
	return httpErr.Code
}

func otpVerifyHttpData(err error) *dto.OtpVerifyResponse {
	var httpErr *coreEntity.HttpError
	if !errors.As(err, &httpErr) {
		return nil
	}
	resp, _ := httpErr.Data.(*dto.OtpVerifyResponse)
	return resp
}

func TestVerifyOTP_EmailChanged(t *testing.T) {
	hashKey := []byte("test-hash-key")
	svc := &AuthService{
		otpHashKey: hashKey,
	}

	code := "123456"
	codeHash := svc.hashOTP(code)

	// Code was originally issued to alice@example.com in client 'acme'.
	oldRow := &model.OtpCode{
		ID:           101,
		Email:        "alice@example.com",
		ClientCode:   "acme",
		CodeHash:     codeHash,
		Purpose:      constant.OtpPurposeLogin,
		OtpSessionID: 1001,
		ExpiresAt:    time.Now().Add(5 * time.Minute),
		CreatedAt:    time.Now(),
	}

	otpRepo := &stubOtpCodeRepo{
		rows: []*model.OtpCode{oldRow},
	}

	fakeDB := &coreService.FakePostgreSQLService{}

	t.Run("code issued to old email is rejected with OTP_EMAIL_CHANGED when verified under new email", func(t *testing.T) {
		svc.otpRepo = otpRepo

		outcome, _, _, _, _, err := svc.verifyOtpRow(
			context.Background(),
			fakeDB,
			"acme",
			fakeDB,
			&userDto.UserListItem{ID: 7},
			VerifyOTPParam{
				Email:    "bob@example.com",
				Platform: constant.PlatformWeb,
				OtpCode:  code,
			},
			"bob@example.com",
			codeHash,
		)

		if !errors.Is(err, errOtpEmailChanged) {
			t.Fatalf("verifyOtpRow err = %v, want errOtpEmailChanged", err)
		}
		if outcome != "" {
			t.Errorf("outcome = %q, want empty", outcome)
		}
		if len(otpRepo.consumedIDs) != 0 {
			t.Errorf("consumedIDs = %v, want none", otpRepo.consumedIDs)
		}

		// Verify HTTP error mapping
		httpErr := otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpEmailChanged, true)
		if otpVerifyHttpCode(httpErr) != fiber.StatusUnauthorized {
			t.Errorf("httpCode = %d, want 401", otpVerifyHttpCode(httpErr))
		}
		data := otpVerifyHttpData(httpErr)
		if data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodeOtpEmailChanged {
			t.Errorf("data.ErrorCode = %v, want %s", data, constant.ErrorCodeOtpEmailChanged)
		}
	})

	t.Run("wrong/unissued code is rejected with errOtpInvalid", func(t *testing.T) {
		svc.otpRepo = otpRepo

		randomHash := svc.hashOTP("999999")
		outcome, _, _, _, _, err := svc.verifyOtpRow(
			context.Background(),
			fakeDB,
			"acme",
			fakeDB,
			&userDto.UserListItem{ID: 7},
			VerifyOTPParam{
				Email:    "bob@example.com",
				Platform: constant.PlatformWeb,
				OtpCode:  "999999",
			},
			"bob@example.com",
			randomHash,
		)

		if !errors.Is(err, errOtpInvalid) {
			t.Fatalf("verifyOtpRow err = %v, want errOtpInvalid", err)
		}
		if outcome != "" {
			t.Errorf("outcome = %q, want empty", outcome)
		}

		httpErr := otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpInvalid, true)
		if otpVerifyHttpCode(httpErr) != fiber.StatusUnauthorized {
			t.Errorf("httpCode = %d, want 401", otpVerifyHttpCode(httpErr))
		}
		data := otpVerifyHttpData(httpErr)
		if data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodeOtpInvalid {
			t.Errorf("data.ErrorCode = %v, want %s", data, constant.ErrorCodeOtpInvalid)
		}
	})

	t.Run("expired code for matching email is rejected with errOtpExpired", func(t *testing.T) {
		expiredRow := &model.OtpCode{
			ID:           102,
			Email:        "bob@example.com",
			ClientCode:   "acme",
			CodeHash:     codeHash,
			Purpose:      constant.OtpPurposeLogin,
			OtpSessionID: 1002,
			ExpiresAt:    time.Now().Add(-time.Minute),
			CreatedAt:    time.Now().Add(-6 * time.Minute),
		}
		expiredRepo := &stubOtpCodeRepo{
			rows: []*model.OtpCode{expiredRow},
		}
		svc.otpRepo = expiredRepo

		outcome, _, _, _, _, err := svc.verifyOtpRow(
			context.Background(),
			fakeDB,
			"acme",
			fakeDB,
			&userDto.UserListItem{ID: 7},
			VerifyOTPParam{
				Email:    "bob@example.com",
				Platform: constant.PlatformWeb,
				OtpCode:  code,
			},
			"bob@example.com",
			codeHash,
		)

		if !errors.Is(err, errOtpExpired) {
			t.Fatalf("verifyOtpRow err = %v, want errOtpExpired", err)
		}
		if outcome != "" {
			t.Errorf("outcome = %q, want empty", outcome)
		}

		httpErr := otpVerifyUnauthorizedError(constant.MsgOtpExpired, constant.ErrorCodeOtpExpired, true)
		if otpVerifyHttpCode(httpErr) != fiber.StatusUnauthorized {
			t.Errorf("httpCode = %d, want 401", otpVerifyHttpCode(httpErr))
		}
		data := otpVerifyHttpData(httpErr)
		if data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodeOtpExpired {
			t.Errorf("data.ErrorCode = %v, want %s", data, constant.ErrorCodeOtpExpired)
		}
	})

	t.Run("consumed code is rejected with errOtpInvalid", func(t *testing.T) {
		now := time.Now()
		consumedRow := &model.OtpCode{
			ID:           103,
			Email:        "bob@example.com",
			ClientCode:   "acme",
			CodeHash:     codeHash,
			Purpose:      constant.OtpPurposeLogin,
			OtpSessionID: 1003,
			ConsumedAt:   &now,
			ExpiresAt:    time.Now().Add(5 * time.Minute),
			CreatedAt:    time.Now(),
		}
		consumedRepo := &stubOtpCodeRepo{
			rows: []*model.OtpCode{consumedRow},
		}
		svc.otpRepo = consumedRepo

		outcome, _, _, _, _, err := svc.verifyOtpRow(
			context.Background(),
			fakeDB,
			"acme",
			fakeDB,
			&userDto.UserListItem{ID: 7},
			VerifyOTPParam{
				Email:    "bob@example.com",
				Platform: constant.PlatformWeb,
				OtpCode:  code,
			},
			"bob@example.com",
			codeHash,
		)

		if !errors.Is(err, errOtpInvalid) {
			t.Fatalf("verifyOtpRow err = %v, want errOtpInvalid", err)
		}
		if outcome != "" {
			t.Errorf("outcome = %q, want empty", outcome)
		}
	})
}
