package service

import (
	"context"
	"errors"
	"log/slog"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// ValidateResetToken backs GET /auth/reset-password/validate/:token. Every
// failure — unknown link, expired, used, invalidated, or a user who is no
// longer active — returns the same neutral 404: never leak which check
// failed. A genuine infra error returns 500, not 404. Read-only: nothing is
// consumed or invalidated here.
func (s *AuthService) ValidateResetToken(ctx context.Context, rawToken string) (*dto.ValidateResetTokenResponse, error) {
	return s.validateResetToken(ctx, s.publicSvc(), rawToken)
}

// validateResetToken takes the schema-scoped handle as an argument, the way
// validateSession does — publicSvc() dials Postgres and log.Fatalf's if it
// cannot, so the logic has to sit behind that call to be exercisable.
func (s *AuthService) validateResetToken(ctx context.Context, publicSvc coreService.PostgreSQLServicer, rawToken string) (*dto.ValidateResetTokenResponse, error) {
	token, err := s.resetTokenRepo.GetOneByHash(ctx, publicSvc, helper.HashToken(rawToken))
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			slog.ErrorContext(ctx, "reset.ValidateToken: resetTokenRepo.GetOneByHash: not found", "err", err)
			return nil, resetTokenValidationNotFound(constant.ErrorCodeLinkInvalid)
		}
		slog.ErrorContext(ctx, "reset.ValidateToken: resetTokenRepo.GetOneByHash", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if err := resetTokenState(token, time.Now()); err != nil {
		slog.ErrorContext(ctx, "reset.ValidateToken: link not usable", "errorCode", resetLinkErrorCode(err))
		return nil, resetTokenValidationNotFound(resetLinkErrorCode(err))
	}

	// Re-check the tenant user is still active — a link minted before a
	// deactivation must not keep working.
	user, err := s.userRepo.GetOneByID(ctx, s.tenantSvc(token.ClientCode), token.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			slog.ErrorContext(ctx, "reset.ValidateToken: userRepo.GetOneByID: not found", "err", err)
			return nil, resetTokenValidationNotFound(constant.ErrorCodeLinkInvalid)
		}
		slog.ErrorContext(ctx, "reset.ValidateToken: userRepo.GetOneByID", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if !user.IsActive || user.ActivationStatus != constant.ActivationStatusActivated {
		slog.ErrorContext(ctx, "reset.ValidateToken: user no longer active")
		return nil, resetTokenValidationNotFound(constant.ErrorCodeLinkInvalid)
	}
	// The link names the email it was minted for; if the account's email has
	// since changed, the old link must stop working rather than resetting
	// the new address's credential (TC-SYNC-02).
	if !strings.EqualFold(user.Email, token.Email) {
		slog.ErrorContext(ctx, "reset.ValidateToken: user email changed since token was minted")
		return nil, resetTokenValidationNotFound(constant.ErrorCodeLinkInvalid)
	}

	return &dto.ValidateResetTokenResponse{Valid: true, Email: token.Email, Reason: nil}, nil
}

func resetTokenValidationNotFound(errorCode string) error {
	reason := constant.MsgResetLinkNeutral
	return &coreEntity.HttpError{
		Code:    404,
		Message: constant.MsgResetLinkNeutral,
		Data: &dto.ValidateResetTokenResponse{
			Valid:     false,
			Reason:    &reason,
			ErrorCode: &errorCode,
		},
	}
}
