package service

import (
	"strings"
	"testing"
)

func TestValidatePasswordPolicy(t *testing.T) {
	tests := []struct {
		name     string
		password string
		confirm  string
		want     []string
	}{
		{
			name:     "valid password",
			password: "Passw0rd!",
			confirm:  "Passw0rd!",
			want:     nil,
		},
		{
			name:     "too short",
			password: "Pw0!",
			confirm:  "Pw0!",
			want:     []string{"Minimum 8 characters"},
		},
		{
			name:     "missing uppercase",
			password: "passw0rd!",
			confirm:  "passw0rd!",
			want:     []string{"One uppercase (A-Z)"},
		},
		{
			name:     "missing lowercase",
			password: "PASSW0RD!",
			confirm:  "PASSW0RD!",
			want:     []string{"One lowercase (a-z)"},
		},
		{
			name:     "missing digit",
			password: "Password!",
			confirm:  "Password!",
			want:     []string{"One number (0-9)"},
		},
		{
			name:     "missing special char",
			password: "Passw0rd1",
			confirm:  "Passw0rd1",
			want:     []string{"One special character"},
		},
		{
			// A password with an interior space must be flagged, not silently
			// trimmed — the design doc is explicit that passwords are never
			// trimmed anywhere in this flow.
			name:     "interior space is rejected, not trimmed",
			password: "Passw 0rd!",
			confirm:  "Passw 0rd!",
			want:     []string{"Password cannot contain spaces"},
		},
		{
			name:     "mismatch",
			password: "Passw0rd!",
			confirm:  "Different1!",
			want:     []string{"Passwords do not match"},
		},
		{
			name:     "73 chars fails length",
			password: strings.Repeat("Aa0!", 18) + "A", // 73 chars
			confirm:  strings.Repeat("Aa0!", 18) + "A",
			want:     []string{"Maximum 72 characters"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := validatePasswordPolicy(tt.password, tt.confirm)
			if !equalRules(got, tt.want) {
				t.Errorf("validatePasswordPolicy(%q, %q) = %v, want %v", tt.password, tt.confirm, got, tt.want)
			}
		})
	}
}

func equalRules(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}
