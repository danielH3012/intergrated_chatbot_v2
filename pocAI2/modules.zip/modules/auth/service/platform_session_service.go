package service

import (
	"context"
	"errors"
	"log/slog"
	"strconv"
	"time"

	"github.com/jackc/pgx/v5"
	"go.temporal.io/sdk/client"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	tsDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

const (
	sessionOutcomeCreated           = "created"
	sessionOutcomeDuplicateDetected = "duplicate_detected"
)

// createPlatformSession enforces Limit Login (max one active session per
// user+platform) before creating anything. Everything goes through here — a
// direct sessions insert would bypass that rule.
func (s *AuthService) createPlatformSession(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	userID int64,
	clientCode string, platform model.Platform, deviceInfo, ipAddress string,
) (outcome string, rawToken string, existing *dto.ExistingSessionInfo, err error) {
	current, err := s.sessionRepo.GetActiveForUpdate(ctx, svc, userID, platform)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return "", "", nil, err
	}
	// dev bypasses the Limit Login gate so parallel test logins don't collide.
	if current != nil && s.envType != "dev" {
		return sessionOutcomeDuplicateDetected, "", &dto.ExistingSessionInfo{
			DeviceInfo:        current.DeviceInfo,
			Platform:          current.Platform,
			LastActivityAt:    current.LastActivityAt,
			ExistingSessionID: &current.ID,
		}, nil
	}

	raw, err := newRawToken()
	if err != nil {
		return "", "", nil, err
	}

	now := time.Now()
	idleTimeout := s.generalSettingsClient.GetSessionIdleTimeout(ctx, clientCode)
	if err := s.sessionRepo.InsertOne(ctx, svc, model.Session{
		UserID:         userID,
		ClientCode:     clientCode,
		Platform:       platform,
		TokenHash:      helper.HashToken(raw),
		DeviceInfo:     deviceInfo,
		IPAddress:      ipAddress,
		LastActivityAt: now,
		ExpiresAt:      now.Add(idleTimeout),
		Status:         constant.SessionStatusActive,
	}); err != nil {
		return "", "", nil, err
	}

	return sessionOutcomeCreated, raw, nil, nil
}

// terminateSession is the shared terminal-transition helper. Every session
// termination routes through it: the repo guard ensures idempotency, and on
// success it cascades to product_sessions, records the session log, and
// publishes the SSE event.
//
// Returns terminated=false when the repo guard matched nothing — the caller
// turns that into the appropriate already-expired outcome.
func (s *AuthService) terminateSession(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	session *model.Session,
	status model.SessionStatus,
	reason model.TerminatedReason,
	logActivity string,
	logNote analyticsModel.SessionLogNote,
) (terminated bool, err error) {
	now := time.Now()
	n, err := s.sessionRepo.Terminate(ctx, svc, session.ID, status, reason, now)
	if err != nil {
		return false, err
	}
	if n == 0 {
		return false, nil
	}

	_, _ = s.productSessionRepo.EndByPlatformSession(ctx, svc, session.ID, constant.TerminatedReasonPlatformCascade, now)

	return true, nil
}

// recordSessionEvent writes a session log and publishes an SSE event after
// the transaction commits. Both are best-effort — a Temporal hiccup must not
// roll back a logout that already happened.
func (s *AuthService) recordSessionEvent(
	ctx context.Context,
	clientCode string,
	session *model.Session,
	logActivity, logStatus string,
	logNote analyticsModel.SessionLogNote,
	sseEvent, sseScope string,
	sseSessionID int64,
) {
	s.recordSessionLog(ctx, clientCode, session.UserID, logActivity, logStatus, string(logNote), session.Platform, session.IPAddress)
	s.publishSessionEvent(ctx, clientCode, sseEvent, sseScope, sseSessionID, session.UserID)
}

// publishSessionEvent dispatches a Temporal workflow to notification-service
// for SSE delivery. Best-effort: errors are logged, never returned.
func (s *AuthService) publishSessionEvent(ctx context.Context, clientCode, event, scope string, sessionID, userID int64) {
	if s.temporalSvc == nil {
		return
	}
	param := map[string]any{
		"event":      event,
		"scope":      scope,
		"sessionId":  sessionID,
		"userId":     userID,
		"clientCode": clientCode,
	}
	_, err := s.temporalSvc.Client.ExecuteWorkflow(ctx, client.StartWorkflowOptions{
		TaskQueue: s.notificationTaskQueue,
	}, constant.NotificationPublishSSEWorkflow, param)
	if err != nil {
		slog.ErrorContext(ctx, "session: publishSessionEvent temporal dispatch", "event", event, "err", err)
	}
}

// issueMfaPreAuthToken mints a pre-auth session row specifically for MFA handoffs,
// populating all required MFA routing and risk columns (device_id, factor1_method,
// mfa_reason, geo coordinates, country_code) and setting the 10-minute MFA TTL.
func (s *AuthService) issueMfaPreAuthToken(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	userID int64,
	clientCode string,
	reason model.MfaReason,
	factor1Method model.Factor1Method,
	platform model.Platform,
	deviceID, ipAddress string,
	geoLat, geoLon *float64,
	countryCode string,
) (string, error) {
	raw, err := newRawToken()
	if err != nil {
		return "", err
	}

	now := time.Now()
	var countryPtr *string
	if countryCode != "" {
		countryPtr = &countryCode
	}
	_ = s.preAuthRepo.InvalidateActive(ctx, svc, userID, clientCode, platform)
	_, err = s.preAuthRepo.InsertOne(ctx, svc, model.PreAuthSession{
		UserID:        userID,
		ClientCode:    clientCode,
		TokenHash:     helper.HashToken(raw),
		Purpose:       constant.PreAuthPurposeMfa,
		Platform:      platform,
		DeviceID:      &deviceID,
		DeviceInfo:    deviceID,
		IPAddress:     ipAddress,
		Factor1Method: &factor1Method,
		MfaReason:     &reason,
		GeoLat:        geoLat,
		GeoLon:        geoLon,
		CountryCode:   countryPtr,
		Status:        constant.PreAuthStatusActive,
		ExpiresAt:     now.Add(constant.MfaSessionTTL),
	})
	if err != nil {
		return "", err
	}
	return raw, nil
}

// recordSessionLog dispatches a session log to analytics-reporting-service
// via Temporal. Best-effort: errors are logged, never returned to the caller.
func (s *AuthService) recordSessionLog(ctx context.Context, clientCode string, userID int64, activity, status, note string, platform model.Platform, ipAddress string) {
	if s.temporalSvc == nil {
		return
	}
	doc := analyticsModel.SessionLog{
		UserID:     strconv.FormatInt(userID, 10),
		ClientCode: clientCode,
		Activity:   analyticsModel.SessionLogActivity(activity),
		Status:     analyticsModel.SessionLogStatus(status),
		Note:       analyticsModel.SessionLogNote(note),
		Platform:   analyticsModel.SessionLogPlatform(platform),
		IPAddress:  &ipAddress,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}
	param := tsDto.CreateSessionLogActivityParam{ClientID: clientCode, SessionLogs: []analyticsModel.SessionLog{doc}}
	_, err := s.temporalSvc.Client.ExecuteWorkflow(ctx, client.StartWorkflowOptions{
		TaskQueue: s.analyticsReportingTaskQueue,
	}, tsConstant.AnalyticsReportingRecordSessionLogsWorkflow, param)
	if err != nil {
		slog.ErrorContext(ctx, "session: temporalSvc.Client.ExecuteWorkflow", "err", err)
	}
}
