package service

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// validateUserActivationToken resolves a token hash to its token row and the
// still-pending tenant user it belongs to. It returns only the sentinels
// above and bare infra errors — never HttpErrors — so callers own logging and
// status mapping, which deliberately differs between a read-only GET and a
// POST that consumes the token.
func (s *AuthService) validateUserActivationToken(ctx context.Context, publicSvc coreService.PostgreSQLServicer, tokenHash string) (*model.ActivationToken, *userDto.UserListItem, error) {
	token, err := s.tokenRepo.GetOneByHash(ctx, publicSvc, tokenHash)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil, errActivationInvalid
		}
		return nil, nil, err
	}

	if err := validateActivationTokenState(token, time.Now()); err != nil {
		return nil, nil, err
	}

	user, err := s.userRepo.GetOneByID(ctx, s.tenantSvc(token.ClientCode), token.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil, errActivationInvalid
		}
		return nil, nil, err
	}
	if user.ActivationStatus != constant.ActivationStatusPending {
		return nil, nil, errActivationInvalid
	}

	return token, user, nil
}

// Sentinels validateUserActivationToken and validateActivationTokenState
// return so callers map the failures onto their own HTTP status:
// ValidateActivationToken sends consumed tokens to the Used 404 and expired
// or otherwise invalid tokens to the generic expired-link 404, while
// SetPassword sends errActivationUsed to 409. They never leave this package.
var (
	errActivationUsed    = errors.New("activation token already consumed")
	errActivationExpired = errors.New("activation token expired")
	errActivationInvalid = errors.New("activation token invalid")
)

func isActivationValidationError(err error) bool {
	return errors.Is(err, errActivationUsed) ||
		errors.Is(err, errActivationExpired) ||
		errors.Is(err, errActivationInvalid)
}

// validateActivationTokenState is the pure validity check for an activation
// token: it must still be Active and not past expires_at. nil means the
// token is usable.
func validateActivationTokenState(t *model.ActivationToken, now time.Time) error {
	switch {
	case t.Status == constant.TokenStatusConsumed:
		return errActivationUsed
	case t.Status != constant.TokenStatusActive:
		return errActivationInvalid
	case !now.Before(t.ExpiresAt):
		return errActivationExpired
	default:
		return nil
	}
}

// validateActivationErr maps validateUserActivationToken's sentinels to the
// two public 404 variants used by ValidateActivationToken. Non-sentinel
// errors are genuine infra failures.
func validateActivationErr(err error) error {
	switch {
	case errors.Is(err, errActivationUsed):
		return coreEntity.NotFound(constant.MsgActivationUsed)
	case errors.Is(err, errActivationExpired), errors.Is(err, errActivationInvalid):
		return coreEntity.NotFound(constant.MsgActivationExpired)
	default:
		return coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
}

// setPasswordLookupErr maps validateUserActivationToken's sentinels for
// SetPassword's initial, unlocked read: unlike the GET mapping, a consumed
// token is its own 409 here, since the caller is holding the token trying to
// use it, not just probing a link.
func setPasswordLookupErr(err error) error {
	switch {
	case errors.Is(err, errActivationUsed):
		return coreEntity.Conflict(constant.MsgActivationUsed)
	case errors.Is(err, errActivationExpired):
		return coreEntity.NotFound(constant.MsgActivationExpired)
	case errors.Is(err, errActivationInvalid):
		return coreEntity.NotFound(constant.MsgActivationInvalid)
	default:
		return coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
}

// setPasswordTxErr maps validateActivationTokenState's sentinels from SetPassword's
// pessimistic in-transaction re-check. Only two buckets, same as the old
// !isTokenActive check: consumed is 409, anything else unusable is 404
// expired.
func setPasswordTxErr(err error) error {
	switch {
	case errors.Is(err, errActivationUsed):
		return coreEntity.Conflict(constant.MsgActivationUsed)
	case errors.Is(err, errActivationExpired), errors.Is(err, errActivationInvalid):
		return coreEntity.NotFound(constant.MsgActivationExpired)
	default:
		return coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
}
