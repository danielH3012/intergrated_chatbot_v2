package service

import (
	"context"
	"errors"
	"log/slog"
	"strconv"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// evaluateAgreementTriggers decides whether the Confirm-to-Continue privacy
// agreement gate must run before login can proceed (auth-foundation §11.1).
// It fires on the first of: (a) the user has never completed a login,
// (b) they last logged out at least 30 days ago, (c) the live policy version
// differs from the one they last accepted (or they never accepted one).
//
// The two timestamps come from the caller's already-loaded user row — both
// factor-1 endpoints read it — so this only reads the consent row. The
// returned version is what the caller stamps on the pre-auth handoff as
// shown_policy_version: the version the screen actually renders is the one
// the consent is later recorded against, never one the client asserts.
//
// Polarity differs between the two timestamps and must not be conflated: a
// nil FirstLoginAt fires, a nil LastLogoutAt does not (no measuring point).
func (s *AuthService) evaluateAgreementTriggers(
	ctx context.Context,
	tenantSvc coreService.PostgreSQLServicer,
	userID int64,
	firstLoginAt, lastLogoutAt *time.Time,
) (triggered bool, policyVersion string, err error) {
	policyVersion, err = s.activePolicyVersion(ctx)
	if err != nil {
		return false, "", nil
	}
	if policyVersion == "" {
		// Nothing published, or enterprise-management is unreachable. There
		// is no policy text to render and no version to record consent
		// against, so the gate cannot fire — an outage there must not park
		// every login behind a blank consent screen. The next login re-runs
		// this and the gate self-heals.
		return false, "", nil
	}

	if firstLoginAt == nil {
		return true, policyVersion, nil
	}
	if lastLogoutAt != nil && time.Since(*lastLogoutAt) >= constant.AgreementIdleWindow {
		return true, policyVersion, nil
	}

	consent, err := s.consentRepo.GetOneByUserID(ctx, tenantSvc, userID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return true, policyVersion, nil
		}
		return false, "", err
	}
	if consent.AcceptedVersion == nil || *consent.AcceptedVersion != policyVersion {
		return true, policyVersion, nil
	}
	return false, policyVersion, nil
}

// activePolicyVersion is the currently published platform_privacy_policy
// It is owned by enterprise-management and read over its internal API
// (GET /internal/privacy-policy/active): the table lives in that service's
// database, and cross-service SQL is forbidden by ADR 001.
func (s *AuthService) activePolicyVersion(ctx context.Context) (string, error) {
	if s.generalSettingsClient == nil {
		slog.ErrorContext(ctx, "login: evaluateAgreementTriggers", "err", errors.New("generalSettings Client is not initialized"))
		return "", errors.New("generalSettings Client is not initialized")
	}

	result, err := s.generalSettingsClient.GetActivePrivacyPolicyVersion(ctx)
	if err != nil {
		slog.ErrorContext(ctx, "login: evaluateAgreementTriggers", "err", err)
		return "", err
	}
	return strconv.Itoa(result), nil
}

// beginAgreement mints the post-factor-1 handoff row the Confirm to Continue
// screen posts back with. It carries everything the resumed login needs —
// factor-1 method, device, IP and the policy version actually shown — so
// nothing identity-bearing has to be resent by the client.
//
// Purpose is 'agreement', not 'mfa': mfa_reason is unknown while the screen
// is pending and chk_pre_auth_sessions_mfa_fields demands it for 'mfa' rows.
// ConfirmAgreement converts the row in place once a reason exists.
//
// Must be called with svc already inside the caller's transaction where one
// is open (VerifyOTP), so a rolled-back factor-1 leaves no orphan row.
func (s *AuthService) beginAgreement(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	userID int64,
	clientCode string,
	factor1Method model.Factor1Method,
	policyVersion string,
	param mfaContext,
) (rawToken string, err error) {
	raw, err := newRawToken()
	if err != nil {
		return "", err
	}

	deviceID := param.DeviceID
	now := time.Now()
	if _, err := s.preAuthRepo.InsertOne(ctx, svc, model.PreAuthSession{
		UserID:             userID,
		ClientCode:         clientCode,
		TokenHash:          helper.HashToken(raw),
		Purpose:            constant.PreAuthPurposeAgreement,
		Platform:           param.Platform,
		DeviceInfo:         param.DeviceID,
		IPAddress:          param.IPAddress,
		DeviceID:           &deviceID,
		Factor1Method:      &factor1Method,
		AgreementPending:   true,
		ShownPolicyVersion: &policyVersion,
		Status:             constant.PreAuthStatusActive,
		ExpiresAt:          now.Add(s.generalSettingsClient.GetPreAuthTTL()),
	}); err != nil {
		return "", err
	}
	return raw, nil
}

// loadAgreementHandoff resolves the raw token to its pending agreement row.
// Unknown, consumed, expired, and "not an agreement handoff" all collapse to
// the same error: the caller answers 401 for every one of them and logs
// none, because no new auth decision was made.
func (s *AuthService) loadAgreementHandoff(ctx context.Context, svc coreService.PostgreSQLServicer, rawToken string) (*model.PreAuthSession, error) {
	row, err := s.preAuthRepo.GetActiveByTokenHash(ctx, svc, helper.HashToken(rawToken))
	if err != nil {
		return nil, err
	}
	if row.Status != constant.PreAuthStatusActive || !row.AgreementPending || !row.ExpiresAt.After(time.Now()) {
		return nil, pgx.ErrNoRows
	}
	return row, nil
}
