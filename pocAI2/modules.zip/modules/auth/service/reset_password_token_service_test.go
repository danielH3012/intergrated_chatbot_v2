package service

import (
	"errors"
	"testing"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

func TestResetTokenState(t *testing.T) {
	now := time.Date(2026, 8, 10, 12, 0, 0, 0, time.UTC)
	consumedAt := now.Add(-time.Hour)
	invalidatedAt := now.Add(-time.Hour)

	base := model.PasswordResetToken{
		Status:    constant.TokenStatusActive,
		ExpiresAt: now.Add(24 * time.Hour),
	}

	tests := []struct {
		name  string
		token *model.PasswordResetToken
		want  error
	}{
		{
			name:  "active link is usable",
			token: &base,
			want:  nil,
		},
		{
			name: "expired link",
			token: func() *model.PasswordResetToken {
				t := base
				t.ExpiresAt = now.Add(-time.Second)
				return &t
			}(),
			want: errResetLinkExpired,
		},
		{
			name: "consumed link via status",
			token: func() *model.PasswordResetToken {
				t := base
				t.Status = constant.TokenStatusConsumed
				return &t
			}(),
			want: errResetLinkUsed,
		},
		{
			name: "consumed link via consumed_at",
			token: func() *model.PasswordResetToken {
				t := base
				t.ConsumedAt = &consumedAt
				return &t
			}(),
			want: errResetLinkUsed,
		},
		{
			name: "invalidated link via status",
			token: func() *model.PasswordResetToken {
				t := base
				t.Status = constant.TokenStatusInvalidated
				return &t
			}(),
			want: errResetLinkInvalid,
		},
		{
			name: "invalidated link via invalidated_at",
			token: func() *model.PasswordResetToken {
				t := base
				t.InvalidatedAt = &invalidatedAt
				return &t
			}(),
			want: errResetLinkInvalid,
		},
		{
			name: "unknown status is invalid",
			token: func() *model.PasswordResetToken {
				t := base
				t.Status = "Superseded"
				return &t
			}(),
			want: errResetLinkInvalid,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := resetTokenState(tt.token, now)
			if !errors.Is(got, tt.want) {
				t.Errorf("resetTokenState() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestResetLinkErrorCode(t *testing.T) {
	tests := []struct {
		name string
		err  error
		want string
	}{
		{"expired", errResetLinkExpired, constant.ErrorCodeLinkExpired},
		{"used", errResetLinkUsed, constant.ErrorCodeLinkUsed},
		{"invalid", errResetLinkInvalid, constant.ErrorCodeLinkInvalid},
		{"unknown error falls back to invalid", errors.New("other"), constant.ErrorCodeLinkInvalid},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := resetLinkErrorCode(tt.err); got != tt.want {
				t.Errorf("resetLinkErrorCode() = %q, want %q", got, tt.want)
			}
		})
	}
}
