package service

import (
	"context"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/repository"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"golang.org/x/sync/errgroup"
)

// MeService assembles the three /me payloads — everything the shell needs
// about the caller, derived entirely from the session. No endpoint here takes
// a user id or a client code from the request, which is what makes the
// responses safe to cache per session.
//
// Permissions are read from iam's own tables; settings and entity come from
// enterprise-management, which owns those tables — cross-service SQL is
// forbidden (ADR 001), so they are HTTP reads.
type MeService struct {
	dbName string
	perms  repository.UserPermissionsRepositor
	ems    *client.EnterpriseManagementClient
	cache  *cache.Cache
}

func NewMeService(dbName string, perms repository.UserPermissionsRepositor, ems *client.EnterpriseManagementClient, c *cache.Cache) *MeService {
	return &MeService{dbName: dbName, perms: perms, ems: ems, cache: c}
}

// tenantSvc routes queries into the client's own schema — the role tables live
// in <clientCode>.*, never in public.
func (s *MeService) tenantSvc(clientCode string) coreService.PostgreSQLServicer {
	return coreService.MakePostgreSQLService(clientCode + ":" + s.dbName)
}

// Permissions is the /me/permissions payload.
func (s *MeService) Permissions(ctx context.Context, userID int64, clientCode string, product *model.Product) (*dto.MePermissions, error) {
	return s.MePermissions(ctx, userID, clientCode, product)
}

// Settings returns the tenant's display settings plus the platform-wide limits.
//
// The two reads are independent, so they run concurrently; either failing fails
// the request. There is no partial payload: a shell that renders half these
// values formats money wrong rather than not at all.
func (s *MeService) Settings(ctx context.Context, clientCode string) (*dto.MeSettings, error) {
	settingsKey := s.cache.MeSettingsKey(clientCode)
	limitsKey := s.cache.MeSystemLimitsKey()

	general, generalHit := cache.Get[dto.GeneralSettings](ctx, s.cache, settingsKey)
	limits, limitsHit := cache.Get[dto.SystemLimits](ctx, s.cache, limitsKey)

	group, groupCtx := errgroup.WithContext(ctx)
	if !generalHit {
		group.Go(func() error {
			row, err := s.ems.GeneralSettings(groupCtx, clientCode)
			if err != nil {
				return err
			}
			general = dto.GeneralSettings(row)
			return nil
		})
	}
	if !limitsHit {
		group.Go(func() error {
			row, err := s.ems.SystemLimits(groupCtx)
			if err != nil {
				return err
			}
			limits = dto.SystemLimits(row)
			return nil
		})
	}
	if err := group.Wait(); err != nil {
		return nil, err
	}

	if !generalHit {
		s.cache.Set(ctx, settingsKey, general)
	}
	if !limitsHit {
		s.cache.Set(ctx, limitsKey, limits)
	}

	return &dto.MeSettings{GeneralSettings: general, SystemLimits: limits}, nil
}

// Entity returns the client the caller is scoped to with its active products.
func (s *MeService) Entity(ctx context.Context, clientCode string) (*dto.MeEntity, error) {
	key := s.cache.MeEntityKey(clientCode)
	if hit, ok := cache.Get[dto.MeEntity](ctx, s.cache, key); ok {
		return &hit, nil
	}

	var (
		clientRow client.Client
		subsRow   client.SubscriptionsResponse
	)

	group, groupCtx := errgroup.WithContext(ctx)
	group.Go(func() error {
		var err error
		clientRow, err = s.ems.ClientByCode(groupCtx, clientCode)
		return err
	})
	group.Go(func() error {
		var err error
		subsRow, err = s.ems.Subscriptions(groupCtx, clientCode)
		return err
	})

	if err := group.Wait(); err != nil {
		return nil, err
	}

	activeProducts := subsRow.ActiveProducts
	if activeProducts == nil {
		activeProducts = []string{}
	}

	payload := dto.MeEntity{
		Entity: dto.Entity{
			// The id is a snowflake BIGINT: as a JSON number it would lose its low
			// digits in the browser.
			ID:   strconv.FormatInt(clientRow.ID, 10),
			Name: clientRow.CompanyName,
			Code: clientRow.ClientCode,
		},
		ActiveProducts: activeProducts,
	}
	s.cache.Set(ctx, key, payload)
	return &payload, nil
}

// InvalidateTenant drops the payloads built from enterprise-management's
// per-tenant rows. Called by EMS after it writes general_settings or clients.
func (s *MeService) InvalidateTenant(ctx context.Context, clientCode string) {
	s.cache.InvalidateTenant(ctx, clientCode)
}

// InvalidateSystemLimits drops the platform-wide limits, shared by every tenant.
func (s *MeService) InvalidateSystemLimits(ctx context.Context) {
	s.cache.InvalidateSystemLimits(ctx)
}
