package service

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	authWorkflow "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/workflow"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// errResendLimitExceeded is the transaction's signal that the chain is
// already at the resend cap: the request must report RESEND_LIMIT_EXCEEDED
// without having inserted or emailed anything.
var errResendLimitExceeded = errors.New("otp resend limit exceeded")

type RequestOTPParam struct {
	Email          string
	Platform       model.Platform
	RecaptchaToken string
	OtpSessionID   *string
	IPAddress      string
}

// RequestOTP backs POST /auth/otp/request: validates the email, issues a
// 6-digit code, stores only its HMAC, and dispatches the email workflow
// fire-and-forget. The request never blocks on SMTP.
//
// Step order follows the LLD literally: CAPTCHA before the account-status
// checks. Unlike Login, the user is already identified here (the credential
// and tenant lookups above), so the reordering deviation documented at
// login_service.go:40-46 does not apply — there is no lock short-circuit to
// run first.
//
// Failure outcomes are ordinary return values, not errors — only a genuine
// validation (422) or infra (500) failure returns a non-nil error.
func (s *AuthService) RequestOTP(ctx context.Context, param RequestOTPParam) (*dto.OtpRequestResponse, error) {
	if param.OtpSessionID != nil {
		trimmed := strings.TrimSpace(*param.OtpSessionID)
		if trimmed == "" {
			return nil, coreEntity.BadRequest("otpSessionId cannot be empty")
		}
		val, err := strconv.ParseInt(trimmed, 10, 64)
		if err != nil || val <= 0 {
			return nil, coreEntity.BadRequest("Invalid otpSessionId")
		}
	}

	captchaRequired := param.Platform == constant.PlatformWeb && param.OtpSessionID == nil

	email := strings.TrimSpace(param.Email)
	if email == "" {
		// Not logged: no user was identified.
		return nil, otpRequestValidationError(constant.MsgEmailEmpty, constant.ErrorCodeEmailEmpty, constant.CaptionFieldEmail, captchaRequired)
	}
	if len(email) > maxEmailLength || !emailFormatRe.MatchString(email) {
		return nil, otpRequestValidationError(constant.MsgEmailFormat, constant.ErrorCodeEmailFormat, constant.CaptionFieldEmail, captchaRequired)
	}

	publicSvc := s.publicSvc()
	cred, err := s.credRepo.GetOneByEmail(ctx, publicSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, otpRequestValidationError(constant.MsgEmailNotRegistered, constant.ErrorCodeEmailNotRegistered, constant.CaptionFieldEmail, captchaRequired)
		}
		slog.ErrorContext(ctx, "request-otp: credRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	tenantSvc := s.tenantSvc(cred.ClientCode)
	user, err := s.userRepo.GetOneByEmail(ctx, tenantSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, otpRequestValidationError(constant.MsgEmailNotRegistered, constant.ErrorCodeEmailNotRegistered, constant.CaptionFieldEmail, captchaRequired)
		}
		slog.ErrorContext(ctx, "request-otp: userRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if captchaRequired && !s.captcha.Verify(ctx, param.RecaptchaToken) {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteCaptchaNotCompleted, param.Platform, param.IPAddress)
		return otpRequestFailedResponse(constant.ErrorCodeCaptchaEmpty, constant.CaptionFieldGlobal, email, captchaRequired, false, 0), nil
	}

	if user.ActivationStatus != constant.ActivationStatusActivated {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteNotActivated, param.Platform, param.IPAddress)
		return otpRequestFailedResponse(constant.ErrorCodeNotActivated, constant.CaptionFieldGlobal, email, captchaRequired, false, 0), nil
	}
	if !user.IsActive {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteInactive, param.Platform, param.IPAddress)
		return otpRequestFailedResponse(constant.ErrorCodeInactive, constant.CaptionFieldGlobal, email, captchaRequired, false, 0), nil
	}

	code, err := generateOTP()
	if err != nil {
		slog.ErrorContext(ctx, "request-otp: generateOTP", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	otpCodeID, otpSessionID, resendCount, err := s.issueOtpCode(ctx, publicSvc, email, cred.ClientCode, param, code)
	if err != nil {
		if errors.Is(err, errResendLimitExceeded) {
			return otpRequestFailedResponse(constant.ErrorCodeResendLimitExceeded, constant.CaptionFieldGlobal, email, captchaRequired, true, constant.OtpMaxResend), nil
		}
		var httpErr *coreEntity.HttpError
		if errors.As(err, &httpErr) {
			return nil, err
		}
		slog.ErrorContext(ctx, "request-otp: issueOtpCode", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// Fire the email workflow after the row is committed. Blocking on the
	// future would reintroduce the SMTP stall the workflow exists to avoid; a
	// failed start is logged and the code stays valid (the user can resend).
	if _, err := s.temporalSvc.Client.ExecuteWorkflow(ctx, client.StartWorkflowOptions{
		ID:                    fmt.Sprintf("otp-email-%d", otpCodeID),
		TaskQueue:             s.temporalSvc.TaskQueue,
		WorkflowIDReusePolicy: enums.WORKFLOW_ID_REUSE_POLICY_REJECT_DUPLICATE,
	}, authWorkflow.SendOtpEmailWorkflow, authWorkflow.SendOtpEmailWorkflowParam{
		Email: email,
		Code:  code,
	}); err != nil {
		slog.ErrorContext(ctx, "request-otp: dispatch send-otp-email workflow", "err", err)
	}

	return &dto.OtpRequestResponse{
		Outcome:               constant.OutcomeSent,
		Email:                 email,
		OtpSessionId:          ptr(strconv.FormatInt(otpSessionID, 10)),
		CaptchaRequired:       captchaRequired,
		ResendCooldownSeconds: otpResendCooldown(resendCount),
		ResendExhausted:       false,
	}, nil
}

// issueOtpCode resolves the resend chain and stores the new code in one
// transaction: invalidate-then-insert holds the "one live code" invariant.
// It returns the new row's id (the email workflow's dedupe key), the
// resend_count the inserted row carries, and the chain's session id.
func (s *AuthService) issueOtpCode(
	ctx context.Context,
	publicSvc coreService.PostgreSQLServicer,
	email, clientCode string,
	param RequestOTPParam,
	code string,
) (otpCodeID, otpSessionID int64, resendCount int, err error) {
	otpCodeID, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (int64, error) {
		publicSvc.SetTransaction(tx)

		// resendCount is the count the inserted row carries: 0 for a fresh
		// chain, latest+1 for a resend inside one.
		resendCount = 0
		if param.OtpSessionID != nil {
			trimmed := strings.TrimSpace(*param.OtpSessionID)
			if trimmed == "" {
				return 0, coreEntity.BadRequest("otpSessionId cannot be empty")
			}
			sessionIDInt, err := strconv.ParseInt(trimmed, 10, 64)
			if err != nil || sessionIDInt <= 0 {
				return 0, coreEntity.BadRequest("Invalid otpSessionId")
			}
			latest, lerr := s.otpRepo.GetLatestInSession(ctx, publicSvc, email, clientCode, sessionIDInt)
			if lerr != nil && !errors.Is(lerr, pgx.ErrNoRows) {
				return 0, lerr
			}
			if lerr == nil {
				// A miss (chain belongs to nobody / another email) is treated
				// as a fresh chain, never an error — do not leak chain
				// existence.
				otpSessionID = sessionIDInt
				resendCount = latest.ResendCount + 1
			}
		}

		if otpSessionID == 0 {
			coreDb.InitSnowflake()
			otpSessionID = coreDb.Node.Generate().Int64()
		}

		// The cap trips on the count THIS row would carry: resend_count climbs
		// 0 (original) → 1…4 (resends), and the next request — whose row would
		// carry 5 — answers RESEND_LIMIT_EXCEEDED. Nothing is inserted,
		// emailed, or logged on the exhausted path.
		if resendCount >= constant.OtpMaxResend {
			return 0, errResendLimitExceeded
		}

		if err := s.otpRepo.InvalidateActive(ctx, publicSvc, email, clientCode, constant.OtpPurposeLogin); err != nil {
			return 0, err
		}

		return s.otpRepo.InsertOne(ctx, publicSvc, model.OtpCode{
			Email:        email,
			ClientCode:   clientCode,
			CodeHash:     s.hashOTP(code),
			Purpose:      constant.OtpPurposeLogin,
			OtpSessionID: otpSessionID,
			ResendCount:  resendCount,
			Platform:     param.Platform,
			ExpiresAt:    time.Now().Add(constant.OtpTTL),
		})
	})
	return otpCodeID, otpSessionID, resendCount, err
}

func otpRequestValidationError(message, errorCode, captionField string, captchaRequired bool) error {
	return &coreEntity.HttpError{
		Code:    fiber.StatusUnprocessableEntity,
		Message: message,
		Data: &dto.OtpRequestResponse{
			ErrorCode:       &errorCode,
			CaptionField:    &captionField,
			CaptchaRequired: captchaRequired,
		},
	}
}

func otpRequestFailedResponse(errorCode, captionField, email string, captchaRequired, resendExhausted bool, resendCount int) *dto.OtpRequestResponse {
	return &dto.OtpRequestResponse{
		Outcome:               constant.OutcomeFailed,
		Email:                 email,
		CaptchaRequired:       captchaRequired,
		ResendCooldownSeconds: otpResendCooldown(resendCount),
		ResendExhausted:       resendExhausted,
		ErrorCode:             &errorCode,
		CaptionField:          &captionField,
	}
}
