package service

import (
	"errors"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// Sentinels resetTokenState returns so callers can map the three link
// failures onto their distinct errorCodes without re-reading the row. They
// never leave this package; every HTTP-facing caller maps all three to the
// same neutral 404.
var (
	errResetLinkExpired = errors.New("reset link expired")
	errResetLinkUsed    = errors.New("reset link already used")
	errResetLinkInvalid = errors.New("reset link invalid")
)

// resetTokenState is the pure validity check for a password reset link: it
// must still be Active, not past expires_at, not consumed and not invalidated.
// nil means the link is usable.
func resetTokenState(t *model.PasswordResetToken, now time.Time) error {
	switch {
	case t.Status == constant.TokenStatusConsumed || t.ConsumedAt != nil:
		return errResetLinkUsed
	case t.Status != constant.TokenStatusActive || t.InvalidatedAt != nil:
		return errResetLinkInvalid
	case now.After(t.ExpiresAt):
		return errResetLinkExpired
	default:
		return nil
	}
}

// resetLinkErrorCode picks the errorCode for the sentinel resetTokenState
// returned. The HTTP status and message stay neutral across all three — only
// this string differentiates for the FE and the logs.
func resetLinkErrorCode(err error) string {
	switch {
	case errors.Is(err, errResetLinkExpired):
		return constant.ErrorCodeLinkExpired
	case errors.Is(err, errResetLinkUsed):
		return constant.ErrorCodeLinkUsed
	default:
		return constant.ErrorCodeLinkInvalid
	}
}

// resetLinkLogNote picks the §9 log note for the sentinel resetTokenState
// returned. An invalidated link (superseded by a resend) is logged the same
// as expired — it maps to the same "Expired" copy the FE shows (TC-VALIDATE-04).
func resetLinkLogNote(err error) string {
	if errors.Is(err, errResetLinkUsed) {
		return constant.LogNoteResetLinkUsed
	}
	return constant.LogNoteResetLinkExpired
}
