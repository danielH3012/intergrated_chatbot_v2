package service

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
)

// pendingHandoff is a live agreement gate: active, unexpired, pending, with
// the version the Confirm to Continue screen rendered stamped on it.
func pendingHandoff() *model.PreAuthSession {
	f1Pass := constant.Factor1MethodPassword
	return &model.PreAuthSession{
		ID:                 42,
		UserID:             7,
		ClientCode:         "acme",
		Purpose:            constant.PreAuthPurposeAgreement,
		Platform:           constant.PlatformWeb,
		DeviceInfo:         "device-1",
		IPAddress:          "127.0.0.1",
		DeviceID:           ptr("device-1"),
		Factor1Method:      &f1Pass,
		AgreementPending:   true,
		ShownPolicyVersion: ptr("2.0"),
		Status:             constant.PreAuthStatusActive,
		ExpiresAt:          time.Now().Add(constant.PreAuthTTL),
	}
}

type agreementFixture struct {
	svc      *AuthService
	preAuth  *fakePreAuthRepo
	consent  *fakeConsentRepo
	sessions *fakeSessionRepo
	db       *fakeDBFactory
}

func newAgreementFixture(t *testing.T, row *model.PreAuthSession) *agreementFixture {
	t.Helper()

	f := &agreementFixture{
		preAuth:  &fakePreAuthRepo{row: row},
		consent:  &fakeConsentRepo{},
		sessions: &fakeSessionRepo{},
		db:       &fakeDBFactory{},
	}
	f.svc = &AuthService{
		preAuthRepo:           f.preAuth,
		consentRepo:           f.consent,
		sessionRepo:           f.sessions,
		generalSettingsClient: policyClient(t, 2),
	}
	f.svc.SetServiceFactoryForTest(f.db.factory())
	return f
}

func accept() dto.ConfirmAgreementRequest {
	accepted := true
	return dto.ConfirmAgreementRequest{PreAuthToken: "raw-token", AgreementAccepted: &accepted}
}

// Every unusable token answers the same 401 and writes nothing — the client
// cannot tell "never existed" from "already used" from "expired".
func TestConfirmAgreement_Unauthorized(t *testing.T) {
	expired := pendingHandoff()
	expired.ExpiresAt = time.Now().Add(-time.Minute)

	consumed := pendingHandoff()
	consumed.Status = constant.PreAuthStatusConsumed

	notAGate := pendingHandoff()
	notAGate.AgreementPending = false

	cases := []struct {
		name string
		row  *model.PreAuthSession
	}{
		{"unknown token", nil},
		{"expired", expired},
		{"already consumed", consumed},
		{"not an agreement handoff", notAGate},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newAgreementFixture(t, tc.row)

			_, err := f.svc.ConfirmAgreement(context.Background(), accept())
			if httpStatus(err) != fiber.StatusUnauthorized {
				t.Fatalf("status = %d, want 401 (err %v)", httpStatus(err), err)
			}
			if len(f.consent.writes) != 0 {
				t.Error("no consent may be recorded for an unusable token")
			}
			if len(f.preAuth.consumed) != 0 {
				t.Error("an unusable token must not be consumed again")
			}
			if len(f.sessions.inserted) != 0 {
				t.Error("no session may be created")
			}
		})
	}
}

// Declining is the only way to reach 422. The attempt is abandoned: token
// consumed, no consent row, no session.
func TestConfirmAgreement_Declined(t *testing.T) {
	cases := []struct {
		name string
		body dto.ConfirmAgreementRequest
	}{
		{"explicit false", dto.ConfirmAgreementRequest{PreAuthToken: "raw-token", AgreementAccepted: new(bool)}},
		{"field absent", dto.ConfirmAgreementRequest{PreAuthToken: "raw-token"}},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newAgreementFixture(t, pendingHandoff())

			_, err := f.svc.ConfirmAgreement(context.Background(), tc.body)
			if httpStatus(err) != fiber.StatusUnprocessableEntity {
				t.Fatalf("status = %d, want 422", httpStatus(err))
			}
			if err.Error() != constant.MsgAgreementDeclined {
				t.Errorf("message = %q, want the PRD copy %q", err.Error(), constant.MsgAgreementDeclined)
			}
			if len(f.preAuth.consumed) != 1 || f.preAuth.consumed[0] != 42 {
				t.Errorf("consumed = %v, want [42] — a decline ends the attempt", f.preAuth.consumed)
			}
			if len(f.consent.writes) != 0 {
				t.Error("a decline must not record consent")
			}
			if len(f.sessions.inserted) != 0 {
				t.Error("a decline must not create a session")
			}
		})
	}
}

// Accepting with no MFA and a free platform is the final login: consent
// recorded against the stamped version, token consumed, session created.
func TestConfirmAgreement_AcceptedCreatesSession(t *testing.T) {
	f := newAgreementFixture(t, pendingHandoff())

	resp, err := f.svc.ConfirmAgreement(context.Background(), accept())
	if err != nil {
		t.Fatalf("ConfirmAgreement() err = %v", err)
	}
	if resp.Outcome != constant.OutcomeSuccess {
		t.Fatalf("outcome = %q, want success", resp.Outcome)
	}
	if resp.RedirectTo == nil || *resp.RedirectTo != constant.RedirectProductHub {
		t.Errorf("redirectTo = %v, want %q", resp.RedirectTo, constant.RedirectProductHub)
	}
	if resp.SessionID == nil || *resp.SessionID == "" {
		t.Fatal("success must return the raw session token")
	}
	if resp.PreAuthToken != nil {
		t.Error("the handoff is consumed on success; no token may be echoed back")
	}

	if len(f.consent.writes) != 1 {
		t.Fatalf("consent writes = %d, want 1", len(f.consent.writes))
	}
	if got := f.consent.writes[0]; got.UserID != 7 || got.Version != "2.0" {
		t.Errorf("consent = %+v, want user 7 at the stamped version 2.0", got)
	}
	if !f.db.sawSchema("acme") {
		t.Error("the consent row must be written in the handoff row's tenant schema")
	}
	if len(f.preAuth.consumed) != 1 {
		t.Errorf("consumed = %v, want the handoff consumed exactly once", f.preAuth.consumed)
	}
	if len(f.sessions.inserted) != 1 || f.sessions.inserted[0].UserID != 7 {
		t.Errorf("sessions = %+v, want one session for user 7", f.sessions.inserted)
	}
}

// The version recorded is the one stamped when the gate fired, never the live
// one: a policy republished while the screen was open is passable, not fatal.
func TestConfirmAgreement_RecordsShownVersionNotLiveVersion(t *testing.T) {
	row := pendingHandoff()
	row.ShownPolicyVersion = ptr("1.0")
	f := newAgreementFixture(t, row) // live version is 2.0

	if _, err := f.svc.ConfirmAgreement(context.Background(), accept()); err != nil {
		t.Fatalf("ConfirmAgreement() err = %v, want the stale stamp to pass", err)
	}
	if len(f.consent.writes) != 1 || f.consent.writes[0].Version != "1.0" {
		t.Fatalf("consent = %+v, want the version the screen actually rendered", f.consent.writes)
	}
}

// Limit Login found another live session: the consent stands, but the handoff
// is re-scoped for confirm-duplicate instead of being consumed, and no
// session or success log is written.
func TestConfirmAgreement_DuplicateDetected(t *testing.T) {
	f := newAgreementFixture(t, pendingHandoff())
	f.sessions.active = &model.Session{
		ID: 99, UserID: 7, ClientCode: "acme", Platform: constant.PlatformWeb,
		DeviceInfo: "Chrome on Windows", LastActivityAt: time.Now(),
	}

	resp, err := f.svc.ConfirmAgreement(context.Background(), accept())
	if err != nil {
		t.Fatalf("ConfirmAgreement() err = %v", err)
	}
	if resp.Outcome != constant.OutcomeDuplicateDetected {
		t.Fatalf("outcome = %q, want duplicate_detected", resp.Outcome)
	}
	if resp.PreAuthToken == nil || *resp.PreAuthToken != "raw-token" {
		t.Errorf("preAuthToken = %v, want the same token for confirm-duplicate", resp.PreAuthToken)
	}
	if resp.ExistingSession == nil || resp.ExistingSession.DeviceInfo != "Chrome on Windows" {
		t.Errorf("existingSession = %+v, want the conflicting session's detail", resp.ExistingSession)
	}
	if resp.SessionID != nil || len(f.sessions.inserted) != 0 {
		t.Error("no session may be created while the duplicate is unresolved")
	}
	if len(f.consent.writes) != 1 {
		t.Error("the consent was legitimate and informed — it must be kept")
	}
	if len(f.preAuth.consumed) != 0 {
		t.Error("the handoff must stay usable for confirm-duplicate")
	}
	if len(f.preAuth.convertedTo) != 1 || f.preAuth.convertedTo[0] != constant.PreAuthPurposeDuplicateLogin {
		t.Fatalf("converted = %v, want the row re-scoped to duplicate_login", f.preAuth.convertedTo)
	}
	if f.preAuth.duplicateID != 99 {
		t.Errorf("existing_session_id = %d, want 99 — confirm-duplicate dereferences it", f.preAuth.duplicateID)
	}
}

// A write failure inside the transaction is a 500 and claims nothing: no
// success, no session token handed out.
func TestConfirmAgreement_WriteFailureIs500(t *testing.T) {
	f := newAgreementFixture(t, pendingHandoff())
	f.consent.writeErr = errors.New("deadlock detected")

	resp, err := f.svc.ConfirmAgreement(context.Background(), accept())
	if httpStatus(err) != fiber.StatusInternalServerError {
		t.Fatalf("status = %d, want 500", httpStatus(err))
	}
	if resp != nil {
		t.Errorf("resp = %+v, want nil on failure", resp)
	}
	if len(f.sessions.inserted) != 0 {
		t.Error("a failed consent write must not leave a session behind")
	}
}

// A lookup failure is an outage, not a bad token: it must not be laundered
// into the 401 that tells the user to log in again.
func TestConfirmAgreement_LookupFailureIs500(t *testing.T) {
	f := newAgreementFixture(t, nil)
	f.preAuth.getErr = errors.New("connection refused")

	_, err := f.svc.ConfirmAgreement(context.Background(), accept())
	if httpStatus(err) != fiber.StatusInternalServerError {
		t.Fatalf("status = %d, want 500", httpStatus(err))
	}
}

// The success log Note belongs to factor-1: this flow never invents its own.
func TestFactor1LogNote(t *testing.T) {
	f1Password := constant.Factor1MethodPassword
	f1Otp := constant.Factor1MethodOtp
	cases := []struct {
		name   string
		method *model.Factor1Method
		want   string
	}{
		{"password", &f1Password, constant.LogNoteLoginSuccess},
		{"otp", &f1Otp, constant.LogNoteLoginOtpSuccess},
		{"missing falls back to password", nil, constant.LogNoteLoginSuccess},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := factor1LogNote(tc.method); got != tc.want {
				t.Fatalf("factor1LogNote() = %q, want %q", got, tc.want)
			}
		})
	}
}

// loadAgreementHandoff is the single authorisation point; it must not leak a
// row that is merely present.
func TestLoadAgreementHandoff(t *testing.T) {
	f := newAgreementFixture(t, pendingHandoff())

	row, err := f.svc.loadAgreementHandoff(context.Background(), f.svc.publicSvc(), "raw-token")
	if err != nil {
		t.Fatalf("loadAgreementHandoff() err = %v", err)
	}
	if row.ID != 42 {
		t.Fatalf("row.ID = %d, want 42", row.ID)
	}

	f2 := newAgreementFixture(t, nil)
	if _, err := f2.svc.loadAgreementHandoff(context.Background(), f2.svc.publicSvc(), "raw-token"); !errors.Is(err, pgx.ErrNoRows) {
		t.Fatalf("err = %v, want pgx.ErrNoRows for a missing row", err)
	}
}
