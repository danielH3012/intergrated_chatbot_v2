package service

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// nextAttemptWindow advances the fixed-window counter. The attempt tables are
// one row per key with a window_start; when the window has rolled over the
// counter restarts at 1 with a fresh window_start, otherwise it increments in
// place. The caller compares the resulting nextCount against the budget.
func nextAttemptWindow(count int, windowStart time.Time, window time.Duration, now time.Time) (nextCount int, nextStart time.Time) {
	if now.Sub(windowStart) >= window {
		return 1, now
	}
	return count + 1, windowStart
}

// resendAvailableInSec is the seconds left in the 60s resend cooldown, clamped
// at 0. It is what the response advertises so the FE can count down.
func resendAvailableInSec(lastAttemptAt, now time.Time) int {
	remaining := constant.ResetPasswordResendCooldown - now.Sub(lastAttemptAt)
	if remaining < 0 {
		return 0
	}
	return int(remaining / time.Second)
}
