package service

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// ValidateSession backs GET /auth/validate, which the gateway calls on every
// request to an authenticated route. Unknown, revoked and idled-out tokens are
// all one neutral 401 — the caller learns nothing beyond "log in again".
func (s *AuthService) ValidateSession(ctx context.Context, rawToken string) (*dto.ValidateSessionResponse, error) {
	return s.validateSession(ctx, s.publicSvc(), rawToken)
}

// validateSession takes the schema-scoped handle as an argument, the way
// createPlatformSession does — publicSvc() dials Postgres and log.Fatalf's if
// it cannot, so the logic has to sit behind that call to be exercisable.
func (s *AuthService) validateSession(ctx context.Context, publicSvc coreService.PostgreSQLServicer, rawToken string) (*dto.ValidateSessionResponse, error) {
	tokenHash := helper.HashToken(rawToken)
	session, err := s.sessionRepo.GetActiveByTokenHash(ctx, publicSvc, tokenHash)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			// On-read expiry: the active lookup missed, but the row may
			// exist as active with a passed expires_at. One extra query
			// on the failure path keeps correctness independent of the
			// sweep cadence.
			if existing, lookErr := s.sessionRepo.GetByTokenHash(ctx, publicSvc, tokenHash); lookErr == nil && existing.Status == constant.SessionStatusActive && existing.ExpiresAt.Before(time.Now()) {
				if terminated, termErr := s.terminateSession(ctx, publicSvc, existing, constant.SessionStatusExpired, constant.TerminatedReasonIdleTimeout, "Session", analyticsModel.SessionLogNoteSessionExpired); termErr != nil {
					slog.ErrorContext(ctx, "auth.ValidateSession: terminateSession (on-read expiry)", "err", termErr)
				} else if terminated {
					s.recordSessionLog(ctx, existing.ClientCode, existing.UserID, "Session", constant.LogStatusFailed, string(analyticsModel.SessionLogNoteSessionExpired), existing.Platform, existing.IPAddress)
				}
			}
			return nil, coreEntity.Unauthorized(constant.MsgSessionInvalid)
		}
		slog.ErrorContext(ctx, "auth.ValidateSession: sessionRepo.GetActiveByTokenHash", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// Slide the idle window. A failure here means the session is still valid
	// but will expire on its original schedule — degraded, not broken, so the
	// request proceeds rather than 500ing a user who did nothing wrong.
	idleTimeout := s.generalSettingsClient.GetSessionIdleTimeout(ctx, session.ClientCode)
	if err := s.sessionRepo.Touch(ctx, publicSvc, session.ID, time.Now(), idleTimeout); err != nil {
		slog.WarnContext(ctx, "auth.ValidateSession: sessionRepo.Touch: session keeps its original expiry",
			"userId", session.UserID, "err", err)
	}

	return &dto.ValidateSessionResponse{UserID: session.UserID, ClientCode: session.ClientCode, SessionID: &session.ID}, nil
}
