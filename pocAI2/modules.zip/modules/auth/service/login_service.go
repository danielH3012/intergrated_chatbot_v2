package service

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

var emailFormatRe = regexp.MustCompile(`^[\w.-]+@[\w.-]+\.\w{2,}$`)

const maxEmailLength = 120

type LoginParam struct {
	Email          string
	Password       string
	RecaptchaToken string
	Platform       model.Platform
	DeviceID       string
	IPAddress      string
}

// resolvedLogin holds the outcome of credential + password validation so that
// Login and DevLogin can share the same front-half without duplication.
type resolvedLogin struct {
	publicSvc       coreService.PostgreSQLServicer
	tenantSvc       coreService.PostgreSQLServicer
	user            *userDto.UserListItem
	clientCode      string
	captchaRequired bool
}

// resolveLogin performs the shared front-half of login: email validation,
// credential and user lookup, activation/active gates, captcha, password
// comparison, and lock checks. On success it returns a resolvedLogin ready
// for the caller to evaluate agreement/MFA gates (Login) or skip them
// (DevLogin) before calling completeLogin.
//
// When skipCaptcha is true the reCAPTCHA check is bypassed entirely and
// captchaRequired is forced to false in all responses (DevLogin path).
//
// Step order here is load-bearing: the lock short-circuit runs before password
// verification so a locked account is never password-probeable, and the
// credential/account checks that are logged always happen after the ones that
// are not (so a bad email never produces a log entry keyed on a user that was
// never identified).
//
// One deviation from the design doc's literal step order: this fetches the
// tenant user (and its activation/active gates) immediately after the
// credential lookup, before the CAPTCHA and empty-password checks. The doc
// orders those first, but every logged branch needs a numeric user id for
// session_logs, and the tenant user lookup is the only source of one before
// the account is otherwise identified. Reordering does not create an oracle:
// every branch here already returns a generic, logged failure.
//
// Failure/lock outcomes are ordinary return values, not errors — only a
// genuine validation (422) or infra (500) failure returns a non-nil error.
func (s *AuthService) resolveLogin(ctx context.Context, param LoginParam, skipCaptcha bool) (*resolvedLogin, *dto.LoginResponse, error) {
	captchaRequired := !skipCaptcha && param.Platform == constant.PlatformWeb

	email := strings.TrimSpace(param.Email)
	if email == "" {
		slog.ErrorContext(ctx, "login: email empty")
		return nil, nil, loginValidationError(constant.MsgEmailEmpty, constant.ErrorCodeEmailEmpty, constant.CaptionFieldEmail, captchaRequired)
	}
	if len(email) > maxEmailLength || !emailFormatRe.MatchString(email) {
		slog.ErrorContext(ctx, "login: email format invalid")
		return nil, nil, loginValidationError(constant.MsgEmailFormat, constant.ErrorCodeEmailFormat, constant.CaptionFieldEmail, captchaRequired)
	}

	publicSvc := s.publicSvc()
	cred, err := s.credRepo.GetOneByEmail(ctx, publicSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			slog.ErrorContext(ctx, "login: credRepo.GetOneByEmail: not found", "err", err)
			return nil, nil, loginValidationError(constant.MsgEmailNotRegistered, constant.ErrorCodeEmailNotRegistered, constant.CaptionFieldEmail, captchaRequired)
		}
		slog.ErrorContext(ctx, "login: credRepo.GetOneByEmail", "err", err)
		return nil, nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	tenantSvc := s.tenantSvc(cred.ClientCode)
	user, err := s.userRepo.GetOneByEmail(ctx, tenantSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			slog.ErrorContext(ctx, "login: userRepo.GetOneByEmail: not found", "err", err)
			return nil, nil, loginValidationError(constant.MsgEmailNotRegistered, constant.ErrorCodeEmailNotRegistered, constant.CaptionFieldEmail, captchaRequired)
		}
		slog.ErrorContext(ctx, "login: userRepo.GetOneByEmail", "err", err)
		return nil, nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// A credential with no password hash is an account that never completed
	// activation — the invite writes the row password-less so login can resolve
	// the tenant at all (see the ems client-creation saga). It reads as
	// not-activated rather than as a wrong password: falling through to the
	// comparison below would answer "Incorrect email or password" and burn
	// lockout counters on an account that has no password to get wrong.
	if user.ActivationStatus != constant.ActivationStatusActivated || cred.PasswordHash == nil {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteNotActivated, param.Platform, param.IPAddress)
		return nil, failedResponse(constant.ErrorCodeNotActivated, constant.CaptionFieldGlobal, captchaRequired), nil
	}
	if !user.IsActive {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteInactive, param.Platform, param.IPAddress)
		return nil, failedResponse(constant.ErrorCodeInactive, constant.CaptionFieldGlobal, captchaRequired), nil
	}

	if captchaRequired && !s.captcha.Verify(ctx, param.RecaptchaToken) {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteCaptchaNotCompleted, param.Platform, param.IPAddress)
		return nil, failedResponse(constant.ErrorCodeCaptchaEmpty, constant.CaptionFieldGlobal, captchaRequired), nil
	}

	// Password is never trimmed.
	if param.Password == "" {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteEmptyPassword, param.Platform, param.IPAddress)
		return nil, failedResponse(constant.ErrorCodePasswordEmpty, constant.CaptionFieldPassword, captchaRequired), nil
	}

	// Lock short-circuit: an in-window re-attempt is rejected before
	// credential evaluation, so a locked account is never password-probeable.
	// This is deliberately not logged and does not touch the counters — the
	// design doc is explicit that in-window attempts are invisible.
	daily, cross, err := s.readLockState(ctx, publicSvc, user.ID, param.Platform)
	if err != nil {
		slog.ErrorContext(ctx, "login: readLockState", "err", err)
		return nil, nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if level, until, active := IsCurrentlyLocked(daily, cross, time.Now()); active {
		return nil, lockedResponse(level, until, captchaRequired), nil
	}

	if cred.PasswordHash == nil || s.password.ComparePassword(*cred.PasswordHash, param.Password) != nil {
		level, until, txErr := s.recordFailedAttempt(ctx, publicSvc, user.ID, cred.ClientCode, param.Platform)
		if txErr != nil {
			slog.ErrorContext(ctx, "login: recordFailedAttempt", "err", txErr)
			return nil, nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		if level == constant.LockLevelNone {
			s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteIncorrectPassword, param.Platform, param.IPAddress)
			return nil, failedResponse(constant.ErrorCodeIncorrect, constant.CaptionFieldGlobal, captchaRequired), nil
		}
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, lockLogNote(level), param.Platform, param.IPAddress)
		return nil, lockedResponse(level, until, captchaRequired), nil
	}

	return &resolvedLogin{
		publicSvc:       publicSvc,
		tenantSvc:       tenantSvc,
		user:            user,
		clientCode:      cred.ClientCode,
		captchaRequired: captchaRequired,
	}, nil, nil
}

// Login backs POST /auth/login. Step order is load-bearing: the lock
// short-circuit runs before password verification so a locked account is
// never password-probeable, and the credential/account checks that are
// logged always happen after the ones that are not (so a bad email never
// produces a log entry keyed on a user that was never identified).
//
// Failure/lock outcomes are ordinary return values, not errors — only a
// genuine validation (422) or infra (500) failure returns a non-nil error.
func (s *AuthService) Login(ctx context.Context, param LoginParam) (*dto.LoginResponse, error) {
	r, failure, err := s.resolveLogin(ctx, param, false)
	if err != nil {
		return nil, err
	}
	if failure != nil {
		return failure, nil
	}

	// Agreement gate always runs before MFA, even if MFA would also trigger —
	// avoids MFA side effects (e.g. sending an OTP) for an attempt that ends
	// in refusal.
	if triggered, policyVersion, err := s.evaluateAgreementTriggers(ctx, r.tenantSvc, r.user.ID, r.user.FirstLoginAt, r.user.LastLogoutAt); err != nil {
		slog.ErrorContext(ctx, "login: evaluateAgreementTriggers", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	} else if triggered {
		preAuthToken, err := s.beginAgreement(ctx, r.publicSvc, r.user.ID, r.clientCode,
			constant.Factor1MethodPassword, policyVersion,
			mfaContext{Platform: param.Platform, DeviceID: param.DeviceID, IPAddress: param.IPAddress})
		if err != nil {
			slog.ErrorContext(ctx, "login: beginAgreement", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		return &dto.LoginResponse{
			Outcome:              constant.OutcomeAgreementRequired,
			PreAuthToken:         &preAuthToken,
			PrivacyPolicyVersion: &policyVersion,
			CaptchaRequired:      r.captchaRequired,
		}, nil
	}

	if reason, triggered, err := s.evaluateMfaTriggers(ctx, r.publicSvc, s.tenantSvc(r.clientCode), r.user.ID, r.clientCode, param.Platform, param.DeviceID, nil, nil, ""); err != nil {
		slog.ErrorContext(ctx, "login: evaluateMfaTriggers", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	} else if triggered {
		handoff, err := s.beginMfa(ctx, r.publicSvc, r.user.ID, r.clientCode,
			reason, constant.Factor1MethodPassword, r.user.Email,
			mfaContext{Platform: param.Platform, DeviceID: param.DeviceID, IPAddress: param.IPAddress})
		if err != nil {
			slog.ErrorContext(ctx, "login: beginMfa", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		return &dto.LoginResponse{
			Outcome:               constant.OutcomeMfaRequired,
			MfaReason:             &handoff.Reason,
			PreAuthToken:          &handoff.PreAuthToken,
			Factor1Method:         &handoff.Factor1Method,
			AuthenticatorEnrolled: &handoff.AuthenticatorEnrolled,
			MfaEmail:              &handoff.Email,
			CaptchaRequired:       r.captchaRequired,
		}, nil
	}

	return s.finishLogin(ctx, r, param)
}

// finishLogin creates the session after all gates have been cleared.
func (s *AuthService) finishLogin(ctx context.Context, r *resolvedLogin, param LoginParam) (*dto.LoginResponse, error) {
	outcome, rawToken, _, existing, _, err := s.completeLogin(ctx, r.publicSvc, r.user.ID, r.clientCode, param)
	if err != nil {
		slog.ErrorContext(ctx, "login: completeLogin", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if outcome == sessionOutcomeDuplicateDetected {
		s.recordLoginAttempt(ctx, r.clientCode, r.user.ID, constant.LogStatusSuccess, constant.LogNoteLoginSuccess, param.Platform, param.IPAddress)
		return &dto.LoginResponse{
			Outcome:         constant.OutcomeSuccess,
			SessionID:       &rawToken,
			ExistingSession: existing,
			CaptchaRequired: r.captchaRequired,
		}, nil
	}

	s.recordLoginAttempt(ctx, r.clientCode, r.user.ID, constant.LogStatusSuccess, constant.LogNoteLoginSuccess, param.Platform, param.IPAddress)
	return &dto.LoginResponse{
		Outcome:         constant.OutcomeSuccess,
		SessionID:       &rawToken,
		CaptchaRequired: r.captchaRequired,
	}, nil
}

func (s *AuthService) readLockState(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.LoginAttemptLock, *model.UserLockState, error) {
	daily, err := s.lockRepo.GetTodayForUpdate(ctx, svc, userID, platform)
	if err != nil {
		if !errors.Is(err, pgx.ErrNoRows) {
			return nil, nil, err
		}
		daily = nil
	}
	cross, err := s.lockRepo.GetLockState(ctx, svc, userID, platform)
	if err != nil {
		if !errors.Is(err, pgx.ErrNoRows) {
			return nil, nil, err
		}
		cross = nil
	}
	return daily, cross, nil
}

// recordFailedAttempt persists the post-failure lock state in one
// transaction with a pessimistic lock on today's row, so two concurrent
// wrong passwords cannot both read the same failed_count and neither lock
// the account.
func (s *AuthService) recordFailedAttempt(ctx context.Context, publicSvc coreService.PostgreSQLServicer, userID int64, clientCode string, platform model.Platform) (level model.LockLevel, until *time.Time, err error) {
	_, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)

		// Transaction-scoped advisory lock on userID guarantees that two
		// concurrent failures serialize cleanly before the daily row exists,
		// preventing unq_login_attempt_lock_user_id_platform_attempt_date collisions.
		if err := publicSvc.Execute(ctx, fmt.Sprintf("SELECT pg_advisory_xact_lock(%d)", userID)); err != nil {
			return struct{}{}, err
		}

		daily, cross, err := s.readLockState(ctx, publicSvc, userID, platform)
		if err != nil {
			return struct{}{}, err
		}

		nextDaily, nextCross, lvl, lockUntil := NextLockState(daily, cross, time.Now())
		nextDaily.UserID, nextDaily.ClientCode, nextDaily.Platform = userID, clientCode, platform
		nextCross.UserID, nextCross.Platform = userID, platform
		level, until = lvl, lockUntil

		if err := s.lockRepo.UpsertToday(ctx, publicSvc, nextDaily); err != nil {
			return struct{}{}, err
		}
		return struct{}{}, s.lockRepo.UpsertLockState(ctx, publicSvc, nextCross)
	})
	return level, until, err
}

// completeLogin resets today's failure counter and creates the session in
// one transaction — a successful login must not leave a stale counter that
// looks like the previous attempts never happened.
//
// On duplicate_detected it also issues the pre-auth token the client needs for
// POST /auth/sessions/confirm-duplicate. That has to happen inside this
// transaction: publicSvc holds the tx handle for as long as it is set, and
// nothing clears it afterwards, so any DB call made after UseTransactions
// returns fails with "tx is closed".
func (s *AuthService) completeLogin(ctx context.Context, publicSvc coreService.PostgreSQLServicer, userID int64, clientCode string, param LoginParam) (outcome, rawToken, preAuthToken string, existing *dto.ExistingSessionInfo, terminated *model.Session, err error) {
	_, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)

		if err := s.lockRepo.ResetToday(ctx, publicSvc, userID, param.Platform); err != nil {
			return struct{}{}, err
		}

		var sessionErr error
		outcome, rawToken, existing, sessionErr = s.createPlatformSession(ctx, publicSvc, userID, clientCode, param.Platform, param.DeviceID, param.IPAddress)
		if sessionErr != nil || outcome != sessionOutcomeDuplicateDetected {
			return struct{}{}, sessionErr
		}

		var existingSessionID int64
		if existing != nil && existing.ExistingSessionID != nil {
			existingSessionID = *existing.ExistingSessionID
		}

		// ponytail: the duplicate-login dialog is disabled, so login takes the
		// session over (last login wins) — the existing session's raw token is
		// hashed on insert and unrecoverable, so the only way to hand the
		// client a usable sessionId is to mint a new one. Delete this block and
		// un-comment the duplicate_detected branch in Login to re-enable the
		// dialog.
		oldSession, sessionErr := s.sessionRepo.GetByID(ctx, publicSvc, existingSessionID)
		if sessionErr != nil {
			return struct{}{}, sessionErr
		}
		if _, sessionErr = s.terminateSession(ctx, publicSvc, oldSession, constant.SessionStatusForceLoggedOut, constant.TerminatedReasonDuplicateLogin, "Session", analyticsModel.SessionLogNoteLoggedOut); sessionErr != nil {
			return struct{}{}, sessionErr
		}
		terminated = oldSession
		_, rawToken, _, sessionErr = s.createPlatformSession(ctx, publicSvc, userID, clientCode, param.Platform, param.DeviceID, param.IPAddress)
		return struct{}{}, sessionErr
	})
	return outcome, rawToken, preAuthToken, existing, terminated, err
}

func (s *AuthService) recordLoginAttempt(ctx context.Context, clientCode string, userID int64, status, note string, platform model.Platform, ipAddress string) {
	s.recordSessionLog(ctx, clientCode, userID, "Login", status, note, platform, ipAddress)
}

func loginValidationError(message, errorCode, captionField string, captchaRequired bool) error {
	return &coreEntity.HttpError{
		Code:    fiber.StatusUnprocessableEntity,
		Message: message,
		Data: &dto.LoginResponse{
			ErrorCode:       &errorCode,
			CaptionField:    &captionField,
			CaptchaRequired: captchaRequired,
		},
	}
}

func failedResponse(errorCode, captionField string, captchaRequired bool) *dto.LoginResponse {
	return &dto.LoginResponse{
		Outcome:         constant.OutcomeFailed,
		ErrorCode:       &errorCode,
		CaptionField:    &captionField,
		CaptchaRequired: captchaRequired,
	}
}

func lockedResponse(level model.LockLevel, until *time.Time, captchaRequired bool) *dto.LoginResponse {
	errorCode := lockErrorCode(level)
	captionField := constant.CaptionFieldGlobal
	return &dto.LoginResponse{
		Outcome:         constant.OutcomeLocked,
		ErrorCode:       &errorCode,
		CaptionField:    &captionField,
		LockLevel:       &level,
		LockUntil:       until,
		CaptchaRequired: captchaRequired,
	}
}

func lockErrorCode(level model.LockLevel) string {
	switch level {
	case constant.LockLevel15m:
		return constant.ErrorCodeLocked15m
	case constant.LockLevel1h:
		return constant.ErrorCodeLocked1h
	case constant.LockLevelRequiresReset:
		return constant.ErrorCodeLockedRequiresReset
	case constant.LockLevelPermanent:
		return constant.ErrorCodeLockedPermanent
	default:
		return constant.ErrorCodeIncorrect
	}
}

func lockLogNote(level model.LockLevel) string {
	switch level {
	case constant.LockLevel15m:
		return constant.LogNoteLocked15m
	case constant.LockLevel1h:
		return constant.LogNoteLocked1h
	case constant.LockLevelRequiresReset:
		return constant.LogNoteLockedRequiresReset
	case constant.LockLevelPermanent:
		return constant.LogNoteAccountLocked
	default:
		return constant.LogNoteIncorrectPassword
	}
}
