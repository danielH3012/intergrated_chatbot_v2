package service

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"github.com/gofiber/fiber/v3"
)

// newService builds a MeService against a stub enterprise-management. The cache
// is deliberately disconnected (nil Valkey): these tests are about what the
// service does with EMS's answers, and a warm cache would hide it.
func newService(t *testing.T, handler http.HandlerFunc) *MeService {
	t.Helper()
	ems := httptest.NewServer(handler)
	t.Cleanup(ems.Close)
	return NewMeService("", nil, client.NewEnterpriseManagementClient(ems.URL, "token", false), cache.NewWith(nil))
}

func writeEnvelope(w http.ResponseWriter, body string) {
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write([]byte(`{"status":200,"message":"ok","data":` + body + `}`))
}

const generalSettingsBody = `{"currencyCode":"IDR","currencySymbol":"Rp","currencyDecimalPlaces":2,
	"timezone":"Asia/Jakarta","dateFormat":"DD/MM/YYYY","timeFormat":"24-hour","sessionIdleTimeout":30}`

const systemLimitsBody = `{"bulkTransactionRowLimit":1000,"selectionLimit":1000,
	"registerAssetBulkLimit":1000,"hierarchyDepthLimit":50,"masterDataCountLimit":10000}`

func TestSettingsMergesBothCalls(t *testing.T) {
	svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-Service-Token") != "token" {
			t.Errorf("missing service token on %s", r.URL.Path)
		}
		switch r.URL.Path {
		case "/internal/general-settings":
			// The tenant is chosen by the header; without it EMS answers for
			// the wrong schema.
			if r.Header.Get("X-Client-ID") != "acme" {
				t.Errorf("client header = %q", r.Header.Get("X-Client-ID"))
			}
			writeEnvelope(w, generalSettingsBody)
		case "/internal/lifecycle-settings/system-limits":
			writeEnvelope(w, systemLimitsBody)
		default:
			t.Errorf("unexpected path %s", r.URL.Path)
		}
	})

	got, err := svc.Settings(context.Background(), "acme")
	if err != nil {
		t.Fatalf("Settings: %v", err)
	}
	// dateFormat passes through verbatim: EMS owns the allowed set, and
	// normalizing here would silently disagree with the value it stores.
	if got.GeneralSettings.DateFormat != "DD/MM/YYYY" {
		t.Errorf("dateFormat = %q, want EMS's value untouched", got.GeneralSettings.DateFormat)
	}
	if got.GeneralSettings.CurrencySymbol != "Rp" || got.GeneralSettings.SessionIdleTimeout != 30 {
		t.Errorf("general settings = %+v", got.GeneralSettings)
	}
	if got.SystemLimits.MasterDataCountLimit != 10000 || got.SystemLimits.HierarchyDepthLimit != 50 {
		t.Errorf("system limits = %+v", got.SystemLimits)
	}
}

func TestSettingsFailsWhenEitherCallFails(t *testing.T) {
	cases := map[string]string{
		"general settings down": "/internal/general-settings",
		"system limits down":    "/internal/lifecycle-settings/system-limits",
	}

	for name, broken := range cases {
		t.Run(name, func(t *testing.T) {
			svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
				if r.URL.Path == broken {
					w.WriteHeader(http.StatusInternalServerError)
					return
				}
				if r.URL.Path == "/internal/general-settings" {
					writeEnvelope(w, generalSettingsBody)
					return
				}
				writeEnvelope(w, systemLimitsBody)
			})

			got, err := svc.Settings(context.Background(), "acme")
			if err == nil {
				t.Fatalf("want an error, got payload %+v", got)
			}
			// A half-filled settings payload would have the FE formatting money
			// with defaults nobody chose, so this must be a hard failure.
			if got != nil {
				t.Errorf("partial payload returned: %+v", got)
			}
			if code := coreEntity.ToHttpError(err).Code; code != fiber.StatusBadGateway {
				t.Errorf("status = %d, want 502", code)
			}
		})
	}
}

const clientBody = `{"_id":2091769471201972224,"companyName":"PT Tag Samurai Indonesia","clientCode":"TSI"}`
const subscriptionsBody = `{"subscriptions":[],"activeProducts":["fixed_asset","admin_console"]}`

func TestEntityStringifiesSnowflakeID(t *testing.T) {
	svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/internal/client":
			writeEnvelope(w, clientBody)
		case "/internal/subscriptions":
			writeEnvelope(w, subscriptionsBody)
		default:
			t.Fatalf("unexpected path %s", r.URL.Path)
		}
	})

	got, err := svc.Entity(context.Background(), "TSI")
	if err != nil {
		t.Fatalf("Entity: %v", err)
	}
	if got.Entity.ID != "2091769471201972224" {
		t.Errorf("_id = %q, want the snowflake as a string", got.Entity.ID)
	}
	if got.Entity.Name != "PT Tag Samurai Indonesia" || got.Entity.Code != "TSI" {
		t.Errorf("entity = %+v", got.Entity)
	}
	if len(got.ActiveProducts) != 2 || got.ActiveProducts[0] != "fixed_asset" || got.ActiveProducts[1] != "admin_console" {
		t.Errorf("activeProducts = %+v", got.ActiveProducts)
	}
}

func TestEntityReturnsActiveProducts(t *testing.T) {
	svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-Service-Token") != "token" {
			t.Errorf("missing service token on %s", r.URL.Path)
		}
		if r.Header.Get("X-Client-ID") != "TSI" {
			t.Errorf("missing or invalid client id header on %s: got %q", r.URL.Path, r.Header.Get("X-Client-ID"))
		}
		switch r.URL.Path {
		case "/internal/client":
			writeEnvelope(w, clientBody)
		case "/internal/subscriptions":
			writeEnvelope(w, `{"subscriptions":[],"activeProducts":["fixed_asset","supply_asset"]}`)
		default:
			t.Fatalf("unexpected path %s", r.URL.Path)
		}
	})

	got, err := svc.Entity(context.Background(), "TSI")
	if err != nil {
		t.Fatalf("Entity: %v", err)
	}
	if len(got.ActiveProducts) != 2 || got.ActiveProducts[0] != "fixed_asset" || got.ActiveProducts[1] != "supply_asset" {
		t.Errorf("activeProducts = %+v, want [fixed_asset supply_asset]", got.ActiveProducts)
	}
}

func TestEntityEmptyActiveProducts(t *testing.T) {
	svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/internal/client":
			writeEnvelope(w, clientBody)
		case "/internal/subscriptions":
			writeEnvelope(w, `{"subscriptions":[],"activeProducts":[]}`)
		default:
			t.Fatalf("unexpected path %s", r.URL.Path)
		}
	})

	got, err := svc.Entity(context.Background(), "TSI")
	if err != nil {
		t.Fatalf("Entity: %v", err)
	}
	if got.ActiveProducts == nil {
		t.Fatal("expected non-nil empty slice for activeProducts")
	}
	if len(got.ActiveProducts) != 0 {
		t.Errorf("expected 0 activeProducts, got %+v", got.ActiveProducts)
	}
}

func TestEntityFailsWhenSubscriptionsFails(t *testing.T) {
	svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/internal/client":
			writeEnvelope(w, clientBody)
		case "/internal/subscriptions":
			w.WriteHeader(http.StatusInternalServerError)
		default:
			t.Fatalf("unexpected path %s", r.URL.Path)
		}
	})

	got, err := svc.Entity(context.Background(), "TSI")
	if err == nil {
		t.Fatalf("want error when subscriptions fails, got %+v", got)
	}
	if code := coreEntity.ToHttpError(err).Code; code != fiber.StatusBadGateway {
		t.Errorf("status = %d, want 502", code)
	}
}

func TestEntityNotFoundWhenClientArchived(t *testing.T) {
	svc := newService(t, func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	})

	_, err := svc.Entity(context.Background(), "gone")
	if err == nil {
		t.Fatal("want an error for a client EMS no longer has")
	}
	// 404, not 502: the session names a client that is archived, which is the
	// FE's cue to log the user out rather than retry.
	if code := coreEntity.ToHttpError(err).Code; code != fiber.StatusNotFound {
		t.Errorf("status = %d, want 404", code)
	}
}
