package service

import (
	"testing"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

var testNow = time.Date(2026, 8, 10, 12, 0, 0, 0, time.UTC)

func TestNextLockState_Progression(t *testing.T) {
	var daily *model.LoginAttemptLock
	var cross *model.UserLockState

	step := func(n int) (level model.LockLevel, until *time.Time) {
		nextDaily, nextCross, level, until := NextLockState(daily, cross, testNow)
		daily, cross = &nextDaily, &nextCross
		if daily.FailedCount != n {
			t.Fatalf("after attempt: failedCount = %d, want %d", daily.FailedCount, n)
		}
		return level, until
	}

	// 1, 2: no lock yet.
	for i := 1; i <= 2; i++ {
		level, until := step(i)
		if level != constant.LockLevelNone || until != nil {
			t.Errorf("attempt %d: level=%s until=%v, want none/nil", i, level, until)
		}
	}

	// 3: crosses into 15m, locked until now+15m.
	level, until := step(3)
	if level != constant.LockLevel15m {
		t.Fatalf("attempt 3: level = %s, want 15m", level)
	}
	if until == nil || !until.Equal(testNow.Add(constant.Lock15mDuration)) {
		t.Errorf("attempt 3: lockUntil = %v, want %v", until, testNow.Add(constant.Lock15mDuration))
	}

	// 4, 5: still in the 15m band.
	for i := 4; i <= 5; i++ {
		level, until := step(i)
		if level != constant.LockLevel15m {
			t.Errorf("attempt %d: level = %s, want 15m", i, level)
		}
		if until == nil {
			t.Errorf("attempt %d: lockUntil is nil, want set", i)
		}
	}

	// 6: crosses into 1h.
	level, until = step(6)
	if level != constant.LockLevel1h {
		t.Fatalf("attempt 6: level = %s, want 1h", level)
	}
	if until == nil || !until.Equal(testNow.Add(constant.Lock1hDuration)) {
		t.Errorf("attempt 6: lockUntil = %v, want %v", until, testNow.Add(constant.Lock1hDuration))
	}
	if cross.Consecutive1hDays != 1 {
		t.Errorf("attempt 6: consecutive1hDays = %d, want 1", cross.Consecutive1hDays)
	}

	// 7, 8: still in the 1h band — no further streak increment.
	for i := 7; i <= 8; i++ {
		level, until := step(i)
		if level != constant.LockLevel1h {
			t.Errorf("attempt %d: level = %s, want 1h", i, level)
		}
		if until == nil {
			t.Errorf("attempt %d: lockUntil is nil, want set", i)
		}
		if cross.Consecutive1hDays != 1 {
			t.Errorf("attempt %d: consecutive1hDays = %d, want still 1 (no double-count)", i, cross.Consecutive1hDays)
		}
	}

	// 9: requires_reset, no lockUntil (cleared only by password reset).
	level, until = step(9)
	if level != constant.LockLevelRequiresReset {
		t.Fatalf("attempt 9: level = %s, want requires_reset", level)
	}
	if until != nil {
		t.Errorf("attempt 9: lockUntil = %v, want nil", until)
	}
	if cross.LockLevel != constant.LockLevelRequiresReset {
		t.Errorf("attempt 9: cross.LockLevel = %s, want requires_reset (must persist across days)", cross.LockLevel)
	}
}

func TestNextLockState_StreakChainReset(t *testing.T) {
	// The chain was last bumped 3 days ago (a gap of more than one day):
	// reaching the 1h stage today must reset the streak to 1, not continue
	// counting from wherever it left off.
	threeDaysAgo := dateOnly(testNow).AddDate(0, 0, -3)
	cross := &model.UserLockState{
		Consecutive1hDays: 5,
		Last1hDate:        &threeDaysAgo,
	}
	daily := &model.LoginAttemptLock{FailedCount: 5} // about to become 6

	nextDaily, nextCross, level, _ := NextLockState(daily, cross, testNow)

	if level != constant.LockLevel1h {
		t.Fatalf("level = %s, want 1h", level)
	}
	if nextCross.Consecutive1hDays != 1 {
		t.Errorf("consecutive1hDays = %d, want 1 (chain reset by the gap)", nextCross.Consecutive1hDays)
	}
	if nextDaily.LockLevel != constant.LockLevel1h {
		t.Errorf("daily.LockLevel = %s, want 1h", nextDaily.LockLevel)
	}
}

func TestNextLockState_StreakLimitJumpsToPermanent(t *testing.T) {
	// The chain already climbed 7 consecutive days (yesterday was the 7th):
	// today's escalation into the 1h stage must jump straight to permanent.
	yesterday := dateOnly(testNow).AddDate(0, 0, -1)
	cross := &model.UserLockState{
		Consecutive1hDays: constant.StreakLimit,
		Last1hDate:        &yesterday,
	}
	daily := &model.LoginAttemptLock{FailedCount: 5} // about to become 6

	nextDaily, nextCross, level, until := NextLockState(daily, cross, testNow)

	if level != constant.LockLevelPermanent {
		t.Fatalf("level = %s, want permanent", level)
	}
	if until != nil {
		t.Errorf("lockUntil = %v, want nil", until)
	}
	if nextDaily.LockLevel != constant.LockLevelPermanent {
		t.Errorf("daily.LockLevel = %s, want permanent", nextDaily.LockLevel)
	}
	if nextCross.LockLevel != constant.LockLevelPermanent {
		t.Errorf("cross.LockLevel = %s, want permanent", nextCross.LockLevel)
	}
}

func TestIsCurrentlyLocked(t *testing.T) {
	fifteenMinAgo := testNow.Add(-15 * time.Minute)
	inFifteenMin := testNow.Add(15 * time.Minute)

	tests := []struct {
		name       string
		daily      *model.LoginAttemptLock
		cross      *model.UserLockState
		wantActive bool
		wantLevel  model.LockLevel
	}{
		{
			name:       "no rows at all",
			wantActive: false,
			wantLevel:  constant.LockLevelNone,
		},
		{
			name: "lock_until in the past is not active",
			daily: &model.LoginAttemptLock{
				AttemptDate: dateOnly(testNow),
				LockLevel:   constant.LockLevel15m,
				LockUntil:   &fifteenMinAgo,
			},
			wantActive: false,
			wantLevel:  constant.LockLevelNone,
		},
		{
			name: "active 15m lock",
			daily: &model.LoginAttemptLock{
				AttemptDate: dateOnly(testNow),
				LockLevel:   constant.LockLevel15m,
				LockUntil:   &inFifteenMin,
			},
			wantActive: true,
			wantLevel:  constant.LockLevel15m,
		},
		{
			name: "daily row from yesterday is not active (day rollover expires timed locks)",
			daily: &model.LoginAttemptLock{
				AttemptDate: dateOnly(testNow).AddDate(0, 0, -1),
				LockLevel:   constant.LockLevel15m,
				LockUntil:   &inFifteenMin, // even with a future timestamp
			},
			wantActive: false,
			wantLevel:  constant.LockLevelNone,
		},
		{
			name:       "requires_reset in cross is active regardless of daily",
			daily:      nil,
			cross:      &model.UserLockState{LockLevel: constant.LockLevelRequiresReset},
			wantActive: true,
			wantLevel:  constant.LockLevelRequiresReset,
		},
		{
			name:       "permanent in cross is active regardless of daily",
			daily:      nil,
			cross:      &model.UserLockState{LockLevel: constant.LockLevelPermanent},
			wantActive: true,
			wantLevel:  constant.LockLevelPermanent,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			level, _, active := IsCurrentlyLocked(tt.daily, tt.cross, testNow)
			if active != tt.wantActive {
				t.Errorf("active = %v, want %v", active, tt.wantActive)
			}
			if level != tt.wantLevel {
				t.Errorf("level = %s, want %s", level, tt.wantLevel)
			}
		})
	}
}
