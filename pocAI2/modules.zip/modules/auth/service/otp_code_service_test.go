package service

import (
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

func TestGenerateOTP(t *testing.T) {
	for i := 0; i < 1000; i++ {
		code, err := generateOTP()
		if err != nil {
			t.Fatalf("generateOTP() err = %v, want nil", err)
		}
		if len(code) != 6 {
			t.Fatalf("generateOTP() = %q, want 6 digits", code)
		}
		if !otpCodeRe.MatchString(code) {
			t.Fatalf("generateOTP() = %q, want exactly 6 digits", code)
		}
	}
}

func TestHashOTP(t *testing.T) {
	svc := &AuthService{otpHashKey: []byte("test-key")}
	other := &AuthService{otpHashKey: []byte("different-key")}

	h1 := svc.hashOTP("123456")
	if h1 != svc.hashOTP("123456") {
		t.Errorf("hashOTP is not stable for the same input: %q vs %q", h1, svc.hashOTP("123456"))
	}
	if h1 == svc.hashOTP("654321") {
		t.Errorf("hashOTP collides across inputs: %q", h1)
	}
	if h1 == other.hashOTP("123456") {
		t.Errorf("hashOTP does not depend on the key: %q", h1)
	}
}

func TestOtpResendCooldown(t *testing.T) {
	for count := 0; count < constant.OtpMaxResend; count++ {
		if got := otpResendCooldown(count); got != constant.OtpResendCooldownSeconds {
			t.Errorf("otpResendCooldown(%d) = %d, want %d", count, got, constant.OtpResendCooldownSeconds)
		}
	}
	if got := otpResendCooldown(constant.OtpMaxResend); got != constant.OtpResendExhaustedCooldownSeconds {
		t.Errorf("otpResendCooldown(%d) = %d, want %d", constant.OtpMaxResend, got, constant.OtpResendExhaustedCooldownSeconds)
	}
}
