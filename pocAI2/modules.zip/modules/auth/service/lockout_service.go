package service

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// IsCurrentlyLocked reports the active lock, if any, without touching
// credentials. Terminal locks (requires_reset / permanent) live in cross and
// win over everything — they are cleared only by a successful password
// reset, never by day rollover or a good login. daily is expected to be
// today's row (or nil), but this still re-checks its date defensively: a
// stale daily row (e.g. from yesterday) must never be read as active, or a
// 15m/1h lock would leak across the day boundary that is supposed to expire
// it.
func IsCurrentlyLocked(daily *model.LoginAttemptLock, cross *model.UserLockState, now time.Time) (level model.LockLevel, until *time.Time, active bool) {
	if cross != nil && isTerminalLevel(cross.LockLevel) {
		return cross.LockLevel, cross.LockUntil, true
	}

	if daily == nil || !sameDate(daily.AttemptDate, now) {
		return constant.LockLevelNone, nil, false
	}
	if daily.LockLevel == constant.LockLevelNone || daily.LockUntil == nil {
		return constant.LockLevelNone, nil, false
	}
	if now.Before(*daily.LockUntil) {
		return daily.LockLevel, daily.LockUntil, true
	}

	return constant.LockLevelNone, nil, false
}

// NextLockState computes the post-failure state. Callers persist what it
// returns (daily via LoginLockRepositor.UpsertToday, cross via
// UpsertLockState) inside the same transaction that recorded the failure.
// This is a pure function — no ctx, no DB — precisely because the lock
// progression table is the one piece of this flow that silently locks real
// users out if it drifts; it needs to be testable without a database.
func NextLockState(daily *model.LoginAttemptLock, cross *model.UserLockState, now time.Time) (nextDaily model.LoginAttemptLock, nextCross model.UserLockState, level model.LockLevel, until *time.Time) {
	if daily != nil {
		nextDaily = *daily
	}
	if cross != nil {
		nextCross = *cross
	}

	nextDaily.FailedCount++
	failedAt := now
	nextDaily.LastFailedAt = &failedAt

	switch {
	case nextDaily.FailedCount >= constant.LockRequiresResetAt:
		nextDaily.LockLevel = constant.LockLevelRequiresReset
		nextDaily.LockUntil = nil
		nextCross.LockLevel = constant.LockLevelRequiresReset
		nextCross.LockUntil = nil

	case nextDaily.FailedCount == constant.LockEscalateAt:
		// Reaching the 1h stage for the first time today. The streak chain
		// needs a date, not just a counter: a gap of more than one day since
		// the last time this stage was reached breaks the chain.
		yesterday := dateOnly(now).AddDate(0, 0, -1)
		if nextCross.Last1hDate == nil || nextCross.Last1hDate.Before(yesterday) {
			nextCross.Consecutive1hDays = 0
		}

		if nextCross.Consecutive1hDays >= constant.StreakLimit {
			// Day 8: the chain already climbed 7 consecutive days: this
			// escalation jumps straight to permanent instead of 1h.
			nextDaily.LockLevel = constant.LockLevelPermanent
			nextDaily.LockUntil = nil
			nextCross.LockLevel = constant.LockLevelPermanent
			nextCross.LockUntil = nil
		} else {
			nextCross.Consecutive1hDays++
			today := dateOnly(now)
			nextCross.Last1hDate = &today
			nextDaily.LockLevel = constant.LockLevel1h
			lockUntil := now.Add(constant.Lock1hDuration)
			nextDaily.LockUntil = &lockUntil
		}

	case nextDaily.FailedCount > constant.LockEscalateAt:
		// 7th/8th attempt of the day: still in the 1h band. Reaching here at
		// all means the previous 1h window already elapsed, so it refreshes.
		nextDaily.LockLevel = constant.LockLevel1h
		lockUntil := now.Add(constant.Lock1hDuration)
		nextDaily.LockUntil = &lockUntil

	case nextDaily.FailedCount >= constant.LockWarnAt:
		// 3rd/4th/5th attempt of the day: the 15m band.
		nextDaily.LockLevel = constant.LockLevel15m
		lockUntil := now.Add(constant.Lock15mDuration)
		nextDaily.LockUntil = &lockUntil

	default:
		nextDaily.LockLevel = constant.LockLevelNone
		nextDaily.LockUntil = nil
	}

	level, until = nextDaily.LockLevel, nextDaily.LockUntil
	if isTerminalLevel(nextCross.LockLevel) {
		level, until = nextCross.LockLevel, nextCross.LockUntil
	}
	return nextDaily, nextCross, level, until
}

func isTerminalLevel(level model.LockLevel) bool {
	return level == constant.LockLevelRequiresReset || level == constant.LockLevelPermanent
}

// dateOnly strips the time-of-day, in UTC, so date comparisons are not
// sensitive to the server's local timezone or to the exact time an attempt
// landed.
func dateOnly(t time.Time) time.Time {
	u := t.UTC()
	return time.Date(u.Year(), u.Month(), u.Day(), 0, 0, 0, 0, time.UTC)
}

func sameDate(a, b time.Time) bool {
	return dateOnly(a).Equal(dateOnly(b))
}
