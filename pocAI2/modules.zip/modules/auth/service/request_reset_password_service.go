package service

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	authWorkflow "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type RequestResetPasswordParam struct {
	Email          string
	RecaptchaToken string
	IPAddress      string
	// Resend distinguishes the resend endpoint: the two share one
	// implementation and differ only in the unknown-email answer (the resend
	// masks it as "sent" so existence stays unprobeable).
	Resend bool
}

// RequestResetPassword backs POST /auth/reset-password/request and
// /auth/reset-password/resend. Step order follows the LLD literally: the
// per-IP budget is enforced before any user lookup, and every branch that
// could leak whether an email is registered answers identically.
//
// The reset page is web-only (same assumption the captcha check makes), so
// every logged entry uses platform "web" and captcha is checked on the
// initial request only.
//
// Failure outcomes are ordinary return values — the "failed" responses are
// HTTP 200. Only a genuine 429 (per-IP budget) or infra (500) failure returns
// a non-nil error.
func (s *AuthService) RequestResetPassword(ctx context.Context, param RequestResetPasswordParam) (*dto.ResetPasswordRequestResponse, error) {
	now := time.Now()

	email := strings.ToLower(strings.TrimSpace(param.Email))
	if email == "" {
		// Not logged: no user was identified.
		return resetPasswordFailedResponse(email, constant.ErrorCodeEmailEmpty, constant.MsgEmailEmpty), nil
	}
	if len(email) > maxEmailLength || !emailFormatRe.MatchString(email) {
		return resetPasswordFailedResponse(email, constant.ErrorCodeEmailFormat, constant.MsgEmailFormat), nil
	}

	// Captcha is checked on the initial request only.
	if !param.Resend && !s.captcha.Verify(ctx, param.RecaptchaToken) {
		return resetPasswordFailedResponse(email, constant.ErrorCodeCaptchaEmpty, constant.MsgCaptchaEmpty), nil
	}

	publicSvc := s.publicSvc()

	// Per-IP budget, checked before any user lookup: a bot hammering reset
	// requests from one IP is cut off even when it varies the email.
	ipAttempt, err := s.resetAttemptRepo.GetByIP(ctx, publicSvc, param.IPAddress)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		slog.ErrorContext(ctx, "request-reset: resetAttemptRepo.GetByIP", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	ipNextCount, ipNextStart := 1, now
	if ipAttempt != nil {
		ipNextCount, ipNextStart = nextAttemptWindow(ipAttempt.AttemptCount, ipAttempt.WindowStart, constant.ResetPasswordIPWindow, now)
	}
	if ipNextCount > constant.ResetPasswordIPBudget {
		// Per-IP is not masked like the per-email budget is: the 429 status
		// itself already announces rate limiting (TC-RATE-04), so hiding it
		// behind status "sent" protects nothing and only breaks TC-API-05.
		return nil, &coreEntity.HttpError{
			Code:    fiber.StatusTooManyRequests,
			Message: constant.MsgTooManyRequests,
			Data:    resetPasswordFailedResponse(email, constant.ErrorCodeRateLimitedIP, constant.MsgTooManyRequests),
		}
	}

	emailAttempt, err := s.resetAttemptRepo.GetByEmail(ctx, publicSvc, email)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		slog.ErrorContext(ctx, "request-reset: resetAttemptRepo.GetByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	emailNextCount, emailNextStart := 1, now
	if emailAttempt != nil {
		emailNextCount, emailNextStart = nextAttemptWindow(emailAttempt.AttemptCount, emailAttempt.WindowStart, constant.ResetPasswordEmailWindow, now)
	}
	cooldownSec := 0
	if emailAttempt != nil {
		cooldownSec = resendAvailableInSec(emailAttempt.LastAttemptAt, now)
	}
	if cooldownSec > 0 || emailNextCount > constant.ResetPasswordEmailBudget {
		if err := s.persistResetAttempts(ctx, publicSvc, email, param.IPAddress, emailAttempt, emailNextCount, emailNextStart, ipAttempt, ipNextCount, ipNextStart, false); err != nil {
			slog.ErrorContext(ctx, "request-reset: persist masked attempt", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		// The true per-email budget exhaustion (not the 60s cooldown) is
		// logged when the subject is identifiable — TC-RATE-03/TC-LOG-03.
		// The response itself stays masked as "sent" either way, so this
		// lookup cannot introduce a timing oracle for the common case: it
		// only runs once the request is already being rejected.
		if emailNextCount > constant.ResetPasswordEmailBudget {
			if cred, err := s.credRepo.GetOneByEmail(ctx, publicSvc, email); err == nil {
				if user, err := s.userRepo.GetOneByEmail(ctx, s.tenantSvc(cred.ClientCode), email); err == nil {
					s.recordSessionLog(ctx, cred.ClientCode, user.ID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNoteTooManyResetAttempts, constant.PlatformWeb, param.IPAddress)
				}
			}
		}
		return resetPasswordSentResponse(email, int(constant.ResetPasswordResendCooldown/time.Second)), nil
	}

	cred, err := s.credRepo.GetOneByEmail(ctx, publicSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			if err := s.persistResetAttempts(ctx, publicSvc, email, param.IPAddress, emailAttempt, emailNextCount, emailNextStart, ipAttempt, ipNextCount, ipNextStart, true); err != nil {
				slog.ErrorContext(ctx, "request-reset: persist unknown-email attempt", "err", err)
				return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
			}
			return resetPasswordUnknownEmailResponse(email, param.Resend), nil
		}
		slog.ErrorContext(ctx, "request-reset: credRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	tenantSvc := s.tenantSvc(cred.ClientCode)
	user, err := s.userRepo.GetOneByEmail(ctx, tenantSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			if err := s.persistResetAttempts(ctx, publicSvc, email, param.IPAddress, emailAttempt, emailNextCount, emailNextStart, ipAttempt, ipNextCount, ipNextStart, true); err != nil {
				slog.ErrorContext(ctx, "request-reset: persist unknown-user attempt", "err", err)
				return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
			}
			return resetPasswordUnknownEmailResponse(email, param.Resend), nil
		}
		slog.ErrorContext(ctx, "request-reset: userRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// A pending-activation account now has a credential row (written at invite
	// time so login can identify it), but reset must still not confirm it
	// exists: it is masked exactly like an unknown address.
	if user.ActivationStatus != constant.ActivationStatusActivated {
		if err := s.persistResetAttempts(ctx, publicSvc, email, param.IPAddress, emailAttempt, emailNextCount, emailNextStart, ipAttempt, ipNextCount, ipNextStart, true); err != nil {
			slog.ErrorContext(ctx, "request-reset: persist pending-activation attempt", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		return resetPasswordUnknownEmailResponse(email, param.Resend), nil
	}

	if !user.IsActive {
		if err := s.persistResetAttempts(ctx, publicSvc, email, param.IPAddress, emailAttempt, emailNextCount, emailNextStart, ipAttempt, ipNextCount, ipNextStart, true); err != nil {
			slog.ErrorContext(ctx, "request-reset: persist inactive-account attempt", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		s.recordSessionLog(ctx, cred.ClientCode, user.ID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNoteInactive, constant.PlatformWeb, param.IPAddress)
		return resetPasswordFailedResponse(email, constant.ErrorCodeInactive, constant.MsgInactive), nil
	}

	rawToken, err := newRawToken()
	if err != nil {
		slog.ErrorContext(ctx, "request-reset: newRawToken", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// A nil attempt row (never seen before) must insert, which the repos read
	// off ID == 0.
	emailAttemptID, ipAttemptID := int64(0), int64(0)
	if emailAttempt != nil {
		emailAttemptID = emailAttempt.ID
	}
	if ipAttempt != nil {
		ipAttemptID = ipAttempt.ID
	}

	tokenID, err := coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (int64, error) {
		publicSvc.SetTransaction(tx)

		// Invalidate-then-insert holds the "one live link per user" invariant
		// (uq_password_reset_tokens_active_user enforces it too).
		if err := s.resetTokenRepo.InvalidateActiveForUser(ctx, publicSvc, user.ID); err != nil {
			return 0, err
		}

		tokenID, err := s.resetTokenRepo.InsertOne(ctx, publicSvc, model.PasswordResetToken{
			UserID:     user.ID,
			Email:      email,
			ClientCode: cred.ClientCode,
			TokenHash:  helper.HashToken(rawToken),
			Status:     constant.TokenStatusActive,
			ExpiresAt:  now.Add(constant.ResetPasswordTokenTTL),
			RequestIP:  param.IPAddress,
		})
		if err != nil {
			return 0, err
		}

		if err := s.resetAttemptRepo.UpsertByEmail(ctx, publicSvc, model.PasswordResetAttemptByEmail{
			ID:            emailAttemptID,
			EmailNorm:     email,
			AttemptCount:  emailNextCount,
			WindowStart:   emailNextStart,
			LastAttemptAt: now,
		}); err != nil {
			return 0, err
		}

		if err := s.resetAttemptRepo.UpsertByIP(ctx, publicSvc, model.PasswordResetAttemptByIP{
			ID:            ipAttemptID,
			RequestIP:     param.IPAddress,
			AttemptCount:  ipNextCount,
			WindowStart:   ipNextStart,
			LastAttemptAt: now,
		}); err != nil {
			return 0, err
		}

		return tokenID, nil
	})
	if err != nil {
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == uniqueViolationCode {
			// uq_password_reset_tokens_active_user tripped: a concurrent
			// double-submit already minted the one allowed active token in a
			// race the 60s cooldown read-then-write can't fully close.
			// Answer the same masked "sent" the cooldown itself would give,
			// not a 500 (TC-REQ-05).
			slog.ErrorContext(ctx, "request-reset: concurrent double-submit", "err", err)
			return resetPasswordSentResponse(email, int(constant.ResetPasswordResendCooldown/time.Second)), nil
		}
		slog.ErrorContext(ctx, "request-reset: transaction", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// Fire the email workflow after the row is committed. Blocking on the
	// future would reintroduce the SMTP stall the workflow exists to avoid; a
	// failed start is logged and the link stays valid (the user can resend).
	if _, err := s.temporalSvc.Client.ExecuteWorkflow(ctx, client.StartWorkflowOptions{
		ID:                    fmt.Sprintf("reset-password-email-%d", tokenID),
		TaskQueue:             s.temporalSvc.TaskQueue,
		WorkflowIDReusePolicy: enums.WORKFLOW_ID_REUSE_POLICY_REJECT_DUPLICATE,
	}, authWorkflow.SendResetPasswordEmailWorkflow, authWorkflow.SendResetPasswordEmailWorkflowParam{
		Email: email,
		Token: rawToken,
	}); err != nil {
		slog.ErrorContext(ctx, "request-reset: dispatch send-reset-password-email workflow", "err", err)
	}

	// Only the initial request is logged (TC-LOG-01); an ordinary resend
	// inside its own success path stays silent (TC-SENT-06) — the masked
	// branches above already cover the resend cases that DO log (rate
	// limit, inactive account).
	if !param.Resend {
		s.recordSessionLog(ctx, cred.ClientCode, user.ID, constant.ActivityResetPassword, constant.LogStatusSuccess, constant.LogNoteResetPasswordRequested, constant.PlatformWeb, param.IPAddress)
	}

	return resetPasswordSentResponse(email, int(constant.ResetPasswordResendCooldown/time.Second)), nil
}

// resetPasswordUnknownEmailResponse keeps the two endpoints' answers apart:
// the request leaks nothing about a registered account either, but names the
// reason; the resend masks it completely as "sent".
func resetPasswordUnknownEmailResponse(email string, resend bool) *dto.ResetPasswordRequestResponse {
	if resend {
		return resetPasswordSentResponse(email, int(constant.ResetPasswordResendCooldown/time.Second))
	}
	return resetPasswordFailedResponse(email, constant.ErrorCodeEmailNotRegistered, constant.MsgEmailNotRegistered)
}

func resetPasswordSentResponse(email string, cooldownSec int) *dto.ResetPasswordRequestResponse {
	return &dto.ResetPasswordRequestResponse{
		Status:               constant.ResetPasswordStatusSent,
		Email:                email,
		ResendAvailableInSec: cooldownSec,
	}
}

func resetPasswordFailedResponse(email, errorCode, message string) *dto.ResetPasswordRequestResponse {
	status := constant.ResetPasswordStatusFailed
	switch errorCode {
	case constant.ErrorCodeEmailNotRegistered:
		status = constant.ResetPasswordStatusNotRegistered
	case constant.ErrorCodeInactive:
		status = constant.ResetPasswordStatusInactive
	case constant.ErrorCodeCaptchaEmpty, constant.ErrorCodeCaptchaFailed:
		status = constant.ResetPasswordStatusCaptchaFailed
	case constant.ErrorCodeRateLimitedIP:
		status = constant.ResetPasswordStatusRateLimited
	}
	return &dto.ResetPasswordRequestResponse{
		Status:    status,
		Email:     email,
		ErrorCode: &errorCode,
		Message:   &message,
	}
}

// persistResetAttempts records the rate-limit counters that apply when a reset
// request does not create a token, such as an unknown email or a masked limit
// response. The IP counter is always written; includeEmail controls whether
// the normalized email counter is written for a known email key.
func (s *AuthService) persistResetAttempts(ctx context.Context, publicSvc coreService.PostgreSQLServicer, email, requestIP string, emailAttempt *model.PasswordResetAttemptByEmail, emailNextCount int, emailNextStart time.Time, ipAttempt *model.PasswordResetAttemptByIP, ipNextCount int, ipNextStart time.Time, includeEmail bool) error {
	emailAttemptID, ipAttemptID := int64(0), int64(0)
	if emailAttempt != nil {
		emailAttemptID = emailAttempt.ID
	}
	if ipAttempt != nil {
		ipAttemptID = ipAttempt.ID
	}
	_, err := coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)
		if includeEmail {
			// Unknown emails still consume the per-email budget to prevent
			// attackers from bypassing abuse controls by rotating addresses.
			if err := s.resetAttemptRepo.UpsertByEmail(ctx, publicSvc, model.PasswordResetAttemptByEmail{
				ID:            emailAttemptID,
				EmailNorm:     email,
				AttemptCount:  emailNextCount,
				WindowStart:   emailNextStart,
				LastAttemptAt: time.Now(),
			}); err != nil {
				return struct{}{}, err
			}
		}
		// Persist the IP budget in the same transaction as the email budget.
		if err := s.resetAttemptRepo.UpsertByIP(ctx, publicSvc, model.PasswordResetAttemptByIP{
			ID:            ipAttemptID,
			RequestIP:     requestIP,
			AttemptCount:  ipNextCount,
			WindowStart:   ipNextStart,
			LastAttemptAt: time.Now(),
		}); err != nil {
			return struct{}{}, err
		}
		return struct{}{}, nil
	})
	return err
}
