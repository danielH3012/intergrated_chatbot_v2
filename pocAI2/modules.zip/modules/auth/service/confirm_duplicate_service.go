package service

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// ConfirmDuplicate resolves a duplicate-detected login by consuming the
// pre-auth token, force-terminating the old session, and creating a new one
// in a single transaction.
func (s *AuthService) ConfirmDuplicate(ctx context.Context, param dto.ConfirmDuplicateRequest, ipAddress string) (*dto.ConfirmDuplicateResponse, error) {
	publicSvc := s.publicSvc()
	preAuthHash := helper.HashToken(param.PreAuthToken)

	preAuth, err := s.preAuthRepo.GetActiveByTokenHash(ctx, publicSvc, preAuthHash)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, coreEntity.Unauthorized("Invalid or expired pre-auth token")
		}
		slog.ErrorContext(ctx, "confirm-duplicate: preAuthRepo.GetActiveByTokenHash", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if preAuth.Status != constant.PreAuthStatusActive {
		return nil, coreEntity.Unauthorized("Pre-auth token already consumed")
	}
	if time.Now().After(preAuth.ExpiresAt) {
		return nil, coreEntity.Unauthorized("Pre-auth token expired")
	}

	// Re-read the old session to check its current status.
	oldSession, err := s.sessionRepo.GetByID(ctx, publicSvc, *preAuth.ExistingSessionID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, coreEntity.Unauthorized("Existing session not found")
		}
		slog.ErrorContext(ctx, "confirm-duplicate: sessionRepo.GetByID", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if oldSession.Status != constant.SessionStatusActive {
		// The old session already expired between dialog and confirm.
		// Consume the pre-auth token but produce no SSE and no log —
		// there is nobody to log out (§1B).
		_ = s.preAuthRepo.Consume(ctx, publicSvc, preAuth.ID)
		return &dto.ConfirmDuplicateResponse{Outcome: constant.OutcomeSessionAlreadyExpired}, nil
	}

	// Single transaction: consume pre-auth, force-terminate old, create new.
	var newRawToken string
	_, txErr := coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)

		if err := s.preAuthRepo.Consume(ctx, publicSvc, preAuth.ID); err != nil {
			return struct{}{}, err
		}

		if _, err := s.terminateSession(ctx, publicSvc, oldSession, constant.SessionStatusForceLoggedOut, constant.TerminatedReasonDuplicateLogin, "Session", analyticsModel.SessionLogNoteLoggedOut); err != nil {
			return struct{}{}, err
		}

		var sessErr error
		_, newRawToken, _, sessErr = s.createPlatformSession(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform, preAuth.DeviceInfo, preAuth.IPAddress)
		if sessErr != nil {
			return struct{}{}, sessErr
		}

		return struct{}{}, nil
	})
	if txErr != nil {
		slog.ErrorContext(ctx, "confirm-duplicate: transaction", "err", txErr)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// Post-commit: log and SSE. Log the old session's termination.
	s.recordSessionLog(ctx, oldSession.ClientCode, oldSession.UserID, "Session", constant.LogStatusFailed, string(analyticsModel.SessionLogNoteLoggedOut), oldSession.Platform, oldSession.IPAddress)
	s.publishSessionEvent(ctx, oldSession.ClientCode, constant.SSEEventSessionLoggedOut, constant.SSEScopeSession, oldSession.ID, oldSession.UserID)

	return &dto.ConfirmDuplicateResponse{
		Outcome:   constant.OutcomeConfirmed,
		SessionID: &newRawToken,
	}, nil
}
