package service

import (
	"context"
	"errors"
	"log/slog"
	"testing"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/repository"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type activationTokenLookupStub struct {
	err error
}

func (s *activationTokenLookupStub) GetOneByHash(context.Context, coreService.PostgreSQLServicer, string) (*model.ActivationToken, error) {
	return nil, s.err
}

func (*activationTokenLookupStub) GetOneByHashForUpdate(context.Context, coreService.PostgreSQLServicer, string) (*model.ActivationToken, error) {
	panic("not called")
}

func (*activationTokenLookupStub) Consume(context.Context, coreService.PostgreSQLServicer, int64) error {
	panic("not called")
}

var _ repository.ActivationTokenRepositor = (*activationTokenLookupStub)(nil)

type recordingSlogHandler struct {
	records []slog.Record
}

func (h *recordingSlogHandler) Enabled(context.Context, slog.Level) bool {
	return true
}

func (h *recordingSlogHandler) Handle(_ context.Context, record slog.Record) error {
	h.records = append(h.records, record)
	return nil
}

func (h *recordingSlogHandler) WithAttrs([]slog.Attr) slog.Handler {
	return h
}

func (h *recordingSlogHandler) WithGroup(string) slog.Handler {
	return h
}

func TestValidateActivationTokenLogging(t *testing.T) {
	t.Run("expected invalid link is not logged as an error", func(t *testing.T) {
		handler := &recordingSlogHandler{}
		previous := slog.Default()
		slog.SetDefault(slog.New(handler))
		t.Cleanup(func() { slog.SetDefault(previous) })

		svc := &AuthService{tokenRepo: &activationTokenLookupStub{err: pgx.ErrNoRows}}
		svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
			return &coreService.FakePostgreSQLService{}
		})

		_, err := svc.ValidateActivationToken(context.Background(), "unknown")
		if err == nil {
			t.Fatal("ValidateActivationToken() error = nil, want 404")
		}
		if len(handler.records) != 0 {
			t.Fatalf("logged %d record(s) for an expected invalid link, want none", len(handler.records))
		}
	})

	t.Run("unexpected lookup failure remains an error log", func(t *testing.T) {
		handler := &recordingSlogHandler{}
		previous := slog.Default()
		slog.SetDefault(slog.New(handler))
		t.Cleanup(func() { slog.SetDefault(previous) })

		svc := &AuthService{tokenRepo: &activationTokenLookupStub{err: errors.New("database unavailable")}}
		svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
			return &coreService.FakePostgreSQLService{}
		})

		_, err := svc.ValidateActivationToken(context.Background(), "unknown")
		if err == nil {
			t.Fatal("ValidateActivationToken() error = nil, want 500")
		}
		if len(handler.records) != 1 || handler.records[0].Level != slog.LevelError {
			t.Fatalf("logged records = %v, want one Error record", handler.records)
		}
	})
}
