package service

import (
	"testing"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

func TestNextAttemptWindow(t *testing.T) {
	now := time.Date(2026, 8, 10, 12, 0, 0, 0, time.UTC)

	tests := []struct {
		name        string
		count       int
		windowStart time.Time
		window      time.Duration
		wantCount   int
		wantStart   time.Time
	}{
		{
			name:        "no row yet starts at 1",
			count:       0,
			windowStart: now.Add(-10 * time.Minute),
			window:      constant.ResetPasswordEmailWindow,
			wantCount:   1,
			wantStart:   now.Add(-10 * time.Minute),
		},
		{
			name:        "mid-window increments in place",
			count:       3,
			windowStart: now.Add(-10 * time.Minute),
			window:      constant.ResetPasswordEmailWindow,
			wantCount:   4,
			wantStart:   now.Add(-10 * time.Minute),
		},
		{
			name:        "window rollover restarts at 1 with a fresh start",
			count:       5,
			windowStart: now.Add(-constant.ResetPasswordEmailWindow),
			window:      constant.ResetPasswordEmailWindow,
			wantCount:   1,
			wantStart:   now,
		},
		{
			name:        "exactly at the boundary counts as rolled over",
			count:       20,
			windowStart: now.Add(-constant.ResetPasswordIPWindow),
			window:      constant.ResetPasswordIPWindow,
			wantCount:   1,
			wantStart:   now,
		},
		{
			name:        "at budget still increments so the caller sees the cap",
			count:       constant.ResetPasswordEmailBudget,
			windowStart: now.Add(-10 * time.Minute),
			window:      constant.ResetPasswordEmailWindow,
			wantCount:   constant.ResetPasswordEmailBudget + 1,
			wantStart:   now.Add(-10 * time.Minute),
		},
		{
			name:        "long past the window restarts at 1",
			count:       9,
			windowStart: now.Add(-2 * constant.ResetPasswordIPWindow),
			window:      constant.ResetPasswordIPWindow,
			wantCount:   1,
			wantStart:   now,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			count, start := nextAttemptWindow(tt.count, tt.windowStart, tt.window, now)
			if count != tt.wantCount {
				t.Errorf("nextAttemptWindow() count = %d, want %d", count, tt.wantCount)
			}
			if !start.Equal(tt.wantStart) {
				t.Errorf("nextAttemptWindow() start = %v, want %v", start, tt.wantStart)
			}
		})
	}
}

func TestResendAvailableInSec(t *testing.T) {
	now := time.Date(2026, 8, 10, 12, 0, 0, 0, time.UTC)

	tests := []struct {
		name          string
		lastAttemptAt time.Time
		want          int
	}{
		{
			name:          "just attempted: full cooldown advertised",
			lastAttemptAt: now,
			want:          60,
		},
		{
			name:          "30 seconds ago: 30 seconds left",
			lastAttemptAt: now.Add(-30 * time.Second),
			want:          30,
		},
		{
			name:          "61 seconds ago: cooldown over",
			lastAttemptAt: now.Add(-61 * time.Second),
			want:          0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := resendAvailableInSec(tt.lastAttemptAt, now); got != tt.want {
				t.Errorf("resendAvailableInSec() = %d, want %d", got, tt.want)
			}
		})
	}
}
