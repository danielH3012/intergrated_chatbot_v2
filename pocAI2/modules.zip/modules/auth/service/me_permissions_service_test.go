package service

import (
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

// These tests cover the mapping that decides what a person may do. It is the
// part of /me that cannot be checked by looking at it: a flag set from the
// wrong row reads exactly like a correct one.

func status(product model.Product, active bool) model.UserModuleStatus {
	return model.UserModuleStatus{ModuleKey: product, IsActive: active}
}

func level(product model.Product, l model.AccessLevel) model.UserAccessLevel {
	return model.UserAccessLevel{Product: product, AccessLevel: l}
}

func TestBuildModuleAccess(t *testing.T) {
	cases := []struct {
		name   string
		rows   dto.UserPermissionRows
		module string
		want   struct{ total, readOnly, access bool }
	}{
		{
			name:   "no module_status row means no access",
			rows:   dto.UserPermissionRows{},
			module: "fixedAsset",
		},
		{
			name: "inactive row means no access",
			rows: dto.UserPermissionRows{
				ModuleStatus: []model.UserModuleStatus{status(model.ProductFixedAsset, false)},
			},
			module: "fixedAsset",
		},
		{
			name: "active row grants access with no level flags",
			rows: dto.UserPermissionRows{
				ModuleStatus: []model.UserModuleStatus{status(model.ProductFixedAsset, true)},
			},
			module: "fixedAsset",
			want:   struct{ total, readOnly, access bool }{access: true},
		},
		{
			name: "total control",
			rows: dto.UserPermissionRows{
				ModuleStatus: []model.UserModuleStatus{status(model.ProductGlobalSettings, true)},
				AccessLevels: []model.UserAccessLevel{level(model.ProductGlobalSettings, model.AccessLevelTotalControl)},
			},
			module: "globalSettings",
			want:   struct{ total, readOnly, access bool }{total: true, access: true},
		},
		{
			name: "read only",
			rows: dto.UserPermissionRows{
				ModuleStatus: []model.UserModuleStatus{status(model.ProductAdminConsole, true)},
				AccessLevels: []model.UserAccessLevel{level(model.ProductAdminConsole, model.AccessLevelReadOnly)},
			},
			module: "adminConsole",
			want:   struct{ total, readOnly, access bool }{readOnly: true, access: true},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := buildModuleAccess(&tc.rows)
			if len(got) != 3 {
				t.Fatalf("moduleAccess has %d entries, want all 3 modules present", len(got))
			}
			entry := got[tc.module]
			if entry.HasAccess != tc.want.access {
				t.Errorf("hasAccess = %v, want %v", entry.HasAccess, tc.want.access)
			}
			if entry.IsTotalControl != tc.want.total {
				t.Errorf("isTotalControl = %v, want %v", entry.IsTotalControl, tc.want.total)
			}
			if entry.IsReadOnly != tc.want.readOnly {
				t.Errorf("isReadOnly = %v, want %v", entry.IsReadOnly, tc.want.readOnly)
			}
		})
	}
}

func TestMapSystemRoleRenamesUpdateToEdit(t *testing.T) {
	got := mapSystemRole(model.UserSystemRole{
		Product:          model.ProductGlobalSettings,
		Key:              model.SystemRoleKeyManageUserAndRole,
		PermissionView:   true,
		PermissionUpdate: true,
	})

	if got.Key != "manage_user_and_role" || got.Product != "global_settings" {
		t.Fatalf("role identity = %q/%q", got.Key, got.Product)
	}
	if !got.Permission.Edit {
		t.Error("permission_update did not map to edit")
	}
	if !got.Permission.View || got.Permission.Create || got.Permission.Delete {
		t.Errorf("other verbs leaked: %+v", got.Permission)
	}
}

func TestBuildMePermissionsProfile(t *testing.T) {
	position := "IT Manager"
	rows := dto.UserPermissionRows{
		Profile: dto.UserProfileRow{
			ID:        2091769471201972224,
			FirstName: "Jane",
			LastName:  "Doe",
			Email:     "jane.doe@tagsamurai.com",
			Position:  &position,
		},
	}

	got := buildMePermissions(&rows, nil)

	// A snowflake id must survive as a string: as a JSON number the browser
	// would round its low digits away.
	if got.ID != "2091769471201972224" {
		t.Errorf("_id = %q, want the id as a string", got.ID)
	}
	if got.FullName != "Jane Doe" {
		t.Errorf("fullName = %q", got.FullName)
	}
	if got.Division != nil {
		t.Errorf("division = %v, want nil when unjoined", *got.Division)
	}
	if got.SystemRoles == nil {
		t.Error("systemRoles is nil; the contract requires an array")
	}
}

func TestBuildSnapshotDropsGrantsOnInactiveModules(t *testing.T) {
	rows := dto.UserPermissionRows{
		Profile: dto.UserProfileRow{ID: 7, FirstName: "Jane", LastName: "Doe"},
		ModuleStatus: []model.UserModuleStatus{
			status(model.ProductGlobalSettings, true),
			status(model.ProductFixedAsset, false),
		},
		AccessLevels: []model.UserAccessLevel{
			level(model.ProductGlobalSettings, model.AccessLevelTotalControl),
			level(model.ProductFixedAsset, model.AccessLevelTotalControl),
		},
		SystemRoles: []model.UserSystemRole{
			{Product: model.ProductGlobalSettings, ScopeLevel: model.ScopeLevelGlobal, Key: model.SystemRoleKeyManageUserAndRole, PermissionView: true},
			{Product: model.ProductFixedAsset, ScopeLevel: model.ScopeLevelGlobal, Key: model.SystemRoleKeyManageHardware, PermissionView: true},
		},
	}

	snapshot := BuildSnapshot(&rows, "acme")

	if !snapshot.IsTotalControl(enum.ModuleAccessGlobalSettings) {
		t.Error("global settings total control was dropped")
	}
	// The user holds a total-control row for fixed asset, but the module is
	// switched off: switching a module off has to actually take the access away.
	if snapshot.IsTotalControl(enum.ModuleAccessFixedAsset) {
		t.Error("fixed asset is inactive but total control survived")
	}
	if _, ok := snapshot.FixedAssetSystemRole.GlobalRole[enum.SystemRoleKeyManageHardware]; ok {
		t.Error("system role on an inactive module survived")
	}
	if _, ok := snapshot.GlobalSettingsSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole]; !ok {
		t.Error("system role on an active module was dropped")
	}
	if snapshot.ClientID != "acme" || snapshot.FullName != "Jane Doe" {
		t.Errorf("identity = %q/%q", snapshot.ClientID, snapshot.FullName)
	}
}

func TestBuildSnapshotAccumulatesFixedAssetGroupRoles(t *testing.T) {
	groupA, groupB := int64(11), int64(22)
	rows := dto.UserPermissionRows{
		ModuleStatus: []model.UserModuleStatus{status(model.ProductFixedAsset, true)},
		SystemRoles: []model.UserSystemRole{
			{Product: model.ProductFixedAsset, ScopeLevel: model.ScopeLevelGroup, Key: model.SystemRoleKeyManageTAG, PermissionView: true, FixedAssetGroupID: &groupA},
			{Product: model.ProductFixedAsset, ScopeLevel: model.ScopeLevelGroup, Key: model.SystemRoleKeyManageTAG, PermissionView: true, PermissionUpdate: true, FixedAssetGroupID: &groupB},
		},
	}

	snapshot := BuildSnapshot(&rows, "acme")

	perms := snapshot.FixedAssetSystemRole.GroupRoles[enum.SystemRoleKeyManageTAG]
	if len(perms.View) != 2 {
		t.Errorf("view groups = %v, want both rows accumulated", perms.View)
	}
	if len(perms.Edit) != 1 || perms.Edit[0] != "22" {
		t.Errorf("edit groups = %v, want only the row that grants it", perms.Edit)
	}
	if !snapshot.HasGroupPermissionFixedAsset(enum.SystemRoleKeyManageTAG, groupB, tsMiddleware.PermEdit) {
		t.Error("edit in group 22 was not granted")
	}
	if snapshot.HasGroupPermissionFixedAsset(enum.SystemRoleKeyManageTAG, groupA, tsMiddleware.PermEdit) {
		t.Error("edit leaked into group 11, which only grants view")
	}
}
