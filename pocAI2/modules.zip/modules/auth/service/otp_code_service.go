package service

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// generateOTP returns 6 digits drawn from crypto/rand. The modulo bias
// (2^32 % 10^6) is negligible for a short-lived login code.
func generateOTP() (string, error) {
	var buf [4]byte
	if _, err := rand.Read(buf[:]); err != nil {
		return "", err
	}
	n := binary.BigEndian.Uint32(buf[:]) % 1_000_000
	return fmt.Sprintf("%06d", n), nil
}

// hashOTP is HMAC-SHA256 hex under s.otpHashKey, not helper.HashToken's bare
// SHA-256 — deliberately keyed. The 10^6 code space makes
// an unkeyed digest exhaustible offline by anyone with a DB read (10^6 hashes
// is seconds on a laptop); the key lives in env, not the DB, so the
// WHERE code_hash = ? lookup is exactly as strong as the key. It cannot be
// salted: the code is looked up by its digest.
func (s *AuthService) hashOTP(code string) string {
	mac := hmac.New(sha256.New, s.otpHashKey)
	mac.Write([]byte(code))
	return hex.EncodeToString(mac.Sum(nil))
}

// otpResendCooldown picks the cooldown shown to the user: the standard 60s
// below the resend cap, the exhausted 600s once the chain's resend_count
// reaches it.
func otpResendCooldown(resendCount int) int {
	if resendCount >= constant.OtpMaxResend {
		return constant.OtpResendExhaustedCooldownSeconds
	}
	return constant.OtpResendCooldownSeconds
}
