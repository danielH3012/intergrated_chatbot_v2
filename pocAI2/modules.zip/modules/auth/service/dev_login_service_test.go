package service

import (
	"context"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// The gates DevLogin exists to skip. Each case is set up so that Login refuses
// and DevLogin gets a session — the assertion on Login is what keeps the case
// honest if the fixture defaults ever drift.
func TestDevLogin_SkipsGates(t *testing.T) {
	cases := []struct {
		name        string
		arrange     func(f *loginFixture)
		wantOutcome string // what plain Login does with the same fixture
	}{
		{
			name: "stale consent",
			arrange: func(f *loginFixture) {
				f.consent.row = &model.UserPrivacyConsent{AcceptedVersion: new("1.0")}
			},
			wantOutcome: constant.OutcomeAgreementRequired,
		},
		{
			name:        "never logged in",
			arrange:     func(f *loginFixture) { f.user.user.FirstLoginAt = nil },
			wantOutcome: constant.OutcomeAgreementRequired,
		},
		{
			name:        "captcha rejected",
			arrange:     func(f *loginFixture) { f.captcha.ok = false },
			wantOutcome: constant.OutcomeFailed,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newLoginFixture(t)
			tc.arrange(f)
			if resp, err := f.svc.Login(context.Background(), webLogin()); err != nil {
				t.Fatalf("Login() err = %v", err)
			} else if resp.Outcome != tc.wantOutcome {
				t.Fatalf("Login outcome = %q, want %q — fixture no longer trips this gate", resp.Outcome, tc.wantOutcome)
			}

			f = newLoginFixture(t)
			tc.arrange(f)
			resp, err := f.svc.DevLogin(context.Background(), webLogin())
			if err != nil {
				t.Fatalf("DevLogin() err = %v, want nil", err)
			}
			if resp.Outcome != constant.OutcomeSuccess {
				t.Fatalf("DevLogin outcome = %q, want %q", resp.Outcome, constant.OutcomeSuccess)
			}
			if resp.SessionID == nil || *resp.SessionID == "" {
				t.Fatal("DevLogin success must return the raw session token")
			}
			if len(f.sessions.inserted) != 1 {
				t.Fatalf("sessions inserted = %d, want 1", len(f.sessions.inserted))
			}
			if resp.CaptchaRequired {
				t.Error("DevLogin must never report captchaRequired")
			}
		})
	}
}

// Skipping the gates is not skipping authentication: credentials, account
// state, and the lockout counter all still apply.
func TestDevLogin_StillEnforcesCredentials(t *testing.T) {
	t.Run("wrong password", func(t *testing.T) {
		f := newLoginFixture(t)
		param := webLogin()
		param.Password = "wrong"

		resp, err := f.svc.DevLogin(context.Background(), param)
		if err != nil {
			t.Fatalf("DevLogin() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeFailed || *resp.ErrorCode != constant.ErrorCodeIncorrect {
			t.Fatalf("got %q/%v, want failed/INCORRECT", resp.Outcome, resp.ErrorCode)
		}
		if len(f.sessions.inserted) != 0 {
			t.Error("a bad password must not create a session")
		}
		if len(f.lock.upserted) != 1 {
			t.Errorf("UpsertToday calls = %d, want 1 — dev login still escalates the lockout ladder", len(f.lock.upserted))
		}
	})

	t.Run("inactive account", func(t *testing.T) {
		f := newLoginFixture(t)
		f.user.user.IsActive = false

		resp, err := f.svc.DevLogin(context.Background(), webLogin())
		if err != nil {
			t.Fatalf("DevLogin() err = %v", err)
		}
		if resp.Outcome != constant.OutcomeFailed || *resp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("got %q/%v, want failed/INACTIVE", resp.Outcome, resp.ErrorCode)
		}
	})
}
