package service

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
)

// DevLogin backs POST /dev/auth/login. It runs the same credential validation
// and password check as Login but skips captcha, agreement, and MFA gates — a
// pure-login endpoint for local development and automated test suites.
func (s *AuthService) DevLogin(ctx context.Context, param LoginParam) (*dto.LoginResponse, error) {
	r, failure, err := s.resolveLogin(ctx, param, true)
	if err != nil {
		return nil, err
	}
	if failure != nil {
		return failure, nil
	}

	slog.InfoContext(ctx, "dev login: skipping agreement and MFA gates", "email", param.Email, "clientCode", r.clientCode)

	return s.finishLogin(ctx, r, param)
}
