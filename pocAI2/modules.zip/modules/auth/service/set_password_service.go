package service

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"log/slog"
	"strings"
	"time"
	"unicode"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

const (
	passwordMinLength = 8
	// passwordMaxLength is capped at bcrypt's 72-byte input limit — anything
	// longer must be rejected here (422) rather than reaching
	// bcrypt.GenerateFromPassword and 500ing.
	passwordMaxLength = 72
)

// uniqueViolationCode is Postgres' SQLSTATE for a unique index conflict.
var uniqueViolationCode = "23505"

type SetPasswordParam struct {
	Token           string
	Password        string
	ConfirmPassword string
}

// SetPassword backs POST /auth/activation/:token/set-password. It atomically
// re-validates the token, persists the credential, consumes the token, and
// activates the user. A credential that already carries a password hash (or a
// unique violation on user_credentials.email) maps to 409, same as a consumed
// token.
func (s *AuthService) SetPassword(ctx context.Context, param SetPasswordParam) (*dto.SetPasswordResponse, error) {
	if failedRules := validatePasswordPolicy(param.Password, param.ConfirmPassword); len(failedRules) > 0 {
		slog.ErrorContext(ctx, "activation.SetPassword: password policy validation failed", "failedRules", failedRules)
		return nil, &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: "Password does not meet the required policy",
			Data:    map[string]any{"failedRules": failedRules},
		}
	}

	publicSvc := s.publicSvc()
	tokenHash := helper.HashToken(param.Token)

	token, user, err := s.validateUserActivationToken(ctx, publicSvc, tokenHash)
	if err != nil {
		if !isActivationValidationError(err) {
			slog.ErrorContext(ctx, "activation.SetPassword: validateUserActivationToken", "err", err)
		}
		return nil, setPasswordLookupErr(err)
	}

	tenantSvc := s.tenantSvc(token.ClientCode)

	passwordHash, err := s.password.HashPassword(param.Password)
	if err != nil {
		slog.ErrorContext(ctx, "activation.SetPassword: password.HashPassword", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	_, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)
		tenantSvc.SetTransaction(tx)

		// Pessimistic re-validation: the same checks as above, but read
		// inside the transaction so a concurrent submit on the same token
		// cannot both pass the earlier, unlocked read.
		reToken, err := s.tokenRepo.GetOneByHashForUpdate(ctx, publicSvc, tokenHash)
		if err != nil {
			return struct{}{}, err
		}
		if err := validateActivationTokenState(reToken, time.Now()); err != nil {
			return struct{}{}, err
		}

		// The invite already wrote a password-less credential row (it is the
		// global email -> client_code index login starts from), so the normal
		// path here is filling in its hash. Insert only covers accounts
		// predating that; a row that already has a hash is an activated
		// account and maps to 409, same as a consumed token.
		switch existing, err := s.credRepo.GetOneByEmail(ctx, publicSvc, user.Email); {
		case err != nil && !errors.Is(err, pgx.ErrNoRows):
			return struct{}{}, err
		case err != nil:
			if err := s.credRepo.InsertOne(ctx, publicSvc, model.UserCredential{
				Email:        user.Email,
				ClientCode:   token.ClientCode,
				PasswordHash: ptr(passwordHash),
			}); err != nil {
				return struct{}{}, err
			}
		case existing.PasswordHash != nil:
			return struct{}{}, errActivationUsed
		default:
			if err := s.credRepo.UpdatePasswordHash(ctx, publicSvc, existing.ID, passwordHash); err != nil {
				return struct{}{}, err
			}
		}

		// Update activation_tokens status to Consumed
		if err := s.tokenRepo.Consume(ctx, publicSvc, reToken.ID); err != nil {
			return struct{}{}, err
		}

		// Update users.activation_status
		if err := s.userRepo.UpdateActivationStatus(ctx, tenantSvc, token.UserID, constant.ActivationStatusActivated); err != nil {
			return struct{}{}, err
		}

		return struct{}{}, nil
	})
	if err != nil {
		if isActivationValidationError(err) {
			return nil, setPasswordTxErr(err)
		}

		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == uniqueViolationCode {
			slog.ErrorContext(ctx, "activation.SetPassword: credential unique violation", "err", err)
			return nil, coreEntity.Conflict(constant.MsgActivationUsed)
		}

		slog.ErrorContext(ctx, "activation.SetPassword: transaction", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	return &dto.SetPasswordResponse{Success: true, RedirectHint: nil}, nil
}

// validatePasswordPolicy returns the failed rule labels verbatim from the
// openapi spec, or nil if the password satisfies all of them. Spaces are
// rejected, never trimmed — a password is never trimmed anywhere in this
// flow.
func validatePasswordPolicy(password, confirm string) []string {
	var rules []string
	runes := []rune(password)

	if len(runes) < passwordMinLength {
		rules = append(rules, "Minimum 8 characters")
	}
	if len(runes) > passwordMaxLength {
		rules = append(rules, "Maximum 72 characters")
	}
	if !coreHelper.Any(runes, func(r rune, _ int) bool { return unicode.IsUpper(r) }) {
		rules = append(rules, "One uppercase (A-Z)")
	}
	if !coreHelper.Any(runes, func(r rune, _ int) bool { return unicode.IsLower(r) }) {
		rules = append(rules, "One lowercase (a-z)")
	}
	if !coreHelper.Any(runes, func(r rune, _ int) bool { return unicode.IsDigit(r) }) {
		rules = append(rules, "One number (0-9)")
	}
	if !coreHelper.Any(runes, func(r rune, _ int) bool { return isSpecialChar(r) }) {
		rules = append(rules, "One special character")
	}
	if strings.ContainsRune(password, ' ') {
		rules = append(rules, "Password cannot contain spaces")
	}

	if len(rules) == 0 && password != confirm {
		rules = append(rules, "Passwords do not match")
	}

	return rules
}

func isSpecialChar(r rune) bool {
	return !unicode.IsLetter(r) && !unicode.IsDigit(r) && !unicode.IsSpace(r)
}

// newRawToken is shared by activation-adjacent flows that mint a random,
// client-held secret whose SHA-256 is what gets stored (see helper.HashToken).
func newRawToken() (string, error) {
	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	return hex.EncodeToString(raw), nil
}
