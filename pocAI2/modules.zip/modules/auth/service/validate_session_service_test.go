package service

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// stubSessionRepo records what ValidateSession asked for and returns what the
// test told it to. Only the methods ValidateSession calls are meaningful.
type stubSessionRepo struct {
	session   *model.Session
	getErr    error
	touchErr  error
	gotHash   string
	touchedID int64
}

func (s *stubSessionRepo) GetActiveByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error) {
	s.gotHash = tokenHash
	return s.session, s.getErr
}

func (s *stubSessionRepo) GetByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubSessionRepo) Touch(_ context.Context, _ coreService.PostgreSQLServicer, id int64, _ time.Time, _ time.Duration) error {
	s.touchedID = id
	return s.touchErr
}

func (s *stubSessionRepo) GetActiveForUpdate(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) (*model.Session, error) {
	panic("not called by ValidateSession")
}

func (s *stubSessionRepo) GetByID(context.Context, coreService.PostgreSQLServicer, int64) (*model.Session, error) {
	panic("not called by ValidateSession")
}

func (s *stubSessionRepo) Terminate(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called by ValidateSession")
}

func (s *stubSessionRepo) ListExpiredActive(context.Context, coreService.PostgreSQLServicer, time.Time, int) ([]model.Session, error) {
	panic("not called by ValidateSession")
}

func (s *stubSessionRepo) TerminateAllActiveForUser(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called by ValidateSession")
}

func (s *stubSessionRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.Session) error {
	panic("not called by ValidateSession")
}

func TestValidateSession(t *testing.T) {
	live := &model.Session{ID: 42, UserID: 7, ClientCode: "acme"}
	// Stub enterprise-management so the tests never dial a real host.
	settingsAPI := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Write([]byte(`{"data":{"sessionIdleTimeout":30}}`))
	}))
	defer settingsAPI.Close()
	fallbackClient := client.NewEnterpriseManagementClient(settingsAPI.URL, "", false)

	t.Run("live session returns identity and slides the window", func(t *testing.T) {
		repo := &stubSessionRepo{session: live}
		svc := &AuthService{sessionRepo: repo, generalSettingsClient: fallbackClient}

		resp, err := svc.validateSession(context.Background(), nil, "raw-token")
		if err != nil {
			t.Fatalf("validateSession() err = %v, want nil", err)
		}
		if resp.UserID != 7 || resp.ClientCode != "acme" {
			t.Errorf("got userId=%d clientCode=%q, want 7 and \"acme\"", resp.UserID, resp.ClientCode)
		}
		if repo.gotHash != helper.HashToken("raw-token") {
			t.Errorf("looked up hash %q, want the SHA-256 of the raw token", repo.gotHash)
		}
		if repo.touchedID != live.ID {
			t.Errorf("touched session %d, want %d", repo.touchedID, live.ID)
		}
	})

	t.Run("unknown or expired token is 401, never 404 or 500", func(t *testing.T) {
		svc := &AuthService{sessionRepo: &stubSessionRepo{getErr: pgx.ErrNoRows}, generalSettingsClient: fallbackClient}

		_, err := svc.validateSession(context.Background(), nil, "raw-token")
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != fiber.StatusUnauthorized {
			t.Fatalf("validateSession() err = %v, want 401 HttpError", err)
		}
	})

	t.Run("lookup failure is 500, not a silent logout", func(t *testing.T) {
		svc := &AuthService{sessionRepo: &stubSessionRepo{getErr: errors.New("connection refused")}, generalSettingsClient: fallbackClient}

		_, err := svc.validateSession(context.Background(), nil, "raw-token")
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != fiber.StatusInternalServerError {
			t.Fatalf("validateSession() err = %v, want 500 HttpError", err)
		}
	})

	t.Run("a failed slide still validates the session", func(t *testing.T) {
		svc := &AuthService{sessionRepo: &stubSessionRepo{session: live, touchErr: errors.New("deadlock")}, generalSettingsClient: fallbackClient}

		resp, err := svc.validateSession(context.Background(), nil, "raw-token")
		if err != nil {
			t.Fatalf("validateSession() err = %v, want nil â€” a failed slide is degraded, not fatal", err)
		}
		if resp.UserID != 7 {
			t.Errorf("got userId=%d, want 7", resp.UserID)
		}
	})

	t.Run("on-read expiry terminates an expired active session", func(t *testing.T) {
		expired := &model.Session{
			ID: 99, UserID: 7, ClientCode: "acme", Platform: "web",
			Status: constant.SessionStatusActive, ExpiresAt: time.Now().Add(-time.Minute),
			IPAddress: "127.0.0.1",
		}
		termRepo := &stubSessionRepoWithExpiry{activeErr: pgx.ErrNoRows, byHashSession: expired}
		svc := &AuthService{
			sessionRepo:           termRepo,
			generalSettingsClient: fallbackClient,
			productSessionRepo:    &stubProductSessionRepo{},
		}

		_, err := svc.validateSession(context.Background(), nil, "raw-token")
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != fiber.StatusUnauthorized {
			t.Fatalf("validateSession() err = %v, want 401 HttpError", err)
		}
		if !termRepo.terminated {
			t.Error("expected on-read expiry to call terminateSession")
		}
	})
}

// stubSessionRepoWithExpiry supports the on-read expiry test path.
type stubSessionRepoWithExpiry struct {
	activeErr     error
	byHashSession *model.Session
	terminated    bool
}

func (s *stubSessionRepoWithExpiry) GetActiveByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.Session, error) {
	return nil, s.activeErr
}

func (s *stubSessionRepoWithExpiry) GetByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.Session, error) {
	if s.byHashSession != nil {
		return s.byHashSession, nil
	}
	return nil, pgx.ErrNoRows
}

func (s *stubSessionRepoWithExpiry) Touch(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ time.Time, _ time.Duration) error {
	return nil
}

func (s *stubSessionRepoWithExpiry) Terminate(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ model.SessionStatus, _ model.TerminatedReason, _ time.Time) (int64, error) {
	s.terminated = true
	return 1, nil
}

func (s *stubSessionRepoWithExpiry) GetActiveForUpdate(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) (*model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepoWithExpiry) GetByID(context.Context, coreService.PostgreSQLServicer, int64) (*model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepoWithExpiry) ListExpiredActive(context.Context, coreService.PostgreSQLServicer, time.Time, int) ([]model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepoWithExpiry) TerminateAllActiveForUser(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called")
}

func (s *stubSessionRepoWithExpiry) InsertOne(context.Context, coreService.PostgreSQLServicer, model.Session) error {
	panic("not called")
}

// stubProductSessionRepo is a no-op for terminateSession's cascade call.
type stubProductSessionRepo struct{}

func (s *stubProductSessionRepo) EndByPlatformSession(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ model.TerminatedReason, _ time.Time) (int64, error) {
	return 0, nil
}

func (s *stubProductSessionRepo) EndForSubscription(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ int64, _ model.TerminatedReason, _ time.Time) (int64, error) {
	return 0, nil
}
