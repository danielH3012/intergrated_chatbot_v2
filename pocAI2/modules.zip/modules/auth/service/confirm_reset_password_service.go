package service

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type ConfirmResetPasswordParam struct {
	Token           string
	Password        string
	ConfirmPassword string
	IPAddress       string
}

// ConfirmResetPassword backs POST /auth/reset-password/confirm. The token is
// consumed only inside the transaction, so a policy rejection, a same-as-old
// rejection or a 5xx leaves the link reusable.
//
// The link checks (404) use one neutral message for every failure kind — the
// errorCode (LINK_INVALID / LINK_EXPIRED / LINK_USED) still differentiates in
// the response body, but never through the HTTP status or the copy.
func (s *AuthService) ConfirmResetPassword(ctx context.Context, param ConfirmResetPasswordParam) (*dto.ConfirmResetPasswordResponse, error) {
	return s.confirmResetPassword(ctx, s.publicSvc(), param)
}

// confirmResetPassword takes the schema-scoped handle as an argument so the
// transaction path is exercisable without dialing Postgres (see
// validateSession).
func (s *AuthService) confirmResetPassword(ctx context.Context, publicSvc coreService.PostgreSQLServicer, param ConfirmResetPasswordParam) (*dto.ConfirmResetPasswordResponse, error) {
	// The token is resolved before the policy check (ahead of the LLD's step
	// order) so every failure past this point can identify the subject and
	// write the §9 log entry TC-LOG-07 requires — an unresolved token still
	// answers the same neutral 404 with nothing logged (no subject).
	tokenHash := helper.HashToken(param.Token)
	token, err := s.resetTokenRepo.GetOneByHash(ctx, publicSvc, tokenHash)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			slog.ErrorContext(ctx, "reset.Confirm: resetTokenRepo.GetOneByHash: not found", "err", err)
			return nil, resetLinkNotFound(constant.ErrorCodeLinkInvalid)
		}
		slog.ErrorContext(ctx, "reset.Confirm: resetTokenRepo.GetOneByHash", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if err := resetTokenState(token, time.Now()); err != nil {
		slog.ErrorContext(ctx, "reset.Confirm: link not usable", "errorCode", resetLinkErrorCode(err))
		s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, resetLinkLogNote(err), constant.PlatformWeb, param.IPAddress)
		return nil, resetLinkNotFound(resetLinkErrorCode(err))
	}

	if param.Password == "" {
		s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNotePasswordPolicyFailed, constant.PlatformWeb, param.IPAddress)
		return nil, resetPasswordInputError(constant.ErrorCodePasswordEmpty, constant.MsgPasswordEmpty)
	}
	if param.ConfirmPassword == "" {
		s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNotePasswordPolicyFailed, constant.PlatformWeb, param.IPAddress)
		return nil, resetPasswordInputError(constant.ErrorCodeConfirmEmpty, constant.MsgConfirmPasswordEmpty)
	}
	if param.Password != param.ConfirmPassword {
		s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNotePasswordPolicyFailed, constant.PlatformWeb, param.IPAddress)
		// FailedRules carries the same "Passwords do not match" label
		// validatePasswordPolicy would append if this check didn't run
		// first (TC-API-11) — errorCode/message stay PASSWORDS_MISMATCH,
		// distinct from PASSWORD_INVALID (TC-API-10).
		return nil, &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: constant.MsgPasswordsMismatch,
			Data: &dto.ConfirmResetPasswordResponse{
				Status:      constant.ResetPasswordStatusFailed,
				Message:     constant.MsgPasswordsMismatch,
				ErrorCode:   ptr(constant.ErrorCodePasswordsMismatch),
				FailedRules: []string{"Passwords do not match"},
			},
		}
	}
	if rules := validatePasswordPolicy(param.Password, param.ConfirmPassword); len(rules) > 0 {
		slog.ErrorContext(ctx, "reset.Confirm: password policy validation failed", "failedRules", rules)
		s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNotePasswordPolicyFailed, constant.PlatformWeb, param.IPAddress)
		return nil, &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: constant.MsgResetPasswordPolicy,
			Data: &dto.ConfirmResetPasswordResponse{
				Status:      constant.ResetPasswordStatusFailed,
				Message:     constant.MsgResetPasswordPolicy,
				ErrorCode:   ptr(constant.ErrorCodePasswordInvalid),
				FailedRules: rules,
			},
		}
	}

	cred, err := s.credRepo.GetOneByEmail(ctx, publicSvc, token.Email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			// The credential vanished after the link was minted: same neutral
			// 404, never a distinct signal.
			slog.ErrorContext(ctx, "reset.Confirm: credRepo.GetOneByEmail: not found", "err", err)
			s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNoteResetLinkUsed, constant.PlatformWeb, param.IPAddress)
			return nil, resetLinkNotFound(constant.ErrorCodeLinkInvalid)
		}
		slog.ErrorContext(ctx, "reset.Confirm: credRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if cred.PasswordHash != nil && s.password.ComparePassword(*cred.PasswordHash, param.Password) == nil {
		slog.ErrorContext(ctx, "reset.Confirm: new password equals current password")
		s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, constant.LogNotePasswordPolicyFailed, constant.PlatformWeb, param.IPAddress)
		return nil, &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: constant.MsgResetPasswordSameAsOld,
			Data: &dto.ConfirmResetPasswordResponse{
				Status:    constant.ResetPasswordStatusFailed,
				Message:   constant.MsgResetPasswordSameAsOld,
				ErrorCode: ptr(constant.ErrorCodePasswordSameAsOld),
			},
		}
	}

	passwordHash, err := s.password.HashPassword(param.Password)
	if err != nil {
		slog.ErrorContext(ctx, "reset.Confirm: password.HashPassword", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// One transaction: pessimistic re-validation, then the write — update the
	// hash, consume the link, and clear BOTH lock tables. Clearing only
	// login_attempt_locks would leave requires_reset / permanent in
	// user_lock_states, which still short-circuits every login.
	_, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)

		reToken, err := s.resetTokenRepo.GetOneByHashForUpdate(ctx, publicSvc, tokenHash)
		if err != nil {
			return struct{}{}, err
		}
		if err := resetTokenState(reToken, time.Now()); err != nil {
			return struct{}{}, err
		}

		if err := s.credRepo.UpdatePasswordHash(ctx, publicSvc, cred.ID, passwordHash); err != nil {
			return struct{}{}, err
		}
		if err := s.resetTokenRepo.Consume(ctx, publicSvc, reToken.ID); err != nil {
			return struct{}{}, err
		}
		if err := s.lockRepo.ResetAllForUser(ctx, publicSvc, token.UserID); err != nil {
			return struct{}{}, err
		}
		if err := s.lockRepo.ClearLockStates(ctx, publicSvc, token.UserID); err != nil {
			return struct{}{}, err
		}

		return struct{}{}, nil
	})
	if err != nil {
		if errors.Is(err, errResetLinkUsed) || errors.Is(err, errResetLinkExpired) || errors.Is(err, errResetLinkInvalid) {
			slog.ErrorContext(ctx, "reset.Confirm: link not usable in transaction", "errorCode", resetLinkErrorCode(err))
			s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusFailed, resetLinkLogNote(err), constant.PlatformWeb, param.IPAddress)
			return nil, resetLinkNotFound(resetLinkErrorCode(err))
		}
		slog.ErrorContext(ctx, "reset.Confirm: transaction", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	s.recordSessionLog(ctx, token.ClientCode, token.UserID, constant.ActivityResetPassword, constant.LogStatusSuccess, constant.LogNoteResetPasswordSuccess, constant.PlatformWeb, param.IPAddress)

	return &dto.ConfirmResetPasswordResponse{
		Status:  constant.ResetPasswordStatusSuccess,
		Message: constant.MsgResetPasswordDone,
	}, nil
}

func resetPasswordInputError(errorCode, message string) error {
	return &coreEntity.HttpError{
		Code:    fiber.StatusUnprocessableEntity,
		Message: message,
		Data: &dto.ConfirmResetPasswordResponse{
			Status:    constant.ResetPasswordStatusFailed,
			Message:   message,
			ErrorCode: ptr(errorCode),
		},
	}
}

// resetLinkNotFound is the neutral 404 all three link failure kinds share;
// only the errorCode in the body differentiates.
func resetLinkNotFound(errorCode string) error {
	return &coreEntity.HttpError{
		Code:    fiber.StatusNotFound,
		Message: constant.MsgResetLinkNeutral,
		Data: &dto.ConfirmResetPasswordResponse{
			Status:    constant.ResetPasswordStatusFailed,
			Message:   constant.MsgResetLinkNeutral,
			ErrorCode: &errorCode,
		},
	}
}

// ptr is a tiny helper for nullable string fields.
func ptr(s string) *string {
	return &s
}
