package service

import (
	"context"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
)

// TerminateSessionsForAccount force-terminates every active session for a
// user — called when an account is deleted or deactivated.
func (s *AuthService) TerminateSessionsForAccount(ctx context.Context, userID int64, clientCode string, deleted bool) error {
	reason := constant.TerminatedReasonAccountDeactivated
	if deleted {
		reason = constant.TerminatedReasonAccountDeleted
	}
	return s.LogoutAllActiveForUser(ctx, userID, clientCode, reason)
}

// RevokeAppAccess ends all active product sessions for a user + subscription.
func (s *AuthService) RevokeAppAccess(ctx context.Context, userID int64, subscriptionID int64, clientCode string) error {
	svc := s.publicSvc()
	n, err := s.productSessionRepo.EndForSubscription(ctx, svc, userID, subscriptionID, constant.TerminatedReasonAccessRevoked, time.Now())
	if err != nil {
		return err
	}
	slog.InfoContext(ctx, "revoked app access", "userId", userID, "subscriptionId", subscriptionID, "count", n)
	return nil
}

// ExpireIdleSessions is the Temporal activity that batch-terminates expired
// sessions. Registered as a method on AuthService (not TenantDataActivities)
// because it needs terminateSession — and therefore the repos, the Temporal
// client for log dispatch, and the SSE publisher.
func (s *AuthService) ExpireIdleSessions(ctx context.Context) error {
	publicSvc := s.publicSvc()
	now := time.Now()

	sessions, err := s.sessionRepo.ListExpiredActive(ctx, publicSvc, now, 100)
	if err != nil {
		return err
	}

	count := 0
	for i := range sessions {
		terminated, err := s.terminateSession(ctx, publicSvc, &sessions[i], constant.SessionStatusExpired, constant.TerminatedReasonIdleTimeout, "Session", analyticsModel.SessionLogNoteSessionExpired)
		if err != nil {
			slog.ErrorContext(ctx, "expire-idle: terminateSession", "sessionId", sessions[i].ID, "err", err)
			continue
		}
		if terminated {
			count++
			s.recordSessionLog(ctx, sessions[i].ClientCode, sessions[i].UserID, "Session", constant.LogStatusFailed, string(analyticsModel.SessionLogNoteSessionExpired), sessions[i].Platform, sessions[i].IPAddress)
		}
	}

	slog.InfoContext(ctx, "expired idle sessions", "count", count)
	return nil
}
