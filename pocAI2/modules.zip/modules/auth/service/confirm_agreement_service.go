package service

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// ConfirmAgreement backs POST /auth/confirm-agreement: it records the
// Privacy Policy consent for a pending post-factor-1 handoff, then resumes
// the login at exactly the point the gate interrupted it — MFA evaluation.
//
// Every identity-bearing value comes from the handoff row, never from the
// body: the client supplies only the token and the yes/no. That includes the
// consented version, which is the shown_policy_version stamped when the gate
// fired — a policy republished while the screen was open is passable, not
// fatal, and the next login re-fires the gate on the new version.
func (s *AuthService) ConfirmAgreement(ctx context.Context, param dto.ConfirmAgreementRequest) (*dto.ConfirmAgreementResponse, error) {
	publicSvc := s.publicSvc()

	preAuth, err := s.loadAgreementHandoff(ctx, publicSvc, param.PreAuthToken)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			// Unknown / consumed / expired / not an agreement handoff. Not
			// logged: no new auth decision was made, and factor-1's own
			// accounting already happened upstream.
			return nil, coreEntity.Unauthorized(constant.MsgPreAuthExpired)
		}
		slog.ErrorContext(ctx, "confirm-agreement: loadAgreementHandoff", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if param.AgreementAccepted == nil || !*param.AgreementAccepted {
		return nil, s.declineAgreement(ctx, publicSvc, preAuth)
	}

	tenantSvc := s.tenantSvc(preAuth.ClientCode)
	version := ""
	if preAuth.ShownPolicyVersion != nil {
		version = *preAuth.ShownPolicyVersion
	}

	var (
		countryCode  string
		outcome      string
		rawToken     string
		existing     *dto.ExistingSessionInfo
		mfaReason    model.MfaReason
		mfaTriggered bool
	)
	if preAuth.CountryCode != nil {
		countryCode = *preAuth.CountryCode
	}
	deviceID := preAuth.DeviceInfo
	if preAuth.DeviceID != nil {
		deviceID = *preAuth.DeviceID
	}

	_, txErr := coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)
		tenantSvc.SetTransaction(tx)

		// The Agreement gate is resolved by definition at this point and is
		// not re-run; MFA is the gate it interrupted.
		var gerr error
		mfaReason, mfaTriggered, gerr = s.evaluateMfaTriggers(ctx, publicSvc, tenantSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform, deviceID, preAuth.GeoLat, preAuth.GeoLon, countryCode)
		if gerr != nil {
			return struct{}{}, gerr
		}

		if gerr := s.consentRepo.Upsert(ctx, tenantSvc, preAuth.UserID, version, time.Now()); gerr != nil {
			return struct{}{}, gerr
		}

		if mfaTriggered {
			// Convert the handoff in place: same token, same expires_at —
			// the 10-minute budget covers both gates and is not extended.
			return struct{}{}, s.preAuthRepo.ConvertToMfa(ctx, publicSvc, preAuth.ID, mfaReason)
		}

		var serr error
		outcome, rawToken, existing, serr = s.createPlatformSession(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform, preAuth.DeviceInfo, preAuth.IPAddress)
		if serr != nil {
			return struct{}{}, serr
		}

		if outcome == sessionOutcomeDuplicateDetected {
			// The consent stands — it was legitimate and informed — but the
			// row stays unconsumed and re-scoped for confirm-duplicate; no
			// session and no success log until that resolves.
			var existingSessionID int64
			if existing != nil && existing.ExistingSessionID != nil {
				existingSessionID = *existing.ExistingSessionID
			}
			return struct{}{}, s.preAuthRepo.ConvertToDuplicateLogin(ctx, publicSvc, preAuth.ID, existingSessionID)
		}

		return struct{}{}, s.preAuthRepo.Consume(ctx, publicSvc, preAuth.ID)
	})
	if txErr != nil {
		slog.ErrorContext(ctx, "confirm-agreement: transaction", "err", txErr)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if mfaTriggered {
		if mfaReason == constant.MfaReasonUnusualLogin {
			// Dispatched here rather than at factor-1 precisely so a refused
			// consent never triggers it.
			s.sendUnusualLoginAlert(ctx, preAuth.ClientCode, preAuth.UserID,
				mfaContext{Platform: preAuth.Platform, DeviceID: deviceID, IPAddress: preAuth.IPAddress})
		}
		redirect := constant.RedirectMfa
		return &dto.ConfirmAgreementResponse{
			Outcome:      constant.OutcomeMfaRequired,
			RedirectTo:   &redirect,
			MfaReason:    &mfaReason,
			PreAuthToken: &param.PreAuthToken,
		}, nil
	}

	if outcome == sessionOutcomeDuplicateDetected {
		return &dto.ConfirmAgreementResponse{
			Outcome:         constant.OutcomeDuplicateDetected,
			PreAuthToken:    &param.PreAuthToken,
			ExistingSession: existing,
		}, nil
	}

	// The deferred factor-1 success log, written now that the login is final.
	// The Note belongs to factor-1 — this flow never invents its own.
	s.recordLoginAttempt(ctx, preAuth.ClientCode, preAuth.UserID, constant.LogStatusSuccess, factor1LogNote(preAuth.Factor1Method), preAuth.Platform, preAuth.IPAddress)

	redirect := constant.RedirectProductHub
	return &dto.ConfirmAgreementResponse{
		Outcome:    constant.OutcomeSuccess,
		RedirectTo: &redirect,
		SessionID:  &rawToken,
	}, nil
}

// declineAgreement consumes the handoff, logs the refusal, and returns the
// 422 the FE renders verbatim. No session and no consent row.
func (s *AuthService) declineAgreement(ctx context.Context, publicSvc coreService.PostgreSQLServicer, preAuth *model.PreAuthSession) error {
	if err := s.preAuthRepo.Consume(ctx, publicSvc, preAuth.ID); err != nil {
		slog.ErrorContext(ctx, "confirm-agreement: preAuthRepo.Consume", "err", err)
		return coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	s.recordLoginAttempt(ctx, preAuth.ClientCode, preAuth.UserID, constant.LogStatusFailed, constant.LogNoteConsentNotGiven, preAuth.Platform, preAuth.IPAddress)
	return &coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: constant.MsgAgreementDeclined}
}

// factor1LogNote maps the handoff's factor-1 method onto the success Note the
// login flow would have written itself.
func factor1LogNote(method *model.Factor1Method) string {
	if method != nil && *method == constant.Factor1MethodOtp {
		return constant.LogNoteLoginOtpSuccess
	}
	return constant.LogNoteLoginSuccess
}
