package service

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"log/slog"
	"math/big"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	authWorkflow "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/workflow"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// MfaHandoff is everything the four MFA pages need to route, resolved at
// factor-1 time. There is deliberately no POST /auth/mfa/evaluate: every
// field here is known the moment factor-1 succeeds, so an evaluate call
// would be a round trip re-fetching what this response already carries.
// More importantly the unusual-login alert hangs off detection — behind a
// client-called endpoint a client could suppress a security email simply by
// not calling it. See flows/auth/mfa/low-level-design.md §2, Open Item #11.
type MfaHandoff struct {
	Reason model.MfaReason
	// PreAuthToken is the raw handle; only its hash is stored.
	PreAuthToken string
	// Factor1Method drives the first fork: "password" shows Choose
	// Verification Method, "otp" goes straight to the authenticator.
	Factor1Method model.Factor1Method
	// AuthenticatorEnrolled picks Authenticator Verification over
	// Enrollment once the user chooses the authenticator.
	AuthenticatorEnrolled bool
	// Email fills the OTP page subtitle, unmasked per mfa/02-ui-design.md §2.2.
	Email string
}

// mfaContext is the request-scoped device/network detail both factor-1
// endpoints already carry, narrowed to what MFA actually needs so LoginParam
// and VerifyOTPParam can share one call.
type mfaContext struct {
	Platform    model.Platform
	DeviceID    string
	IPAddress   string
	GeoLat      *float64
	GeoLon      *float64
	CountryCode string
}

// evaluateMfaTriggers decides whether factor-2 (MFA) is required:
//  1. First login: user has never completed a login (first_login_at IS NULL).
//  2. Idle >= 30 days: user last logged out >= 30 days ago.
//  3. Unusual login:
//     a. Device not previously trusted on this platform.
//     b. Location distance > 100km from last login coordinate (Haversine).
//     c. Country changed and corridor is untrusted / decayed (>180 days).
func (s *AuthService) evaluateMfaTriggers(
	ctx context.Context,
	publicSvc coreService.PostgreSQLServicer,
	tenantSvc coreService.PostgreSQLServicer,
	userID int64,
	clientCode string,
	platform model.Platform,
	deviceID string,
	geoLat, geoLon *float64,
	countryCode string,
) (reason model.MfaReason, triggered bool, err error) {
	if s.userRepo != nil {
		user, uerr := s.userRepo.GetOneByID(ctx, tenantSvc, userID)
		if uerr != nil && !errors.Is(uerr, pgx.ErrNoRows) {
			return "", false, uerr
		}

		// 1. First login trigger
		if user != nil && user.FirstLoginAt == nil {
			return constant.MfaReasonFirstLogin, true, nil
		}

		// 2. Idle >= 30 days trigger
		if user != nil && user.LastLogoutAt != nil && time.Since(*user.LastLogoutAt) >= constant.AgreementIdleWindow {
			return constant.MfaReasonIdle30d, true, nil
		}
	}

	// 3. Unusual login triggers
	if s.trustedDeviceRepo != nil {
		if deviceID == "" {
			return constant.MfaReasonUnusualLogin, true, nil
		}

		dev, derr := s.trustedDeviceRepo.GetOneByIdentity(ctx, publicSvc, userID, clientCode, platform, deviceID)
		if derr != nil {
			if errors.Is(derr, pgx.ErrNoRows) {
				return constant.MfaReasonUnusualLogin, true, nil
			}
			return "", false, derr
		}
		if dev == nil {
			return constant.MfaReasonUnusualLogin, true, nil
		}

		// Location check (Haversine > 100km)
		if geoLat != nil && geoLon != nil && dev.LastLoginLat != nil && dev.LastLoginLon != nil {
			dist := helper.HaversineDistance(*dev.LastLoginLat, *dev.LastLoginLon, *geoLat, *geoLon)
			if dist > 100.0 {
				return constant.MfaReasonUnusualLogin, true, nil
			}
		}

		// Country check (corridor trust)
		if s.countryPairRepo != nil && countryCode != "" && dev.LastLoginCountry != nil && *dev.LastLoginCountry != "" && !strings.EqualFold(countryCode, *dev.LastLoginCountry) {
			countryA, countryB := helper.SortCountryPair(*dev.LastLoginCountry, countryCode)
			pair, perr := s.countryPairRepo.GetOneByCorridor(ctx, publicSvc, userID, clientCode, countryA, countryB)
			if perr != nil {
				if errors.Is(perr, pgx.ErrNoRows) {
					return constant.MfaReasonUnusualLogin, true, nil
				}
				return "", false, perr
			}
			if pair == nil {
				return constant.MfaReasonUnusualLogin, true, nil
			}

			// Lazy decay check (> 180 days)
			if time.Since(pair.LastSeenAt) > 180*24*time.Hour {
				_ = s.countryPairRepo.ResetDecayed(ctx, publicSvc, pair.ID, time.Now())
				return constant.MfaReasonUnusualLogin, true, nil
			}

			if !pair.IsTrusted {
				return constant.MfaReasonUnusualLogin, true, nil
			}
		}
	}

	return "", false, nil
}

// beginMfa runs every server-side consequence of "MFA is required" —
// minting the pre-auth row with 10-min TTL, checking authenticator enrollment,
// and dispatching the unusual-login alert when appropriate.
func (s *AuthService) beginMfa(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	userID int64,
	clientCode string, reason model.MfaReason, factor1Method model.Factor1Method, email string,
	param mfaContext,
) (*MfaHandoff, error) {
	token, err := s.issueMfaPreAuthToken(ctx, svc, userID, clientCode, reason, factor1Method, param.Platform, param.DeviceID, param.IPAddress, param.GeoLat, param.GeoLon, param.CountryCode)
	if err != nil {
		return nil, err
	}

	enrolled, err := s.hasActiveAuthenticator(ctx, svc, userID, clientCode)
	if err != nil {
		return nil, err
	}

	if reason == constant.MfaReasonUnusualLogin {
		s.sendUnusualLoginAlert(ctx, clientCode, userID, param)
	}

	return &MfaHandoff{
		Reason:                reason,
		PreAuthToken:          token,
		Factor1Method:         factor1Method,
		AuthenticatorEnrolled: enrolled,
		Email:                 email,
	}, nil
}

// hasActiveAuthenticator reports whether the user has an active authenticator enrollment.
func (s *AuthService) hasActiveAuthenticator(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string) (bool, error) {
	if s.authenticatorRepo == nil {
		return false, nil
	}
	enr, err := s.authenticatorRepo.GetOneByUser(ctx, svc, userID, clientCode)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return false, nil
		}
		return false, err
	}
	return enr != nil && enr.IsActive, nil
}

// sendUnusualLoginAlert dispatches the "New sign-in to your TAG Samurai account" email.
func (s *AuthService) sendUnusualLoginAlert(ctx context.Context, clientCode string, userID int64, param mfaContext) {
	// TODO: Integrate Temporal SendUnusualLoginAlertWorkflow / email activity when final design and copy are ready from the designer (TC-AUTH-MFA-62..70)
	slog.InfoContext(ctx, "mfa: unusual login detected, dispatching alert",
		"userId", userID, "clientCode", clientCode, "platform", param.Platform, "ip", param.IPAddress)
}

// finalizeMFALogin atomically completes factor-2 verification: consumes pre-auth session,
// creates platform session, upserts trusted device, updates country pair trust, stamps first_login_at,
// clears daily login locks, and logs exactly one Success log entry to session logs.
func (s *AuthService) finalizeMFALogin(
	ctx context.Context,
	publicSvc coreService.PostgreSQLServicer,
	tenantSvc coreService.PostgreSQLServicer,
	preAuth *model.PreAuthSession,
	user *userDto.UserListItem,
	deviceID string,
	ipAddress string,
	factor1Method model.Factor1Method,
) (sessionToken string, existing *dto.ExistingSessionInfo, err error) {
	if err := s.preAuthRepo.Consume(ctx, publicSvc, preAuth.ID); err != nil {
		return "", nil, err
	}

	outcome, rawToken, existing, serr := s.createPlatformSession(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform, preAuth.DeviceInfo, ipAddress)
	if serr != nil {
		return "", nil, serr
	}
	if outcome == sessionOutcomeDuplicateDetected {
		return "", existing, nil
	}

	// 1. Read previous country on this device before updating
	var priorCountry string
	if s.trustedDeviceRepo != nil {
		priorDev, _ := s.trustedDeviceRepo.GetOneByIdentity(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform, deviceID)
		if priorDev != nil && priorDev.LastLoginCountry != nil {
			priorCountry = *priorDev.LastLoginCountry
		}

		// 2. Upsert trusted device
		_ = s.trustedDeviceRepo.Upsert(ctx, publicSvc, model.TrustedDevice{
			UserID:           preAuth.UserID,
			ClientCode:       preAuth.ClientCode,
			Platform:         preAuth.Platform,
			DeviceID:         deviceID,
			LastLoginLat:     preAuth.GeoLat,
			LastLoginLon:     preAuth.GeoLon,
			LastLoginCountry: preAuth.CountryCode,
			LastUsedAt:       time.Now(),
		})
	}

	// 3. Country pair corridor update
	if s.countryPairRepo != nil && priorCountry != "" && preAuth.CountryCode != nil && *preAuth.CountryCode != "" && !strings.EqualFold(priorCountry, *preAuth.CountryCode) {
		countryA, countryB := helper.SortCountryPair(priorCountry, *preAuth.CountryCode)
		pair, perr := s.countryPairRepo.GetOneByCorridor(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, countryA, countryB)
		now := time.Now()
		if perr != nil && errors.Is(perr, pgx.ErrNoRows) || pair == nil {
			_ = s.countryPairRepo.Upsert(ctx, publicSvc, model.KnownCountryPair{
				UserID:          preAuth.UserID,
				ClientCode:      preAuth.ClientCode,
				CountryA:        countryA,
				CountryB:        countryB,
				Frequency:       1,
				IsTrusted:       false,
				FirstSeenAt:     now,
				WindowStartedAt: now,
				LastSeenAt:      now,
			})
		} else {
			if now.Sub(pair.LastSeenAt) > 180*24*time.Hour {
				pair.Frequency = 1
				pair.IsTrusted = false
				pair.WindowStartedAt = now
				pair.LastSeenAt = now
			} else if now.Sub(pair.WindowStartedAt) > 90*24*time.Hour {
				pair.Frequency = 1
				pair.IsTrusted = false
				pair.WindowStartedAt = now
				pair.LastSeenAt = now
			} else {
				pair.Frequency++
				pair.IsTrusted = pair.Frequency >= 3
				pair.LastSeenAt = now
			}
			_ = s.countryPairRepo.Upsert(ctx, publicSvc, *pair)
		}
	}

	// 4. Set first_login_at if not set yet
	if s.userRepo != nil && user != nil && user.FirstLoginAt == nil {
		_ = s.userRepo.UpdateFirstLoginAt(ctx, tenantSvc, preAuth.UserID, time.Now())
	}

	// 5. Invalidate any pending active MFA OTP codes for this user
	if s.otpRepo != nil && user != nil {
		_ = s.otpRepo.InvalidateActive(ctx, publicSvc, user.Email, preAuth.ClientCode, constant.OtpPurposeMfa)
	}

	// 6. Reset login attempt locks
	if s.lockRepo != nil {
		_ = s.lockRepo.ResetToday(ctx, publicSvc, preAuth.UserID, preAuth.Platform)
	}

	// 7. Record Success log to session logs with Note matching factor-1
	note := constant.LogNoteLoginSuccess
	if factor1Method == constant.Factor1MethodOtp {
		note = constant.LogNoteLoginOtpSuccess
	} else if factor1Method == constant.Factor1MethodBiometric {
		note = constant.LogNoteLoginBiometricSuccess
	}
	s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusSuccess, note, preAuth.Platform, ipAddress)

	return rawToken, nil, nil
}

// SendMfaOtp sends or resends an MFA OTP code to the user's registered email.
func (s *AuthService) SendMfaOtp(ctx context.Context, param dto.MfaOtpSendRequest, ipAddress string) (*dto.MfaOtpSendResponse, error) {
	if param.OtpSessionID != nil {
		trimmed := strings.TrimSpace(*param.OtpSessionID)
		if trimmed == "" {
			return nil, coreEntity.BadRequest("otpSessionId cannot be empty")
		}
		val, err := strconv.ParseInt(trimmed, 10, 64)
		if err != nil || val <= 0 {
			return nil, coreEntity.BadRequest("Invalid otpSessionId")
		}
	}

	publicSvc := s.publicSvc()

	tokenHash := helper.HashToken(param.PreAuthToken)
	preAuth, err := s.preAuthRepo.GetActiveByTokenHash(ctx, publicSvc, tokenHash)
	if err != nil || preAuth == nil || preAuth.Status != constant.PreAuthStatusActive || preAuth.Purpose != constant.PreAuthPurposeMfa || time.Now().After(preAuth.ExpiresAt) {
		return &dto.MfaOtpSendResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodePreAuthSessionExpired),
		}, nil
	}

	tenantSvc := s.tenantSvc(preAuth.ClientCode)
	user, err := s.userRepo.GetOneByID(ctx, tenantSvc, preAuth.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
			return &dto.MfaOtpSendResponse{
				Outcome:   constant.OutcomeFailed,
				ErrorCode: ptr(constant.ErrorCodeInactive),
			}, nil
		}
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if user == nil || !user.IsActive {
		_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
		return &dto.MfaOtpSendResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeInactive),
		}, nil
	}

	// Generate 6-digit numeric code
	n, _ := rand.Int(rand.Reader, big.NewInt(1000000))
	code := fmt.Sprintf("%06d", n.Int64())

	otpCodeID, otpSessionID, resendCount, err := s.issueMfaOtpCode(ctx, publicSvc, user.Email, preAuth.ClientCode, preAuth.Platform, param.OtpSessionID, code)
	if err != nil {
		if errors.Is(err, errResendLimitExceeded) {
			exhaustedCooldown := constant.OtpResendExhaustedCooldownSeconds
			isExhausted := true
			return &dto.MfaOtpSendResponse{
				Outcome:               constant.OutcomeFailed,
				ErrorCode:             ptr(constant.ErrorCodeResendLimitExceeded),
				ResendCooldownSeconds: &exhaustedCooldown,
				ResendExhausted:       &isExhausted,
			}, nil
		}
		var httpErr *coreEntity.HttpError
		if errors.As(err, &httpErr) {
			return nil, err
		}
		slog.ErrorContext(ctx, "mfa: issueMfaOtpCode", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	// Dispatch email workflow
	if _, err := s.temporalSvc.Client.ExecuteWorkflow(ctx, client.StartWorkflowOptions{
		ID:                    fmt.Sprintf("mfa-otp-email-%d", otpCodeID),
		TaskQueue:             s.temporalSvc.TaskQueue,
		WorkflowIDReusePolicy: enums.WORKFLOW_ID_REUSE_POLICY_REJECT_DUPLICATE,
	}, authWorkflow.SendOtpEmailWorkflow, authWorkflow.SendOtpEmailWorkflowParam{
		Email: user.Email,
		Code:  code,
	}); err != nil {
		slog.ErrorContext(ctx, "mfa: dispatch send-otp-email workflow", "err", err)
	}

	cooldown := otpResendCooldown(resendCount)
	return &dto.MfaOtpSendResponse{
		Outcome:               constant.OutcomeSent,
		Email:                 &user.Email,
		OtpSessionID:          ptr(strconv.FormatInt(otpSessionID, 10)),
		ResendCooldownSeconds: &cooldown,
		ResendExhausted:       new(bool),
	}, nil
}

// issueMfaOtpCode resolves the resend chain and inserts the MFA OTP code with purpose='mfa'.
func (s *AuthService) issueMfaOtpCode(
	ctx context.Context,
	publicSvc coreService.PostgreSQLServicer,
	email, clientCode string,
	platform model.Platform,
	sessionIDParam *string,
	code string,
) (otpCodeID, otpSessionID int64, resendCount int, err error) {
	otpCodeID, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (int64, error) {
		publicSvc.SetTransaction(tx)

		resendCount = 0
		if sessionIDParam != nil {
			trimmed := strings.TrimSpace(*sessionIDParam)
			if trimmed == "" {
				return 0, coreEntity.BadRequest("otpSessionId cannot be empty")
			}
			sessionIDInt, err := strconv.ParseInt(trimmed, 10, 64)
			if err != nil || sessionIDInt <= 0 {
				return 0, coreEntity.BadRequest("Invalid otpSessionId")
			}
			latest, lerr := s.otpRepo.GetLatestInSession(ctx, publicSvc, email, clientCode, sessionIDInt)
			if lerr != nil && !errors.Is(lerr, pgx.ErrNoRows) {
				return 0, lerr
			}
			if lerr == nil {
				otpSessionID = sessionIDInt
				resendCount = latest.ResendCount + 1
			}
		}

		if otpSessionID == 0 {
			otpSessionID = time.Now().UnixNano()
		}

		if resendCount >= constant.OtpMaxResend {
			return 0, errResendLimitExceeded
		}

		if err := s.otpRepo.InvalidateActive(ctx, publicSvc, email, clientCode, constant.OtpPurposeMfa); err != nil {
			return 0, err
		}

		return s.otpRepo.InsertOne(ctx, publicSvc, model.OtpCode{
			Email:        email,
			ClientCode:   clientCode,
			CodeHash:     s.hashOTP(code),
			Purpose:      constant.OtpPurposeMfa,
			OtpSessionID: otpSessionID,
			ResendCount:  resendCount,
			Platform:     platform,
			ExpiresAt:    time.Now().Add(constant.OtpTTL),
		})
	})
	return otpCodeID, otpSessionID, resendCount, err
}

// VerifyMfaOtp verifies the factor-2 email OTP code.
func (s *AuthService) VerifyMfaOtp(ctx context.Context, param dto.MfaOtpVerifyRequest, ipAddress string) (*dto.MfaVerifyResponse, error) {
	publicSvc := s.publicSvc()

	tokenHash := helper.HashToken(param.PreAuthToken)
	preAuth, err := s.preAuthRepo.GetActiveByTokenHash(ctx, publicSvc, tokenHash)
	if err != nil || preAuth == nil || preAuth.Status != constant.PreAuthStatusActive || preAuth.Purpose != constant.PreAuthPurposeMfa || time.Now().After(preAuth.ExpiresAt) {
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodePreAuthSessionExpired),
		}, nil
	}

	tenantSvc := s.tenantSvc(preAuth.ClientCode)
	user, err := s.userRepo.GetOneByID(ctx, tenantSvc, preAuth.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
			s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteInactive, preAuth.Platform, ipAddress)
			return &dto.MfaVerifyResponse{
				Outcome:   constant.OutcomeFailed,
				ErrorCode: ptr(constant.ErrorCodeInactive),
			}, nil
		}
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if user == nil || !user.IsActive {
		_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
		s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteInactive, preAuth.Platform, ipAddress)
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeInactive),
		}, nil
	}

	// Validate 6 digits
	if len(param.OtpCode) != 6 {
		s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpEmpty, preAuth.Platform, ipAddress)
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeOtpEmpty),
		}, nil
	}

	codeHash := s.hashOTP(param.OtpCode)
	var rawToken string
	var existing *dto.ExistingSessionInfo

	_, txErr := coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)
		tenantSvc.SetTransaction(tx)

		row, rerr := s.otpRepo.GetOneByHashForUpdate(ctx, publicSvc, user.Email, preAuth.ClientCode, codeHash, constant.OtpPurposeMfa)
		if rerr != nil {
			if errors.Is(rerr, pgx.ErrNoRows) {
				if other, oerr := s.otpRepo.GetLatestByHashAndClient(ctx, publicSvc, preAuth.ClientCode, codeHash, constant.OtpPurposeMfa); oerr == nil && other != nil && other.Email != user.Email {
					s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpEmailChanged, preAuth.Platform, ipAddress)
					return struct{}{}, errOtpEmailChanged
				}
				s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpIncorrect, preAuth.Platform, ipAddress)
				return struct{}{}, errOtpInvalid
			}
			return struct{}{}, rerr
		}

		if row.ConsumedAt != nil || row.InvalidatedAt != nil {
			s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpIncorrect, preAuth.Platform, ipAddress)
			return struct{}{}, errOtpInvalid
		}

		if !row.ExpiresAt.After(time.Now()) {
			s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpExpired, preAuth.Platform, ipAddress)
			return struct{}{}, errOtpExpired
		}

		if cerr := s.otpRepo.Consume(ctx, publicSvc, row.ID); cerr != nil {
			return struct{}{}, cerr
		}

		factor1 := constant.Factor1MethodPassword
		if preAuth.Factor1Method != nil {
			factor1 = *preAuth.Factor1Method
		}

		var ferr error
		rawToken, existing, ferr = s.finalizeMFALogin(ctx, publicSvc, tenantSvc, preAuth, user, param.DeviceID, ipAddress, factor1)
		if ferr != nil {
			return struct{}{}, ferr
		}

		return struct{}{}, nil
	})

	if txErr != nil {
		if errors.Is(txErr, errOtpInvalid) {
			return &dto.MfaVerifyResponse{Outcome: constant.OutcomeFailed, ErrorCode: ptr(constant.ErrorCodeOtpInvalid)}, nil
		}
		if errors.Is(txErr, errOtpExpired) {
			return &dto.MfaVerifyResponse{Outcome: constant.OutcomeFailed, ErrorCode: ptr(constant.ErrorCodeOtpExpired)}, nil
		}
		if errors.Is(txErr, errOtpEmailChanged) {
			return &dto.MfaVerifyResponse{Outcome: constant.OutcomeFailed, ErrorCode: ptr(constant.ErrorCodeOtpEmailChanged)}, nil
		}
		slog.ErrorContext(ctx, "mfa: verify otp transaction", "err", txErr)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if existing != nil {
		return &dto.MfaVerifyResponse{
			Outcome: constant.OutcomeDuplicateDetected,
		}, nil
	}

	return &dto.MfaVerifyResponse{
		Outcome:      constant.OutcomeSuccess,
		RedirectTo:   ptr(constant.RedirectProductHub),
		SessionToken: &rawToken,
	}, nil
}

// VerifyMfaAuthenticator verifies a TOTP code from an authenticator app.
func (s *AuthService) VerifyMfaAuthenticator(ctx context.Context, param dto.MfaAuthenticatorVerifyRequest, ipAddress string) (*dto.MfaVerifyResponse, error) {
	publicSvc := s.publicSvc()

	tokenHash := helper.HashToken(param.PreAuthToken)
	preAuth, err := s.preAuthRepo.GetActiveByTokenHash(ctx, publicSvc, tokenHash)
	if err != nil || preAuth == nil || preAuth.Status != constant.PreAuthStatusActive || preAuth.Purpose != constant.PreAuthPurposeMfa || time.Now().After(preAuth.ExpiresAt) {
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodePreAuthSessionExpired),
		}, nil
	}

	tenantSvc := s.tenantSvc(preAuth.ClientCode)
	user, err := s.userRepo.GetOneByID(ctx, tenantSvc, preAuth.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
			s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteInactive, preAuth.Platform, ipAddress)
			return &dto.MfaVerifyResponse{
				Outcome:   constant.OutcomeFailed,
				ErrorCode: ptr(constant.ErrorCodeInactive),
			}, nil
		}
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if user == nil || !user.IsActive {
		_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
		s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteInactive, preAuth.Platform, ipAddress)
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeInactive),
		}, nil
	}

	// Validate TOTP format
	if len(param.TotpCode) != 6 {
		s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpEmpty, preAuth.Platform, ipAddress)
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeTotpEmpty),
		}, nil
	}

	enr, err := s.authenticatorRepo.GetOneByUser(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode)
	if err != nil || enr == nil || !enr.IsActive {
		s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpIncorrect, preAuth.Platform, ipAddress)
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeTotpInvalid),
		}, nil
	}

	decryptedSecret, err := helper.DecryptSecret(enr.SecretEncrypted, s.encryptionKey)
	if err != nil {
		slog.ErrorContext(ctx, "mfa: decrypt authenticator secret", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if !helper.VerifyTOTP(string(decryptedSecret), param.TotpCode, time.Now(), constant.TotpDriftSteps) {
		s.recordSessionLog(ctx, preAuth.ClientCode, preAuth.UserID, string(analyticsModel.SessionLogActivityLogin), constant.LogStatusFailed, constant.LogNoteOtpIncorrect, preAuth.Platform, ipAddress)
		return &dto.MfaVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeTotpInvalid),
		}, nil
	}

	factor1 := constant.Factor1MethodPassword
	if preAuth.Factor1Method != nil {
		factor1 = *preAuth.Factor1Method
	}

	var rawToken string
	var existing *dto.ExistingSessionInfo

	_, txErr := coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)
		tenantSvc.SetTransaction(tx)

		var ferr error
		rawToken, existing, ferr = s.finalizeMFALogin(ctx, publicSvc, tenantSvc, preAuth, user, param.DeviceID, ipAddress, factor1)
		if ferr != nil {
			return struct{}{}, ferr
		}

		return struct{}{}, nil
	})
	if txErr != nil {
		slog.ErrorContext(ctx, "mfa: finalizeMFALogin transaction", "err", txErr)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	if existing != nil {
		return &dto.MfaVerifyResponse{
			Outcome: constant.OutcomeDuplicateDetected,
		}, nil
	}

	return &dto.MfaVerifyResponse{
		Outcome:      constant.OutcomeSuccess,
		RedirectTo:   ptr(constant.RedirectProductHub),
		SessionToken: &rawToken,
	}, nil
}

// EnrollMfaAuthenticator initiates enrollment by returning a QR code URI and base32 secret.
// Idempotent: re-calling returns the same existing secret.
func (s *AuthService) EnrollMfaAuthenticator(ctx context.Context, param dto.MfaEnrollRequest) (*dto.MfaEnrollResponse, error) {
	publicSvc := s.publicSvc()

	tokenHash := helper.HashToken(param.PreAuthToken)
	preAuth, err := s.preAuthRepo.GetActiveByTokenHash(ctx, publicSvc, tokenHash)
	if err != nil || preAuth == nil || preAuth.Status != constant.PreAuthStatusActive || preAuth.Purpose != constant.PreAuthPurposeMfa || time.Now().After(preAuth.ExpiresAt) {
		return nil, &coreEntity.HttpError{
			Code:    200,
			Message: constant.MsgSessionExpiredLoginAgain,
		}
	}

	tenantSvc := s.tenantSvc(preAuth.ClientCode)
	user, err := s.userRepo.GetOneByID(ctx, tenantSvc, preAuth.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
			return nil, &coreEntity.HttpError{
				Code:    200,
				Message: constant.MsgInactive,
			}
		}
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if user == nil || !user.IsActive {
		_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
		return nil, &coreEntity.HttpError{
			Code:    200,
			Message: constant.MsgInactive,
		}
	}

	var secretBase32 string
	existing, err := s.authenticatorRepo.GetOneByUser(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return nil, err
	}

	if existing != nil {
		if existing.IsActive {
			return nil, coreEntity.BadRequest("Authenticator app is already enrolled and active")
		}
		raw, derr := helper.DecryptSecret(existing.SecretEncrypted, s.encryptionKey)
		if derr != nil {
			return nil, derr
		}
		secretBase32 = string(raw)
	} else {
		_, encoded, gerr := helper.GenerateTOTPSecret()
		if gerr != nil {
			return nil, gerr
		}
		secretBase32 = encoded

		encrypted, eerr := helper.EncryptSecret([]byte(secretBase32), s.encryptionKey)
		if eerr != nil {
			return nil, eerr
		}

		if _, err := s.authenticatorRepo.InsertOne(ctx, publicSvc, model.AuthenticatorEnrollment{
			UserID:          preAuth.UserID,
			ClientCode:      preAuth.ClientCode,
			SecretEncrypted: encrypted,
			IsActive:        false,
		}); err != nil {
			return nil, err
		}
	}

	qrCodeURI := helper.BuildOtpauthURI(constant.TotpIssuer, user.Email, secretBase32)
	return &dto.MfaEnrollResponse{
		QrCodeURI:    qrCodeURI,
		SecretKey:    secretBase32,
		PreAuthToken: param.PreAuthToken,
	}, nil
}

// VerifyEnrollMfaAuthenticator verifies the setup code and activates the authenticator enrollment.
func (s *AuthService) VerifyEnrollMfaAuthenticator(ctx context.Context, param dto.MfaEnrollVerifyRequest, ipAddress string) (*dto.MfaEnrollVerifyResponse, error) {
	publicSvc := s.publicSvc()

	tokenHash := helper.HashToken(param.PreAuthToken)
	preAuth, err := s.preAuthRepo.GetActiveByTokenHash(ctx, publicSvc, tokenHash)
	if err != nil || preAuth == nil || preAuth.Status != constant.PreAuthStatusActive || preAuth.Purpose != constant.PreAuthPurposeMfa || time.Now().After(preAuth.ExpiresAt) {
		return &dto.MfaEnrollVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodePreAuthSessionExpired),
		}, nil
	}

	tenantSvc := s.tenantSvc(preAuth.ClientCode)
	user, err := s.userRepo.GetOneByID(ctx, tenantSvc, preAuth.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
			return &dto.MfaEnrollVerifyResponse{
				Outcome:   constant.OutcomeFailed,
				ErrorCode: ptr(constant.ErrorCodeInactive),
			}, nil
		}
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if user == nil || !user.IsActive {
		_ = s.preAuthRepo.InvalidateActive(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode, preAuth.Platform)
		return &dto.MfaEnrollVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeInactive),
		}, nil
	}

	if len(param.VerifyCode) != 6 {
		return &dto.MfaEnrollVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeVerifyEmpty),
		}, nil
	}

	enr, err := s.authenticatorRepo.GetOneByUser(ctx, publicSvc, preAuth.UserID, preAuth.ClientCode)
	if err != nil || enr == nil {
		return &dto.MfaEnrollVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeVerifyInvalid),
		}, nil
	}

	decryptedSecret, err := helper.DecryptSecret(enr.SecretEncrypted, s.encryptionKey)
	if err != nil {
		return nil, err
	}

	if !helper.VerifyTOTP(string(decryptedSecret), param.VerifyCode, time.Now(), constant.TotpDriftSteps) {
		return &dto.MfaEnrollVerifyResponse{
			Outcome:   constant.OutcomeFailed,
			ErrorCode: ptr(constant.ErrorCodeVerifyInvalid),
		}, nil
	}

	now := time.Now()
	if err := s.authenticatorRepo.Activate(ctx, publicSvc, enr.ID, now); err != nil {
		return nil, err
	}
	if err := s.userRepo.UpdateAuthenticatorEnrolled(ctx, tenantSvc, preAuth.UserID, true); err != nil {
		return nil, err
	}

	return &dto.MfaEnrollVerifyResponse{
		Outcome: constant.OutcomeSuccess,
	}, nil
}
