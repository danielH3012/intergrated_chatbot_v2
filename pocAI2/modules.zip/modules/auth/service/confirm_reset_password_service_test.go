package service

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/provider"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// stubResetPasswordTokenRepo records what confirm asked for and returns what
// the test told it to. GetOneByHashForUpdate falls back to the same row as
// GetOneByHash unless reToken is set separately.
type stubResetPasswordTokenRepo struct {
	token          *model.PasswordResetToken
	reToken        *model.PasswordResetToken
	getErr         error
	reGetErr       error
	consumedIDs    []int64
	invalidatedFor []int64
}

func (s *stubResetPasswordTokenRepo) GetOneByHash(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.PasswordResetToken, error) {
	return s.token, s.getErr
}

func (s *stubResetPasswordTokenRepo) GetOneByHashForUpdate(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.PasswordResetToken, error) {
	if s.reToken != nil {
		return s.reToken, s.reGetErr
	}
	return s.token, s.reGetErr
}

func (s *stubResetPasswordTokenRepo) InvalidateActiveForUser(_ context.Context, _ coreService.PostgreSQLServicer, userID int64) error {
	s.invalidatedFor = append(s.invalidatedFor, userID)
	return nil
}

func (s *stubResetPasswordTokenRepo) InsertOne(_ context.Context, _ coreService.PostgreSQLServicer, _ model.PasswordResetToken) (int64, error) {
	return 1, nil
}

func (s *stubResetPasswordTokenRepo) Consume(_ context.Context, _ coreService.PostgreSQLServicer, id int64) error {
	s.consumedIDs = append(s.consumedIDs, id)
	return nil
}

type stubResetCredRepo struct {
	cred        *model.UserCredential
	getErr      error
	updatedID   int64
	updatedHash string
}

func (s *stubResetCredRepo) GetOneByEmail(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.UserCredential, error) {
	return s.cred, s.getErr
}

func (s *stubResetCredRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.UserCredential) error {
	panic("not called by ConfirmResetPassword")
}

func (s *stubResetCredRepo) UpdatePasswordHash(_ context.Context, _ coreService.PostgreSQLServicer, id int64, hash string) error {
	s.updatedID, s.updatedHash = id, hash
	return nil
}

type stubResetLockRepo struct {
	resetAllUserIDs   []int64
	clearStateUserIDs []int64
}

func (s *stubResetLockRepo) GetTodayForUpdate(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) (*model.LoginAttemptLock, error) {
	panic("not called by ConfirmResetPassword")
}
func (s *stubResetLockRepo) GetLockState(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) (*model.UserLockState, error) {
	panic("not called by ConfirmResetPassword")
}
func (s *stubResetLockRepo) UpsertToday(context.Context, coreService.PostgreSQLServicer, model.LoginAttemptLock) error {
	panic("not called by ConfirmResetPassword")
}
func (s *stubResetLockRepo) UpsertLockState(context.Context, coreService.PostgreSQLServicer, model.UserLockState) error {
	panic("not called by ConfirmResetPassword")
}
func (s *stubResetLockRepo) ResetToday(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) error {
	panic("not called by ConfirmResetPassword")
}
func (s *stubResetLockRepo) ResetAllForUser(_ context.Context, _ coreService.PostgreSQLServicer, userID int64) error {
	s.resetAllUserIDs = append(s.resetAllUserIDs, userID)
	return nil
}
func (s *stubResetLockRepo) ClearLockStates(_ context.Context, _ coreService.PostgreSQLServicer, userID int64) error {
	s.clearStateUserIDs = append(s.clearStateUserIDs, userID)
	return nil
}

// liveResetToken is a usable link: active, unexpired, unconsumed,
// uninvalidated.
func liveResetToken(userID int64) *model.PasswordResetToken {
	return &model.PasswordResetToken{
		ID:         99,
		UserID:     userID,
		Email:      "user@example.com",
		ClientCode: "acme",
		Status:     constant.TokenStatusActive,
		// confirmResetPassword checks against time.Now(), not testNow.
		ExpiresAt: time.Now().Add(24 * time.Hour),
		RequestIP: "127.0.0.1",
	}
}

func httpCode(err error) int {
	var httpErr *coreEntity.HttpError
	if !errors.As(err, &httpErr) {
		return 0
	}
	return httpErr.Code
}

func httpData(err error) *dto.ConfirmResetPasswordResponse {
	var httpErr *coreEntity.HttpError
	if !errors.As(err, &httpErr) {
		return nil
	}
	resp, _ := httpErr.Data.(*dto.ConfirmResetPasswordResponse)
	return resp
}

func TestConfirmResetPassword(t *testing.T) {
	pass := &provider.PasswordProvider{}
	oldHash, err := pass.HashPassword("OldPassw0rd!")
	if err != nil {
		t.Fatalf("HashPassword(old) err = %v", err)
	}

	confirm := func(t *testing.T, svc *AuthService, param ConfirmResetPasswordParam) (*dto.ConfirmResetPasswordResponse, error) {
		return svc.confirmResetPassword(context.Background(), &coreService.FakePostgreSQLService{}, param)
	}

	t.Run("policy failure is 422 with failedRules and consumes nothing", func(t *testing.T) {
		svc := &AuthService{
			resetTokenRepo: &stubResetPasswordTokenRepo{token: liveResetToken(1)},
			credRepo:       &stubResetCredRepo{},
			lockRepo:       &stubResetLockRepo{},
			password:       pass,
		}

		_, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "weak",
			ConfirmPassword: "weak",
		})

		if httpCode(err) != fiber.StatusUnprocessableEntity {
			t.Fatalf("err code = %d, want 422", httpCode(err))
		}
		data := httpData(err)
		if data == nil || len(data.FailedRules) == 0 {
			t.Fatalf("want failedRules in response data, got %+v", data)
		}
		if data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodePasswordInvalid {
			t.Errorf("errorCode = %v, want %s", data.ErrorCode, constant.ErrorCodePasswordInvalid)
		}
	})

	t.Run("same as current password is 422 and consumes nothing", func(t *testing.T) {
		tokenRepo := &stubResetPasswordTokenRepo{token: liveResetToken(7)}
		svc := &AuthService{
			resetTokenRepo: tokenRepo,
			credRepo:       &stubResetCredRepo{cred: &model.UserCredential{ID: 3, PasswordHash: ptr(oldHash)}},
			lockRepo:       &stubResetLockRepo{},
			password:       pass,
		}

		_, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "OldPassw0rd!",
			ConfirmPassword: "OldPassw0rd!",
		})

		if httpCode(err) != fiber.StatusUnprocessableEntity {
			t.Fatalf("err code = %d, want 422", httpCode(err))
		}
		if data := httpData(err); data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodePasswordSameAsOld {
			t.Errorf("errorCode = %v, want %s", httpData(err).ErrorCode, constant.ErrorCodePasswordSameAsOld)
		}
		if len(tokenRepo.consumedIDs) != 0 {
			t.Errorf("token consumed on a rejected confirm: %v", tokenRepo.consumedIDs)
		}
	})

	t.Run("expired link is a neutral 404 and consumes nothing", func(t *testing.T) {
		token := liveResetToken(7)
		token.ExpiresAt = time.Now().Add(-time.Minute)
		tokenRepo := &stubResetPasswordTokenRepo{token: token}
		svc := &AuthService{
			resetTokenRepo: tokenRepo,
			credRepo:       &stubResetCredRepo{},
			lockRepo:       &stubResetLockRepo{},
			password:       pass,
		}

		_, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "NewPassw0rd!",
			ConfirmPassword: "NewPassw0rd!",
		})

		if httpCode(err) != fiber.StatusNotFound {
			t.Fatalf("err code = %d, want 404", httpCode(err))
		}
		if data := httpData(err); data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodeLinkExpired {
			t.Errorf("errorCode = %v, want %s", httpData(err).ErrorCode, constant.ErrorCodeLinkExpired)
		}
		if len(tokenRepo.consumedIDs) != 0 {
			t.Errorf("token consumed on an expired link: %v", tokenRepo.consumedIDs)
		}
	})

	t.Run("used link is a neutral 404 and consumes nothing", func(t *testing.T) {
		token := liveResetToken(7)
		token.Status = constant.TokenStatusConsumed
		tokenRepo := &stubResetPasswordTokenRepo{token: token}
		svc := &AuthService{
			resetTokenRepo: tokenRepo,
			credRepo:       &stubResetCredRepo{},
			lockRepo:       &stubResetLockRepo{},
			password:       pass,
		}

		_, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "NewPassw0rd!",
			ConfirmPassword: "NewPassw0rd!",
		})

		if httpCode(err) != fiber.StatusNotFound {
			t.Fatalf("err code = %d, want 404", httpCode(err))
		}
		if data := httpData(err); data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodeLinkUsed {
			t.Errorf("errorCode = %v, want %s", httpData(err).ErrorCode, constant.ErrorCodeLinkUsed)
		}
	})

	t.Run("unknown link is a neutral 404", func(t *testing.T) {
		svc := &AuthService{
			resetTokenRepo: &stubResetPasswordTokenRepo{getErr: pgx.ErrNoRows},
			credRepo:       &stubResetCredRepo{},
			lockRepo:       &stubResetLockRepo{},
			password:       pass,
		}

		_, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "NewPassw0rd!",
			ConfirmPassword: "NewPassw0rd!",
		})

		if httpCode(err) != fiber.StatusNotFound {
			t.Fatalf("err code = %d, want 404", httpCode(err))
		}
		if data := httpData(err); data == nil || data.ErrorCode == nil || *data.ErrorCode != constant.ErrorCodeLinkInvalid {
			t.Errorf("errorCode = %v, want %s", httpData(err).ErrorCode, constant.ErrorCodeLinkInvalid)
		}
	})

	t.Run("success writes the password, consumes the link and clears both lock tables", func(t *testing.T) {
		token := liveResetToken(7)
		tokenRepo := &stubResetPasswordTokenRepo{token: token}
		credRepo := &stubResetCredRepo{cred: &model.UserCredential{ID: 3, PasswordHash: ptr(oldHash)}}
		lockRepo := &stubResetLockRepo{}
		svc := &AuthService{
			resetTokenRepo: tokenRepo,
			credRepo:       credRepo,
			lockRepo:       lockRepo,
			password:       pass,
		}

		resp, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "NewPassw0rd!",
			ConfirmPassword: "NewPassw0rd!",
		})
		if err != nil {
			t.Fatalf("confirmResetPassword() err = %v, want nil", err)
		}
		if resp == nil || resp.Status != constant.ResetPasswordStatusSuccess {
			t.Errorf("resp.Status = %+v, want success", resp)
		}

		if credRepo.updatedID != 3 {
			t.Errorf("password hash written to credential %d, want 3", credRepo.updatedID)
		}
		if credRepo.updatedHash == "" || credRepo.updatedHash == oldHash {
			t.Errorf("password hash not rewritten: old=%q new=%q", oldHash, credRepo.updatedHash)
		}
		if err := pass.ComparePassword(credRepo.updatedHash, "NewPassw0rd!"); err != nil {
			t.Errorf("written hash does not match the new password: %v", err)
		}

		if len(tokenRepo.consumedIDs) != 1 || tokenRepo.consumedIDs[0] != token.ID {
			t.Errorf("consumed ids = %v, want [%d]", tokenRepo.consumedIDs, token.ID)
		}
		if len(lockRepo.resetAllUserIDs) != 1 || lockRepo.resetAllUserIDs[0] != token.UserID {
			t.Errorf("ResetAllForUser called for %v, want [%d]", lockRepo.resetAllUserIDs, token.UserID)
		}
		if len(lockRepo.clearStateUserIDs) != 1 || lockRepo.clearStateUserIDs[0] != token.UserID {
			t.Errorf("ClearLockStates called for %v, want [%d]", lockRepo.clearStateUserIDs, token.UserID)
		}
	})

	t.Run("concurrent consumption mid-transaction is a 404, not a double write", func(t *testing.T) {
		token := liveResetToken(7)
		used := liveResetToken(7)
		used.Status = constant.TokenStatusConsumed
		tokenRepo := &stubResetPasswordTokenRepo{token: token, reToken: used}
		svc := &AuthService{
			resetTokenRepo: tokenRepo,
			credRepo:       &stubResetCredRepo{cred: &model.UserCredential{ID: 3, PasswordHash: ptr(oldHash)}},
			lockRepo:       &stubResetLockRepo{},
			password:       pass,
		}

		_, err := confirm(t, svc, ConfirmResetPasswordParam{
			Token:           "raw-token",
			Password:        "NewPassw0rd!",
			ConfirmPassword: "NewPassw0rd!",
		})

		if httpCode(err) != fiber.StatusNotFound {
			t.Fatalf("err code = %d, want 404", httpCode(err))
		}
	})
}
