package service

import (
	"errors"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func TestValidateActivationErrMapsPublic404Variants(t *testing.T) {
	tests := []struct {
		name    string
		err     error
		message string
	}{
		{name: "consumed token", err: errActivationUsed, message: constant.MsgActivationUsed},
		{name: "expired token", err: errActivationExpired, message: constant.MsgActivationExpired},
		{name: "invalid token", err: errActivationInvalid, message: constant.MsgActivationExpired},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := validateActivationErr(tt.err)

			var httpErr *coreEntity.HttpError
			if !errors.As(err, &httpErr) {
				t.Fatalf("validateActivationErr() error = %v, want HttpError", err)
			}
			if httpErr.Code != fiber.StatusNotFound {
				t.Errorf("status = %d, want %d", httpErr.Code, fiber.StatusNotFound)
			}
			if httpErr.Message != tt.message {
				t.Errorf("message = %q, want %q", httpErr.Message, tt.message)
			}
		})
	}
}
