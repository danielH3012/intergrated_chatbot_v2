package service

import (
	"context"
	"strconv"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

// This file is the single place a user's rows become an authorization answer.
// Two projections come out of one read: the /me/permissions payload the shell
// renders, and the UserAccessCache every service in the platform gates on.
// They must never disagree, which is why they are built side by side rather
// than by two independent queries.

// moduleAccessKey maps the database product to the JSON key in
// /me/permissions.moduleAccess.
var moduleAccessKey = map[model.Product]string{
	model.ProductFixedAsset:     "fixedAsset",
	model.ProductGlobalSettings: "globalSettings",
	model.ProductAdminConsole:   "adminConsole",
}

// snapshotModule maps the database product to ts-utils' shared module enum.
var snapshotModule = map[model.Product]enum.ModuleAccess{
	model.ProductFixedAsset:     enum.ModuleAccessFixedAsset,
	model.ProductGlobalSettings: enum.ModuleAccessGlobalSettings,
	model.ProductAdminConsole:   enum.ModuleAccessAdminConsole,
}

// MePermissions builds the /me/permissions payload, served from cache when warm.
//
// product narrows systemRoles only; moduleAccess always carries all three
// modules because the shell renders every tile regardless.
func (s *MeService) MePermissions(ctx context.Context, userID int64, clientCode string, product *model.Product) (*dto.MePermissions, error) {
	// Only the unfiltered payload is cached: caching per (user, product) would
	// multiply keys and invalidation for a query parameter the shell rarely sends.
	cacheable := product == nil
	key := s.cache.MePermissionsKey(userID)
	if cacheable {
		if hit, ok := cache.Get[dto.MePermissions](ctx, s.cache, key); ok {
			return &hit, nil
		}
	}

	rows, err := s.permissionRows(ctx, userID, clientCode, product)
	if err != nil {
		return nil, err
	}

	payload := buildMePermissions(rows, product)
	if cacheable {
		s.cache.Set(ctx, key, payload)
	}
	return payload, nil
}

// RolesSnapshot builds the UserAccessCache ts-utils' LoadUserRoles serves to
// every consumer service, from this user's real rows.
//
// It fails closed: an error here means the caller cannot be authorized, and
// LoadUserRolesFrom turns that into a 401/503 rather than an empty snapshot
// that would read as "this user holds nothing" — or, as the placeholder this
// replaced did, as "this user holds everything".
func (s *MeService) RolesSnapshot(ctx context.Context, userID int64, clientCode string) (tsMiddleware.UserAccessCache, error) {
	key := tsMiddleware.UserRolesCacheKey(strconv.FormatInt(userID, 10))
	if hit, ok := cache.Get[tsMiddleware.UserAccessCache](ctx, s.cache, key); ok {
		return hit, nil
	}

	rows, err := s.permissionRows(ctx, userID, clientCode, nil)
	if err != nil {
		return tsMiddleware.UserAccessCache{}, err
	}

	snapshot := BuildSnapshot(rows, clientCode)
	// Warming the shared key here is what lets every other service read the
	// snapshot straight from Valkey without a hop into iam.
	s.cache.Set(ctx, key, snapshot)
	return snapshot, nil
}

func (s *MeService) permissionRows(ctx context.Context, userID int64, clientCode string, product *model.Product) (*dto.UserPermissionRows, error) {
	return s.perms.GetPermissionRows(ctx, s.tenantSvc(clientCode), userID, product)
}

// systemRoles is only meaningful for a single product, so an unfiltered
// request returns an empty list rather than a mix across products.
func buildMePermissions(rows *dto.UserPermissionRows, product *model.Product) *dto.MePermissions {
	roles := make([]dto.SystemRole, 0, len(rows.SystemRoles))
	if product != nil {
		for _, row := range rows.SystemRoles {
			roles = append(roles, mapSystemRole(row))
		}
	}

	return &dto.MePermissions{
		ID:             strconv.FormatInt(rows.Profile.ID, 10),
		ProfilePicture: rows.Profile.ProfilePicture,
		FullName:       strings.TrimSpace(rows.Profile.FirstName + " " + rows.Profile.LastName),
		Email:          rows.Profile.Email,
		Position:       rows.Profile.Position,
		Division:       rows.Profile.Division,
		ModuleAccess:   buildModuleAccess(rows),
		SystemRoles:    roles,
	}
}

// buildModuleAccess reduces the module-status and access-level rows to one
// entry per module.
//
// hasAccess requires a row that is active: no row means no access. The table's
// DEFAULT TRUE only applies once a row exists, so treating an absent row as
// "on" would hand a module to every user nobody has provisioned yet.
func buildModuleAccess(rows *dto.UserPermissionRows) map[string]dto.ModuleAccessEntry {
	access := map[string]dto.ModuleAccessEntry{}
	for _, key := range moduleAccessKey {
		access[key] = dto.ModuleAccessEntry{}
	}

	for _, status := range rows.ModuleStatus {
		key, ok := moduleAccessKey[status.ModuleKey]
		if !ok {
			continue // a product this API does not expose (yet)
		}
		entry := access[key]
		entry.HasAccess = status.IsActive
		access[key] = entry
	}

	for _, level := range rows.AccessLevels {
		key, ok := moduleAccessKey[level.Product]
		if !ok {
			continue
		}
		entry := access[key]
		entry.IsTotalControl = level.AccessLevel == model.AccessLevelTotalControl
		entry.IsReadOnly = level.AccessLevel == model.AccessLevelReadOnly
		access[key] = entry
	}

	return access
}

// mapSystemRole is the only place permission_update becomes edit.
func mapSystemRole(row model.UserSystemRole) dto.SystemRole {
	return dto.SystemRole{
		Key:     string(row.Key),
		Product: string(row.Product),
		Permission: dto.Permission{
			Create: row.PermissionCreate,
			View:   row.PermissionView,
			Edit:   row.PermissionUpdate,
			Delete: row.PermissionDelete,
		},
	}
}

// BuildSnapshot fills the shared UserAccessCache: module flags, then the system
// roles split per product. Fixed asset is the only product with group-scoped
// roles, so it is the only one with a GroupRoles map to fill.
func BuildSnapshot(rows *dto.UserPermissionRows, clientCode string) tsMiddleware.UserAccessCache {
	snapshot := tsMiddleware.UserAccessCache{
		ID:           int(rows.Profile.ID),
		FullName:     strings.TrimSpace(rows.Profile.FirstName + " " + rows.Profile.LastName),
		Email:        rows.Profile.Email,
		ClientID:     clientCode,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{},
	}
	snapshot.FixedAssetSystemRole.GlobalRole = map[enum.SystemRoleKey]tsMiddleware.Permissions[bool]{}
	snapshot.FixedAssetSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{}
	snapshot.GlobalSettingsSystemRole.GlobalRole = map[enum.SystemRoleKey]tsMiddleware.Permissions[bool]{}
	snapshot.AdminConsoleSystemRole.GlobalRole = map[enum.SystemRoleKey]tsMiddleware.Permissions[bool]{}

	// A module the user cannot reach carries no grants at all — an inactive
	// module_status row must not leave a total-control level standing.
	active := map[model.Product]bool{}
	for _, status := range rows.ModuleStatus {
		active[status.ModuleKey] = status.IsActive
	}

	for _, level := range rows.AccessLevels {
		module, ok := snapshotModule[level.Product]
		if !ok || !active[level.Product] {
			continue
		}
		snapshot.ModuleAccess[module] = tsMiddleware.ModuleFlags{
			IsTotalControl: level.AccessLevel == model.AccessLevelTotalControl,
			IsReadOnly:     level.AccessLevel == model.AccessLevelReadOnly,
		}
	}

	for _, row := range rows.SystemRoles {
		if !active[row.Product] {
			continue
		}
		key := enum.SystemRoleKey(row.Key)
		perms := tsMiddleware.Permissions[bool]{
			Create: row.PermissionCreate,
			View:   row.PermissionView,
			Edit:   row.PermissionUpdate,
			Delete: row.PermissionDelete,
		}

		switch row.Product {
		case model.ProductGlobalSettings:
			snapshot.GlobalSettingsSystemRole.GlobalRole[key] = perms
		case model.ProductAdminConsole:
			// Admin console group scoping has no home in the shared snapshot;
			// such a grant is dropped rather than silently widened to
			// tenant-wide.
			if row.ScopeLevel != model.ScopeLevelGroup {
				snapshot.AdminConsoleSystemRole.GlobalRole[key] = perms
			}
		case model.ProductFixedAsset:
			if row.ScopeLevel == model.ScopeLevelGroup {
				addGroupRole(snapshot.FixedAssetSystemRole.GroupRoles, key, row)
				continue
			}
			snapshot.FixedAssetSystemRole.GlobalRole[key] = perms
		}
	}

	return snapshot
}

// addGroupRole appends the row's group id to each verb it grants. Group roles
// carry the list of groups a user may act on per verb, so several rows for the
// same key accumulate rather than overwrite.
func addGroupRole(dst map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string], key enum.SystemRoleKey, row model.UserSystemRole) {
	if row.FixedAssetGroupID == nil {
		return
	}
	groupID := strconv.FormatInt(*row.FixedAssetGroupID, 10)

	perms := dst[key]
	if row.PermissionCreate {
		perms.Create = append(perms.Create, groupID)
	}
	if row.PermissionView {
		perms.View = append(perms.View, groupID)
	}
	if row.PermissionUpdate {
		perms.Edit = append(perms.Edit, groupID)
	}
	if row.PermissionDelete {
		perms.Delete = append(perms.Delete, groupID)
	}
	dst[key] = perms
}
