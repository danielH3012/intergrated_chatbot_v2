package service

import (
	"context"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	analyticsModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// Logout terminates the session identified by the gateway-supplied session id.
// Note the status asymmetry: logout logs Success, every other termination
// logs Failed.
func (s *AuthService) Logout(ctx context.Context, sessionID int64) (*dto.LogoutResponse, error) {
	publicSvc := s.publicSvc()

	session, err := s.sessionRepo.GetByID(ctx, publicSvc, sessionID)
	if err != nil {
		slog.ErrorContext(ctx, "logout: sessionRepo.GetByID", "err", err)
		return &dto.LogoutResponse{Outcome: constant.OutcomeAlreadyExpired}, nil
	}

	if session.Status != constant.SessionStatusActive {
		return &dto.LogoutResponse{Outcome: constant.OutcomeAlreadyExpired}, nil
	}

	terminated, err := s.terminateSession(ctx, publicSvc, session, constant.SessionStatusLoggedOut, constant.TerminatedReasonManualLogout, "Logout", analyticsModel.SessionLogNoteLoggedOut)
	if err != nil {
		slog.ErrorContext(ctx, "logout: terminateSession", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if !terminated {
		return &dto.LogoutResponse{Outcome: constant.OutcomeAlreadyExpired}, nil
	}

	s.recordSessionEvent(ctx, session.ClientCode, session, "Logout", constant.LogStatusSuccess, analyticsModel.SessionLogNoteLoggedOut, constant.SSEEventSessionLoggedOut, constant.SSEScopeSession, session.ID)

	return &dto.LogoutResponse{Outcome: constant.OutcomeLoggedOut}, nil
}

// LogoutAllActiveForUser terminates every active session for a user — called
// from the cascade path. Exported so it can be registered as a Temporal
// activity.
func (s *AuthService) LogoutAllActiveForUser(ctx context.Context, userID int64, clientCode string, reason model.TerminatedReason) error {
	publicSvc := s.publicSvc()

	n, err := s.sessionRepo.TerminateAllActiveForUser(ctx, publicSvc, userID, constant.SessionStatusForceLoggedOut, reason, time.Now())
	if err != nil {
		return err
	}
	slog.InfoContext(ctx, "terminated sessions for user", "userId", userID, "count", n, "reason", reason)
	return nil
}
