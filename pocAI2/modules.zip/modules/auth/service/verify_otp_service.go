package service

import (
	"context"
	"errors"
	"log/slog"
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// otpCodeRe is exactly six digits — the format gate before hashing.
var otpCodeRe = regexp.MustCompile(`^\d{6}$`)

// Sentinels the transaction returns for the logged failure kinds, so the
// caller can map them onto their distinct 401s without interpreting the row.
var (
	errOtpInvalid      = errors.New("otp invalid")
	errOtpExpired      = errors.New("otp expired")
	errOtpEmailChanged = errors.New("otp email changed")
)

type VerifyOTPParam struct {
	Email     string
	Platform  model.Platform
	DeviceID  string
	OtpCode   string
	IPAddress string
}

// VerifyOTP backs POST /auth/otp/verify: checks the submitted code against
// the HMAC'd row, then runs the same downstream gates as password login
// (Agreement → MFA → session).
//
// It deliberately never touches login_attempt_locks or user_lock_states —
// that ladder belongs to password login, and completeLogin resets it, so the
// omission would otherwise read as a bug. A wrong OTP is a possession-check
// failure with its own limit: the row's 5-minute TTL and the 5-resend cap.
//
// Failure outcomes are 401 HttpErrors, not ordinary return values: every
// failed branch here is indistinguishable from a bad credential (no
// enumeration), and the OTP-specific ones are logged against the user they
// identified.
func (s *AuthService) VerifyOTP(ctx context.Context, param VerifyOTPParam) (*dto.OtpVerifyResponse, error) {
	captchaRequired := param.Platform == constant.PlatformWeb
	email := strings.TrimSpace(param.Email)

	publicSvc := s.publicSvc()
	cred, err := s.credRepo.GetOneByEmail(ctx, publicSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			// Neutral 401: a bad email must be indistinguishable from a bad
			// code, so it is not logged against any user.
			return nil, otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpInvalid, captchaRequired)
		}
		slog.ErrorContext(ctx, "verify-otp: credRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	tenantSvc := s.tenantSvc(cred.ClientCode)
	user, err := s.userRepo.GetOneByEmail(ctx, tenantSvc, email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpInvalid, captchaRequired)
		}
		slog.ErrorContext(ctx, "verify-otp: userRepo.GetOneByEmail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if user.ActivationStatus != constant.ActivationStatusActivated || !user.IsActive {
		// Same neutral 401: the account state is not disclosed by OTP verify.
		return nil, otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpInvalid, captchaRequired)
	}

	// The code check runs after the lookups because the log entry needs a
	// numeric user id — the same trade Login makes.
	if !otpCodeRe.MatchString(param.OtpCode) {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusFailed, constant.LogNoteOtpEmpty, param.Platform, param.IPAddress)
		return nil, otpVerifyValidationError(constant.MsgOtpEmpty, constant.ErrorCodeOtpEmpty, captchaRequired)
	}

	outcome, rawToken, existing, handoff, agreementToken, err := s.verifyOtpRow(ctx, publicSvc, cred.ClientCode, tenantSvc, user, param, email, s.hashOTP(param.OtpCode))
	if err != nil {
		switch {
		case errors.Is(err, errOtpEmailChanged):
			return nil, otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpEmailChanged, captchaRequired)
		case errors.Is(err, errOtpInvalid):
			return nil, otpVerifyUnauthorizedError(constant.MsgOtpInvalid, constant.ErrorCodeOtpInvalid, captchaRequired)
		case errors.Is(err, errOtpExpired):
			return nil, otpVerifyUnauthorizedError(constant.MsgOtpExpired, constant.ErrorCodeOtpExpired, captchaRequired)
		default:
			slog.ErrorContext(ctx, "verify-otp: verifyOtpRow", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
	}

	if outcome == sessionOutcomeDuplicateDetected {
		// No session row and no success log — resolving the duplicate is
		// deferred to POST /auth/sessions/confirm-duplicate (not in scope).
		return &dto.OtpVerifyResponse{
			Outcome:         constant.OutcomeDuplicateDetected,
			ExistingSession: existing,
			CaptchaRequired: captchaRequired,
		}, nil
	}

	if outcome == sessionOutcomeCreated {
		s.recordLoginAttempt(ctx, cred.ClientCode, user.ID, constant.LogStatusSuccess, constant.LogNoteLoginOtpSuccess, param.Platform, param.IPAddress)
		return &dto.OtpVerifyResponse{
			Outcome:         constant.OutcomeSuccess,
			SessionID:       &rawToken,
			CaptchaRequired: captchaRequired,
		}, nil
	}

	if outcome == constant.OutcomeMfaRequired {
		return &dto.OtpVerifyResponse{
			Outcome:               outcome,
			MfaReason:             &handoff.Reason,
			PreAuthToken:          &handoff.PreAuthToken,
			Factor1Method:         &handoff.Factor1Method,
			AuthenticatorEnrolled: &handoff.AuthenticatorEnrolled,
			CaptchaRequired:       captchaRequired,
		}, nil
	}

	// agreement_required: the client posts agreementToken back to
	// POST /auth/confirm-agreement, which resumes the login at MFA.
	return &dto.OtpVerifyResponse{
		Outcome:         outcome,
		PreAuthToken:    &agreementToken,
		CaptchaRequired: captchaRequired,
	}, nil
}

// verifyOtpRow evaluates the code row and, when it checks out, runs the
// Agreement → MFA → session chain in one transaction. The code is consumed
// only after every gate passes; a failed gate leaves it reusable.
func (s *AuthService) verifyOtpRow(
	ctx context.Context,
	publicSvc coreService.PostgreSQLServicer,
	clientCode string,
	tenantSvc coreService.PostgreSQLServicer,
	user *userDto.UserListItem,
	param VerifyOTPParam,
	email string,
	codeHash string,
) (outcome, rawToken string, existing *dto.ExistingSessionInfo, handoff *MfaHandoff, agreementToken string, err error) {
	userID := user.ID
	firstLoginAt, lastLogoutAt := user.FirstLoginAt, user.LastLogoutAt
	_, err = coreService.UseTransactions(ctx, publicSvc.GetPool(), func(tx pgx.Tx) (struct{}, error) {
		publicSvc.SetTransaction(tx)

		// No state filter on the lookup: a right-but-stale code must be told
		// it expired rather than mislabelled "Incorrect OTP". The caller
		// distinguishes consumed / invalidated / expired below.
		row, rerr := s.otpRepo.GetOneByHashForUpdate(ctx, publicSvc, param.Email, clientCode, codeHash, constant.OtpPurposeLogin)
		if rerr != nil {
			if errors.Is(rerr, pgx.ErrNoRows) {
				// If no code was found for this specific email, check if the code
				// was issued to a different email under the same client (e.g. user edited email).
				if other, oerr := s.otpRepo.GetLatestByHashAndClient(ctx, publicSvc, clientCode, codeHash, constant.OtpPurposeLogin); oerr == nil && other != nil && other.Email != param.Email {
					s.recordLoginAttempt(ctx, clientCode, userID, constant.LogStatusFailed, constant.LogNoteOtpEmailChanged, param.Platform, param.IPAddress)
					return struct{}{}, errOtpEmailChanged
				}
				s.recordLoginAttempt(ctx, clientCode, userID, constant.LogStatusFailed, constant.LogNoteOtpIncorrect, param.Platform, param.IPAddress)
				return struct{}{}, errOtpInvalid
			}
			return struct{}{}, rerr
		}
		if row.ConsumedAt != nil || row.InvalidatedAt != nil {
			s.recordLoginAttempt(ctx, clientCode, userID, constant.LogStatusFailed, constant.LogNoteOtpIncorrect, param.Platform, param.IPAddress)
			return struct{}{}, errOtpInvalid
		}
		if !row.ExpiresAt.After(time.Now()) {
			s.recordLoginAttempt(ctx, clientCode, userID, constant.LogStatusFailed, constant.LogNoteOtpExpired, param.Platform, param.IPAddress)
			return struct{}{}, errOtpExpired
		}

		// Agreement gate always runs before MFA, even if MFA would also
		// trigger — avoids MFA side effects for an attempt that ends in
		// refusal.
		if triggered, policyVersion, gerr := s.evaluateAgreementTriggers(ctx, tenantSvc, userID, firstLoginAt, lastLogoutAt); gerr != nil {
			return struct{}{}, gerr
		} else if triggered {
			// Factor-1 is complete, so the code is consumed here too: the
			// login resumes from the agreement handoff, not from this code.
			if cerr := s.otpRepo.Consume(ctx, publicSvc, row.ID); cerr != nil {
				return struct{}{}, cerr
			}
			agreementToken, gerr = s.beginAgreement(ctx, publicSvc, userID, clientCode,
				constant.Factor1MethodOtp, policyVersion,
				mfaContext{Platform: param.Platform, DeviceID: param.DeviceID, IPAddress: param.IPAddress})
			if gerr != nil {
				return struct{}{}, gerr
			}
			outcome = constant.OutcomeAgreementRequired
			return struct{}{}, nil
		}

		// The MFA decision and its side effects (pre-auth row, unusual-login
		// alert) run here, in-process and inside this transaction — not
		// behind an evaluate endpoint the client would have to call. A
		// rolled-back verify therefore leaves no orphan pre-auth row and
		// sends no alert. Factor-1 is OTP, so the client skips the Choose
		// Verification Method page entirely (mfa/02-ui-design.md §2.1).
		if reason, triggered, gerr := s.evaluateMfaTriggers(ctx, publicSvc, tenantSvc, userID, clientCode, param.Platform, param.DeviceID, nil, nil, ""); gerr != nil {
			return struct{}{}, gerr
		} else if triggered {
			handoff, gerr = s.beginMfa(ctx, publicSvc, userID, clientCode,
				reason, constant.Factor1MethodOtp, email,
				mfaContext{Platform: param.Platform, DeviceID: param.DeviceID, IPAddress: param.IPAddress})
			if gerr != nil {
				return struct{}{}, gerr
			}
			outcome = constant.OutcomeMfaRequired
			return struct{}{}, nil
		}

		if cerr := s.otpRepo.Consume(ctx, publicSvc, row.ID); cerr != nil {
			return struct{}{}, cerr
		}

		var serr error
		outcome, rawToken, existing, serr = s.createPlatformSession(ctx, publicSvc, userID, clientCode, param.Platform, param.DeviceID, param.IPAddress)
		return struct{}{}, serr
	})
	return outcome, rawToken, existing, handoff, agreementToken, err
}

func otpVerifyValidationError(message, errorCode string, captchaRequired bool) error {
	captionField := constant.CaptionFieldGlobal
	return &coreEntity.HttpError{
		Code:    fiber.StatusUnprocessableEntity,
		Message: message,
		Data: &dto.OtpVerifyResponse{
			ErrorCode:       &errorCode,
			CaptionField:    &captionField,
			CaptchaRequired: captchaRequired,
		},
	}
}

func otpVerifyUnauthorizedError(message, errorCode string, captchaRequired bool) error {
	captionField := constant.CaptionFieldGlobal
	return &coreEntity.HttpError{
		Code:    fiber.StatusUnauthorized,
		Message: message,
		Data: &dto.OtpVerifyResponse{
			ErrorCode:       &errorCode,
			CaptionField:    &captionField,
			CaptchaRequired: captchaRequired,
		},
	}
}
