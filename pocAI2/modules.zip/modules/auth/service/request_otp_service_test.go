package service

import (
	"context"
	"errors"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func TestRequestOTP_SessionIDValidation(t *testing.T) {
	svc := &AuthService{}

	t.Run("rejects empty string otpSessionId with bad request", func(t *testing.T) {
		emptyStr := ""
		_, err := svc.RequestOTP(context.Background(), RequestOTPParam{
			Email:        "test@example.com",
			Platform:     constant.PlatformWeb,
			OtpSessionID: &emptyStr,
		})
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})

	t.Run("rejects whitespace-only otpSessionId with bad request", func(t *testing.T) {
		spaceStr := "   "
		_, err := svc.RequestOTP(context.Background(), RequestOTPParam{
			Email:        "test@example.com",
			Platform:     constant.PlatformWeb,
			OtpSessionID: &spaceStr,
		})
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})

	t.Run("rejects non-numeric otpSessionId with bad request", func(t *testing.T) {
		invalidStr := "abc-invalid"
		_, err := svc.RequestOTP(context.Background(), RequestOTPParam{
			Email:        "test@example.com",
			Platform:     constant.PlatformWeb,
			OtpSessionID: &invalidStr,
		})
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})

	t.Run("rejects negative or zero otpSessionId with bad request", func(t *testing.T) {
		negStr := "-10"
		_, err := svc.RequestOTP(context.Background(), RequestOTPParam{
			Email:        "test@example.com",
			Platform:     constant.PlatformWeb,
			OtpSessionID: &negStr,
		})
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})
}
