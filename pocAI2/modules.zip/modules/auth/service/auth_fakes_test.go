package service

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strconv"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	userRepository "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// Shared doubles for the login-side service tests. Each records what it was
// asked so a test can assert on the write, not only on the response — a login
// that answers "success" while never creating a session is the bug these are
// here to catch.

// ---------- credentials ----------

type fakeCredRepo struct {
	cred *model.UserCredential
	err  error
}

func (f *fakeCredRepo) GetOneByEmail(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.UserCredential, error) {
	if f.err != nil {
		return nil, f.err
	}
	return f.cred, nil
}
func (f *fakeCredRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.UserCredential) error {
	panic("not called")
}
func (f *fakeCredRepo) UpdatePasswordHash(context.Context, coreService.PostgreSQLServicer, int64, string) error {
	panic("not called")
}

// ---------- tenant users ----------

type fakeUserRepo struct {
	userRepository.UserRepositor
	user *userDto.UserListItem
	err  error
}

func (f *fakeUserRepo) GetOneByEmail(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*userDto.UserListItem, error) {
	if f.err != nil {
		return nil, f.err
	}
	return f.user, nil
}
func (f *fakeUserRepo) GetOneByID(_ context.Context, _ coreService.PostgreSQLServicer, _ int64) (*userDto.UserListItem, error) {
	if f.err != nil {
		return nil, f.err
	}
	if f.user == nil {
		return nil, pgx.ErrNoRows
	}
	return f.user, nil
}
func (f *fakeUserRepo) UpdateActivationStatus(context.Context, coreService.PostgreSQLServicer, int64, string) error {
	panic("not called")
}
func (f *fakeUserRepo) UpdateFirstLoginAt(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, t time.Time) error {
	if f.user != nil {
		f.user.FirstLoginAt = &t
	}
	return nil
}
func (f *fakeUserRepo) UpdateAuthenticatorEnrolled(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, enrolled bool) error {
	if f.user != nil {
		f.user.IsAuthenticatorEnrolled = enrolled
	}
	return nil
}

// ---------- login locks ----------

type fakeLockRepo struct {
	daily      *model.LoginAttemptLock
	state      *model.UserLockState
	readErr    error
	upserted   []model.LoginAttemptLock
	resetToday int
}

func (f *fakeLockRepo) GetTodayForUpdate(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ model.Platform) (*model.LoginAttemptLock, error) {
	if f.readErr != nil {
		return nil, f.readErr
	}
	if f.daily == nil {
		return nil, pgx.ErrNoRows
	}
	return f.daily, nil
}
func (f *fakeLockRepo) GetLockState(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ model.Platform) (*model.UserLockState, error) {
	if f.state == nil {
		return nil, pgx.ErrNoRows
	}
	return f.state, nil
}
func (f *fakeLockRepo) UpsertToday(_ context.Context, _ coreService.PostgreSQLServicer, row model.LoginAttemptLock) error {
	f.upserted = append(f.upserted, row)
	return nil
}
func (f *fakeLockRepo) UpsertLockState(context.Context, coreService.PostgreSQLServicer, model.UserLockState) error {
	return nil
}
func (f *fakeLockRepo) ResetToday(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) error {
	f.resetToday++
	return nil
}
func (f *fakeLockRepo) ResetAllForUser(context.Context, coreService.PostgreSQLServicer, int64) error {
	panic("not called")
}
func (f *fakeLockRepo) ClearLockStates(context.Context, coreService.PostgreSQLServicer, int64) error {
	panic("not called")
}

// ---------- sessions ----------

type fakeSessionRepo struct {
	// active is what Limit Login finds; nil means the platform is free.
	active    *model.Session
	inserted  []model.Session
	insertErr error
}

func (f *fakeSessionRepo) GetActiveForUpdate(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ model.Platform) (*model.Session, error) {
	if f.active == nil {
		return nil, pgx.ErrNoRows
	}
	return f.active, nil
}
func (f *fakeSessionRepo) InsertOne(_ context.Context, _ coreService.PostgreSQLServicer, session model.Session) error {
	if f.insertErr != nil {
		return f.insertErr
	}
	f.inserted = append(f.inserted, session)
	return nil
}
func (f *fakeSessionRepo) GetActiveByTokenHash(context.Context, coreService.PostgreSQLServicer, string) (*model.Session, error) {
	panic("not called")
}
func (f *fakeSessionRepo) GetByID(context.Context, coreService.PostgreSQLServicer, int64) (*model.Session, error) {
	panic("not called")
}
func (f *fakeSessionRepo) GetByTokenHash(context.Context, coreService.PostgreSQLServicer, string) (*model.Session, error) {
	panic("not called")
}
func (f *fakeSessionRepo) Touch(context.Context, coreService.PostgreSQLServicer, int64, time.Time, time.Duration) error {
	panic("not called")
}
func (f *fakeSessionRepo) Terminate(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called")
}
func (f *fakeSessionRepo) ListExpiredActive(context.Context, coreService.PostgreSQLServicer, time.Time, int) ([]model.Session, error) {
	panic("not called")
}
func (f *fakeSessionRepo) TerminateAllActiveForUser(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called")
}

// ---------- pre-auth handoffs ----------

type fakePreAuthRepo struct {
	row    *model.PreAuthSession
	getErr error

	inserted    []model.PreAuthSession
	consumed    []int64
	convertedTo []model.PreAuthPurpose
	mfaReasons  []model.MfaReason
	duplicateID int64
	writeErr    error
}

func (f *fakePreAuthRepo) InsertOne(_ context.Context, _ coreService.PostgreSQLServicer, row model.PreAuthSession) (int64, error) {
	if f.writeErr != nil {
		return 0, f.writeErr
	}
	f.inserted = append(f.inserted, row)
	return int64(len(f.inserted)), nil
}
func (f *fakePreAuthRepo) GetActiveByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.PreAuthSession, error) {
	if f.getErr != nil {
		return nil, f.getErr
	}
	if f.row == nil {
		return nil, pgx.ErrNoRows
	}
	return f.row, nil
}
func (f *fakePreAuthRepo) InvalidateActive(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ string, _ model.Platform) error {
	if f.row != nil {
		f.row.Status = constant.PreAuthStatusInvalidated
	}
	return nil
}
func (f *fakePreAuthRepo) Consume(_ context.Context, _ coreService.PostgreSQLServicer, id int64) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	if f.row != nil && f.row.ID == id {
		if f.row.Status != constant.PreAuthStatusActive {
			return pgx.ErrNoRows
		}
		f.row.Status = constant.PreAuthStatusConsumed
	}
	f.consumed = append(f.consumed, id)
	return nil
}
func (f *fakePreAuthRepo) ConvertToMfa(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, reason model.MfaReason) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	f.convertedTo = append(f.convertedTo, constant.PreAuthPurposeMfa)
	f.mfaReasons = append(f.mfaReasons, reason)
	return nil
}
func (f *fakePreAuthRepo) ConvertToDuplicateLogin(_ context.Context, _ coreService.PostgreSQLServicer, _, existingSessionID int64) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	f.convertedTo = append(f.convertedTo, constant.PreAuthPurposeDuplicateLogin)
	f.duplicateID = existingSessionID
	return nil
}

// ---------- privacy consent ----------

type consentWrite struct {
	UserID  int64
	Version string
}

type fakeConsentRepo struct {
	row *model.UserPrivacyConsent
	err error

	writes   []consentWrite
	writeErr error
}

func (f *fakeConsentRepo) GetOneByUserID(context.Context, coreService.PostgreSQLServicer, int64) (*model.UserPrivacyConsent, error) {
	return f.row, f.err
}

func (f *fakeConsentRepo) Upsert(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, version string, _ time.Time) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	f.writes = append(f.writes, consentWrite{UserID: userID, Version: version})
	return nil
}

// ---------- trusted devices ----------

type fakeTrustedDeviceRepo struct {
	devices  map[string]*model.TrustedDevice
	upserted []model.TrustedDevice
	getErr   error
	writeErr error
}

func newFakeTrustedDeviceRepo() *fakeTrustedDeviceRepo {
	return &fakeTrustedDeviceRepo{
		devices: make(map[string]*model.TrustedDevice),
	}
}

func (f *fakeTrustedDeviceRepo) key(userID int64, clientCode string, platform model.Platform, deviceID string) string {
	return string(platform) + ":" + clientCode + ":" + deviceID
}

func (f *fakeTrustedDeviceRepo) GetOneByIdentity(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, clientCode string, platform model.Platform, deviceID string) (*model.TrustedDevice, error) {
	if f.getErr != nil {
		return nil, f.getErr
	}
	dev, ok := f.devices[f.key(userID, clientCode, platform, deviceID)]
	if !ok || dev == nil {
		return nil, pgx.ErrNoRows
	}
	return dev, nil
}

func (f *fakeTrustedDeviceRepo) Upsert(_ context.Context, _ coreService.PostgreSQLServicer, row model.TrustedDevice) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	f.upserted = append(f.upserted, row)
	f.devices[f.key(row.UserID, row.ClientCode, row.Platform, row.DeviceID)] = &row
	return nil
}

// ---------- known country pairs ----------

type fakeCountryPairRepo struct {
	pairs    map[string]*model.KnownCountryPair
	upserted []model.KnownCountryPair
	getErr   error
	writeErr error
}

func newFakeCountryPairRepo() *fakeCountryPairRepo {
	return &fakeCountryPairRepo{
		pairs: make(map[string]*model.KnownCountryPair),
	}
}

func (f *fakeCountryPairRepo) key(userID int64, clientCode, countryA, countryB string) string {
	return clientCode + ":" + countryA + ":" + countryB
}

func (f *fakeCountryPairRepo) GetOneByCorridor(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, clientCode string, countryA, countryB string) (*model.KnownCountryPair, error) {
	if f.getErr != nil {
		return nil, f.getErr
	}
	pair, ok := f.pairs[f.key(userID, clientCode, countryA, countryB)]
	if !ok || pair == nil {
		return nil, pgx.ErrNoRows
	}
	return pair, nil
}

func (f *fakeCountryPairRepo) Upsert(_ context.Context, _ coreService.PostgreSQLServicer, row model.KnownCountryPair) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	f.upserted = append(f.upserted, row)
	f.pairs[f.key(row.UserID, row.ClientCode, row.CountryA, row.CountryB)] = &row
	return nil
}

func (f *fakeCountryPairRepo) ResetDecayed(_ context.Context, _ coreService.PostgreSQLServicer, id int64, now time.Time) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	for _, p := range f.pairs {
		if p.ID == id {
			p.Frequency = 1
			p.IsTrusted = false
			p.WindowStartedAt = now
			p.UpdatedAt = now
		}
	}
	return nil
}

// ---------- authenticator enrollments ----------

type fakeAuthenticatorEnrollmentRepo struct {
	enrollments map[string]*model.AuthenticatorEnrollment
	getErr      error
	writeErr    error
}

func newFakeAuthenticatorEnrollmentRepo() *fakeAuthenticatorEnrollmentRepo {
	return &fakeAuthenticatorEnrollmentRepo{
		enrollments: make(map[string]*model.AuthenticatorEnrollment),
	}
}

func (f *fakeAuthenticatorEnrollmentRepo) key(userID int64, clientCode string) string {
	return clientCode + ":" + string(rune(userID))
}

func (f *fakeAuthenticatorEnrollmentRepo) GetOneByUser(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, clientCode string) (*model.AuthenticatorEnrollment, error) {
	if f.getErr != nil {
		return nil, f.getErr
	}
	enr, ok := f.enrollments[f.key(userID, clientCode)]
	if !ok || enr == nil {
		return nil, pgx.ErrNoRows
	}
	return enr, nil
}

func (f *fakeAuthenticatorEnrollmentRepo) InsertOne(_ context.Context, _ coreService.PostgreSQLServicer, row model.AuthenticatorEnrollment) (int64, error) {
	if f.writeErr != nil {
		return 0, f.writeErr
	}
	f.enrollments[f.key(row.UserID, row.ClientCode)] = &row
	return row.ID, nil
}

func (f *fakeAuthenticatorEnrollmentRepo) Activate(_ context.Context, _ coreService.PostgreSQLServicer, id int64, enrolledAt time.Time) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	for _, enr := range f.enrollments {
		if enr.ID == id {
			enr.IsActive = true
			enr.EnrolledAt = &enrolledAt
		}
	}
	return nil
}

func (f *fakeAuthenticatorEnrollmentRepo) DeleteByUser(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, clientCode string) error {
	if f.writeErr != nil {
		return f.writeErr
	}
	delete(f.enrollments, f.key(userID, clientCode))
	return nil
}

// ---------- providers ----------

// fakePassword accepts exactly one password, so a test never pays for a real
// hash comparison and "wrong password" is unambiguous.
type fakePassword struct{ correct string }

func (f *fakePassword) Init()  {}
func (f *fakePassword) Close() {}
func (f *fakePassword) HashPassword(p string) (string, error) {
	return "hashed:" + p, nil
}
func (f *fakePassword) ComparePassword(_, plain string) error {
	if plain == f.correct {
		return nil
	}
	return errors.New("password mismatch")
}

type fakeCaptcha struct{ ok bool }

func (f *fakeCaptcha) Init()                                   {}
func (f *fakeCaptcha) Close()                                  {}
func (f *fakeCaptcha) Verify(_ context.Context, _ string) bool { return f.ok }

// ---------- helpers ----------

// policyClient stands in for enterprise-management's internal privacy-policy
// API. version == 0 serves 404 — nothing published.
//
// version is a JSON number, not a string: that is what enterprise-management
// serves (platform_privacy_policy.version is an int). A stub that quoted it
// let a type mismatch in the real client pass every test while the agreement
// gate silently never fired in production.
func policyClient(t *testing.T, version int) *client.EnterpriseManagementClient {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/internal/privacy-policy/active" || version == 0 {
			w.WriteHeader(http.StatusNotFound)
			return
		}
		_, _ = w.Write([]byte(`{"data":{"version":` + strconv.Itoa(version) + `}}`))
	}))
	t.Cleanup(srv.Close)
	return client.NewEnterpriseManagementClient(srv.URL, "test-token", false)
}

// fakeDBFactory hands every schema its own fake servicer, and remembers which
// schemas were asked for — the tenant one has to be the handoff row's client
// code, or the consent row lands in the wrong schema.
type fakeDBFactory struct{ schemas []string }

func (f *fakeDBFactory) factory() func(string) coreService.PostgreSQLServicer {
	return func(schema string) coreService.PostgreSQLServicer {
		f.schemas = append(f.schemas, schema)
		return &coreService.FakePostgreSQLService{}
	}
}

func (f *fakeDBFactory) sawSchema(schema string) bool {
	for _, s := range f.schemas {
		if s == schema {
			return true
		}
	}
	return false
}

func httpStatus(err error) int {
	var httpErr *coreEntity.HttpError
	if !errors.As(err, &httpErr) {
		return 0
	}
	return httpErr.Code
}
