package service

import (
	"context"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func TestEvaluateAgreementTriggers(t *testing.T) {
	now := time.Now()
	long := now.Add(-40 * 24 * time.Hour)
	recent := now.Add(-time.Hour)
	current := "2"
	stale := "1"

	cases := []struct {
		name         string
		firstLoginAt *time.Time
		lastLogoutAt *time.Time
		consent      *model.UserPrivacyConsent
		consentErr   error
		want         bool
	}{
		{"never logged in", nil, nil, &model.UserPrivacyConsent{AcceptedVersion: &current}, nil, true},
		{"idle 40 days", &recent, &long, &model.UserPrivacyConsent{AcceptedVersion: &current}, nil, true},
		{"no consent row", &recent, &recent, nil, pgx.ErrNoRows, true},
		{"stale version", &recent, &recent, &model.UserPrivacyConsent{AcceptedVersion: &stale}, nil, true},
		{"null version", &recent, &recent, &model.UserPrivacyConsent{}, nil, true},
		// Never logged out is not a measuring point — it must not fire (b).
		{"current consent, never logged out", &recent, nil, &model.UserPrivacyConsent{AcceptedVersion: &current}, nil, false},
		{"current consent, recent logout", &recent, &recent, &model.UserPrivacyConsent{AcceptedVersion: &current}, nil, false},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			svc := &AuthService{
				consentRepo:           &fakeConsentRepo{row: tc.consent, err: tc.consentErr},
				generalSettingsClient: policyClient(t, 2),
			}
			got, version, err := svc.evaluateAgreementTriggers(context.Background(), &coreService.FakePostgreSQLService{}, 7, tc.firstLoginAt, tc.lastLogoutAt)
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			if got != tc.want {
				t.Fatalf("triggered = %v, want %v", got, tc.want)
			}
			if version != current {
				t.Fatalf("policyVersion = %q, want %q", version, current)
			}
		})
	}
}

// No published policy (404) or an unreachable enterprise-management must not
// park a login behind a consent screen that has no text and no version.
func TestEvaluateAgreementTriggersWithoutPublishedPolicy(t *testing.T) {
	svc := &AuthService{
		consentRepo:           &fakeConsentRepo{err: pgx.ErrNoRows},
		generalSettingsClient: policyClient(t, 0),
	}

	triggered, version, err := svc.evaluateAgreementTriggers(context.Background(), &coreService.FakePostgreSQLService{}, 7, nil, nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if triggered || version != "" {
		t.Fatalf("triggered = %v, version = %q; want false, \"\"", triggered, version)
	}
}
