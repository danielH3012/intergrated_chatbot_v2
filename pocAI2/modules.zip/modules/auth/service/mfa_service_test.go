package service

import (
	"context"
	"encoding/json"
	"errors"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// The MFA handoff replaced POST /auth/mfa/evaluate: the client routes to one
// of four factor-2 pages using only what factor-1 returned. These assert the
// contract that makes that possible — if a field stops being emitted, the
// client silently loses a branch and there is no evaluate call left to
// recover it.

func mfaLoginResponse(h *MfaHandoff) dto.LoginResponse {
	return dto.LoginResponse{
		Outcome:               constant.OutcomeMfaRequired,
		MfaReason:             &h.Reason,
		PreAuthToken:          &h.PreAuthToken,
		Factor1Method:         &h.Factor1Method,
		AuthenticatorEnrolled: &h.AuthenticatorEnrolled,
		MfaEmail:              &h.Email,
	}
}

func TestMfaHandoff_CarriesEveryRoutingField(t *testing.T) {
	h := &MfaHandoff{
		Reason:                constant.MfaReasonUnusualLogin,
		PreAuthToken:          "pat_abc123",
		Factor1Method:         constant.Factor1MethodPassword,
		AuthenticatorEnrolled: false,
		Email:                 "john@email.com",
	}

	raw, err := json.Marshal(mfaLoginResponse(h))
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal(raw, &got); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}

	// Every field the client needs to pick a page without a second call.
	want := map[string]any{
		"outcome":               constant.OutcomeMfaRequired,
		"mfaReason":             string(constant.MfaReasonUnusualLogin),
		"preAuthToken":          "pat_abc123",
		"factor1Method":         string(constant.Factor1MethodPassword),
		"authenticatorEnrolled": false,
		"mfaEmail":              "john@email.com",
	}
	for k, v := range want {
		if got[k] != v {
			t.Errorf("%s = %v, want %v", k, got[k], v)
		}
	}
}

func TestMfaHandoff_EnrolledFalseIsEmitted(t *testing.T) {
	h := &MfaHandoff{Factor1Method: constant.Factor1MethodOtp, AuthenticatorEnrolled: false}

	raw, err := json.Marshal(mfaLoginResponse(h))
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal(raw, &got); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if _, ok := got["authenticatorEnrolled"]; !ok {
		t.Fatal("authenticatorEnrolled omitted when false; client would route to Verification instead of Enrollment")
	}
	if got["authenticatorEnrolled"] != false {
		t.Errorf("authenticatorEnrolled = %v, want false", got["authenticatorEnrolled"])
	}
}

func TestLoginResponse_NoMfaFieldsOnSuccess(t *testing.T) {
	token := "sess_xyz"
	raw, err := json.Marshal(dto.LoginResponse{
		Outcome:   constant.OutcomeSuccess,
		SessionID: &token,
	})
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal(raw, &got); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	for _, k := range []string{"mfaReason", "preAuthToken", "factor1Method", "authenticatorEnrolled", "mfaEmail"} {
		if _, ok := got[k]; ok {
			t.Errorf("%s present on a success response", k)
		}
	}
}

func TestOtpVerifyResponse_MfaHandoff(t *testing.T) {
	h := &MfaHandoff{
		Reason:                constant.MfaReasonFirstLogin,
		PreAuthToken:          "pat_def456",
		Factor1Method:         constant.Factor1MethodOtp,
		AuthenticatorEnrolled: true,
	}

	raw, err := json.Marshal(dto.OtpVerifyResponse{
		Outcome:               constant.OutcomeMfaRequired,
		MfaReason:             &h.Reason,
		PreAuthToken:          &h.PreAuthToken,
		Factor1Method:         &h.Factor1Method,
		AuthenticatorEnrolled: &h.AuthenticatorEnrolled,
	})
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal(raw, &got); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if got["factor1Method"] != string(constant.Factor1MethodOtp) {
		t.Errorf("factor1Method = %v, want otp", got["factor1Method"])
	}
	if got["preAuthToken"] != "pat_def456" {
		t.Errorf("preAuthToken = %v, want pat_def456", got["preAuthToken"])
	}
}

// -------------------------------------------------------------
// Test Fixture for MFA Service Tests
// -------------------------------------------------------------

type mfaFixture struct {
	svc         *AuthService
	user        *fakeUserRepo
	preAuth     *fakePreAuthRepo
	devices     *fakeTrustedDeviceRepo
	pairs       *fakeCountryPairRepo
	enrollments *fakeAuthenticatorEnrollmentRepo
	sessions    *fakeSessionRepo
	otp         *fakeOtpRepo
	db          *fakeDBFactory
	key         []byte
}

type fakeOtpRepo struct {
	rows        []*model.OtpCode
	consumedIDs []int64
}

func (f *fakeOtpRepo) GetOneByHashForUpdate(_ context.Context, _ coreService.PostgreSQLServicer, email, clientCode, codeHash, purpose string) (*model.OtpCode, error) {
	for _, r := range f.rows {
		if r.Email == email && r.ClientCode == clientCode && r.CodeHash == codeHash && r.Purpose == purpose {
			return r, nil
		}
	}
	return nil, pgx.ErrNoRows
}

func (f *fakeOtpRepo) GetLatestByHashAndClient(_ context.Context, _ coreService.PostgreSQLServicer, clientCode, codeHash, purpose string) (*model.OtpCode, error) {
	for _, r := range f.rows {
		if r.ClientCode == clientCode && r.CodeHash == codeHash && r.Purpose == purpose {
			return r, nil
		}
	}
	return nil, pgx.ErrNoRows
}

func (f *fakeOtpRepo) GetLatestInSession(_ context.Context, _ coreService.PostgreSQLServicer, email, clientCode string, otpSessionID int64) (*model.OtpCode, error) {
	var latest *model.OtpCode
	for _, r := range f.rows {
		if r.Email == email && r.ClientCode == clientCode && r.OtpSessionID == otpSessionID {
			latest = r
		}
	}
	if latest == nil {
		return nil, pgx.ErrNoRows
	}
	return latest, nil
}

func (f *fakeOtpRepo) InvalidateActive(_ context.Context, _ coreService.PostgreSQLServicer, email, clientCode, purpose string) error {
	now := time.Now()
	for _, r := range f.rows {
		if r.Email == email && r.ClientCode == clientCode && r.Purpose == purpose && r.ConsumedAt == nil && r.InvalidatedAt == nil {
			r.InvalidatedAt = &now
		}
	}
	return nil
}

func (f *fakeOtpRepo) InsertOne(_ context.Context, _ coreService.PostgreSQLServicer, row model.OtpCode) (int64, error) {
	row.ID = int64(len(f.rows) + 1)
	f.rows = append(f.rows, &row)
	return row.ID, nil
}

func (f *fakeOtpRepo) Consume(_ context.Context, _ coreService.PostgreSQLServicer, id int64) error {
	now := time.Now()
	for _, r := range f.rows {
		if r.ID == id {
			r.ConsumedAt = &now
			f.consumedIDs = append(f.consumedIDs, id)
			return nil
		}
	}
	return nil
}

func (f *fakeOtpRepo) DeleteCreatedBefore(_ context.Context, _ coreService.PostgreSQLServicer, _ time.Time) (int64, error) {
	return 0, nil
}

func newMfaFixture(t *testing.T) *mfaFixture {
	t.Helper()

	encKey := []byte("platform-aes-256-secret-test-key-32b")
	yesterday := time.Now().Add(-24 * time.Hour)
	f := &mfaFixture{
		user: &fakeUserRepo{
			user: &userDto.UserListItem{
				ID:                      7,
				Email:                   "user@example.com",
				IsActive:                true,
				ActivationStatus:        constant.ActivationStatusActivated,
				FirstLoginAt:            &yesterday,
				IsAuthenticatorEnrolled: false,
			},
		},
		preAuth:     &fakePreAuthRepo{},
		devices:     newFakeTrustedDeviceRepo(),
		pairs:       newFakeCountryPairRepo(),
		enrollments: newFakeAuthenticatorEnrollmentRepo(),
		sessions:    &fakeSessionRepo{},
		otp:         &fakeOtpRepo{},
		db:          &fakeDBFactory{},
		key:         encKey,
	}

	f.svc = &AuthService{
		userRepo:          f.user,
		preAuthRepo:       f.preAuth,
		trustedDeviceRepo: f.devices,
		countryPairRepo:   f.pairs,
		authenticatorRepo: f.enrollments,
		sessionRepo:       f.sessions,
		otpRepo:           f.otp,
		otpHashKey:        []byte("otp-test-hash-key"),
		encryptionKey:     encKey,
	}
	f.svc.SetServiceFactoryForTest(f.db.factory())
	return f
}

func TestEvaluateMfaTriggers_FirstLogin(t *testing.T) {
	f := newMfaFixture(t)
	f.user.user.FirstLoginAt = nil // Never logged in before

	reason, triggered, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-1", nil, nil, "ID",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if !triggered || reason != constant.MfaReasonFirstLogin {
		t.Fatalf("expected trigger first_login, got triggered=%v, reason=%v", triggered, reason)
	}
}

func TestEvaluateMfaTriggers_Idle30d(t *testing.T) {
	f := newMfaFixture(t)
	oldLogout := time.Now().Add(-35 * 24 * time.Hour) // 35 days idle
	f.user.user.LastLogoutAt = &oldLogout

	reason, triggered, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-1", nil, nil, "ID",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if !triggered || reason != constant.MfaReasonIdle30d {
		t.Fatalf("expected trigger idle_30d, got triggered=%v, reason=%v", triggered, reason)
	}
}

func TestEvaluateMfaTriggers_UnusualLogin_UntrustedDevice(t *testing.T) {
	f := newMfaFixture(t)
	// No trusted device in repo for device-unknown

	reason, triggered, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-unknown", nil, nil, "ID",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if !triggered || reason != constant.MfaReasonUnusualLogin {
		t.Fatalf("expected trigger unusual_login for unknown device, got triggered=%v, reason=%v", triggered, reason)
	}
}

func TestEvaluateMfaTriggers_UnusualLogin_LocationDistance(t *testing.T) {
	f := newMfaFixture(t)
	// Trust device in Jakarta
	jktLat, jktLon := -6.2088, 106.8456
	f.devices.devices[f.devices.key(7, "acme", constant.PlatformWeb, "device-1")] = &model.TrustedDevice{
		UserID: 7, ClientCode: "acme", Platform: constant.PlatformWeb, DeviceID: "device-1",
		LastLoginLat: &jktLat, LastLoginLon: &jktLon, LastLoginCountry: ptr("ID"),
	}

	// Login from Bandung (~120km away > 100km threshold)
	bdgLat, bdgLon := -6.9175, 107.6191
	reason, triggered, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-1", &bdgLat, &bdgLon, "ID",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if !triggered || reason != constant.MfaReasonUnusualLogin {
		t.Fatalf("expected trigger unusual_login for distance > 100km, got triggered=%v, reason=%v", triggered, reason)
	}
}

func TestEvaluateMfaTriggers_CountryCorridor_DecayAndTrust(t *testing.T) {
	f := newMfaFixture(t)
	f.devices.devices[f.devices.key(7, "acme", constant.PlatformWeb, "device-1")] = &model.TrustedDevice{
		UserID: 7, ClientCode: "acme", Platform: constant.PlatformWeb, DeviceID: "device-1",
		LastLoginCountry: ptr("ID"),
	}

	// Untrusted corridor (frequency < 3)
	f.pairs.pairs[f.pairs.key(7, "acme", "ID", "SG")] = &model.KnownCountryPair{
		ID: 1, UserID: 7, ClientCode: "acme", CountryA: "ID", CountryB: "SG",
		Frequency: 2, IsTrusted: false, WindowStartedAt: time.Now(), LastSeenAt: time.Now(),
	}

	reason, triggered, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-1", nil, nil, "SG",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if !triggered || reason != constant.MfaReasonUnusualLogin {
		t.Fatalf("expected trigger unusual_login for untrusted country corridor")
	}

	// Trusted corridor (is_trusted = true) -> should NOT trigger unusual login
	f.pairs.pairs[f.pairs.key(7, "acme", "ID", "SG")].IsTrusted = true
	_, triggeredTrusted, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-1", nil, nil, "SG",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if triggeredTrusted {
		t.Fatalf("trusted corridor should not trigger unusual login")
	}

	// Decayed corridor (>180 days since last seen) -> triggers unusual login and resets
	f.pairs.pairs[f.pairs.key(7, "acme", "ID", "SG")].LastSeenAt = time.Now().Add(-190 * 24 * time.Hour)
	_, triggeredDecayed, err := f.svc.evaluateMfaTriggers(
		context.Background(),
		f.db.factory()("public"),
		f.db.factory()("acme"),
		7, "acme", constant.PlatformWeb, "device-1", nil, nil, "SG",
	)
	if err != nil {
		t.Fatalf("evaluateMfaTriggers failed: %v", err)
	}
	if !triggeredDecayed {
		t.Fatalf("decayed corridor should trigger unusual login")
	}
}

func TestEnrollAndVerifyAuthenticator(t *testing.T) {
	f := newMfaFixture(t)
	preAuthToken := "raw-pre-auth-token-123"
	factor1 := constant.Factor1MethodPassword
	mfaReason := constant.MfaReasonFirstLogin
	f.preAuth.row = &model.PreAuthSession{
		ID:            10,
		UserID:        7,
		ClientCode:    "acme",
		TokenHash:     helper.HashToken(preAuthToken),
		Purpose:       constant.PreAuthPurposeMfa,
		Status:        constant.PreAuthStatusActive,
		Factor1Method: &factor1,
		MfaReason:     &mfaReason,
		ExpiresAt:     time.Now().Add(10 * time.Minute),
	}

	// 1. Enroll
	enrollResp, err := f.svc.EnrollMfaAuthenticator(context.Background(), dto.MfaEnrollRequest{
		PreAuthToken: preAuthToken,
	})
	if err != nil {
		t.Fatalf("EnrollMfaAuthenticator failed: %v", err)
	}
	if enrollResp.SecretKey == "" || enrollResp.QrCodeURI == "" {
		t.Fatalf("expected non-empty secretKey and qrCodeUri")
	}

	// Idempotency: re-enrolling returns same secret
	reEnroll, err := f.svc.EnrollMfaAuthenticator(context.Background(), dto.MfaEnrollRequest{
		PreAuthToken: preAuthToken,
	})
	if err != nil {
		t.Fatalf("re-enroll failed: %v", err)
	}
	if reEnroll.SecretKey != enrollResp.SecretKey {
		t.Fatalf("enrollment not idempotent: %s != %s", reEnroll.SecretKey, enrollResp.SecretKey)
	}

	// 2. Verify with wrong code -> fails
	verifyBad, err := f.svc.VerifyEnrollMfaAuthenticator(context.Background(), dto.MfaEnrollVerifyRequest{
		PreAuthToken: preAuthToken,
		VerifyCode:   "000000",
	}, "127.0.0.1")
	if err != nil {
		t.Fatalf("VerifyEnrollMfaAuthenticator error: %v", err)
	}
	if verifyBad.Outcome != constant.OutcomeFailed || *verifyBad.ErrorCode != constant.ErrorCodeVerifyInvalid {
		t.Fatalf("expected outcome failed with VERIFY_INVALID, got %+v", verifyBad)
	}

	// 3. Verify with valid TOTP code
	secretBytes, _ := helper.DecodeTOTPSecret(enrollResp.SecretKey)
	validCode := helper.GenerateTOTPCode(secretBytes, time.Now())

	verifyGood, err := f.svc.VerifyEnrollMfaAuthenticator(context.Background(), dto.MfaEnrollVerifyRequest{
		PreAuthToken: preAuthToken,
		VerifyCode:   validCode,
	}, "127.0.0.1")
	if err != nil {
		t.Fatalf("VerifyEnrollMfaAuthenticator failed: %v", err)
	}
	if verifyGood.Outcome != constant.OutcomeSuccess {
		t.Fatalf("expected outcome success, got %+v", verifyGood)
	}
	if !f.user.user.IsAuthenticatorEnrolled {
		t.Fatalf("expected users.is_authenticator_enrolled to be true after successful enrollment verify")
	}
}

func TestVerifyMfaAuthenticator_LoginFinal(t *testing.T) {
	f := newMfaFixture(t)
	preAuthToken := "raw-pre-auth-token-456"
	factor1 := constant.Factor1MethodPassword
	mfaReason := constant.MfaReasonUnusualLogin
	f.preAuth.row = &model.PreAuthSession{
		ID:            20,
		UserID:        7,
		ClientCode:    "acme",
		TokenHash:     helper.HashToken(preAuthToken),
		Purpose:       constant.PreAuthPurposeMfa,
		Status:        constant.PreAuthStatusActive,
		Factor1Method: &factor1,
		MfaReason:     &mfaReason,
		ExpiresAt:     time.Now().Add(10 * time.Minute),
	}

	// Setup active enrollment
	rawSecret, base32Secret, _ := helper.GenerateTOTPSecret()
	encSecret, _ := helper.EncryptSecret([]byte(base32Secret), f.key)
	f.enrollments.enrollments[f.enrollments.key(7, "acme")] = &model.AuthenticatorEnrollment{
		ID: 1, UserID: 7, ClientCode: "acme", SecretEncrypted: encSecret, IsActive: true,
	}

	validCode := helper.GenerateTOTPCode(rawSecret, time.Now())

	resp, err := f.svc.VerifyMfaAuthenticator(context.Background(), dto.MfaAuthenticatorVerifyRequest{
		PreAuthToken: preAuthToken,
		TotpCode:     validCode,
		DeviceID:     "device-mfa-1",
	}, "127.0.0.1")
	if err != nil {
		t.Fatalf("VerifyMfaAuthenticator failed: %v", err)
	}
	if resp.Outcome != constant.OutcomeSuccess || resp.SessionToken == nil {
		t.Fatalf("expected outcome success with sessionToken, got %+v", resp)
	}
	if len(f.preAuth.consumed) != 1 || f.preAuth.consumed[0] != 20 {
		t.Fatalf("expected preAuth row 20 to be consumed, got %v", f.preAuth.consumed)
	}
}

func TestMfaFactor2_UserDeactivatedMidFlow(t *testing.T) {
	// Deactivate user mid-flow (TC-AUTH-MFA-87, TC-AUTH-MFA-119)

	t.Run("VerifyMfaOtp rejects inactive user with INACTIVE", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_inactive_otp"
		factor1 := constant.Factor1MethodPassword
		mfaReason := constant.MfaReasonUnusualLogin
		f.preAuth.row = &model.PreAuthSession{
			ID:            31,
			UserID:        7,
			ClientCode:    "acme",
			TokenHash:     helper.HashToken(preAuthToken),
			Purpose:       constant.PreAuthPurposeMfa,
			Status:        constant.PreAuthStatusActive,
			Factor1Method: &factor1,
			MfaReason:     &mfaReason,
			ExpiresAt:     time.Now().Add(10 * time.Minute),
		}
		f.user.user.IsActive = false

		otpResp, err := f.svc.VerifyMfaOtp(context.Background(), dto.MfaOtpVerifyRequest{
			PreAuthToken: preAuthToken,
			OtpCode:      "123456",
			DeviceID:     "device-1",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if otpResp.Outcome != constant.OutcomeFailed || otpResp.ErrorCode == nil || *otpResp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("expected outcome failed with ErrorCode INACTIVE, got %+v", otpResp)
		}
	})

	t.Run("VerifyMfaAuthenticator rejects inactive user with INACTIVE", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_inactive_totp"
		factor1 := constant.Factor1MethodPassword
		mfaReason := constant.MfaReasonUnusualLogin
		f.preAuth.row = &model.PreAuthSession{
			ID:            32,
			UserID:        7,
			ClientCode:    "acme",
			TokenHash:     helper.HashToken(preAuthToken),
			Purpose:       constant.PreAuthPurposeMfa,
			Status:        constant.PreAuthStatusActive,
			Factor1Method: &factor1,
			MfaReason:     &mfaReason,
			ExpiresAt:     time.Now().Add(10 * time.Minute),
		}
		f.user.user.IsActive = false

		totpResp, err := f.svc.VerifyMfaAuthenticator(context.Background(), dto.MfaAuthenticatorVerifyRequest{
			PreAuthToken: preAuthToken,
			TotpCode:     "123456",
			DeviceID:     "device-1",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if totpResp.Outcome != constant.OutcomeFailed || totpResp.ErrorCode == nil || *totpResp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("expected outcome failed with ErrorCode INACTIVE, got %+v", totpResp)
		}
	})

	t.Run("SendMfaOtp rejects inactive user with INACTIVE", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_inactive_send"
		factor1 := constant.Factor1MethodPassword
		mfaReason := constant.MfaReasonUnusualLogin
		f.preAuth.row = &model.PreAuthSession{
			ID:            33,
			UserID:        7,
			ClientCode:    "acme",
			TokenHash:     helper.HashToken(preAuthToken),
			Purpose:       constant.PreAuthPurposeMfa,
			Status:        constant.PreAuthStatusActive,
			Factor1Method: &factor1,
			MfaReason:     &mfaReason,
			ExpiresAt:     time.Now().Add(10 * time.Minute),
		}
		f.user.user.IsActive = false

		sendResp, err := f.svc.SendMfaOtp(context.Background(), dto.MfaOtpSendRequest{
			PreAuthToken: preAuthToken,
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if sendResp.Outcome != constant.OutcomeFailed || sendResp.ErrorCode == nil || *sendResp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("expected outcome failed with ErrorCode INACTIVE, got %+v", sendResp)
		}
	})
}

func TestSendMfaOtp_SessionIDValidation(t *testing.T) {
	f := newMfaFixture(t)
	preAuthToken := "pat_valid_session"
	factor1 := constant.Factor1MethodPassword
	mfaReason := constant.MfaReasonUnusualLogin
	f.preAuth.row = &model.PreAuthSession{
		ID:            34,
		UserID:        7,
		ClientCode:    "acme",
		TokenHash:     helper.HashToken(preAuthToken),
		Purpose:       constant.PreAuthPurposeMfa,
		Status:        constant.PreAuthStatusActive,
		Factor1Method: &factor1,
		MfaReason:     &mfaReason,
		ExpiresAt:     time.Now().Add(10 * time.Minute),
	}

	t.Run("rejects empty string otpSessionId with bad request", func(t *testing.T) {
		emptyStr := ""
		_, err := f.svc.SendMfaOtp(context.Background(), dto.MfaOtpSendRequest{
			PreAuthToken: preAuthToken,
			OtpSessionID: &emptyStr,
		}, "127.0.0.1")
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})

	t.Run("rejects whitespace-only otpSessionId with bad request", func(t *testing.T) {
		spaceStr := "   "
		_, err := f.svc.SendMfaOtp(context.Background(), dto.MfaOtpSendRequest{
			PreAuthToken: preAuthToken,
			OtpSessionID: &spaceStr,
		}, "127.0.0.1")
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})

	t.Run("rejects non-numeric otpSessionId with bad request", func(t *testing.T) {
		invalidStr := "abc-not-a-number"
		_, err := f.svc.SendMfaOtp(context.Background(), dto.MfaOtpSendRequest{
			PreAuthToken: preAuthToken,
			OtpSessionID: &invalidStr,
		}, "127.0.0.1")
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})

	t.Run("rejects negative or zero otpSessionId with bad request", func(t *testing.T) {
		negStr := "-10"
		_, err := f.svc.SendMfaOtp(context.Background(), dto.MfaOtpSendRequest{
			PreAuthToken: preAuthToken,
			OtpSessionID: &negStr,
		}, "127.0.0.1")
		if err == nil {
			t.Fatal("expected error, got nil")
		}
		var httpErr *coreEntity.HttpError
		if !errors.As(err, &httpErr) || httpErr.Code != 400 {
			t.Fatalf("expected 400 bad request, got %v", err)
		}
	})
}

func TestMfaConcurrency_CrossActionRace(t *testing.T) {
	// TC-AUTH-MFA-121: Verify OTP vs Verify Authenticator on same mfa_session (2 tabs)
	t.Run("TC-AUTH-MFA-121 Verify OTP wins -> Verify Authenticator rejected as PRE_AUTH_SESSION_EXPIRED", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_race_121"
		factor1 := constant.Factor1MethodPassword
		mfaReason := constant.MfaReasonUnusualLogin
		f.preAuth.row = &model.PreAuthSession{
			ID:            41,
			UserID:        7,
			ClientCode:    "acme",
			TokenHash:     helper.HashToken(preAuthToken),
			Purpose:       constant.PreAuthPurposeMfa,
			Status:        constant.PreAuthStatusActive,
			Factor1Method: &factor1,
			MfaReason:     &mfaReason,
			ExpiresAt:     time.Now().Add(10 * time.Minute),
		}

		// Setup valid OTP code in fakeOtpRepo (Tab A)
		otpCode := "654321"
		f.otp.rows = append(f.otp.rows, &model.OtpCode{
			ID:         101,
			Email:      "user@example.com",
			ClientCode: "acme",
			CodeHash:   f.svc.hashOTP(otpCode),
			Purpose:    constant.OtpPurposeMfa,
			ExpiresAt:  time.Now().Add(5 * time.Minute),
		})

		// Setup active authenticator enrollment with valid TOTP (Tab B)
		rawSecret, base32Secret, _ := helper.GenerateTOTPSecret()
		encSecret, _ := helper.EncryptSecret([]byte(base32Secret), f.key)
		f.enrollments.enrollments[f.enrollments.key(7, "acme")] = &model.AuthenticatorEnrollment{
			ID: 1, UserID: 7, ClientCode: "acme", SecretEncrypted: encSecret, IsActive: true,
		}
		validTotp := helper.GenerateTOTPCode(rawSecret, time.Now())

		// 1. Tab A verifies OTP successfully -> consumes pre_auth session
		tabAResp, err := f.svc.VerifyMfaOtp(context.Background(), dto.MfaOtpVerifyRequest{
			PreAuthToken: preAuthToken,
			OtpCode:      otpCode,
			DeviceID:     "device-tab-a",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("Tab A VerifyMfaOtp failed: %v", err)
		}
		if tabAResp.Outcome != constant.OutcomeSuccess || tabAResp.SessionToken == nil {
			t.Fatalf("Tab A expected outcome success, got %+v", tabAResp)
		}

		// 2. Tab B tries to verify Authenticator with same preAuthToken -> rejected as PRE_AUTH_SESSION_EXPIRED (NOT TOTP_INVALID)
		tabBResp, err := f.svc.VerifyMfaAuthenticator(context.Background(), dto.MfaAuthenticatorVerifyRequest{
			PreAuthToken: preAuthToken,
			TotpCode:     validTotp,
			DeviceID:     "device-tab-b",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("Tab B VerifyMfaAuthenticator error: %v", err)
		}
		if tabBResp.Outcome != constant.OutcomeFailed || tabBResp.ErrorCode == nil || *tabBResp.ErrorCode != constant.ErrorCodePreAuthSessionExpired {
			t.Fatalf("Tab B expected outcome failed with PRE_AUTH_SESSION_EXPIRED, got %+v", tabBResp)
		}

		// Verify session was created only once and preAuth was consumed once
		if len(f.preAuth.consumed) != 1 || f.preAuth.consumed[0] != 41 {
			t.Fatalf("expected preAuth row 41 consumed exactly once, got %v", f.preAuth.consumed)
		}
	})

	// TC-AUTH-MFA-122: Enrollment Verify vs Verify OTP on same mfa_session
	t.Run("TC-AUTH-MFA-122 Verify OTP wins -> Enrollment Verify rejected and is_active remains false", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_race_122"
		factor1 := constant.Factor1MethodPassword
		mfaReason := constant.MfaReasonUnusualLogin
		f.preAuth.row = &model.PreAuthSession{
			ID:            42,
			UserID:        7,
			ClientCode:    "acme",
			TokenHash:     helper.HashToken(preAuthToken),
			Purpose:       constant.PreAuthPurposeMfa,
			Status:        constant.PreAuthStatusActive,
			Factor1Method: &factor1,
			MfaReason:     &mfaReason,
			ExpiresAt:     time.Now().Add(10 * time.Minute),
		}

		// Tab A initiated enrollment (unactivated record)
		rawSecret, base32Secret, _ := helper.GenerateTOTPSecret()
		encSecret, _ := helper.EncryptSecret([]byte(base32Secret), f.key)
		f.enrollments.enrollments[f.enrollments.key(7, "acme")] = &model.AuthenticatorEnrollment{
			ID: 2, UserID: 7, ClientCode: "acme", SecretEncrypted: encSecret, IsActive: false,
		}
		validSetupCode := helper.GenerateTOTPCode(rawSecret, time.Now())

		// Setup valid OTP code in fakeOtpRepo (Tab B)
		otpCode := "112233"
		f.otp.rows = append(f.otp.rows, &model.OtpCode{
			ID:         102,
			Email:      "user@example.com",
			ClientCode: "acme",
			CodeHash:   f.svc.hashOTP(otpCode),
			Purpose:    constant.OtpPurposeMfa,
			ExpiresAt:  time.Now().Add(5 * time.Minute),
		})

		// 1. Tab B verifies OTP successfully first -> consumes pre_auth session
		tabBResp, err := f.svc.VerifyMfaOtp(context.Background(), dto.MfaOtpVerifyRequest{
			PreAuthToken: preAuthToken,
			OtpCode:      otpCode,
			DeviceID:     "device-tab-b",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("Tab B VerifyMfaOtp failed: %v", err)
		}
		if tabBResp.Outcome != constant.OutcomeSuccess || tabBResp.SessionToken == nil {
			t.Fatalf("Tab B expected outcome success, got %+v", tabBResp)
		}

		// 2. Tab A tries to submit enrollment verify code -> rejected as PRE_AUTH_SESSION_EXPIRED
		tabAResp, err := f.svc.VerifyEnrollMfaAuthenticator(context.Background(), dto.MfaEnrollVerifyRequest{
			PreAuthToken: preAuthToken,
			VerifyCode:   validSetupCode,
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("Tab A VerifyEnrollMfaAuthenticator error: %v", err)
		}
		if tabAResp.Outcome != constant.OutcomeFailed || tabAResp.ErrorCode == nil || *tabAResp.ErrorCode != constant.ErrorCodePreAuthSessionExpired {
			t.Fatalf("Tab A expected outcome failed with PRE_AUTH_SESSION_EXPIRED, got %+v", tabAResp)
		}

		// Ensure enrollment remains unactivated (is_active = false)
		enr := f.enrollments.enrollments[f.enrollments.key(7, "acme")]
		if enr.IsActive {
			t.Fatalf("expected authenticator enrollment is_active to remain false, but got true")
		}
		if f.user.user.IsAuthenticatorEnrolled {
			t.Fatalf("expected users.is_authenticator_enrolled to remain false")
		}
	})

	t.Run("TC-AUTH-MFA-54 Active Authenticator Enrollment Cannot Re-enroll or Leak Secret", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_active_enroll"
		f.preAuth.row = &model.PreAuthSession{
			ID:         42,
			UserID:     7,
			ClientCode: "acme",
			TokenHash:  helper.HashToken(preAuthToken),
			Purpose:    constant.PreAuthPurposeMfa,
			Status:     constant.PreAuthStatusActive,
			ExpiresAt:  time.Now().Add(10 * time.Minute),
		}

		rawSecret, base32Secret, _ := helper.GenerateTOTPSecret()
		encSecret, _ := helper.EncryptSecret([]byte(base32Secret), f.key)
		_ = rawSecret
		f.enrollments.enrollments[f.enrollments.key(7, "acme")] = &model.AuthenticatorEnrollment{
			ID: 2, UserID: 7, ClientCode: "acme", SecretEncrypted: encSecret, IsActive: true,
		}

		_, err := f.svc.EnrollMfaAuthenticator(context.Background(), dto.MfaEnrollRequest{
			PreAuthToken: preAuthToken,
		})
		if err == nil {
			t.Fatalf("expected EnrollMfaAuthenticator to fail for already active enrollment, but got nil error")
		}
	})

	t.Run("TC-AUTH-MFA-88 Missing or Deleted User during MFA returns INACTIVE gracefully", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_deleted_user"
		resetActivePreAuth := func() {
			f.preAuth.row = &model.PreAuthSession{
				ID:         42,
				UserID:     99999, // user does not exist
				ClientCode: "acme",
				TokenHash:  helper.HashToken(preAuthToken),
				Purpose:    constant.PreAuthPurposeMfa,
				Status:     constant.PreAuthStatusActive,
				ExpiresAt:  time.Now().Add(10 * time.Minute),
			}
		}
		f.user.err = pgx.ErrNoRows

		// 1. SendMfaOtp
		resetActivePreAuth()
		sendResp, err := f.svc.SendMfaOtp(context.Background(), dto.MfaOtpSendRequest{
			PreAuthToken: preAuthToken,
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("unexpected 500 error on SendMfaOtp: %v", err)
		}
		if sendResp.Outcome != constant.OutcomeFailed || sendResp.ErrorCode == nil || *sendResp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("expected INACTIVE on SendMfaOtp, got %+v", sendResp)
		}

		// 2. VerifyMfaOtp
		resetActivePreAuth()
		verifyOtpResp, err := f.svc.VerifyMfaOtp(context.Background(), dto.MfaOtpVerifyRequest{
			PreAuthToken: preAuthToken,
			OtpCode:      "123456",
			DeviceID:     "dev-1",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("unexpected 500 error on VerifyMfaOtp: %v", err)
		}
		if verifyOtpResp.Outcome != constant.OutcomeFailed || verifyOtpResp.ErrorCode == nil || *verifyOtpResp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("expected INACTIVE on VerifyMfaOtp, got %+v", verifyOtpResp)
		}

		// 3. VerifyMfaAuthenticator
		resetActivePreAuth()
		verifyAuthResp, err := f.svc.VerifyMfaAuthenticator(context.Background(), dto.MfaAuthenticatorVerifyRequest{
			PreAuthToken: preAuthToken,
			TotpCode:     "123456",
			DeviceID:     "dev-1",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("unexpected 500 error on VerifyMfaAuthenticator: %v", err)
		}
		if verifyAuthResp.Outcome != constant.OutcomeFailed || verifyAuthResp.ErrorCode == nil || *verifyAuthResp.ErrorCode != constant.ErrorCodeInactive {
			t.Fatalf("expected INACTIVE on VerifyMfaAuthenticator, got %+v", verifyAuthResp)
		}
	})

	t.Run("TC-AUTH-MFA-40 Finalizing MFA via Authenticator invalidates pending Email OTP codes", func(t *testing.T) {
		f := newMfaFixture(t)
		preAuthToken := "pat_switch_method"
		factor1 := constant.Factor1MethodPassword
		f.preAuth.row = &model.PreAuthSession{
			ID:            42,
			UserID:        7,
			ClientCode:    "acme",
			TokenHash:     helper.HashToken(preAuthToken),
			Purpose:       constant.PreAuthPurposeMfa,
			Status:        constant.PreAuthStatusActive,
			Factor1Method: &factor1,
			ExpiresAt:     time.Now().Add(10 * time.Minute),
		}

		// User requested an OTP email first
		otpCode := "654321"
		otpRow := &model.OtpCode{
			ID:         201,
			Email:      "user@example.com",
			ClientCode: "acme",
			CodeHash:   f.svc.hashOTP(otpCode),
			Purpose:    constant.OtpPurposeMfa,
			ExpiresAt:  time.Now().Add(5 * time.Minute),
		}
		f.otp.rows = append(f.otp.rows, otpRow)

		// User switches to Authenticator and verifies with TOTP
		rawSecret, base32Secret, _ := helper.GenerateTOTPSecret()
		encSecret, _ := helper.EncryptSecret([]byte(base32Secret), f.key)
		f.enrollments.enrollments[f.enrollments.key(7, "acme")] = &model.AuthenticatorEnrollment{
			ID: 2, UserID: 7, ClientCode: "acme", SecretEncrypted: encSecret, IsActive: true,
		}
		totpCode := helper.GenerateTOTPCode(rawSecret, time.Now())

		verifyResp, err := f.svc.VerifyMfaAuthenticator(context.Background(), dto.MfaAuthenticatorVerifyRequest{
			PreAuthToken: preAuthToken,
			TotpCode:     totpCode,
			DeviceID:     "device-auth",
		}, "127.0.0.1")
		if err != nil {
			t.Fatalf("VerifyMfaAuthenticator failed: %v", err)
		}
		if verifyResp.Outcome != constant.OutcomeSuccess {
			t.Fatalf("expected outcome success, got %+v", verifyResp)
		}

		// Assert that the previously active OTP code is now invalidated
		if otpRow.InvalidatedAt == nil {
			t.Errorf("expected pending OTP code to be invalidated upon final login via Authenticator, but InvalidatedAt is nil")
		}
	})
}
