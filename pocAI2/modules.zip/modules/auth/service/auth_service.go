// Package service implements account activation and login with password.
package service

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/repository"
	userRepository "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/provider"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// AuthService is a cross-schema domain: activation and login both read/write
// the shared public schema (activation_tokens, user_credentials, sessions,
// login_attempt_locks, user_lock_states, otp_codes, pre_auth_sessions,
// product_sessions) and a tenant schema (users), so it composes both the auth
// domain's own repositories and the user domain's (owned there per ADR 003).
type AuthService struct {
	dbName             string
	tokenRepo          repository.ActivationTokenRepositor
	credRepo           repository.UserCredentialRepositor
	sessionRepo        repository.SessionRepositor
	lockRepo           repository.LoginLockRepositor
	otpRepo            repository.OtpCodeRepositor
	resetTokenRepo     repository.PasswordResetTokenRepositor
	resetAttemptRepo   repository.PasswordResetAttemptRepositor
	preAuthRepo        repository.PreAuthSessionRepositor
	consentRepo        repository.UserPrivacyConsentRepositor
	productSessionRepo repository.ProductSessionRepositor
	trustedDeviceRepo  repository.TrustedDeviceRepositor
	countryPairRepo    repository.KnownCountryPairRepositor
	authenticatorRepo  repository.AuthenticatorEnrollmentRepositor
	userRepo           userRepository.UserRepositor
	password           provider.PasswordProviderer
	captcha            provider.RecaptchaProviderer
	// temporalSvc dispatches the OTP email workflow; the client lives on the
	// concrete *TemporalService, not the interface.
	temporalSvc *coreService.TemporalService
	// analyticsReportingTaskQueue is the task queue RecordSessionLogsWorkflow
	// is started on, in analytics-reporting-service's Temporal worker.
	analyticsReportingTaskQueue string
	// notificationTaskQueue is where SSE-publishing workflows are started.
	notificationTaskQueue string
	// generalSettingsClient fetches session idle timeout from
	// enterprise-management. Falls back to the constant on error.
	generalSettingsClient *client.EnterpriseManagementClient
	// otpHashKey HMAC-keys the OTP digests. It must never be empty (app.New
	// fails fast): an unkeyed digest of the 10^6 code space is exhaustible
	// offline by anyone with a DB read.
	otpHashKey []byte
	// encryptionKey encrypts TOTP secrets at rest in authenticator_enrollments.
	encryptionKey []byte
	// envType is config.AppConfig.EnvType; "dev" bypasses the Limit Login gate.
	envType string
	// makeSvc is the DB factory behind publicSvc/tenantSvc; swapped by
	// SetServiceFactoryForTest because the real one opens a pool and fatals
	// when Postgres is down.
	makeSvc func(schema string) coreService.PostgreSQLServicer
}

func NewAuthService(
	dbName string,
	tokenRepo repository.ActivationTokenRepositor,
	credRepo repository.UserCredentialRepositor,
	sessionRepo repository.SessionRepositor,
	lockRepo repository.LoginLockRepositor,
	otpRepo repository.OtpCodeRepositor,
	resetTokenRepo repository.PasswordResetTokenRepositor,
	resetAttemptRepo repository.PasswordResetAttemptRepositor,
	preAuthRepo repository.PreAuthSessionRepositor,
	consentRepo repository.UserPrivacyConsentRepositor,
	productSessionRepo repository.ProductSessionRepositor,
	trustedDeviceRepo repository.TrustedDeviceRepositor,
	countryPairRepo repository.KnownCountryPairRepositor,
	authenticatorRepo repository.AuthenticatorEnrollmentRepositor,
	userRepo userRepository.UserRepositor,
	password provider.PasswordProviderer,
	captcha provider.RecaptchaProviderer,
	temporalSvc *coreService.TemporalService,
	analyticsReportingTaskQueue string,
	notificationTaskQueue string,
	generalSettingsClient *client.EnterpriseManagementClient,
	otpHashKey []byte,
	encryptionKey []byte,
	envType string,
) *AuthService {
	return &AuthService{
		dbName:                      dbName,
		tokenRepo:                   tokenRepo,
		credRepo:                    credRepo,
		sessionRepo:                 sessionRepo,
		lockRepo:                    lockRepo,
		otpRepo:                     otpRepo,
		resetTokenRepo:              resetTokenRepo,
		resetAttemptRepo:            resetAttemptRepo,
		preAuthRepo:                 preAuthRepo,
		consentRepo:                 consentRepo,
		productSessionRepo:          productSessionRepo,
		trustedDeviceRepo:           trustedDeviceRepo,
		countryPairRepo:             countryPairRepo,
		authenticatorRepo:           authenticatorRepo,
		userRepo:                    userRepo,
		password:                    password,
		captcha:                     captcha,
		temporalSvc:                 temporalSvc,
		analyticsReportingTaskQueue: analyticsReportingTaskQueue,
		notificationTaskQueue:       notificationTaskQueue,
		generalSettingsClient:       generalSettingsClient,
		otpHashKey:                  otpHashKey,
		encryptionKey:               encryptionKey,
		envType:                     envType,
	}
}

func (s *AuthService) publicSvc() coreService.PostgreSQLServicer {
	return s.svcFor("public")
}

func (s *AuthService) tenantSvc(clientCode string) coreService.PostgreSQLServicer {
	return s.svcFor(clientCode)
}

// svcFor opens the schema's own servicer. The service holds dbName, never a
// live PostgreSQLService: that struct carries per-instance transaction state,
// so a shared instance would race across concurrent calls (ADR 004).
func (s *AuthService) svcFor(schema string) coreService.PostgreSQLServicer {
	if s.makeSvc != nil {
		return s.makeSvc(schema)
	}
	return coreService.MakePostgreSQLService(schema + ":" + s.dbName)
}

// SetServiceFactoryForTest replaces the DB factory with a stub so unit tests
// never touch Postgres. schema is "public" or the tenant's client code.
func (s *AuthService) SetServiceFactoryForTest(factory func(schema string) coreService.PostgreSQLServicer) {
	s.makeSvc = factory
}
