// Package constant holds auth-domain constants: token/lock/session status
// values and the user-facing copy strings the design docs mandate verbatim.
package constant

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

// SessionCookieName carries the raw session token: login sets it, and
// GET /auth/validate reads it back out on every gateway-forwarded request.
const SessionCookieName = "sid"

// Token statuses (activation_tokens / password_reset_tokens /
// pre_auth_sessions .status). TokenStatusInvalidated is stamped by
// InvalidateActiveForUser when a resend replaces the previous live link.
const (
	TokenStatusActive      = model.TokenStatusActive
	TokenStatusConsumed    = model.TokenStatusConsumed
	TokenStatusSuperseded  = model.TokenStatusSuperseded
	TokenStatusInvalidated = model.TokenStatusInvalidated
)

// Tenant user activation statuses (users.activation_status).
const (
	ActivationStatusPending   = "Pending Activation"
	ActivationStatusActivated = "Activated"
)

// Login outcomes (LoginResponse.outcome).
const (
	OutcomeSuccess               = "success"
	OutcomeAgreementRequired     = "agreement_required"
	OutcomeMfaRequired           = "mfa_required"
	OutcomeFailed                = "failed"
	OutcomeLocked                = "locked"
	OutcomeDuplicateDetected     = "duplicate_detected"
	OutcomeSent                  = "sent" // OtpRequestResponse.outcome
	OutcomeConfirmed             = "confirmed"
	OutcomeSessionAlreadyExpired = "session_already_expired"
	OutcomeLoggedOut             = "logged_out"
	OutcomeAlreadyExpired        = "already_expired"
)

// Reset password statuses (ResetPasswordResponse.status /
// ResetPasswordConfirmResponse.status).
const (
	ResetPasswordStatusSent          = "sent"
	ResetPasswordStatusNotRegistered = "not_registered"
	ResetPasswordStatusFailed        = "failed"
	ResetPasswordStatusInactive      = "inactive"
	ResetPasswordStatusCaptchaFailed = "captcha_failed"
	ResetPasswordStatusRateLimited   = "rate_limited"
	ResetPasswordStatusSuccess       = "success"
)

// Lock levels (login_attempt_locks.lock_level / user_lock_states.lock_level).
const (
	LockLevelNone          = model.LockLevelNone
	LockLevel15m           = model.LockLevel15m
	LockLevel1h            = model.LockLevel1h
	LockLevelRequiresReset = model.LockLevelRequiresReset
	LockLevelPermanent     = model.LockLevelPermanent
)

// Platforms (LoginRequest.platform).
const (
	PlatformWeb    = model.PlatformWeb
	PlatformMobile = model.PlatformMobile
)

// Session statuses (sessions.status).
const (
	SessionStatusActive         = model.SessionStatusActive
	SessionStatusLoggedOut      = model.SessionStatusLoggedOut
	SessionStatusForceLoggedOut = model.SessionStatusForceLoggedOut
	SessionStatusExpired        = model.SessionStatusExpired
)

// Terminated reasons (sessions.terminated_reason).
const (
	TerminatedReasonDuplicateLogin     = model.TerminatedReasonDuplicateLogin
	TerminatedReasonManualLogout       = model.TerminatedReasonManualLogout
	TerminatedReasonIdleTimeout        = model.TerminatedReasonIdleTimeout
	TerminatedReasonAccountDeleted     = model.TerminatedReasonAccountDeleted
	TerminatedReasonAccountDeactivated = model.TerminatedReasonAccountDeactivated
	TerminatedReasonPlatformCascade    = model.TerminatedReasonPlatformCascade
	TerminatedReasonLogout             = model.TerminatedReasonLogout
	TerminatedReasonAccessRevoked      = model.TerminatedReasonAccessRevoked
)

// Product session statuses (product_sessions.status).
const (
	ProductSessionStatusActive = model.ProductSessionStatusActive
	ProductSessionStatusEnded  = model.ProductSessionStatusEnded
)

// Pre-auth session lifecycle.
const (
	PreAuthTTL                   = 5 * time.Minute
	PreAuthPurposeDuplicateLogin = model.PreAuthPurposeDuplicateLogin
	PreAuthPurposeMfa            = model.PreAuthPurposeMfa
	PreAuthPurposeAgreement      = model.PreAuthPurposeAgreement
	PreAuthStatusActive          = model.TokenStatusActive
	PreAuthStatusConsumed        = model.TokenStatusConsumed
	PreAuthStatusInvalidated     = model.TokenStatusInvalidated
)

// Factor-1 methods (LoginResponse.factor1Method / OtpVerifyResponse.factor1Method).
// Returned on the mfa_required handoff so the client knows whether to show the
// Choose Verification Method page (password) or go straight to the
// authenticator (otp) - mfa/02-ui-design.md section 2.1.
const (
	Factor1MethodPassword  = model.Factor1MethodPassword
	Factor1MethodOtp       = model.Factor1MethodOtp
	Factor1MethodBiometric = model.Factor1MethodBiometric
)

// MFA trigger reasons (LoginResponse.mfaReason). Audit/telemetry only - no
// MFA screen renders the reason.
const (
	MfaReasonFirstLogin   = model.MfaReasonFirstLogin
	MfaReasonIdle30d      = model.MfaReasonIdle30d
	MfaReasonUnusualLogin = model.MfaReasonUnusualLogin
)

// Error codes (LoginResponse.errorCode).
const (
	ErrorCodeEmailEmpty          = "EMAIL_EMPTY"
	ErrorCodeEmailFormat         = "EMAIL_FORMAT"
	ErrorCodeEmailNotRegistered  = "EMAIL_NOT_REGISTERED"
	ErrorCodePasswordEmpty       = "PASSWORD_EMPTY"
	ErrorCodeCaptchaEmpty        = "CAPTCHA_EMPTY"
	ErrorCodeNotActivated        = "NOT_ACTIVATED"
	ErrorCodeInactive            = "INACTIVE"
	ErrorCodeIncorrect           = "INCORRECT"
	ErrorCodeLocked15m           = "LOCKED_15M"
	ErrorCodeLocked1h            = "LOCKED_1H"
	ErrorCodeLockedRequiresReset = "LOCKED_REQUIRES_RESET"
	ErrorCodeLockedPermanent     = "LOCKED_PERMANENT"

	// OTP error codes (OtpRequestResponse.errorCode / OtpVerifyResponse.errorCode).
	ErrorCodeResendLimitExceeded   = "RESEND_LIMIT_EXCEEDED"
	ErrorCodeOtpEmpty              = "OTP_EMPTY"
	ErrorCodeOtpInvalid            = "OTP_INVALID"
	ErrorCodeOtpExpired            = "OTP_EXPIRED"
	ErrorCodeOtpEmailChanged       = "OTP_EMAIL_CHANGED"
	ErrorCodeTotpEmpty             = "TOTP_EMPTY"
	ErrorCodeTotpInvalid           = "TOTP_INVALID"
	ErrorCodeVerifyEmpty           = "VERIFY_EMPTY"
	ErrorCodeVerifyInvalid         = "VERIFY_INVALID"
	ErrorCodePreAuthSessionExpired = "PRE_AUTH_SESSION_EXPIRED"

	// Reset password error codes (ResetPasswordResponse.errorCode /
	// ResetPasswordConfirmResponse.errorCode).
	ErrorCodeCaptchaFailed     = "CAPTCHA_FAILED"
	ErrorCodeConfirmEmpty      = "CONFIRM_EMPTY"
	ErrorCodePasswordsMismatch = "PASSWORDS_MISMATCH"
	ErrorCodeRateLimitedIP     = "RATE_LIMITED_IP"
	ErrorCodePasswordInvalid   = "PASSWORD_INVALID"
	ErrorCodePasswordSameAsOld = "PASSWORD_SAME_AS_OLD"
	ErrorCodeLinkInvalid       = "LINK_INVALID"
	ErrorCodeLinkExpired       = "LINK_EXPIRED"
	ErrorCodeLinkUsed          = "LINK_USED"
)

// Post-login redirect targets returned with the outcome so the FE never
// composes them (prd-conventions §5).
const (
	RedirectProductHub = "/portal/product-hub"
	RedirectMfa        = "/auth/mfa"
)

// AgreementIdleWindow is trigger (b): a user who last logged out at least
// this long ago is re-shown the policy.
const AgreementIdleWindow = 30 * 24 * time.Hour

// Caption fields (LoginResponse.captionField) — which form field the FE
// renders the error under.
const (
	CaptionFieldEmail    = "email"
	CaptionFieldPassword = "password"
	CaptionFieldGlobal   = "global"
)

// Exact user-facing copy, taken verbatim from the openapi examples. The
// handler/service never compose these strings — they only pick from here.
const (
	MsgEmailEmpty          = "Email must not be empty"
	MsgEmailFormat         = "Email format is incorrect"
	MsgEmailNotRegistered  = "Email is not registered yet"
	MsgPasswordEmpty       = "Password must not be empty"
	MsgCaptchaEmpty        = "Please verify that you are not a robot"
	MsgNotActivated        = "Your account has not been activated"
	MsgInactive            = "Your account is inactive"
	MsgIncorrect           = "Incorrect email or password"
	MsgLocked15m           = "Too many failed login attempts. Your account is locked for 15 minutes. You can try again at %s."
	MsgLocked1h            = "Too many failed login attempts. Your account is locked for 1 hour. You can try again at %s."
	MsgLockedRequiresReset = "Please reset your password."
	MsgLockedPermanent     = "For security reasons, your account has been locked. Please reset your password to regain access."
	MsgLoginSuccessful     = "Login successful"

	// Agreement gate copy (confirm-agreement/API §4 — rendered verbatim).
	MsgAgreementDeclined = "You need to agree to the Privacy Policy to continue"
	MsgPreAuthExpired    = "Your session has expired. Please log in again."

	MsgActivationExpired   = "This activation link has expired. Activation links are valid for 24 hours. Please contact your administrator to receive a new activation email."
	MsgActivationInvalid   = "This activation link is invalid. Please contact your administrator to receive a new activation email."
	MsgActivationUsed      = "This activation link has already been used. Your account has been activated."
	MsgInternalServerError = "Internal server error"
	MsgAccountActivated    = "Account activated"
	MsgTokenValid          = "Token valid"

	MsgSessionValid   = "Session valid"
	MsgSessionMissing = "No session"
	// MsgSessionInvalid covers unknown, revoked and idled-out tokens alike —
	// never say which.
	MsgSessionInvalid = "Session invalid or expired"

	MsgOtpRequestSent = "OTP sent"
	MsgOtpResendLimit = "You have reached the maximum number of OTP resends. Please request a new code."
	MsgOtpEmpty       = "OTP must not be empty"
	MsgOtpInvalid     = "Incorrect OTP"
	MsgOtpExpired     = "OTP has expired"

	// MFA user-facing copy (openapi and mfa PRD verbatim strings).
	MsgVerificationCodeSent     = "Verification code sent"
	MsgVerificationComplete     = "Verification complete"
	MsgEnrollmentGenerated      = "Enrollment data generated"
	MsgAuthenticatorAdded       = "Authenticator app added"
	MsgEnrollmentVerifyComplete = "Enrollment verification complete"
	MsgEnter6DigitCode          = "Please enter the 6-digit code."
	MsgInvalidCode              = "Invalid code"
	MsgTooManyAttempts          = "Too many attempts. Please try again later."
	MsgSessionExpiredLoginAgain = "Session expired. Please log in again."

	MsgResetPasswordSent      = "Password reset email sent"
	MsgResetPasswordResent    = "Password reset email resent"
	MsgResetPasswordDone      = "Password updated successfully"
	MsgResetPasswordPolicy    = "Password does not meet the required policy"
	MsgConfirmPasswordEmpty   = "Confirm password must not be empty"
	MsgPasswordsMismatch      = "Passwords do not match"
	MsgResetPasswordSameAsOld = "Password must be different from your old password"
	MsgTooManyRequests        = "Too many requests. Please try again later."
	// MsgResetLinkNeutral covers unknown, expired and used links alike — never
	// say which, so a link cannot be probed. The errorCode (LINK_INVALID /
	// LINK_EXPIRED / LINK_USED) still differentiates for the FE and the logs.
	MsgResetLinkNeutral = "This reset link is invalid or expired"
)

// Lock progression thresholds (auth-foundation §3.1).
const (
	LockWarnAt          = 3 // failed_count reaching this → 15m
	LockEscalateAt      = 6 // failed_count reaching this → 1h
	LockRequiresResetAt = 9 // failed_count reaching this → requires_reset
	StreakLimit         = 7 // consecutive_1h_days at which the NEXT 1h-stage failure → permanent

	Lock15mDuration = 15 * time.Minute
	Lock1hDuration  = time.Hour

	// SessionIdleTimeout is the fallback idle timeout when
	// enterprise-management's general-settings endpoint is unreachable. The
	// real value is fetched per-request from the general-settings client.
	SessionIdleTimeout = 30 * time.Minute

	// SessionCookieMaxAge makes the session cookie persistent (survives
	// browser close, per session-management PRD §7/§10 "Browser web ditutup
	// != logout"). Real expiry is server-side (sessions.expires_at, slid by
	// idle activity) — this only needs to outlive any realistic active
	// session so the cookie itself never expires the session early.
	SessionCookieMaxAge = 30 * 24 * time.Hour
)

// Log statuses written to session_logs.
const (
	LogStatusSuccess = "Success"
	LogStatusFailed  = "Failed"
)

// Log notes written to session_logs (auth-foundation §9.1 Table A).
const (
	LogNoteCaptchaNotCompleted = "Captcha not completed"
	LogNoteEmptyPassword       = "Empty password"
	LogNoteNotActivated        = "Account is not activated"
	LogNoteInactive            = "Account is inactive"
	LogNoteIncorrectPassword   = "Incorrect password"
	LogNoteLocked15m           = "Locked 15 minutes"
	LogNoteLocked1h            = "Locked 1 hour"
	LogNoteLockedRequiresReset = "Locked requires reset"
	LogNoteAccountLocked       = "Account locked"
	LogNoteLoginSuccess        = "Login with password"
	LogNoteConsentNotGiven     = "Consent not given"

	// OTP log notes (auth-foundation §9.1 Table A, login-otp flow).
	LogNoteOtpEmpty              = "Empty OTP"
	LogNoteOtpIncorrect          = "Incorrect OTP"
	LogNoteOtpExpired            = "OTP expired"
	LogNoteOtpEmailChanged       = "OTP invalid — email changed"
	LogNoteLoginOtpSuccess       = "Login with OTP"
	LogNoteLoginBiometricSuccess = "Login with biometric"
)

// OTP purposes (otp_codes.purpose).
const (
	OtpPurposeLogin = "login"
	OtpPurposeMfa   = "mfa"
)

// MFA and TOTP lifecycle and parameters (RFC 6238).
const (
	MfaSessionTTL  = 10 * time.Minute
	TotpAlgorithm  = "SHA1"
	TotpDigits     = 6
	TotpPeriod     = 30 * time.Second
	TotpDriftSteps = 1
	TotpIssuer     = "TAG Samurai"
)

// Reset password log notes. ActivityResetPassword is the Activity written
// to session_logs for every reset request / confirmation.
const (
	LogNoteTooManyResetAttempts   = "Too many reset attempts"
	LogNoteResetPasswordRequested = "Password reset requested"
	LogNoteResetPasswordSuccess   = "Password updated successfully"
	LogNoteResetLinkExpired       = "Reset link expired"
	LogNoteResetLinkUsed          = "Reset link already used"
	LogNotePasswordPolicyFailed   = "Password does not meet requirements"
)

// OTP code lifecycle (flows/auth/login-otp, design-summary).
const (
	// OtpTTL is how long an issued code stays valid.
	OtpTTL = 5 * time.Minute
	// OtpMaxResend is the number of resends allowed per chain; the next
	// request answers RESEND_LIMIT_EXCEEDED and inserts nothing.
	OtpMaxResend = 5
	// OtpResendCooldownSeconds is shown to the user between resends; once the
	// chain's resend_count reaches the cap, OtpResendExhaustedCooldownSeconds
	// replaces it.
	OtpResendCooldownSeconds          = 60
	OtpResendExhaustedCooldownSeconds = 600
	// OtpRetention is how long rows survive before the hourly purge sweep
	// deletes them (historical rows are kept on purpose until then).
	OtpRetention = 24 * time.Hour
)

// Temporal activity/workflow names this service registers. The activity names
// must match the worker-registered method names exactly (RegisterActivity
// derives them from the method, and workflows dispatch by string).
const (
	ActivitySendOtpEmail  = "SendOtpEmail"
	ActivityPurgeOtpCodes = "PurgeOtpCodes"
	// WorkflowPurgeOtpCodes is what the hourly schedule starts by name.
	WorkflowPurgeOtpCodes = "PurgeOtpCodesWorkflow"

	ActivitySendResetPasswordEmail = "SendResetPasswordEmail"

	// Idle session sweep.
	ActivityExpireIdleSessions = "ExpireIdleSessions"
	WorkflowExpireIdleSessions = "ExpireIdleSessionsWorkflow"

	// SSE publishing via notification-service.
	NotificationPublishSSEWorkflow = "NotificationPublishSSEWorkflow"
)

// SSE event names and scopes.
const (
	SSEEventSessionLoggedOut   = "session.logged_out"
	SSEEventAccountDeleted     = "account.deleted"
	SSEEventAccountDeactivated = "account.deactivated"
	SSEEventSessionLogCreated  = "session_log.created"

	SSEScopeSession = "session"
	SSEScopeUser    = "user"
)

// Activity written to session_logs for the reset-password flow.
const ActivityResetPassword = "Reset Password"

// Reset password budgets (flows/auth/reset-password). The attempt tables are
// one row per key with a fixed window_start: when the window rolls over the
// counter resets to 1 and window_start moves forward — no summing over rows.
const (
	// ResetPasswordTokenTTL is how long a reset link stays valid.
	ResetPasswordTokenTTL = 24 * time.Hour
	// ResetPasswordEmailBudget is the per-email allowance per 24h window.
	ResetPasswordEmailBudget = 5
	ResetPasswordEmailWindow = 24 * time.Hour
	// ResetPasswordIPBudget is the per-IP allowance per 1h window.
	ResetPasswordIPBudget = 20
	ResetPasswordIPWindow = time.Hour
	// ResetPasswordResendCooldown is the minimum gap between a request and a
	// resend for the same email.
	ResetPasswordResendCooldown = 60 * time.Second
)
