package auth

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

// SetupPublicRoutes registers routes that do not require a session cookie —
// login, activation, reset-password, confirm-duplicate, and the gateway's
// forwardAuth target (which validates the session token itself, not a session
// cookie established before the call).
func SetupPublicRoutes(app *fiber.App, cookieDomain string, authSvc *service.AuthService) {
	h := handler.NewAuthHandler(authSvc, cookieDomain)

	app.Get("/auth/activation/:token", h.HandleValidateActivationToken)
	app.Post("/auth/activation/:token/set-password", h.HandleSetPassword)
	app.Post("/auth/login", h.HandleLogin)
	app.Post("/auth/otp/request", h.HandleRequestOTP)
	app.Post("/auth/otp/verify", h.HandleVerifyOTP)
	// Confirm-agreement: its credential is the post-factor-1 pre-auth token.
	app.Post("/auth/confirm-agreement", h.HandleConfirmAgreement)
	app.Post("/auth/reset-password/request", h.HandleRequestResetPassword)
	app.Post("/auth/reset-password/resend", h.HandleResendResetPassword)
	app.Get("/auth/reset-password/validate/:token", h.HandleValidateResetToken)
	app.Post("/auth/reset-password/confirm", h.HandleConfirmResetPassword)

	// Confirm-duplicate: its credential is the pre-auth token, not a session.
	app.Post("/auth/sessions/confirm-duplicate", h.HandleConfirmDuplicate)

	// MFA factor-2 and authenticator enrollment endpoints.
	app.Post("/auth/mfa/otp/send", h.HandleSendMfaOtp)
	app.Post("/auth/mfa/otp/verify", h.HandleVerifyMfaOtp)
	app.Post("/auth/mfa/authenticator/verify", h.HandleVerifyMfaAuthenticator)
	app.Post("/auth/mfa/authenticator/enroll", h.HandleEnrollMfaAuthenticator)
	app.Post("/auth/mfa/authenticator/enroll/verify", h.HandleVerifyEnrollMfaAuthenticator)

	// The gateway's forwardAuth target, called on every request to an
	// authenticated route: it validates the session cookie, slides its idle
	// expiry, and answers with the X-User-ID / X-Client-ID / X-Entity-ID headers the backend
	// services gate on. Public because the caller has no identity yet — the
	// session token it presents is the credential.
	app.Get("/auth/validate", h.HandleValidateSession)
}

// SetupAuthenticatedRoutes registers routes that require a valid session —
// the gateway stamps X-Session-ID after a successful forwardAuth, so these
// arrive with the numeric session id. Per ADR 013, a route is authenticated
// because of the function it sits in.
func SetupAuthenticatedRoutes(app *fiber.App, cookieDomain string, authSvc *service.AuthService, meSvc *service.MeService) {
	h := handler.NewAuthHandler(authSvc, cookieDomain)

	app.Put("/auth/sessions/heartbeat", h.HandleHeartbeat)
	app.Post("/auth/logout", h.HandleLogout)

	// The /me namespace: get caller's data
	me := handler.NewMeHandler(meSvc)
	app.Get("/me/permissions", me.HandleMePermissions)
	app.Get("/me/settings", me.HandleMeSettings)
	app.Get("/me/entity", me.HandleMeEntity)
}

// SetupInternalRoutes mounts the cache drops that will be called from enterprise-management
func SetupInternalRoutes(app *fiber.App, serviceToken string, meSvc *service.MeService) {
	me := handler.NewMeHandler(meSvc)

	guard := tsMiddleware.RequireServiceToken(serviceToken)
	app.Delete("/internal/cache/me/tenant/:clientCode", guard, me.HandleInvalidateTenantCache)
	app.Delete("/internal/cache/me/system-limits", guard, me.HandleInvalidateSystemLimitsCache)
}

// Dev only routes for test purpose, bypass mfa and others
// Require config devRoutesEnabled
func SetupDevRoutes(app *fiber.App, cookieDomain string, authSvc *service.AuthService) {
	h := handler.NewAuthHandler(authSvc, cookieDomain)

	dev := app.Group("/dev")
	dev.Post("/auth/login", h.HandleDevLogin)
}
