package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

// SendResetPasswordEmailWorkflowParam mirrors activity.SendResetPasswordEmailParam
// — Temporal serializes the payload, not the type.
type SendResetPasswordEmailWorkflowParam struct {
	Email string
	Token string
}

// SendResetPasswordEmailWorkflow sends the reset link once. The caller starts
// it fire-and-forget (the request must not block on SMTP); a failed send is
// retried by Temporal's activity retry policy.
func SendResetPasswordEmailWorkflow(ctx workflow.Context, param SendResetPasswordEmailWorkflowParam) error {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())
	return workflow.ExecuteActivity(activityCtx, constant.ActivitySendResetPasswordEmail, activity.SendResetPasswordEmailParam{
		Email: param.Email,
		Token: param.Token,
	}).Get(activityCtx, nil)
}
