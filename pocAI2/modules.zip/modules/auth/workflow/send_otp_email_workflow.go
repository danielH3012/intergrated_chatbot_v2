// Package workflow implements the iam-service Temporal workflows: iam's own
// fire-and-forget OTP email dispatch and the hourly retention sweep.
package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

// SendOtpEmailWorkflowParam mirrors activity.SendOtpEmailParam — Temporal
// serializes the payload, not the type.
type SendOtpEmailWorkflowParam struct {
	Email string
	Code  string
}

// SendOtpEmailWorkflow sends the issued code once. The caller starts it
// fire-and-forget (the request must not block on SMTP); a failed send is
// retried by Temporal's activity retry policy.
func SendOtpEmailWorkflow(ctx workflow.Context, param SendOtpEmailWorkflowParam) error {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())
	return workflow.ExecuteActivity(activityCtx, constant.ActivitySendOtpEmail, activity.SendOtpEmailParam{
		Email: param.Email,
		Code:  param.Code,
	}).Get(activityCtx, nil)
}
