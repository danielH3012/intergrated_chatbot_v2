package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

// ExpireIdleSessionsWorkflow runs the ExpireIdleSessions activity once.
func ExpireIdleSessionsWorkflow(ctx workflow.Context) error {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())
	return workflow.ExecuteActivity(activityCtx, constant.ActivityExpireIdleSessions).Get(activityCtx, nil)
}
