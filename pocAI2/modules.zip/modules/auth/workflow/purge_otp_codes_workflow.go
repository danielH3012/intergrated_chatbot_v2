package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

// PurgeOtpCodesWorkflow is started hourly by the iam-otp-codes-purge
// schedule and sweeps otp_codes rows past the retention window. A failure is
// retried by the schedule's retry policy; the next run converges.
func PurgeOtpCodesWorkflow(ctx workflow.Context) error {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())
	return workflow.ExecuteActivity(activityCtx, constant.ActivityPurgeOtpCodes).Get(activityCtx, nil)
}
