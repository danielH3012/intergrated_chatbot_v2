package activity

import (
	"context"
	"fmt"
	"log/slog"
	"net/url"
	"strings"

	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// SendResetPasswordEmailParam carries the reset link delivery. The raw token
// is passed as the workflow argument and never re-read from the DB — only its
// SHA-256 is stored, so there is nothing to read back.
type SendResetPasswordEmailParam struct {
	Email string
	Token string
}

// SendResetPasswordEmail mails the reset link. The method name is the
// activity name SendResetPasswordEmailWorkflow dispatches by, so it must not
// change.
//
// Same nil-mailer degradation as SendActivationEmail: with no SMTP configured
// the send is skipped and the link is still issued (the caller's log is the
// only trace, matching how the other emails behave locally).
func (a *TenantDataActivities) SendResetPasswordEmail(ctx context.Context, param SendResetPasswordEmailParam) error {
	if a.emailSvc == nil {
		slog.ErrorContext(ctx, "Email service not set")
		return nil
	}

	resetURL := a.resetPasswordURL
	if resetURL == "" {
		resetURL = "http://localhost:3000/reset-password"
	}
	separator := "?"
	if strings.Contains(resetURL, "?") {
		separator = "&"
	}
	link := resetURL + separator + "token=" + url.QueryEscape(param.Token)
	body := fmt.Sprintf("<p>Someone requested a password reset for your account.</p><p><a href=\"%s\">Confirm Email</a></p><p>If the button does not work, open this link:</p><p>%s</p>", link, link)
	return a.emailSvc.SendEmail(coreService.SendEmailProps{
		To:      param.Email,
		Subject: "Reset your TAG Samurai password",
		Body:    body,
	})
}
