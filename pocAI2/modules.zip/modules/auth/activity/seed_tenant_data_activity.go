// Package activity implements the iam-service Temporal activities, run on the
// iam-service-local worker. The tenant-migration activities are dispatched by
// other services' sagas onto this task queue; the OTP activities (SendOtpEmail,
// PurgeOtpCodes) are dispatched by iam's own workflows.
package activity

import (
	"context"
	"fmt"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/repository"
	divisionHelper "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/division/helper"
	"gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	utilDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// TenantDataActivities seeds the default rows a brand-new tenant schema needs.
//
// It holds dbName, not a PostgreSQLService instance: that struct carries
// per-instance transaction state, so a shared instance would race across
// concurrently-executing activities. Each method builds its own service.
type TenantDataActivities struct {
	dbName   string
	emailSvc coreService.EmailServicer
	otpRepo  repository.OtpCodeRepositor
	// cache is dropped after the module-status write. Seeding creates the user,
	// so nothing can be cached under that id yet — this is here because it is
	// the writer of user_module_status, and every writer of the role tables
	// owes the cache a drop. The next writer to be added copies this line
	// rather than discovering the rule the hard way.
	cache            *cache.Cache
	resetPasswordURL string
}

func NewTenantDataActivities(dbName string, emailSvc coreService.EmailServicer, otpRepo repository.OtpCodeRepositor, c *cache.Cache, resetPasswordURLs ...string) *TenantDataActivities {
	resetPasswordURL := ""
	if len(resetPasswordURLs) > 0 {
		resetPasswordURL = resetPasswordURLs[0]
	}
	return &TenantDataActivities{dbName: dbName, emailSvc: emailSvc, otpRepo: otpRepo, cache: c, resetPasswordURL: resetPasswordURL}
}

// tenantSvc routes queries into the client's own schema (<clientID>, public).
func (a *TenantDataActivities) tenantSvc(clientID string) coreService.PostgreSQLServicer {
	return coreService.MakePostgreSQLService(clientID + ":" + a.dbName)
}

// SeedTenantData seeds the tenant's default division, default position, and
// admin user. The method name is the activity name the client-creation saga
// dispatches by (ActivitySeedTenantData), so it must not change.
//
// It writes tenant-schema rows only. The admin's public-schema rows are their
// own activities — CreateUserCredentials and SendActivationEmail — so a failed
// credential insert or mailer outage retries without re-running the seeding.
//
// Idempotency is required, not optional: the saga retries this activity, and a
// retry after a partial run must not collide with the unique email index or
// duplicate the default rows. Every step is guarded by an existence check, and
// an existing division/position is read back so the user row links to it.
func (a *TenantDataActivities) SeedTenantData(ctx context.Context, param temporal.SeedTenantDataParam) error {
	// Not closed on the way out: MakePostgreSQLService hands back a pgxpool cached
	// process-wide per database, so Close() would tear down the pool every other
	// activity and request is using — and ConnectPostgres keeps handing the dead one
	// back, so every later seed fails with "closed pool" until the process restarts.
	tenantSvc := a.tenantSvc(param.ClientID)

	divisionID, err := a.ensureDivision(ctx, tenantSvc, param.ContactPersonDivision)
	if err != nil {
		return fmt.Errorf("seed division: %w", err)
	}

	positionID, err := a.ensurePosition(ctx, tenantSvc, param.ContactPersonPosition)
	if err != nil {
		return fmt.Errorf("seed position: %w", err)
	}

	firstName, lastName := splitContactName(param.ContactPersonName)
	userID, err := a.ensureUser(ctx, tenantSvc, divisionID, positionID, firstName, lastName, param.ContactPersonEmail)
	if err != nil {
		return fmt.Errorf("seed user: %w", err)
	}

	if err := a.ensureUserModuleStatuses(ctx, tenantSvc, userID); err != nil {
		return fmt.Errorf("seed user module status: %w", err)
	}
	a.cache.InvalidateUserRoles(ctx, userID)

	return nil
}

// ensureDivision inserts the tenant's default division unless one with the
// given name already exists, and returns its id either way.
func (a *TenantDataActivities) ensureDivision(ctx context.Context, svc coreService.PostgreSQLServicer, name string) (int64, error) {
	where := sql_query.WhereQuery{
		"name": {Operator: sql_query.SQLOperatorEqual, Value: name},
	}
	existing, err := a.rowIDIfExists(ctx, svc, utilDb.DivisionTableName, where)
	if err != nil {
		return 0, err
	}
	if existing != 0 {
		return existing, nil
	}

	code, err := divisionHelper.GenerateDivisionCode(name, func(candidate string) (bool, error) {
		codeWhere := sql_query.WhereQuery{
			"code": {Operator: sql_query.SQLOperatorILike, Value: candidate},
		}
		count, err := svc.CountWithFilter(ctx, utilDb.DivisionTableName, codeWhere)
		return count == 0, err
	})
	if err != nil {
		return 0, fmt.Errorf("generate division code: %w", err)
	}

	id, err := svc.InsertOneWithData(ctx, utilDb.DivisionTableName, model.Division{
		Name:      name,
		Code:      &code,
		IsDefault: true,
	})
	if err != nil {
		return 0, err
	}
	return toInt64(id), nil
}

// ensurePosition inserts the tenant's default position unless one with the
// given name already exists, and returns its id either way.
func (a *TenantDataActivities) ensurePosition(ctx context.Context, svc coreService.PostgreSQLServicer, name string) (int64, error) {
	return a.ensureDefaultRow(ctx, svc, utilDb.PositionTableName, model.Position{Name: name, IsDefault: true}, name)
}

// ensureDefaultRow is the shared existence-checked insert behind both default
// rows: count first, reuse the existing row's id if one is already there, else
// insert and use the generated snowflake id.
func (a *TenantDataActivities) ensureDefaultRow(ctx context.Context, svc coreService.PostgreSQLServicer, table string, row any, name string) (int64, error) {
	where := sql_query.WhereQuery{
		"name": {Operator: sql_query.SQLOperatorEqual, Value: name},
	}

	existing, err := a.rowIDIfExists(ctx, svc, table, where)
	if err != nil {
		return 0, err
	}
	if existing != 0 {
		return existing, nil
	}

	id, err := svc.InsertOneWithData(ctx, table, row)
	if err != nil {
		return 0, err
	}
	return toInt64(id), nil
}

// ensureUser inserts the admin user row unless one with this email already
// exists, linking it to the seeded default division and position, and returns
// the user's id either way.
func (a *TenantDataActivities) ensureUser(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	divisionID, positionID int64,
	firstName, lastName, email string,
) (int64, error) {
	where := sql_query.WhereQuery{
		"email": {Operator: sql_query.SQLOperatorEqual, Value: email},
	}

	existing, err := a.rowIDIfExists(ctx, svc, utilDb.UserTableName, where)
	if err != nil {
		return 0, err
	}
	if existing != 0 {
		return existing, nil
	}

	id, err := svc.InsertOneWithData(ctx, utilDb.UserTableName, model.User{
		FirstName:        firstName,
		LastName:         lastName,
		Email:            email,
		DivisionID:       divisionID,
		PositionID:       &positionID,
		ActivationStatus: constant.ActivationStatusPending,
	})
	if err != nil {
		return 0, err
	}
	return toInt64(id), nil
}

// seededModuleKeys are the modules every seeded admin user gets a status row
// for.
var seededModuleKeys = []model.Product{model.ProductGlobalSettings, model.ProductAdminConsole, model.ProductFixedAsset}

// ensureUserModuleStatuses inserts an active status row for userID in every
// seeded module, skipping any module that already has one.
func (a *TenantDataActivities) ensureUserModuleStatuses(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error {
	for _, moduleKey := range seededModuleKeys {
		where := sql_query.WhereQuery{
			"user_id":    {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"module_key": {Operator: sql_query.SQLOperatorEqual, Value: moduleKey},
		}

		exists, err := a.rowExists(ctx, svc, utilDb.UserModuleStatusTableName, where)
		if err != nil {
			return err
		}
		if exists {
			continue
		}

		if _, err := svc.InsertOneWithData(ctx, utilDb.UserModuleStatusTableName, model.UserModuleStatus{
			UserID:    userID,
			ModuleKey: moduleKey,
			IsActive:  true,
		}); err != nil {
			return err
		}

		if _, err := svc.InsertOneWithData(ctx, utilDb.UserAccessLevelTableName, model.UserAccessLevel{
			UserID:      userID,
			Product:     moduleKey,
			AccessLevel: model.AccessLevelTotalControl,
			ModifiedBy:  nil,
		}); err != nil {
			return err
		}
	}
	return nil
}

// rowExists reports whether any row matching where exists in table. Used for
// tables like user_module_status that have no single-column id to read back.
func (a *TenantDataActivities) rowExists(ctx context.Context, svc coreService.PostgreSQLServicer, table string, where sql_query.WhereQuery) (bool, error) {
	count, err := svc.CountWithFilter(ctx, table, where)
	if err != nil {
		return false, err
	}
	return count != 0, nil
}

// rowIDIfExists returns the id of the first row matching where, or 0 if none
// does.
func (a *TenantDataActivities) rowIDIfExists(ctx context.Context, svc coreService.PostgreSQLServicer, table string, where sql_query.WhereQuery) (int64, error) {
	count, err := svc.CountWithFilter(ctx, table, where)
	if err != nil {
		return 0, err
	}
	if count == 0 {
		return 0, nil
	}

	query, args, err := sql_query.NewSQLSelectBuilder[idRow](table).
		Where(where).
		Build()
	if err != nil {
		return 0, err
	}

	var row idRow
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return 0, err
	}
	return row.ID, nil
}

// toInt64 converts the scalar returned by InsertOneWithData (the RETURNING id)
// to an int64 snowflake id.
func toInt64(v any) int64 {
	switch t := v.(type) {
	case int:
		return int64(t)
	case int64:
		return t
	case float64:
		return int64(t)
	default:
		return 0
	}
}

// splitContactName splits a contact person's name on the first space into
// first and last name. A single-word name yields an empty last name.
func splitContactName(name string) (firstName, lastName string) {
	name = strings.TrimSpace(name)
	firstName, rest, found := strings.Cut(name, " ")
	if !found {
		return name, ""
	}
	return firstName, strings.TrimSpace(rest)
}

// idRow is the minimal projection used to read an existing row's id back.
type idRow struct {
	ID int64 `json:"_id" column:"id"`
}
