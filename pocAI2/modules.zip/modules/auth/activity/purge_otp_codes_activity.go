package activity

import (
	"context"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// PurgeOtpCodes deletes otp_codes rows older than the retention window in one
// bulk query. The method name is the activity name PurgeOtpCodesWorkflow
// dispatches by, so it must not change.
//
// The hourly schedule runs this instead of per-row timers: historical rows
// are kept for audit for 24 hours, then swept. A missed run only delays the
// sweep — the next run deletes everything past the cutoff.
func (a *TenantDataActivities) PurgeOtpCodes(ctx context.Context) error {
	n, err := a.otpRepo.DeleteCreatedBefore(ctx, a.publicSvc(), time.Now().Add(-constant.OtpRetention))
	if err != nil {
		return err
	}
	slog.InfoContext(ctx, "purged expired otp codes", "count", n)
	return nil
}
