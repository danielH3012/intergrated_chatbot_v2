package activity

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	utilDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/provider"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// CreateUserCredentials inserts the login credential for the seeded admin unless
// one with this email already exists. The method name is the activity name the
// client-creation saga dispatches by (ActivityCreateUserCredentials), so it must
// not change.
//
// The row lives in the public schema, not the tenant's: login happens before a
// tenant is known, so the lookup is by email across every client. That is also
// why this is not part of SeedTenantData, which only writes tenant-schema rows.
//
// Idempotency is required, not optional: the saga retries this activity, and a
// second insert would collide with the unique email index.
func (a *TenantDataActivities) CreateUserCredentials(ctx context.Context, param temporal.CreateUserCredentialsParam) error {
	svc := a.publicSvc()

	existing, err := a.rowIDIfExists(ctx, svc, utilDb.UserCredentialTableName, sql_query.WhereQuery{
		"email":       {Operator: sql_query.SQLOperatorEqual, Value: param.Email},
		"client_code": {Operator: sql_query.SQLOperatorEqual, Value: param.ClientID},
	})
	if err != nil {
		return err
	}
	if existing != 0 {
		return nil
	}

	// An empty password means the account was created with an activation link
	// instead: the row still has to exist (it is the global email ->
	// client_code index login resolves a tenant through), but password_hash
	// stays NULL until set-password fills it in.
	var passwordHash *string
	if param.Password != "" {
		passwordProvider := &provider.PasswordProvider{}
		hash, err := passwordProvider.HashPassword(param.Password)
		if err != nil {
			return err
		}
		passwordHash = &hash
	}

	_, err = svc.InsertOneWithData(ctx, utilDb.UserCredentialTableName, userCredentialRow{
		Email:        param.Email,
		ClientCode:   param.ClientID,
		PasswordHash: passwordHash,
	})
	return err
}

// userCredentialRow is the subset of the public user_credentials table this
// activity writes.
type userCredentialRow struct {
	ID           int64   `json:"_id" column:"user_credentials.id"`
	Email        string  `json:"email" column:"user_credentials.email"`
	ClientCode   string  `json:"client_code" column:"user_credentials.client_code"`
	PasswordHash *string `json:"password_hash" column:"user_credentials.password_hash"`
}
