package activity

import (
	"context"
	"fmt"

	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// clientAuthTables are the public-schema tables carrying a client_code.
//
// user_credentials is deleted LAST on purpose: purging password_reset_attempts_by_email needs
// it to resolve the client's addresses (that table is keyed by email, not client_code). Keeping
// it until the end means a retry after a mid-loop failure can still resolve them.
var clientAuthTables = []string{
	"activation_tokens",
	"sessions",
	"product_sessions",
	"pre_auth_sessions",
	"otp_codes",
	"password_reset_tokens",
	"login_attempt_locks",
	"user_credentials",
}

// PurgeClientAuthData removes all public-schema authentication rows owned by a client.
// The tenant schema does not contain these rows, so dropping it cannot clean them up.
// DeleteManyWithFilter is idempotent, which makes the activity safe to retry.
//
// user_lock_states is deliberately left: it is keyed by user_id, and snowflake ids are never
// reused, so its leftovers are inert rather than reachable by a future tenant.
func (a *TenantDataActivities) PurgeClientAuthData(ctx context.Context, clientID string) error {
	svc := a.publicSvc()

	if err := a.purgeResetAttempts(ctx, svc, clientID); err != nil {
		return err
	}

	where := sql_query.WhereQuery{
		"client_code": {Operator: sql_query.SQLOperatorEqual, Value: clientID},
	}
	for _, table := range clientAuthTables {
		if _, err := svc.DeleteManyWithFilter(ctx, table, where); err != nil {
			return fmt.Errorf("purge %s: %w", table, err)
		}
	}
	return nil
}

// purgeResetAttempts clears the reset-password throttle counters for this client's addresses.
// password_reset_attempts_by_email is keyed by email_norm with no client_code, so without this
// a re-onboarded address inherits the deleted tenant's attempt count and can start out locked.
// The _by_ip table is not tenant-scoped at all and is left alone.
func (a *TenantDataActivities) purgeResetAttempts(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	clientID string,
) error {
	type row struct {
		EmailNorm string `json:"emailNorm"`
	}

	// Same normalisation the reset flow applies before writing email_norm.
	const query = `SELECT DISTINCT LOWER(TRIM(email)) AS "emailNorm"
		FROM user_credentials WHERE client_code = $1`

	rows := []row{}
	if err := svc.SelectMany(&rows, ctx, query, clientID); err != nil {
		return fmt.Errorf("resolve client emails: %w", err)
	}
	if len(rows) == 0 {
		return nil
	}

	emails := make([]string, 0, len(rows))
	for _, r := range rows {
		emails = append(emails, r.EmailNorm)
	}

	if _, err := svc.DeleteManyWithFilter(ctx, "password_reset_attempts_by_email", sql_query.WhereQuery{
		"email_norm": {Operator: sql_query.SQLOperatorIn, Value: emails},
	}); err != nil {
		return fmt.Errorf("purge password_reset_attempts_by_email: %w", err)
	}
	return nil
}
