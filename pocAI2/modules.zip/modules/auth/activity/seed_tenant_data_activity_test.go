package activity

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestSplitContactName(t *testing.T) {
	tests := []struct {
		name      string
		in        string
		wantFirst string
		wantLast  string
	}{
		{"full name", "Jane Doe", "Jane", "Doe"},
		{"single word", "Jane", "Jane", ""},
		{"multi-word last name", "Jane Ann Doe", "Jane", "Ann Doe"},
		{"leading and trailing spaces", "  Jane  Doe  ", "Jane", "Doe"},
		{"empty", "", "", ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			first, last := splitContactName(tt.in)
			assert.Equal(t, tt.wantFirst, first)
			assert.Equal(t, tt.wantLast, last)
		})
	}
}
