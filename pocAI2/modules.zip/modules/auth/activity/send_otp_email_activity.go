package activity

import (
	"context"
	"log"
	"log/slog"

	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// SendOtpEmailParam carries the OTP delivery. The plaintext code is passed as
// the workflow argument and never re-read from the DB — only its HMAC is
// stored, so there is nothing to read back.
type SendOtpEmailParam struct {
	Email string
	Code  string
}

// SendOtpEmail mails the 6-digit code. The method name is the activity name
// SendOtpEmailWorkflow dispatches by, so it must not change.
//
// Same nil-mailer degradation as SendActivationEmail: with no SMTP configured
// the send is skipped and the code is still issued (the caller's log is the
// only trace, matching how the activation email behaves locally).
func (a *TenantDataActivities) SendOtpEmail(ctx context.Context, param SendOtpEmailParam) error {
	if a.emailSvc == nil {
		slog.ErrorContext(ctx, "Email service not set")
		return nil
	}

	log.Println("Send email to " + param.Email)
	return a.emailSvc.SendEmail(coreService.SendEmailProps{
		To:      param.Email,
		Subject: "Your TAG Samurai verification code",
		Body:    param.Code,
	})
}
