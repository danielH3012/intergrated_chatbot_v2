package activity

import (
	"context"
	"fmt"

	userRepository "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	"gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	utilDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// EditUserActivationStatus sets the seeded admin's activation status when the
// client-creation saga hands them a password directly instead of an activation
// email. The method name is the activity name that saga dispatches by
// (ActivityEditUserActivationStatus), so it must not change.
//
// It runs after SeedTenantData and finds that seeding's user row by email, so
// the saga does not have to carry a user id across services.
//
// Idempotency is required, not optional: the saga retries this activity, and an
// UPDATE to the same value is naturally a no-op.
func (a *TenantDataActivities) EditUserActivationStatus(ctx context.Context, param temporal.EditUserActivationStatusParam) error {
	tenantSvc := a.tenantSvc(param.ClientID)

	userID, err := a.rowIDIfExists(ctx, tenantSvc, utilDb.UserTableName, sql_query.WhereQuery{
		"email": {Operator: sql_query.SQLOperatorEqual, Value: param.Email},
	})
	if err != nil {
		return fmt.Errorf("look up seeded user: %w", err)
	}
	if userID == 0 {
		return fmt.Errorf("no user with email %s in tenant %s", param.Email, param.ClientID)
	}

	if err := userRepository.NewUserRepository().UpdateActivationStatus(ctx, tenantSvc, userID, param.Status); err != nil {
		return fmt.Errorf("update activation status: %w", err)
	}
	return nil
}
