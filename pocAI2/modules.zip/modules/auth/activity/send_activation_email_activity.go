package activity

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	"gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	utilDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// activationTokenTTL is how long the seeded admin has to activate the account.
const activationTokenTTL = 24 * time.Hour

// publicSvc targets the shared public schema, where activation_tokens and
// user_credentials live.
func (a *TenantDataActivities) publicSvc() coreService.PostgreSQLServicer {
	return coreService.MakePostgreSQLService("public:" + a.dbName)
}

// SendActivationEmail issues the activation token the seeded admin uses to set
// their own password, and emails the raw token to them. The method name is the
// activity name the client-creation saga dispatches by
// (ActivitySendActivationEmail), so it must not change.
//
// It runs after SeedTenantData and finds that seeding's user row by email, so the
// saga does not have to carry a user id across services.
//
// Idempotency is required, not optional: the saga retries this activity, and a
// user who already has an active token keeps it rather than getting a second one.
//
// Only the SHA-256 of the token is stored: activation lookups hash the token
// from the link and match on token_hash, which a salted hash (bcrypt) could not
// be searched by. The emailed token is the exact hex string the hash covers.
func (a *TenantDataActivities) SendActivationEmail(ctx context.Context, param temporal.SendActivationEmailParam) error {
	// Neither service is closed on the way out: MakePostgreSQLService hands back a
	// pgxpool cached process-wide per database, so Close() would tear down the pool
	// every other activity and request is using.
	userID, err := a.rowIDIfExists(ctx, a.tenantSvc(param.ClientID), utilDb.UserTableName, sql_query.WhereQuery{
		"email": {Operator: sql_query.SQLOperatorEqual, Value: param.Email},
	})
	if err != nil {
		return fmt.Errorf("look up seeded user: %w", err)
	}
	if userID == 0 {
		return fmt.Errorf("no user with email %s in tenant %s", param.Email, param.ClientID)
	}

	svc := a.publicSvc()
	existing, err := a.rowIDIfExists(ctx, svc, utilDb.ActivationTokenTableName, sql_query.WhereQuery{
		"user_id":     {Operator: sql_query.SQLOperatorEqual, Value: userID},
		"client_code": {Operator: sql_query.SQLOperatorEqual, Value: param.ClientID},
		"status":      {Operator: sql_query.SQLOperatorEqual, Value: constant.TokenStatusActive},
	})
	if err != nil {
		return err
	}
	if existing != 0 {
		return nil
	}

	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		return err
	}
	rawToken := hex.EncodeToString(raw)

	if _, err := svc.InsertOneWithData(ctx, utilDb.ActivationTokenTableName, activationTokenRow{
		TokenHash:  helper.HashToken(rawToken),
		ClientCode: param.ClientID,
		UserID:     userID,
		ExpiresAt:  time.Now().Add(activationTokenTTL),
		Status:     constant.TokenStatusActive,
	}); err != nil {
		return err
	}

	if a.emailSvc == nil {
		slog.Error("Email service not set")
		return nil
	}

	return a.emailSvc.SendEmail(coreService.SendEmailProps{
		To:      param.Email,
		Subject: "Your " + param.ClientID + " account activation token",
		Body:    rawToken,
	})
}

// activationTokenRow is the subset of the public activation_tokens table this
// activity writes. status defaults to 'active' in the schema, so it is omitted.
type activationTokenRow struct {
	ID         int64             `json:"_id" column:"activation_tokens.id"`
	TokenHash  string            `json:"token_hash" column:"activation_tokens.token_hash"`
	ClientCode string            `json:"client_code" column:"activation_tokens.client_code"`
	UserID     int64             `json:"user_id" column:"activation_tokens.user_id"`
	ExpiresAt  time.Time         `json:"expires_at" column:"activation_tokens.expires_at"`
	Status     model.TokenStatus `json:"status" column:"activation_tokens.status"`
}
