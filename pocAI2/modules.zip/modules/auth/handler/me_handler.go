package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// MeHandler serves the /me endpoints. Identity comes from the headers the
// gateway stamps after a successful forwardAuth — never from the request body
// or a path parameter.
type MeHandler struct {
	svc *service.MeService
}

func NewMeHandler(svc *service.MeService) *MeHandler {
	return &MeHandler{svc: svc}
}

// HandleMePermissions serves GET /me/permissions.
func (h *MeHandler) HandleMePermissions(c fiber.Ctx) error {
	userID, clientCode, err := requestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	product, err := parseProduct(c.Query("product"))
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	payload, err := h.svc.Permissions(c.Context(), userID, clientCode, product)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Successfully retrieve permissions", payload)
}

// HandleMeSettings serves GET /me/settings.
func (h *MeHandler) HandleMeSettings(c fiber.Ctx) error {
	_, clientCode, err := requestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	payload, err := h.svc.Settings(c.Context(), clientCode)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Successfully retrieve settings", payload)
}

// HandleMeEntity serves GET /me/entity.
func (h *MeHandler) HandleMeEntity(c fiber.Ctx) error {
	_, clientCode, err := requestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	payload, err := h.svc.Entity(c.Context(), clientCode)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Successfully retrieve entity", payload)
}

// parseProduct validates the optional ?product filter.
func parseProduct(raw string) (*model.Product, error) {
	if raw == "" {
		return nil, nil
	}
	switch model.Product(raw) {
	case model.ProductGlobalSettings, model.ProductAdminConsole, model.ProductFixedAsset:
		product := model.Product(raw)
		return &product, nil
	default:
		return nil, coreEntity.UnprocessableEntity("Invalid product")
	}
}

// reads client id & userID from headers
func requestIdentity(c fiber.Ctx) (int64, string, error) {
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return 0, "", coreEntity.Unauthorized("Missing " + tsConstant.HEADER_CLIENT_ID)
	}
	raw := c.Get(tsConstant.HEADER_USER_ID)
	if raw == "" {
		return 0, "", coreEntity.Unauthorized("Missing " + tsConstant.HEADER_USER_ID)
	}
	userID, err := strconv.ParseInt(raw, 10, 64)
	if err != nil {
		return 0, "", coreEntity.Unauthorized("Invalid " + tsConstant.HEADER_USER_ID)
	}
	return userID, clientCode, nil
}

// HandleInvalidateTenantCache serves DELETE /internal/cache/me/tenant/:clientCode.
func (h *MeHandler) HandleInvalidateTenantCache(c fiber.Ctx) error {
	clientCode := c.Params("clientCode")
	if clientCode == "" {
		return coreEntity.BadRequest("Missing client code").SendResponse(c)
	}
	h.svc.InvalidateTenant(c.Context(), clientCode)
	return coreHelper.Success(c, "Cache invalidated", nil)
}

// HandleInvalidateSystemLimitsCache serves DELETE /internal/cache/me/system-limits.
func (h *MeHandler) HandleInvalidateSystemLimitsCache(c fiber.Ctx) error {
	h.svc.InvalidateSystemLimits(c.Context())
	return coreHelper.Success(c, "Cache invalidated", nil)
}
