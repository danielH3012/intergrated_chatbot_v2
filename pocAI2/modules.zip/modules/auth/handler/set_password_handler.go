package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *AuthHandler) HandleSetPassword(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.SetPasswordRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if body.Password == "" {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: constant.MsgPasswordEmpty}).SendResponse(c)
	}
	if body.ConfirmPassword == "" {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: constant.MsgConfirmPasswordEmpty}).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.SetPassword(ctx, service.SetPasswordParam{
		Token:           c.Params("token"),
		Password:        body.Password,
		ConfirmPassword: body.ConfirmPassword,
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, constant.MsgAccountActivated, resp)
}
