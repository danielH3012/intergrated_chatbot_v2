package handler

import (
	"github.com/gofiber/fiber/v3"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// HandleHeartbeat slides the idle window for the session identified by
// X-Session-ID (gateway-stamped).
func (h *AuthHandler) HandleHeartbeat(c fiber.Ctx) error {
	sessionID, err := parseSessionID(c)
	if err != nil {
		return err
	}

	resp, err := h.authSvc.Heartbeat(c.Context(), sessionID)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Heartbeat ok", resp)
}
