package handler_test

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	userRepository "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type mfaTestFixture struct {
	preAuth     *mfaStubPreAuthRepo
	user        *mfaStubUserRepo
	devices     *stubTrustedDeviceRepo
	pairs       *stubCountryPairRepo
	enrollments *stubAuthenticatorEnrollmentRepo
	sessions    *stubSessionRepo
	otp         *stubOtpRepo
	key         []byte
}

type mfaStubPreAuthRepo struct {
	row *model.PreAuthSession
}

func (s *mfaStubPreAuthRepo) GetActiveByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, hash string) (*model.PreAuthSession, error) {
	if s.row != nil && s.row.TokenHash == hash {
		return s.row, nil
	}
	return nil, pgx.ErrNoRows
}

func (s *mfaStubPreAuthRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.PreAuthSession) (int64, error) {
	return 1, nil
}

func (s *mfaStubPreAuthRepo) InvalidateActive(context.Context, coreService.PostgreSQLServicer, int64, string, model.Platform) error {
	return nil
}

func (s *mfaStubPreAuthRepo) Consume(context.Context, coreService.PostgreSQLServicer, int64) error {
	return nil
}

func (s *mfaStubPreAuthRepo) ConvertToMfa(context.Context, coreService.PostgreSQLServicer, int64, model.MfaReason) error {
	return nil
}

func (s *mfaStubPreAuthRepo) ConvertToDuplicateLogin(context.Context, coreService.PostgreSQLServicer, int64, int64) error {
	return nil
}

type mfaStubUserRepo struct {
	userRepository.UserRepositor
	user *userDto.UserListItem
}

func (s *mfaStubUserRepo) GetOneByID(_ context.Context, _ coreService.PostgreSQLServicer, _ int64) (*userDto.UserListItem, error) {
	if s.user == nil {
		return nil, pgx.ErrNoRows
	}
	return s.user, nil
}

func (s *mfaStubUserRepo) GetOneByEmail(context.Context, coreService.PostgreSQLServicer, string) (*userDto.UserListItem, error) {
	return s.user, nil
}

func (s *mfaStubUserRepo) UpdateFirstLoginAt(context.Context, coreService.PostgreSQLServicer, int64, time.Time) error {
	return nil
}

func (s *mfaStubUserRepo) UpdateAuthenticatorEnrolled(context.Context, coreService.PostgreSQLServicer, int64, bool) error {
	return nil
}

func (s *mfaStubUserRepo) UpdateActivationStatus(context.Context, coreService.PostgreSQLServicer, int64, string) error {
	return nil
}

type stubTrustedDeviceRepo struct{}

func (s *stubTrustedDeviceRepo) GetOneByIdentity(context.Context, coreService.PostgreSQLServicer, int64, string, model.Platform, string) (*model.TrustedDevice, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubTrustedDeviceRepo) Upsert(context.Context, coreService.PostgreSQLServicer, model.TrustedDevice) error {
	return nil
}

type stubCountryPairRepo struct{}

func (s *stubCountryPairRepo) GetOneByCorridor(context.Context, coreService.PostgreSQLServicer, int64, string, string, string) (*model.KnownCountryPair, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubCountryPairRepo) Upsert(context.Context, coreService.PostgreSQLServicer, model.KnownCountryPair) error {
	return nil
}

func (s *stubCountryPairRepo) ResetDecayed(context.Context, coreService.PostgreSQLServicer, int64, time.Time) error {
	return nil
}

type stubAuthenticatorEnrollmentRepo struct {
	enr *model.AuthenticatorEnrollment
}

func (s *stubAuthenticatorEnrollmentRepo) GetOneByUser(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ string) (*model.AuthenticatorEnrollment, error) {
	if s.enr == nil {
		return nil, pgx.ErrNoRows
	}
	return s.enr, nil
}

func (s *stubAuthenticatorEnrollmentRepo) InsertOne(_ context.Context, _ coreService.PostgreSQLServicer, enr model.AuthenticatorEnrollment) (int64, error) {
	s.enr = &enr
	return 1, nil
}

func (s *stubAuthenticatorEnrollmentRepo) Activate(_ context.Context, _ coreService.PostgreSQLServicer, _ int64, _ time.Time) error {
	if s.enr != nil {
		s.enr.IsActive = true
	}
	return nil
}

func (s *stubAuthenticatorEnrollmentRepo) DeleteByUser(context.Context, coreService.PostgreSQLServicer, int64, string) error {
	s.enr = nil
	return nil
}

type stubOtpRepo struct{}

func (s *stubOtpRepo) GetOneByHashForUpdate(context.Context, coreService.PostgreSQLServicer, string, string, string, string) (*model.OtpCode, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubOtpRepo) GetLatestByHashAndClient(context.Context, coreService.PostgreSQLServicer, string, string, string) (*model.OtpCode, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubOtpRepo) GetLatestInSession(context.Context, coreService.PostgreSQLServicer, string, string, int64) (*model.OtpCode, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubOtpRepo) InvalidateActive(context.Context, coreService.PostgreSQLServicer, string, string, string) error {
	return nil
}

func (s *stubOtpRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.OtpCode) (int64, error) {
	return 1, nil
}

func (s *stubOtpRepo) Consume(context.Context, coreService.PostgreSQLServicer, int64) error {
	return nil
}

func (s *stubOtpRepo) DeleteCreatedBefore(context.Context, coreService.PostgreSQLServicer, time.Time) (int64, error) {
	return 0, nil
}

func newMfaTestApp(t *testing.T, fix *mfaTestFixture) *fiber.App {
	t.Helper()

	policyAPI := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(`{"data":{"version":"2.0"}}`))
	}))
	t.Cleanup(policyAPI.Close)

	svc := service.NewAuthService(
		"tagsamurai_iam",
		nil,
		nil,
		fix.sessions,
		nil,
		fix.otp,
		nil,
		nil,
		fix.preAuth,
		nil,
		nil,
		fix.devices,
		fix.pairs,
		fix.enrollments,
		fix.user,
		nil,
		nil,
		nil,
		"", "",
		client.NewEnterpriseManagementClient(policyAPI.URL, "test-token", false),
		[]byte("test-key"),
		fix.key,
		"prod", // envType
	)
	svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	auth.SetupPublicRoutes(app, "test-cookie-domain", svc)
	return app
}

func postJSON(app *fiber.App, path, body string) (*http.Response, string) {
	req := httptest.NewRequest(fiber.MethodPost, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	raw, _ := io.ReadAll(res.Body)
	_ = res.Body.Close()
	return res, string(raw)
}

func TestMfaHandler_SendOtp_Validation(t *testing.T) {
	fix := &mfaTestFixture{
		preAuth:  &mfaStubPreAuthRepo{},
		sessions: &stubSessionRepo{},
		user:     &mfaStubUserRepo{},
		key:      []byte("platform-aes-256-secret-test-key-32b"),
	}
	app := newMfaTestApp(t, fix)

	res, _ := postJSON(app, "/auth/mfa/otp/send", `{"preAuthToken":`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for malformed json", res.StatusCode)
	}

	res, _ = postJSON(app, "/auth/mfa/otp/send", `{}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for missing preAuthToken", res.StatusCode)
	}

	res, _ = postJSON(app, "/auth/mfa/otp/send", `{"preAuthToken":"tok","otpSessionId":""}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for empty otpSessionId", res.StatusCode)
	}

	res, _ = postJSON(app, "/auth/mfa/otp/send", `{"preAuthToken":"tok","otpSessionId":"abc"}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for non-numeric otpSessionId", res.StatusCode)
	}

	res, _ = postJSON(app, "/auth/mfa/otp/send", `{"preAuthToken":"tok","otpSessionId":12345}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for number otpSessionId", res.StatusCode)
	}
}

func TestMfaHandler_VerifyOtp_Validation(t *testing.T) {
	fix := &mfaTestFixture{
		preAuth:  &mfaStubPreAuthRepo{},
		sessions: &stubSessionRepo{},
		user:     &mfaStubUserRepo{},
		key:      []byte("platform-aes-256-secret-test-key-32b"),
	}
	app := newMfaTestApp(t, fix)

	res, _ := postJSON(app, "/auth/mfa/otp/verify", `{"preAuthToken":`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for malformed json", res.StatusCode)
	}

	res, _ = postJSON(app, "/auth/mfa/otp/verify", `{"preAuthToken":"token"}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for missing otpCode and deviceId", res.StatusCode)
	}
}

func TestMfaHandler_VerifyAuthenticator_Validation(t *testing.T) {
	fix := &mfaTestFixture{
		preAuth:  &mfaStubPreAuthRepo{},
		sessions: &stubSessionRepo{},
		user:     &mfaStubUserRepo{},
		key:      []byte("platform-aes-256-secret-test-key-32b"),
	}
	app := newMfaTestApp(t, fix)

	res, _ := postJSON(app, "/auth/mfa/authenticator/verify", `{"preAuthToken":`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for malformed json", res.StatusCode)
	}

	res, _ = postJSON(app, "/auth/mfa/authenticator/verify", `{"preAuthToken":"token"}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 for missing totpCode and deviceId", res.StatusCode)
	}
}

func TestMfaHandler_EnrollAndVerifyAuthenticator(t *testing.T) {
	key := []byte("platform-aes-256-secret-test-key-32b")
	preAuthToken := "pat_valid_123"
	factor1 := constant.Factor1MethodPassword
	mfaReason := constant.MfaReasonFirstLogin
	yesterday := time.Now().Add(-24 * time.Hour)

	fix := &mfaTestFixture{
		preAuth: &mfaStubPreAuthRepo{
			row: &model.PreAuthSession{
				ID:            10,
				UserID:        7,
				ClientCode:    "acme",
				TokenHash:     helper.HashToken(preAuthToken),
				Purpose:       constant.PreAuthPurposeMfa,
				Status:        constant.PreAuthStatusActive,
				Factor1Method: &factor1,
				MfaReason:     &mfaReason,
				ExpiresAt:     time.Now().Add(10 * time.Minute),
			},
		},
		user: &mfaStubUserRepo{
			user: &userDto.UserListItem{
				ID:                      7,
				Email:                   "bob@example.com",
				IsActive:                true,
				ActivationStatus:        constant.ActivationStatusActivated,
				FirstLoginAt:            &yesterday,
				IsAuthenticatorEnrolled: false,
			},
		},
		devices:     &stubTrustedDeviceRepo{},
		pairs:       &stubCountryPairRepo{},
		enrollments: &stubAuthenticatorEnrollmentRepo{},
		sessions:    &stubSessionRepo{},
		otp:         &stubOtpRepo{},
		key:         key,
	}

	app := newMfaTestApp(t, fix)

	// 1. POST /auth/mfa/authenticator/enroll
	res, body := postJSON(app, "/auth/mfa/authenticator/enroll", `{"preAuthToken":"pat_valid_123"}`)
	if res.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200 (body %s)", res.StatusCode, body)
	}
	if !strings.Contains(body, "otpauth://totp/") || !strings.Contains(body, "Enrollment data generated") {
		t.Fatalf("unexpected enroll response: %s", body)
	}

	// 2. POST /auth/mfa/authenticator/enroll/verify with invalid code
	res, body = postJSON(app, "/auth/mfa/authenticator/enroll/verify", `{"preAuthToken":"pat_valid_123","verifyCode":"000000"}`)
	if res.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200 (body %s)", res.StatusCode, body)
	}
	if !strings.Contains(body, "VERIFY_INVALID") {
		t.Fatalf("expected VERIFY_INVALID in response: %s", body)
	}

	// 3. POST /auth/mfa/authenticator/enroll/verify with valid code
	decryptedSecret, _ := helper.DecryptSecret(fix.enrollments.enr.SecretEncrypted, key)
	secretBytes, _ := helper.DecodeTOTPSecret(string(decryptedSecret))
	validCode := helper.GenerateTOTPCode(secretBytes, time.Now())

	res, body = postJSON(app, "/auth/mfa/authenticator/enroll/verify", `{"preAuthToken":"pat_valid_123","verifyCode":"`+validCode+`"}`)
	if res.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200 (body %s)", res.StatusCode, body)
	}
	if !strings.Contains(body, "Authenticator app added") || !strings.Contains(body, "success") {
		t.Fatalf("expected success in response: %s", body)
	}
}
