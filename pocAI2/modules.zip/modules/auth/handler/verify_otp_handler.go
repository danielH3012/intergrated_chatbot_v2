package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *AuthHandler) HandleVerifyOTP(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.OtpVerifyRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.VerifyOTP(ctx, service.VerifyOTPParam{
		Email:     body.Email,
		Platform:  body.Platform,
		DeviceID:  body.DeviceID,
		OtpCode:   body.OtpCode,
		IPAddress: c.Req().IP(),
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	// Only a genuine success signs the session cookie; every other outcome is
	// a plain 200 envelope (or an error above), exactly like the login handler.
	if resp.Outcome == constant.OutcomeSuccess && resp.SessionID != nil {
		c.Cookie(&fiber.Cookie{
			Name:     constant.SessionCookieName,
			Value:    *resp.SessionID,
			Domain:   h.cookieDomain,
			HTTPOnly: true,
			Secure:   false,
			SameSite: "Lax",
			Path:     "/",
			MaxAge:   int(constant.SessionCookieMaxAge.Seconds()),
		})
	}

	return coreHelper.Success(c, constant.MsgLoginSuccessful, resp)
}
