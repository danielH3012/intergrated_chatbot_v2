package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// SessionTokenHeaderName lets a caller without a cookie jar — another service,
// or a developer driving the API by hand — present the same raw session token.
const SessionTokenHeaderName = "X-Session-Token"

// SessionHeaderIDName is the numeric session id the gateway stamps after a
// successful forwardAuth validation.
const SessionHeaderIDName = "X-Session-ID"

// HandleValidateSession is the gateway's forwardAuth target: it answers 2xx
// with the identity headers the gateway copies onto the request it forwards,
// and any non-2xx is returned to the client verbatim.
//
// GET only: Traefik's forwardAuth calls the auth address with a plain GET
// regardless of the client's original method (preserveRequestMethod is not set
// in api-gateway/conf/dynamic.yml).
func (h *AuthHandler) HandleValidateSession(c fiber.Ctx) error {
	rawToken := c.Cookies(constant.SessionCookieName)
	if rawToken == "" {
		rawToken = c.Get(SessionTokenHeaderName)
	}
	if rawToken == "" {
		return coreEntity.Unauthorized(constant.MsgSessionMissing).SendResponse(c)
	}

	resp, err := h.authSvc.ValidateSession(c.Context(), rawToken)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	// Listed in the gateway's authResponseHeaders — these, and only these, are
	// copied onto the forwarded request.
	c.Set(tsConstant.HEADER_USER_ID, strconv.FormatInt(resp.UserID, 10))
	c.Set(tsConstant.HEADER_CLIENT_ID, resp.ClientCode)
	c.Set(tsConstant.HEADER_ENTITY_ID, resp.ClientCode)
	if resp.SessionID != nil {
		c.Set(SessionHeaderIDName, strconv.FormatInt(*resp.SessionID, 10))
	}

	return coreHelper.Success(c, constant.MsgSessionValid, resp)
}
