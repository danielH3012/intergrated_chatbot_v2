package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

func (h *AuthHandler) HandleValidateResetToken(c fiber.Ctx) error {
	resp, err := h.authSvc.ValidateResetToken(c.Context(), c.Params("token"))
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, constant.MsgTokenValid, resp)
}
