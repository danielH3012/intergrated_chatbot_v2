package handler_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func newRequestOtpTestApp(t *testing.T) *fiber.App {
	t.Helper()

	policyAPI := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(`{"data":{"version":"2.0"}}`))
	}))
	t.Cleanup(policyAPI.Close)

	svc := service.NewAuthService(
		"tagsamurai_iam",
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		nil,
		"", "",
		client.NewEnterpriseManagementClient(policyAPI.URL, "test-token", false),
		[]byte("test-key"),
		[]byte("test-key-32-bytes-long-secret!!"),
		"prod",
	)
	svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	auth.SetupPublicRoutes(app, "test-cookie-domain", svc)
	return app
}

func TestRequestOtpHandler_Validation(t *testing.T) {
	app := newRequestOtpTestApp(t)

	t.Run("malformed JSON is 400", func(t *testing.T) {
		res, _ := postJSON(app, "/auth/otp/request", `{"email":`)
		if res.StatusCode != fiber.StatusBadRequest {
			t.Fatalf("status = %d, want 400 for malformed json", res.StatusCode)
		}
	})

	t.Run("missing platform is 400", func(t *testing.T) {
		res, _ := postJSON(app, "/auth/otp/request", `{"email":"test@example.com"}`)
		if res.StatusCode != fiber.StatusBadRequest {
			t.Fatalf("status = %d, want 400 for missing platform", res.StatusCode)
		}
	})

	t.Run("number otpSessionId is 400", func(t *testing.T) {
		res, _ := postJSON(app, "/auth/otp/request", `{"email":"test@example.com","platform":"web","otpSessionId":12345}`)
		if res.StatusCode != fiber.StatusBadRequest {
			t.Fatalf("status = %d, want 400 for number otpSessionId", res.StatusCode)
		}
	})

	t.Run("non-numeric string otpSessionId is 400", func(t *testing.T) {
		res, _ := postJSON(app, "/auth/otp/request", `{"email":"test@example.com","platform":"web","otpSessionId":"abc"}`)
		if res.StatusCode != fiber.StatusBadRequest {
			t.Fatalf("status = %d, want 400 for non-numeric otpSessionId", res.StatusCode)
		}
	})

	t.Run("empty string otpSessionId is 400", func(t *testing.T) {
		res, _ := postJSON(app, "/auth/otp/request", `{"email":"test@example.com","platform":"web","otpSessionId":""}`)
		if res.StatusCode != fiber.StatusBadRequest {
			t.Fatalf("status = %d, want 400 for empty otpSessionId", res.StatusCode)
		}
	})
}
