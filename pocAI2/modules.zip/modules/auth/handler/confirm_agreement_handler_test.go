package handler_test

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// Doubles: only the repositories the confirm-agreement route actually
// touches are scripted; everything else panics so a silent extra dependency
// shows up as a failure rather than as a nil-pointer surprise in production.

type stubPreAuthRepo struct {
	row      *model.PreAuthSession
	consumed []int64
}

func (s *stubPreAuthRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.PreAuthSession) (int64, error) {
	panic("not called")
}

func (s *stubPreAuthRepo) GetActiveByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.PreAuthSession, error) {
	if s.row == nil {
		return nil, pgx.ErrNoRows
	}
	return s.row, nil
}

func (s *stubPreAuthRepo) InvalidateActive(context.Context, coreService.PostgreSQLServicer, int64, string, model.Platform) error {
	return nil
}

func (s *stubPreAuthRepo) Consume(_ context.Context, _ coreService.PostgreSQLServicer, id int64) error {
	s.consumed = append(s.consumed, id)
	return nil
}

func (s *stubPreAuthRepo) ConvertToMfa(context.Context, coreService.PostgreSQLServicer, int64, model.MfaReason) error {
	panic("not called")
}

func (s *stubPreAuthRepo) ConvertToDuplicateLogin(context.Context, coreService.PostgreSQLServicer, int64, int64) error {
	panic("not called")
}

type stubConsentRepo struct{ writes int }

func (s *stubConsentRepo) GetOneByUserID(context.Context, coreService.PostgreSQLServicer, int64) (*model.UserPrivacyConsent, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubConsentRepo) Upsert(context.Context, coreService.PostgreSQLServicer, int64, string, time.Time) error {
	s.writes++
	return nil
}

type stubSessionRepo struct{ inserted int }

func (s *stubSessionRepo) GetActiveForUpdate(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) (*model.Session, error) {
	return nil, pgx.ErrNoRows
}

func (s *stubSessionRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.Session) error {
	s.inserted++
	return nil
}

func (s *stubSessionRepo) GetActiveByTokenHash(context.Context, coreService.PostgreSQLServicer, string) (*model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepo) GetByID(context.Context, coreService.PostgreSQLServicer, int64) (*model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepo) GetByTokenHash(context.Context, coreService.PostgreSQLServicer, string) (*model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepo) Touch(context.Context, coreService.PostgreSQLServicer, int64, time.Time, time.Duration) error {
	panic("not called")
}

func (s *stubSessionRepo) Terminate(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called")
}

func (s *stubSessionRepo) ListExpiredActive(context.Context, coreService.PostgreSQLServicer, time.Time, int) ([]model.Session, error) {
	panic("not called")
}

func (s *stubSessionRepo) TerminateAllActiveForUser(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called")
}

// newTestApp builds the app the handler tests hit: the real public routes,
// with the DB factory stubbed and enterprise-management faked.
func newTestApp(t *testing.T, preAuth *stubPreAuthRepo, consent *stubConsentRepo, sessions *stubSessionRepo) *fiber.App {
	t.Helper()

	policyAPI := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(`{"data":{"version":"2.0"}}`))
	}))
	t.Cleanup(policyAPI.Close)

	svc := service.NewAuthService(
		"tagsamurai_iam",
		nil,      // activation tokens
		nil,      // credentials
		sessions, // sessions
		nil,      // login locks
		nil,      // otp codes
		nil,      // reset tokens
		nil,      // reset attempts
		preAuth,  // pre-auth handoffs
		consent,  // privacy consent
		nil,      // product sessions
		nil,      // trusted devices
		nil,      // known country pairs
		nil,      // authenticator enrollments
		nil,      // tenant users
		nil,      // password provider
		nil,      // captcha provider
		nil,      // temporal
		"", "",   // task queues
		client.NewEnterpriseManagementClient(policyAPI.URL, "test-token", false),
		[]byte("test-key"),
		[]byte("test-key"),
		"prod", // envType
	)
	svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	auth.SetupPublicRoutes(app, "test-cookie-domain", svc)
	return app
}

func post(app *fiber.App, path, body string) (*http.Response, string) {
	req := httptest.NewRequest(fiber.MethodPost, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	raw, _ := io.ReadAll(res.Body)
	_ = res.Body.Close()
	return res, string(raw)
}

func livePendingHandoff() *model.PreAuthSession {
	factor1 := constant.Factor1MethodPassword
	policyVersion := "2.0"
	return &model.PreAuthSession{
		ID: 42, UserID: 7, ClientCode: "acme",
		Purpose: constant.PreAuthPurposeAgreement, Platform: constant.PlatformWeb,
		DeviceInfo: "device-1", IPAddress: "127.0.0.1",
		Factor1Method:      &factor1,
		AgreementPending:   true,
		ShownPolicyVersion: &policyVersion,
		Status:             constant.PreAuthStatusActive,
		ExpiresAt:          time.Now().Add(constant.PreAuthTTL),
		TokenHash:          helper.HashToken("raw-token"),
	}
}

func TestConfirmAgreement_MalformedBodyIs400(t *testing.T) {
	app := newTestApp(t, &stubPreAuthRepo{}, &stubConsentRepo{}, &stubSessionRepo{})

	res, body := post(app, "/auth/confirm-agreement", `{"preAuthToken":`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400: %s", res.StatusCode, body)
	}
}

func TestConfirmAgreement_MissingTokenIs400(t *testing.T) {
	app := newTestApp(t, &stubPreAuthRepo{}, &stubConsentRepo{}, &stubSessionRepo{})

	res, body := post(app, "/auth/confirm-agreement", `{"agreementAccepted":true}`)
	if res.StatusCode != fiber.StatusBadRequest {
		t.Fatalf("status = %d, want 400 â€” preAuthToken is required: %s", res.StatusCode, body)
	}
}

func TestConfirmAgreement_UnknownTokenIs401(t *testing.T) {
	app := newTestApp(t, &stubPreAuthRepo{}, &stubConsentRepo{}, &stubSessionRepo{})

	res, body := post(app, "/auth/confirm-agreement", `{"preAuthToken":"nope","agreementAccepted":true}`)
	if res.StatusCode != fiber.StatusUnauthorized {
		t.Fatalf("status = %d, want 401: %s", res.StatusCode, body)
	}
	if len(res.Cookies()) != 0 {
		t.Error("a rejected confirm must not set a session cookie")
	}
}

func TestConfirmAgreement_DeclineIs422WithPrdCopy(t *testing.T) {
	preAuth := &stubPreAuthRepo{row: livePendingHandoff()}
	consent := &stubConsentRepo{}
	app := newTestApp(t, preAuth, consent, &stubSessionRepo{})

	res, body := post(app, "/auth/confirm-agreement", `{"preAuthToken":"raw-token","agreementAccepted":false}`)
	if res.StatusCode != fiber.StatusUnprocessableEntity {
		t.Fatalf("status = %d, want 422: %s", res.StatusCode, body)
	}
	var envelope struct {
		Message string `json:"message"`
	}
	if err := json.Unmarshal([]byte(body), &envelope); err != nil {
		t.Fatalf("body is not the standard envelope: %v (%s)", err, body)
	}
	if envelope.Message != constant.MsgAgreementDeclined {
		t.Errorf("message = %q, want the PRD copy %q", envelope.Message, constant.MsgAgreementDeclined)
	}
	if consent.writes != 0 {
		t.Error("a decline must not record consent")
	}
	if len(preAuth.consumed) != 1 {
		t.Error("a decline must consume the handoff")
	}
}

func TestConfirmAgreement_AcceptSetsSessionCookie(t *testing.T) {
	sessions := &stubSessionRepo{}
	app := newTestApp(t, &stubPreAuthRepo{row: livePendingHandoff()}, &stubConsentRepo{}, sessions)

	res, body := post(app, "/auth/confirm-agreement", `{"preAuthToken":"raw-token","agreementAccepted":true}`)
	if res.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200: %s", res.StatusCode, body)
	}
	if sessions.inserted != 1 {
		t.Fatalf("sessions inserted = %d, want 1", sessions.inserted)
	}

	var envelope struct {
		Data struct {
			Outcome    string `json:"outcome"`
			RedirectTo string `json:"redirectTo"`
			SessionID  string `json:"sessionId"`
		} `json:"data"`
	}
	if err := json.Unmarshal([]byte(body), &envelope); err != nil {
		t.Fatalf("decode: %v (%s)", err, body)
	}
	if envelope.Data.Outcome != constant.OutcomeSuccess || envelope.Data.RedirectTo != constant.RedirectProductHub {
		t.Errorf("data = %+v, want success + product hub", envelope.Data)
	}

	var cookie *http.Cookie
	for _, c := range res.Cookies() {
		if c.Name == constant.SessionCookieName {
			cookie = c
		}
	}
	if cookie == nil {
		t.Fatalf("no %q cookie set; got %v", constant.SessionCookieName, res.Cookies())
	}
	if cookie.Value != envelope.Data.SessionID {
		t.Errorf("cookie value %q != returned sessionId %q", cookie.Value, envelope.Data.SessionID)
	}
	if !cookie.HttpOnly {
		t.Errorf("session cookie must be HttpOnly, got %+v", cookie)
	}
}
