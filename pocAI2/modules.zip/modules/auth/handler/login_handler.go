package handler

import (
	"context"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleLogin backs POST /auth/login.
func (h *AuthHandler) HandleLogin(c fiber.Ctx) error {
	return h.handleLogin(c, h.authSvc.Login)
}

// HandleDevLogin backs POST /dev/auth/login. Same request/response contract as
// HandleLogin; the service it calls skips captcha, agreement, and MFA gates.
// Dev-only — the route is registered only when config.DevRoutesEnabled is set.
func (h *AuthHandler) HandleDevLogin(c fiber.Ctx) error {
	return h.handleLogin(c, h.authSvc.DevLogin)
}

// handleLogin is the shared transport half of both login routes: bind,
// validate, delegate, set the session cookie on success. The only difference
// between the two routes is which service function runs the gates.
func (h *AuthHandler) handleLogin(c fiber.Ctx, login func(context.Context, service.LoginParam) (*dto.LoginResponse, error)) error {
	ctx := c.Context()

	var body dto.LoginRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := login(ctx, service.LoginParam{
		Email:          body.Email,
		Password:       body.Password,
		RecaptchaToken: body.RecaptchaToken,
		Platform:       body.Platform,
		DeviceID:       body.DeviceID,
		IPAddress:      c.Req().IP(),
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	// The failure/lock/agreement/mfa outcomes are all HTTP 200 with the same
	// envelope message — only genuine 422/500 errors go through ToHttpError
	// above. See LoginResponse.outcome for what actually happened.
	if resp.Outcome == constant.OutcomeSuccess && resp.SessionID != nil {
		c.Cookie(&fiber.Cookie{
			Name:     constant.SessionCookieName,
			Value:    *resp.SessionID,
			Domain:   h.cookieDomain,
			HTTPOnly: true,
			Secure:   false,
			SameSite: "Lax",
			Path:     "/",
			MaxAge:   int(constant.SessionCookieMaxAge.Seconds()),
		})
	}

	return coreHelper.Success(c, constant.MsgLoginSuccessful, resp)
}
