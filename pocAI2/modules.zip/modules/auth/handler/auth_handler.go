// Package handler serves the auth API surface (activation, login).
package handler

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
)

type AuthHandler struct {
	cookieDomain string

	authSvc *service.AuthService
}

func NewAuthHandler(authSvc *service.AuthService, cookieDomain string) *AuthHandler {
	return &AuthHandler{authSvc: authSvc, cookieDomain: cookieDomain}
}
