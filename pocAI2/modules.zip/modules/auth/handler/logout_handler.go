package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// HandleLogout terminates the session identified by X-Session-ID (gateway-stamped).
func (h *AuthHandler) HandleLogout(c fiber.Ctx) error {
	sessionID, err := parseSessionID(c)
	if err != nil {
		return err
	}

	resp, err := h.authSvc.Logout(c.Context(), sessionID)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	// Clear the session cookie.
	c.Cookie(&fiber.Cookie{
		Name:     constant.SessionCookieName,
		Value:    "",
		Domain:   h.cookieDomain,
		HTTPOnly: true,
		Secure:   false,
		SameSite: "Lax",
		Path:     "/",
		MaxAge:   -1,
	})

	return coreHelper.Success(c, "Logged out", resp)
}

// parseSessionID extracts the numeric X-Session-ID header set by the gateway.
func parseSessionID(c fiber.Ctx) (int64, error) {
	raw := c.Get(SessionHeaderIDName)
	if raw == "" {
		return 0, coreEntity.Unauthorized(constant.MsgSessionMissing)
	}
	id, err := strconv.ParseInt(raw, 10, 64)
	if err != nil {
		return 0, coreEntity.Unauthorized(constant.MsgSessionInvalid)
	}
	return id, nil
}
