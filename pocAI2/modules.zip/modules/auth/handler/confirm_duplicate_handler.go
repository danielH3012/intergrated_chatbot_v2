package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *AuthHandler) HandleConfirmDuplicate(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.ConfirmDuplicateRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.ConfirmDuplicate(ctx, body, c.Req().IP())
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	if resp.Outcome == constant.OutcomeConfirmed && resp.SessionID != nil {
		c.Cookie(&fiber.Cookie{
			Name:     constant.SessionCookieName,
			Value:    *resp.SessionID,
			Domain:   h.cookieDomain,
			HTTPOnly: true,
			Secure:   false,
			SameSite: "Lax",
			Path:     "/",
			MaxAge:   int(constant.SessionCookieMaxAge.Seconds()),
		})
	}

	return coreHelper.Success(c, "Duplicate resolved", resp)
}
