package handler

import (
	"encoding/json"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

func TestHandleSetPasswordEmptyFields(t *testing.T) {
	tests := []struct {
		name    string
		body    string
		message string
	}{
		{
			name:    "password",
			body:    `{"confirmPassword":"Valid1!x"}`,
			message: constant.MsgPasswordEmpty,
		},
		{
			name:    "confirm password",
			body:    `{"password":"Valid1!x"}`,
			message: constant.MsgConfirmPasswordEmpty,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			app := fiber.New()
			app.Post("/auth/activation/:token/set-password", (&AuthHandler{}).HandleSetPassword)

			req := httptest.NewRequest(
				fiber.MethodPost,
				"/auth/activation/token/set-password",
				strings.NewReader(tt.body),
			)
			req.Header.Set("Content-Type", "application/json")
			res, err := app.Test(req)
			if err != nil {
				t.Fatalf("request failed: %v", err)
			}
			defer res.Body.Close()

			if res.StatusCode != fiber.StatusUnprocessableEntity {
				raw, _ := io.ReadAll(res.Body)
				t.Fatalf("status = %d, want 422: %s", res.StatusCode, raw)
			}

			var envelope struct {
				Message string `json:"message"`
			}
			if err := json.NewDecoder(res.Body).Decode(&envelope); err != nil {
				t.Fatalf("decode response: %v", err)
			}
			if envelope.Message != tt.message {
				t.Errorf("message = %q, want %q", envelope.Message, tt.message)
			}
		})
	}
}
