package handler

import (
	"net/http/httptest"
	"testing"

	"github.com/gofiber/fiber/v3"

	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
)

// Every /me answer is derived from the gateway-stamped identity. A request
// without it must be refused rather than answered for whoever seems likely —
// these are the cases where a wrong default would leak another user's data.
func TestRequestIdentityRejectsMissingHeaders(t *testing.T) {
	cases := []struct {
		name    string
		user    string
		client  string
		wantErr bool
	}{
		{name: "both present", user: "42", client: "acme"},
		{name: "no user", client: "acme", wantErr: true},
		{name: "no client", user: "42", wantErr: true},
		{name: "unparseable user", user: "not-a-number", client: "acme", wantErr: true},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			app := fiber.New()
			var gotUser int64
			var gotClient string
			var gotErr error
			app.Get("/probe", func(c fiber.Ctx) error {
				gotUser, gotClient, gotErr = requestIdentity(c)
				return c.SendStatus(fiber.StatusOK)
			})

			req := httptest.NewRequest(fiber.MethodGet, "/probe", nil)
			if tc.user != "" {
				req.Header.Set(tsConstant.HEADER_USER_ID, tc.user)
			}
			if tc.client != "" {
				req.Header.Set(tsConstant.HEADER_CLIENT_ID, tc.client)
			}
			if _, err := app.Test(req); err != nil {
				t.Fatalf("request: %v", err)
			}

			if tc.wantErr {
				if gotErr == nil {
					t.Fatalf("want an error, got user %d / client %q", gotUser, gotClient)
				}
				return
			}
			if gotErr != nil {
				t.Fatalf("unexpected error: %v", gotErr)
			}
			if gotUser != 42 || gotClient != "acme" {
				t.Errorf("identity = %d/%q", gotUser, gotClient)
			}
		})
	}
}

func TestParseProduct(t *testing.T) {
	if got, err := parseProduct(""); err != nil || got != nil {
		t.Errorf("empty product = %v, %v; want no filter", got, err)
	}
	got, err := parseProduct("fixed_asset")
	if err != nil || got == nil || string(*got) != "fixed_asset" {
		t.Errorf("fixed_asset = %v, %v", got, err)
	}
	// Rejected rather than ignored: silently returning every product would look
	// to the caller like the filter had been applied.
	if _, err := parseProduct("supply_asset"); err == nil {
		t.Error("unknown product was accepted")
	}
}
