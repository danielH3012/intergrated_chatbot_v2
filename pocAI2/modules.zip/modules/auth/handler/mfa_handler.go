package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleSendMfaOtp handles POST /auth/mfa/otp/send to issue or resend a factor-2 OTP code.
func (h *AuthHandler) HandleSendMfaOtp(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.MfaOtpSendRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.SendMfaOtp(ctx, body, c.Req().IP())
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	msg := constant.MsgVerificationCodeSent
	if resp.Outcome == constant.OutcomeFailed && resp.ErrorCode != nil {
		switch *resp.ErrorCode {
		case constant.ErrorCodeResendLimitExceeded:
			msg = constant.MsgTooManyAttempts
		case constant.ErrorCodePreAuthSessionExpired:
			msg = constant.MsgSessionExpiredLoginAgain
		case constant.ErrorCodeInactive:
			msg = constant.MsgInactive
		}
	}

	return coreHelper.Success(c, msg, resp)
}

// HandleVerifyMfaOtp handles POST /auth/mfa/otp/verify to verify factor-2 email OTP.
func (h *AuthHandler) HandleVerifyMfaOtp(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.MfaOtpVerifyRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.VerifyMfaOtp(ctx, body, c.Req().IP())
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	msg := constant.MsgLoginSuccessful
	if resp.Outcome == constant.OutcomeSuccess && resp.SessionToken != nil {
		c.Cookie(&fiber.Cookie{
			Name:     constant.SessionCookieName,
			Value:    *resp.SessionToken,
			Domain:   h.cookieDomain,
			HTTPOnly: true,
			Secure:   true,
			SameSite: "Lax",
			Path:     "/",
			MaxAge:   int(constant.SessionCookieMaxAge.Seconds()),
		})
	} else if resp.Outcome == constant.OutcomeFailed && resp.ErrorCode != nil {
		switch *resp.ErrorCode {
		case constant.ErrorCodeOtpInvalid, constant.ErrorCodeOtpEmailChanged:
			msg = constant.MsgInvalidCode
		case constant.ErrorCodeOtpExpired:
			msg = constant.MsgOtpExpired
		case constant.ErrorCodePreAuthSessionExpired:
			msg = constant.MsgSessionExpiredLoginAgain
		case constant.ErrorCodeOtpEmpty:
			msg = constant.MsgEnter6DigitCode
		case constant.ErrorCodeInactive:
			msg = constant.MsgInactive
		}
	}

	return coreHelper.Success(c, msg, resp)
}

// HandleVerifyMfaAuthenticator handles POST /auth/mfa/authenticator/verify to verify TOTP.
func (h *AuthHandler) HandleVerifyMfaAuthenticator(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.MfaAuthenticatorVerifyRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.VerifyMfaAuthenticator(ctx, body, c.Req().IP())
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	msg := constant.MsgLoginSuccessful
	if resp.Outcome == constant.OutcomeSuccess && resp.SessionToken != nil {
		c.Cookie(&fiber.Cookie{
			Name:     constant.SessionCookieName,
			Value:    *resp.SessionToken,
			Domain:   h.cookieDomain,
			HTTPOnly: true,
			Secure:   true,
			SameSite: "Lax",
			Path:     "/",
			MaxAge:   int(constant.SessionCookieMaxAge.Seconds()),
		})
	} else if resp.Outcome == constant.OutcomeFailed && resp.ErrorCode != nil {
		switch *resp.ErrorCode {
		case constant.ErrorCodeTotpInvalid:
			msg = constant.MsgInvalidCode
		case constant.ErrorCodePreAuthSessionExpired:
			msg = constant.MsgSessionExpiredLoginAgain
		case constant.ErrorCodeTotpEmpty:
			msg = constant.MsgEnter6DigitCode
		case constant.ErrorCodeInactive:
			msg = constant.MsgInactive
		}
	}

	return coreHelper.Success(c, msg, resp)
}

// HandleEnrollMfaAuthenticator handles POST /auth/mfa/authenticator/enroll to generate QR/secret.
func (h *AuthHandler) HandleEnrollMfaAuthenticator(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.MfaEnrollRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.EnrollMfaAuthenticator(ctx, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, constant.MsgEnrollmentGenerated, resp)
}

// HandleVerifyEnrollMfaAuthenticator handles POST /auth/mfa/authenticator/enroll/verify to activate enrollment.
func (h *AuthHandler) HandleVerifyEnrollMfaAuthenticator(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.MfaEnrollVerifyRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.VerifyEnrollMfaAuthenticator(ctx, body, c.Req().IP())
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	msg := constant.MsgAuthenticatorAdded
	if resp.Outcome == constant.OutcomeFailed && resp.ErrorCode != nil {
		switch *resp.ErrorCode {
		case constant.ErrorCodeVerifyInvalid:
			msg = constant.MsgInvalidCode
		case constant.ErrorCodeVerifyEmpty:
			msg = constant.MsgEnter6DigitCode
		case constant.ErrorCodePreAuthSessionExpired:
			msg = constant.MsgSessionExpiredLoginAgain
		case constant.ErrorCodeInactive:
			msg = constant.MsgInactive
		}
	}

	return coreHelper.Success(c, msg, resp)
}
