package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *AuthHandler) HandleRequestOTP(c fiber.Ctx) error {
	ctx := c.Context()

	var body dto.OtpRequestRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.BadRequest(err.Error()).SendResponse(c)
	}

	resp, err := h.authSvc.RequestOTP(ctx, service.RequestOTPParam{
		Email:          body.Email,
		Platform:       body.Platform,
		RecaptchaToken: body.RecaptchaToken,
		OtpSessionID:   body.OtpSessionId,
		IPAddress:      c.Req().IP(),
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, constant.MsgOtpRequestSent, resp)
}
