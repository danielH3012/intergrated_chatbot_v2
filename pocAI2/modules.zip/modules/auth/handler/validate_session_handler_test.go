package handler_test

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type validateSessionStubRepo struct {
	session *model.Session
}

func (s *validateSessionStubRepo) GetActiveForUpdate(context.Context, coreService.PostgreSQLServicer, int64, model.Platform) (*model.Session, error) {
	panic("not called by validateSession")
}

func (s *validateSessionStubRepo) GetActiveByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error) {
	if s.session != nil && tokenHash == helper.HashToken("valid-token") {
		return s.session, nil
	}
	return nil, pgx.ErrNoRows
}

func (s *validateSessionStubRepo) GetByID(context.Context, coreService.PostgreSQLServicer, int64) (*model.Session, error) {
	panic("not called by validateSession")
}

func (s *validateSessionStubRepo) GetByTokenHash(_ context.Context, _ coreService.PostgreSQLServicer, _ string) (*model.Session, error) {
	return nil, pgx.ErrNoRows
}

func (s *validateSessionStubRepo) Touch(context.Context, coreService.PostgreSQLServicer, int64, time.Time, time.Duration) error {
	return nil
}

func (s *validateSessionStubRepo) Terminate(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called by validateSession")
}

func (s *validateSessionStubRepo) ListExpiredActive(context.Context, coreService.PostgreSQLServicer, time.Time, int) ([]model.Session, error) {
	panic("not called by validateSession")
}

func (s *validateSessionStubRepo) TerminateAllActiveForUser(context.Context, coreService.PostgreSQLServicer, int64, model.SessionStatus, model.TerminatedReason, time.Time) (int64, error) {
	panic("not called by validateSession")
}

func (s *validateSessionStubRepo) InsertOne(context.Context, coreService.PostgreSQLServicer, model.Session) error {
	panic("not called by validateSession")
}

func newValidateSessionApp(sessionRepo *validateSessionStubRepo) *fiber.App {
	svc := service.NewAuthService(
		"tagsamurai_iam",
		nil,         // tokenRepo
		nil,         // credRepo
		sessionRepo, // sessionRepo
		nil,         // lockRepo
		nil,         // otpRepo
		nil,         // resetTokenRepo
		nil,         // resetAttemptRepo
		nil,         // preAuthRepo
		nil,         // consentRepo
		nil,         // productSessionRepo
		nil,         // trustedDeviceRepo
		nil,         // countryPairRepo
		nil,         // authenticatorRepo
		nil,         // userRepo
		nil,         // password
		nil,         // captcha
		nil,         // temporalSvc
		"", "",      // queues
		nil, // generalSettingsClient (handles nil safely)
		[]byte("test-key"),
		[]byte("test-key"),
		"test",
	)
	svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	auth.SetupPublicRoutes(app, "test-cookie-domain", svc)
	return app
}

func TestHandleValidateSession_LiveSessionCookie(t *testing.T) {
	sessionID := int64(42)
	live := &model.Session{
		ID:         sessionID,
		UserID:     7,
		ClientCode: "acme",
	}
	app := newValidateSessionApp(&validateSessionStubRepo{session: live})

	req := httptest.NewRequest(fiber.MethodGet, "/auth/validate", nil)
	req.AddCookie(&http.Cookie{
		Name:  constant.SessionCookieName,
		Value: "valid-token",
	})

	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode != fiber.StatusOK {
		body, _ := io.ReadAll(res.Body)
		t.Fatalf("status = %d, want 200: %s", res.StatusCode, string(body))
	}

	// Gateway forwardAuth identity headers
	gotUserID := res.Header.Get(tsConstant.HEADER_USER_ID)
	gotClientID := res.Header.Get(tsConstant.HEADER_CLIENT_ID)
	gotEntityID := res.Header.Get(tsConstant.HEADER_ENTITY_ID)
	gotSessionID := res.Header.Get(handler.SessionHeaderIDName)

	if gotUserID != "7" {
		t.Errorf("X-User-ID = %q, want \"7\"", gotUserID)
	}
	if gotClientID != "acme" {
		t.Errorf("X-Client-ID = %q, want \"acme\"", gotClientID)
	}
	if gotEntityID != "acme" {
		t.Errorf("X-Entity-ID = %q, want \"acme\"", gotEntityID)
	}
	if gotEntityID != gotClientID {
		t.Errorf("X-Entity-ID (%q) != X-Client-ID (%q)", gotEntityID, gotClientID)
	}
	if gotSessionID != "42" {
		t.Errorf("X-Session-ID = %q, want \"42\"", gotSessionID)
	}

	// Body contract verification
	var envelope struct {
		Code    int    `json:"code"`
		Status  string `json:"status"`
		Message string `json:"message"`
		Data    struct {
			UserID     int64  `json:"userId"`
			ClientCode string `json:"clientCode"`
			SessionID  *int64 `json:"sessionId"`
		} `json:"data"`
	}
	if err := json.NewDecoder(res.Body).Decode(&envelope); err != nil {
		t.Fatalf("failed to decode response envelope: %v", err)
	}
	if envelope.Message != constant.MsgSessionValid {
		t.Errorf("envelope message = %q, want %q", envelope.Message, constant.MsgSessionValid)
	}
	if envelope.Data.UserID != 7 || envelope.Data.ClientCode != "acme" || envelope.Data.SessionID == nil || *envelope.Data.SessionID != 42 {
		t.Errorf("envelope data = %+v, want userId=7 clientCode=acme sessionId=42", envelope.Data)
	}
}

func TestHandleValidateSession_LiveSessionTokenHeader(t *testing.T) {
	sessionID := int64(101)
	live := &model.Session{
		ID:         sessionID,
		UserID:     12,
		ClientCode: "tenant-beta",
	}
	app := newValidateSessionApp(&validateSessionStubRepo{session: live})

	req := httptest.NewRequest(fiber.MethodGet, "/auth/validate", nil)
	req.Header.Set(handler.SessionTokenHeaderName, "valid-token")

	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode != fiber.StatusOK {
		body, _ := io.ReadAll(res.Body)
		t.Fatalf("status = %d, want 200: %s", res.StatusCode, string(body))
	}

	gotUserID := res.Header.Get(tsConstant.HEADER_USER_ID)
	gotClientID := res.Header.Get(tsConstant.HEADER_CLIENT_ID)
	gotEntityID := res.Header.Get(tsConstant.HEADER_ENTITY_ID)
	gotSessionID := res.Header.Get(handler.SessionHeaderIDName)

	if gotUserID != "12" {
		t.Errorf("X-User-ID = %q, want \"12\"", gotUserID)
	}
	if gotClientID != "tenant-beta" {
		t.Errorf("X-Client-ID = %q, want \"tenant-beta\"", gotClientID)
	}
	if gotEntityID != "tenant-beta" {
		t.Errorf("X-Entity-ID = %q, want \"tenant-beta\"", gotEntityID)
	}
	if gotEntityID != gotClientID {
		t.Errorf("X-Entity-ID (%q) != X-Client-ID (%q)", gotEntityID, gotClientID)
	}
	if gotSessionID != "101" {
		t.Errorf("X-Session-ID = %q, want \"101\"", gotSessionID)
	}
}

func TestHandleValidateSession_MissingSessionReturns401(t *testing.T) {
	app := newValidateSessionApp(&validateSessionStubRepo{})

	req := httptest.NewRequest(fiber.MethodGet, "/auth/validate", nil)
	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode != fiber.StatusUnauthorized {
		body, _ := io.ReadAll(res.Body)
		t.Fatalf("status = %d, want 401: %s", res.StatusCode, string(body))
	}

	// No identity headers should be set on unauthorized
	if h := res.Header.Get(tsConstant.HEADER_USER_ID); h != "" {
		t.Errorf("X-User-ID must not be set on 401, got %q", h)
	}
	if h := res.Header.Get(tsConstant.HEADER_CLIENT_ID); h != "" {
		t.Errorf("X-Client-ID must not be set on 401, got %q", h)
	}
	if h := res.Header.Get(tsConstant.HEADER_ENTITY_ID); h != "" {
		t.Errorf("X-Entity-ID must not be set on 401, got %q", h)
	}
	if h := res.Header.Get(handler.SessionHeaderIDName); h != "" {
		t.Errorf("X-Session-ID must not be set on 401, got %q", h)
	}

	var envelope struct {
		Message string `json:"message"`
	}
	if err := json.NewDecoder(res.Body).Decode(&envelope); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}
	if envelope.Message != constant.MsgSessionMissing {
		t.Errorf("message = %q, want %q", envelope.Message, constant.MsgSessionMissing)
	}
}

func TestHandleValidateSession_InvalidSessionReturns401(t *testing.T) {
	app := newValidateSessionApp(&validateSessionStubRepo{session: nil})

	req := httptest.NewRequest(fiber.MethodGet, "/auth/validate", nil)
	req.AddCookie(&http.Cookie{
		Name:  constant.SessionCookieName,
		Value: "invalid-token",
	})

	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode != fiber.StatusUnauthorized {
		body, _ := io.ReadAll(res.Body)
		t.Fatalf("status = %d, want 401: %s", res.StatusCode, string(body))
	}

	if h := res.Header.Get(tsConstant.HEADER_USER_ID); h != "" {
		t.Errorf("X-User-ID must not be set on 401, got %q", h)
	}
	if h := res.Header.Get(tsConstant.HEADER_CLIENT_ID); h != "" {
		t.Errorf("X-Client-ID must not be set on 401, got %q", h)
	}
	if h := res.Header.Get(tsConstant.HEADER_ENTITY_ID); h != "" {
		t.Errorf("X-Entity-ID must not be set on 401, got %q", h)
	}
	if h := res.Header.Get(handler.SessionHeaderIDName); h != "" {
		t.Errorf("X-Session-ID must not be set on 401, got %q", h)
	}

	var envelope struct {
		Message string `json:"message"`
	}
	if err := json.NewDecoder(res.Body).Decode(&envelope); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}
	if envelope.Message != constant.MsgSessionInvalid {
		t.Errorf("message = %q, want %q", envelope.Message, constant.MsgSessionInvalid)
	}
}

func TestHandleValidateSession_OverridesClientSuppliedIdentityHeaders(t *testing.T) {
	sessionID := int64(88)
	live := &model.Session{
		ID:         sessionID,
		UserID:     99,
		ClientCode: "legit-tenant",
	}
	app := newValidateSessionApp(&validateSessionStubRepo{session: live})

	req := httptest.NewRequest(fiber.MethodGet, "/auth/validate", nil)
	req.AddCookie(&http.Cookie{
		Name:  constant.SessionCookieName,
		Value: "valid-token",
	})
	// Simulate an adversary attempting to spoof identity headers
	req.Header.Set(tsConstant.HEADER_USER_ID, "666")
	req.Header.Set(tsConstant.HEADER_CLIENT_ID, "attacker-client")
	req.Header.Set(tsConstant.HEADER_ENTITY_ID, "attacker-entity")

	res, err := app.Test(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer res.Body.Close()

	if res.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200", res.StatusCode)
	}

	gotUserID := res.Header.Get(tsConstant.HEADER_USER_ID)
	gotClientID := res.Header.Get(tsConstant.HEADER_CLIENT_ID)
	gotEntityID := res.Header.Get(tsConstant.HEADER_ENTITY_ID)

	if gotUserID != "99" {
		t.Errorf("X-User-ID = %q, want \"99\" (overriding spoofed header)", gotUserID)
	}
	if gotClientID != "legit-tenant" {
		t.Errorf("X-Client-ID = %q, want \"legit-tenant\" (overriding spoofed header)", gotClientID)
	}
	if gotEntityID != "legit-tenant" {
		t.Errorf("X-Entity-ID = %q, want \"legit-tenant\" (overriding spoofed header)", gotEntityID)
	}
	if gotEntityID != gotClientID {
		t.Errorf("X-Entity-ID (%q) != X-Client-ID (%q)", gotEntityID, gotClientID)
	}
}
