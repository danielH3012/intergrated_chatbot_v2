package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const sessionTableName = "sessions"

type SessionRepositor interface {
	// GetActiveForUpdate finds a still-live session for (userID, platform),
	// locked for the duration of the transaction — this is what Limit Login
	// checks before a new session may be created. pgx.ErrNoRows means none
	// exists.
	GetActiveForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.Session, error)
	// GetActiveByTokenHash finds a still-live session by its bearer token's
	// hash — the gateway's per-request lookup. pgx.ErrNoRows means the token is
	// unknown, revoked, or idled out; the caller must not distinguish those.
	GetActiveByTokenHash(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error)
	// GetByID finds a session by its numeric id, any status — heartbeat and
	// logout lookup by the gateway-supplied id.
	GetByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Session, error)
	// GetByTokenHash finds a session by its token hash, any status — the
	// on-read expiry path needs to find active-but-expired rows that
	// GetActiveByTokenHash filters out.
	GetByTokenHash(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error)
	// Touch slides the idle window: last_activity_at = now, expires_at = now +
	// idle timeout. Separate from the read so a failure here is degraded, not
	// fatal — the session keeps its original expiry.
	Touch(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, now time.Time, idleTimeout time.Duration) error
	// Terminate sets status and terminated_reason on an active session.
	// The WHERE status='active' guard is the idempotency mechanism: a
	// concurrent sweep or on-read check that lands second affects zero rows.
	// Returns the number of rows affected.
	Terminate(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, status model.SessionStatus, reason model.TerminatedReason, now time.Time) (int64, error)
	// ListExpiredActive returns active sessions whose expires_at has passed,
	// limited to the given batch size — the idle sweep's query.
	ListExpiredActive(ctx context.Context, svc coreService.PostgreSQLServicer, now time.Time, limit int) ([]model.Session, error)
	// TerminateAllActiveForUser force-terminates every active session for a
	// user — account cascade (deletion / deactivation).
	TerminateAllActiveForUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, status model.SessionStatus, reason model.TerminatedReason, now time.Time) (int64, error)
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, session model.Session) error
}

var _ SessionRepositor = (*SessionRepository)(nil)

type SessionRepository struct{}

func NewSessionRepository() *SessionRepository {
	return &SessionRepository{}
}

func (r *SessionRepository) GetActiveForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.Session, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.Session](sessionTableName).
		Where(sql_query.WhereQuery{
			"user_id":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"platform":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platform},
			"status":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.SessionStatusActive},
			"expires_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorGreaterThan, Value: time.Now()},
		}).
		SetLimit(1).
		ForUpdate(nil).
		Build()
	if err != nil {
		return nil, err
	}

	var session model.Session
	if err := svc.SelectOne(&session, ctx, query, args...); err != nil {
		return nil, err
	}
	return &session, nil
}

func (r *SessionRepository) GetActiveByTokenHash(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.Session](sessionTableName).
		Where(sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: tokenHash},
			"status":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.SessionStatusActive},
			"expires_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorGreaterThan, Value: time.Now()},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var session model.Session
	if err := svc.SelectOne(&session, ctx, query, args...); err != nil {
		return nil, err
	}
	return &session, nil
}

func (r *SessionRepository) Touch(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, now time.Time, idleTimeout time.Duration) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		sessionTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"last_activity_at": now,
			"expires_at":       now.Add(idleTimeout),
			"updated_at":       now,
		},
	)
	return err
}

// InsertOne generates id and timestamps server-side; leave those fields zero
// on session.
func (r *SessionRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, session model.Session) error {
	_, err := svc.InsertOneWithData(ctx, sessionTableName, session)
	return err
}

func (r *SessionRepository) GetByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Session, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.Session](sessionTableName).
		Where(sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var session model.Session
	if err := svc.SelectOne(&session, ctx, query, args...); err != nil {
		return nil, err
	}
	return &session, nil
}

func (r *SessionRepository) GetByTokenHash(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.Session, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.Session](sessionTableName).
		Where(sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: tokenHash},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var session model.Session
	if err := svc.SelectOne(&session, ctx, query, args...); err != nil {
		return nil, err
	}
	return &session, nil
}

func (r *SessionRepository) Terminate(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, status model.SessionStatus, reason model.TerminatedReason, now time.Time) (int64, error) {
	return svc.UpdateManyWithData(
		ctx,
		sessionTableName,
		sql_query.WhereQuery{
			"id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
			"status": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.SessionStatusActive},
		},
		sql_query.UpdateQuery{
			"status":            status,
			"terminated_reason": reason,
			"terminated_at":     now,
			"updated_at":        now,
		},
	)
}

func (r *SessionRepository) ListExpiredActive(ctx context.Context, svc coreService.PostgreSQLServicer, now time.Time, limit int) ([]model.Session, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.Session](sessionTableName).
		Where(sql_query.WhereQuery{
			"status":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.SessionStatusActive},
			"expires_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorLessThan, Value: now},
		}).
		SetLimit(limit).
		Build()
	if err != nil {
		return nil, err
	}

	var sessions []model.Session
	if err := svc.SelectMany(&sessions, ctx, query, args...); err != nil {
		return nil, err
	}
	return sessions, nil
}

func (r *SessionRepository) TerminateAllActiveForUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, status model.SessionStatus, reason model.TerminatedReason, now time.Time) (int64, error) {
	return svc.UpdateManyWithData(
		ctx,
		sessionTableName,
		sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"status":  sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.SessionStatusActive},
		},
		sql_query.UpdateQuery{
			"status":            status,
			"terminated_reason": reason,
			"terminated_at":     now,
			"updated_at":        now,
		},
	)
}
