package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const passwordResetTokenTableName = "password_reset_tokens"

type PasswordResetTokenRepositor interface {
	// GetOneByHash finds the row this link belongs to regardless of its state —
	// the caller distinguishes consumed / invalidated / expired, and a status
	// filter here would collapse all three into "not found".
	GetOneByHash(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.PasswordResetToken, error)
	// GetOneByHashForUpdate is the pessimistic in-transaction re-validation
	// variant, locked for the duration of the transaction so two concurrent
	// confirms of the same link cannot both read it as active.
	GetOneByHashForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.PasswordResetToken, error)
	// InvalidateActiveForUser stamps the still-live link (status='Active') for
	// this user — the "one live reset link" invariant, run inside the
	// invalidate-then-insert transaction. No row means no active link, which is
	// a no-op, not an error.
	InvalidateActiveForUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error
	// InsertOne inserts the row and returns the server-generated snowflake id
	// (used as the email workflow's dedupe key). Leave ID zero.
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PasswordResetToken) (int64, error)
	// Consume stamps consumed_at and status='Consumed' on the confirmed link.
	Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error
}

var _ PasswordResetTokenRepositor = (*PasswordResetTokenRepository)(nil)

type PasswordResetTokenRepository struct{}

func NewPasswordResetTokenRepository() *PasswordResetTokenRepository {
	return &PasswordResetTokenRepository{}
}

func (r *PasswordResetTokenRepository) GetOneByHash(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.PasswordResetToken, error) {
	return r.getOneByHash(ctx, svc, hash, false)
}

func (r *PasswordResetTokenRepository) GetOneByHashForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.PasswordResetToken, error) {
	return r.getOneByHash(ctx, svc, hash, true)
}

func (r *PasswordResetTokenRepository) getOneByHash(ctx context.Context, svc coreService.PostgreSQLServicer, hash string, forUpdate bool) (*model.PasswordResetToken, error) {
	builder := sql_query.NewSQLSelectBuilder[model.PasswordResetToken](passwordResetTokenTableName).
		Where(sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: hash},
		}).
		SetLimit(1)
	if forUpdate {
		builder = builder.ForUpdate(nil)
	}

	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var token model.PasswordResetToken
	if err := svc.SelectOne(&token, ctx, query, args...); err != nil {
		return nil, err
	}
	return &token, nil
}

func (r *PasswordResetTokenRepository) InvalidateActiveForUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error {
	_, err := svc.UpdateManyWithData(
		ctx,
		passwordResetTokenTableName,
		sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"status":  sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.TokenStatusActive},
		},
		sql_query.UpdateQuery{
			"status":         constant.TokenStatusInvalidated,
			"invalidated_at": time.Now(),
		},
	)
	return err
}

func (r *PasswordResetTokenRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PasswordResetToken) (int64, error) {
	id, err := svc.InsertOneWithData(ctx, passwordResetTokenTableName, row)
	if err != nil {
		return 0, err
	}
	return toID(id), nil
}

func (r *PasswordResetTokenRepository) Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		passwordResetTokenTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"status":      constant.TokenStatusConsumed,
			"consumed_at": time.Now(),
		},
	)
	return err
}
