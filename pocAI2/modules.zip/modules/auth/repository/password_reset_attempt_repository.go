package repository

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// The fixed-window attempt tables. Each is one row per key (email_norm /
// request_ip) with a window_start; when the window rolls over, the service
// rewrites attempt_count back to 1 and resets window_start instead of summing
// rows — no migration against the applied tables.
const (
	passwordResetAttemptByEmailTableName = "password_reset_attempts_by_email"
	passwordResetAttemptByIPTableName    = "password_reset_attempts_by_ip"
)

type PasswordResetAttemptRepositor interface {
	GetByEmail(ctx context.Context, svc coreService.PostgreSQLServicer, emailNorm string) (*model.PasswordResetAttemptByEmail, error)
	UpsertByEmail(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PasswordResetAttemptByEmail) error
	GetByIP(ctx context.Context, svc coreService.PostgreSQLServicer, requestIP string) (*model.PasswordResetAttemptByIP, error)
	UpsertByIP(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PasswordResetAttemptByIP) error
}

var _ PasswordResetAttemptRepositor = (*PasswordResetAttemptRepository)(nil)

type PasswordResetAttemptRepository struct{}

func NewPasswordResetAttemptRepository() *PasswordResetAttemptRepository {
	return &PasswordResetAttemptRepository{}
}

func (r *PasswordResetAttemptRepository) GetByEmail(ctx context.Context, svc coreService.PostgreSQLServicer, emailNorm string) (*model.PasswordResetAttemptByEmail, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.PasswordResetAttemptByEmail](passwordResetAttemptByEmailTableName).
		Where(sql_query.WhereQuery{
			"email_norm": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: emailNorm},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.PasswordResetAttemptByEmail
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

// UpsertByEmail branches on row.ID like LoginLockRepository.UpsertToday:
// InsertOneWithData for a new key, UpdateOneWithData for an existing one. A
// plain upsert cannot express the caller's already-computed attempt_count /
// window_start — only EXCLUDED values — so the two-step shape is kept.
func (r *PasswordResetAttemptRepository) UpsertByEmail(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PasswordResetAttemptByEmail) error {
	if row.ID == 0 {
		_, err := svc.InsertOneWithData(ctx, passwordResetAttemptByEmailTableName, row)
		return err
	}

	_, err := svc.UpdateOneWithData(
		ctx,
		passwordResetAttemptByEmailTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: row.ID},
		},
		sql_query.UpdateQuery{
			"attempt_count":   row.AttemptCount,
			"window_start":    row.WindowStart,
			"last_attempt_at": row.LastAttemptAt,
		},
	)
	return err
}

func (r *PasswordResetAttemptRepository) GetByIP(ctx context.Context, svc coreService.PostgreSQLServicer, requestIP string) (*model.PasswordResetAttemptByIP, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.PasswordResetAttemptByIP](passwordResetAttemptByIPTableName).
		Where(sql_query.WhereQuery{
			"request_ip": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: requestIP},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.PasswordResetAttemptByIP
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *PasswordResetAttemptRepository) UpsertByIP(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PasswordResetAttemptByIP) error {
	if row.ID == 0 {
		_, err := svc.InsertOneWithData(ctx, passwordResetAttemptByIPTableName, row)
		return err
	}

	_, err := svc.UpdateOneWithData(
		ctx,
		passwordResetAttemptByIPTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: row.ID},
		},
		sql_query.UpdateQuery{
			"attempt_count":   row.AttemptCount,
			"window_start":    row.WindowStart,
			"last_attempt_at": row.LastAttemptAt,
		},
	)
	return err
}
