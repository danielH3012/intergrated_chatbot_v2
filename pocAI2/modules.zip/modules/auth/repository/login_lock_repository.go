package repository

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const (
	loginAttemptLockTableName = "login_attempt_locks"
	userLockStateTableName    = "user_lock_states"
)

type LoginLockRepositor interface {
	// GetTodayForUpdate reads today's row for (userID, platform), pessimistically
	// locked. pgx.ErrNoRows means no attempt has been recorded today yet — not
	// an error condition callers need to branch on separately from a real DB
	// failure; the service treats it as a zero row.
	GetTodayForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.LoginAttemptLock, error)
	GetLockState(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.UserLockState, error)
	UpsertToday(ctx context.Context, svc coreService.PostgreSQLServicer, row model.LoginAttemptLock) error
	UpsertLockState(ctx context.Context, svc coreService.PostgreSQLServicer, row model.UserLockState) error
	// ResetToday clears today's counter on a successful login. A row that
	// does not exist yet (never failed today) is a no-op, not an error.
	ResetToday(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) error
	// ResetAllForUser clears every row of login_attempt_locks for the user —
	// all platforms and all dates — back to the unlocked baseline. A successful
	// password reset must not leave yesterday's row re-locking the account.
	ResetAllForUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error
	// ClearLockStates clears both platforms of user_lock_states back to
	// 'none'. This is the only place the terminal requires_reset / permanent
	// locks are lifted, and the only way the account recovers.
	ClearLockStates(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error
}

var _ LoginLockRepositor = (*LoginLockRepository)(nil)

type LoginLockRepository struct{}

func NewLoginLockRepository() *LoginLockRepository {
	return &LoginLockRepository{}
}

// today returns the UTC calendar date with the time portion zeroed, so it
// matches the DATE column regardless of the server's local timezone.
func today() time.Time {
	now := time.Now().UTC()
	return time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.UTC)
}

func (r *LoginLockRepository) GetTodayForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.LoginAttemptLock, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.LoginAttemptLock](loginAttemptLockTableName).
		Where(sql_query.WhereQuery{
			"user_id":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"platform":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platform},
			"attempt_date": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: today()},
		}).
		SetLimit(1).
		ForUpdate(nil).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.LoginAttemptLock
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *LoginLockRepository) GetLockState(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) (*model.UserLockState, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.UserLockState](userLockStateTableName).
		Where(sql_query.WhereQuery{
			"user_id":  sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"platform": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platform},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.UserLockState
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *LoginLockRepository) UpsertToday(ctx context.Context, svc coreService.PostgreSQLServicer, row model.LoginAttemptLock) error {
	if row.ID == 0 {
		row.AttemptDate = today()
		_, err := svc.InsertOneWithData(ctx, loginAttemptLockTableName, row)
		return err
	}

	_, err := svc.UpdateOneWithData(
		ctx,
		loginAttemptLockTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: row.ID},
		},
		sql_query.UpdateQuery{
			"failed_count":        row.FailedCount,
			"lock_level":          row.LockLevel,
			"lock_until":          row.LockUntil,
			"consecutive_1h_days": row.Consecutive1hDays,
			"last_failed_at":      row.LastFailedAt,
		},
	)
	return err
}

func (r *LoginLockRepository) UpsertLockState(ctx context.Context, svc coreService.PostgreSQLServicer, row model.UserLockState) error {
	if row.ID == 0 {
		_, err := svc.InsertOneWithData(ctx, userLockStateTableName, row)
		return err
	}

	_, err := svc.UpdateOneWithData(
		ctx,
		userLockStateTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: row.ID},
		},
		sql_query.UpdateQuery{
			"lock_level":          row.LockLevel,
			"lock_until":          row.LockUntil,
			"consecutive_1h_days": row.Consecutive1hDays,
			"last_1h_date":        row.Last1hDate,
		},
	)
	return err
}

func (r *LoginLockRepository) ResetToday(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, platform model.Platform) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		loginAttemptLockTableName,
		sql_query.WhereQuery{
			"user_id":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"platform":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platform},
			"attempt_date": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: today()},
		},
		sql_query.UpdateQuery{
			"failed_count": 0,
			"lock_level":   constant.LockLevelNone,
			"lock_until":   nil,
		},
	)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil
	}
	return err
}

// ResetAllForUser is the reset-wide counterpart of ResetToday: it clears
// every platform's and every date's rows, so a password reset wipes the whole
// failed-attempt ladder rather than just today's counter.
func (r *LoginLockRepository) ResetAllForUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error {
	_, err := svc.UpdateManyWithData(
		ctx,
		loginAttemptLockTableName,
		sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		},
		sql_query.UpdateQuery{
			"failed_count":        0,
			"lock_level":          constant.LockLevelNone,
			"lock_until":          nil,
			"consecutive_1h_days": 0,
			"last_failed_at":      nil,
		},
	)
	return err
}

// ClearLockStates clears both platforms of user_lock_states. Clearing only
// login_attempt_locks would leave the terminal requires_reset / permanent
// level in cross, which still short-circuits every login.
func (r *LoginLockRepository) ClearLockStates(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error {
	_, err := svc.UpdateManyWithData(
		ctx,
		userLockStateTableName,
		sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		},
		sql_query.UpdateQuery{
			"lock_level":          constant.LockLevelNone,
			"lock_until":          nil,
			"consecutive_1h_days": 0,
			"last_1h_date":        nil,
		},
	)
	return err
}
