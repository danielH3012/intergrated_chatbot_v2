package repository

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// UserPermissionsRepositor reads a user's authorization state. It is separate
// from UserRepositor because it is the one read that decides what a person may
// do — everything in it is security-relevant, and it is the read every service
// in the platform ends up depending on through the RBAC snapshot.
type UserPermissionsRepositor interface {
	// GetPermissionRows returns the profile plus the three role tables for one
	// user. product filters system roles only; module access always covers all
	// products, because the FE renders every module's tile either way.
	GetPermissionRows(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, product *model.Product) (*dto.UserPermissionRows, error)
}

var _ UserPermissionsRepositor = (*UserPermissionsRepository)(nil)

type UserPermissionsRepository struct{}

func NewUserPermissionsRepository() *UserPermissionsRepository {
	return &UserPermissionsRepository{}
}

func (r *UserPermissionsRepository) GetPermissionRows(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	userID int64,
	product *model.Product,
) (*dto.UserPermissionRows, error) {
	profile, err := r.profile(ctx, svc, userID)
	if err != nil {
		return nil, err
	}

	moduleStatus, err := rowsByUser[model.UserModuleStatus](ctx, svc, db.UserModuleStatusTableName, "user_module_status.user_id", userID, nil)
	if err != nil {
		return nil, err
	}

	accessLevels, err := rowsByUser[model.UserAccessLevel](ctx, svc, db.UserAccessLevelTableName, "user_access_levels.user_id", userID, nil)
	if err != nil {
		return nil, err
	}

	var roleFilter sql_query.WhereQuery
	if product != nil {
		roleFilter = sql_query.WhereQuery{
			"user_system_roles.product": {Operator: sql_query.SQLOperatorEqual, Value: string(*product)},
		}
	}
	systemRoles, err := rowsByUser[model.UserSystemRole](ctx, svc, db.UserSystemRoleTableName, "user_system_roles.user_id", userID, roleFilter)
	if err != nil {
		return nil, err
	}

	return &dto.UserPermissionRows{
		Profile:      *profile,
		ModuleStatus: moduleStatus,
		AccessLevels: accessLevels,
		SystemRoles:  systemRoles,
	}, nil
}

func (r *UserPermissionsRepository) profile(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) (*dto.UserProfileRow, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[dto.UserProfileRow](db.UserTableName).
		Where(sql_query.WhereQuery{
			"users.id":         {Operator: sql_query.SQLOperatorEqual, Value: userID},
			"users.deleted_at": {Operator: sql_query.SQLOperatorIsNull},
		}).
		LeftJoin(db.PositionTableName, "positions.id = users.position_id").
		LeftJoin(db.DivisionTableName, "divisions.id = users.division_id").
		SetLimit(1).
		Build()
	if err != nil {
		slog.ErrorContext(ctx, "user.profile query build failed", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	var profile dto.UserProfileRow
	if err := svc.SelectOne(&profile, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "user.profile select failed", "userId", userID, "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	// SelectOne leaves the zero value when nothing matched: a soft-deleted or
	// unknown user must not read as "a user with no permissions".
	if profile.ID == 0 {
		return nil, coreEntity.NotFound("User not found")
	}
	return &profile, nil
}

// rowsByUser is the same three-line read for each role table: every column of
// T for one user, optionally narrowed. Generic (and therefore a function, not
// a method) because only the projection type differs — writing it out three
// times is how the three drift apart.
func rowsByUser[T any](
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	table, userColumn string,
	userID int64,
	extra sql_query.WhereQuery,
) ([]T, error) {
	where := sql_query.WhereQuery{
		userColumn: {Operator: sql_query.SQLOperatorEqual, Value: userID},
	}
	for k, v := range extra {
		where[k] = v
	}

	query, args, err := sql_query.NewSQLSelectBuilder[T](table).Where(where).Build()
	if err != nil {
		slog.ErrorContext(ctx, "user permissions query build failed", "table", table, "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	rows := []T{}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "user permissions select failed", "table", table, "userId", userID, "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	return rows, nil
}
