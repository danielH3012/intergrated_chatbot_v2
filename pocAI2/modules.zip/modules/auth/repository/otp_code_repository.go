package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const otpCodesTableName = "otp_codes"

type OtpCodeRepositor interface {
	// GetOneByHashForUpdate finds the row this code belongs to regardless of
	// its state — the caller distinguishes consumed / invalidated / expired,
	// and a status filter here would collapse all three into "not found".
	// Locked for the duration of the transaction, so two concurrent verifies
	// of the same code cannot both consume it.
	GetOneByHashForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, email, clientCode, codeHash, purpose string) (*model.OtpCode, error)
	// GetLatestByHashAndClient finds the latest row for this code hash within
	// a client across any email address — used to detect OTP_EMAIL_CHANGED
	// when a code was issued for an email the user subsequently edited.
	GetLatestByHashAndClient(ctx context.Context, svc coreService.PostgreSQLServicer, clientCode, codeHash, purpose string) (*model.OtpCode, error)
	// GetLatestInSession finds the newest row of one resend chain. pgx.ErrNoRows
	// means the chain belongs to nobody or to another email — the caller treats
	// that as a fresh chain, never an error.
	GetLatestInSession(ctx context.Context, svc coreService.PostgreSQLServicer, email, clientCode string, otpSessionID int64) (*model.OtpCode, error)
	// InvalidateActive stamps invalidated_at on the still-live row (not yet
	// consumed, not yet invalidated) for (email, client_code, purpose) — the "one live
	// code" invariant, run inside the invalidate-then-insert transaction.
	InvalidateActive(ctx context.Context, svc coreService.PostgreSQLServicer, email, clientCode, purpose string) error
	// InsertOne inserts the row and returns the server-generated snowflake id
	// (used as the email workflow's dedupe key).
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.OtpCode) (int64, error)
	// Consume stamps consumed_at on the verified row.
	Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error
	// DeleteCreatedBefore bulk-deletes rows older than cutoff and returns how
	// many were removed — the retention sweep's one query.
	DeleteCreatedBefore(ctx context.Context, svc coreService.PostgreSQLServicer, cutoff time.Time) (int64, error)
}

var _ OtpCodeRepositor = (*OtpCodeRepository)(nil)

type OtpCodeRepository struct{}

func NewOtpCodeRepository() *OtpCodeRepository {
	return &OtpCodeRepository{}
}

func (r *OtpCodeRepository) GetOneByHashForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, email, clientCode, codeHash, purpose string) (*model.OtpCode, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.OtpCode](otpCodesTableName).
		Where(sql_query.WhereQuery{
			"email":       sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: email},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"code_hash":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: codeHash},
			"purpose":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: purpose},
		}).
		SetLimit(1).
		ForUpdate(nil).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.OtpCode
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *OtpCodeRepository) GetLatestByHashAndClient(ctx context.Context, svc coreService.PostgreSQLServicer, clientCode, codeHash, purpose string) (*model.OtpCode, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.OtpCode](otpCodesTableName).
		Where(sql_query.WhereQuery{
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"code_hash":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: codeHash},
			"purpose":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: purpose},
		}).
		OrderBy([]string{"otp_codes.created_at"}, false).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.OtpCode
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *OtpCodeRepository) GetLatestInSession(ctx context.Context, svc coreService.PostgreSQLServicer, email, clientCode string, otpSessionID int64) (*model.OtpCode, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.OtpCode](otpCodesTableName).
		Where(sql_query.WhereQuery{
			"email":          sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: email},
			"client_code":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"otp_session_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: otpSessionID},
		}).
		OrderBy([]string{"otp_codes.created_at"}, false).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.OtpCode
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *OtpCodeRepository) InvalidateActive(ctx context.Context, svc coreService.PostgreSQLServicer, email, clientCode, purpose string) error {
	_, err := svc.UpdateManyWithData(
		ctx,
		otpCodesTableName,
		sql_query.WhereQuery{
			"email":          sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: email},
			"client_code":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"purpose":        sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: purpose},
			"consumed_at":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
			"invalidated_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		},
		sql_query.UpdateQuery{
			"invalidated_at": time.Now(),
			"updated_at":     time.Now(),
		},
	)
	return err
}

func (r *OtpCodeRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.OtpCode) (int64, error) {
	id, err := svc.InsertOneWithData(ctx, otpCodesTableName, row)
	if err != nil {
		return 0, err
	}
	return toID(id), nil
}

func (r *OtpCodeRepository) Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		otpCodesTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"consumed_at": time.Now(),
			"updated_at":  time.Now(),
		},
	)
	return err
}

func (r *OtpCodeRepository) DeleteCreatedBefore(ctx context.Context, svc coreService.PostgreSQLServicer, cutoff time.Time) (int64, error) {
	return svc.DeleteManyWithFilter(
		ctx,
		otpCodesTableName,
		sql_query.WhereQuery{
			"created_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorLessThan, Value: cutoff},
		},
	)
}

// toID converts the scalar returned by InsertOneWithData (the RETURNING id)
// to an int64 snowflake id.
func toID(v any) int64 {
	switch t := v.(type) {
	case int:
		return int64(t)
	case int64:
		return t
	case float64:
		return int64(t)
	default:
		return 0
	}
}
