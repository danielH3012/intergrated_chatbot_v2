package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const preAuthSessionTableName = "pre_auth_sessions"

type PreAuthSessionRepositor interface {
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PreAuthSession) (int64, error)
	// GetActiveByTokenHash finds the pre-auth row by its token hash
	// regardless of state — the caller distinguishes expired / consumed.
	GetActiveByTokenHash(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.PreAuthSession, error)
	// InvalidateActive invalidates any unconsumed active pre-auth rows for
	// (user_id, client_code, platform) before creating a new one (PRD §5.3).
	InvalidateActive(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string, platform model.Platform) error
	// Consume stamps consumed_at and status='Consumed' on the row.
	Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error
	// ConvertToMfa re-scopes a resolved agreement row into the MFA handoff
	// in place — same row, same token, same TTL, so the two gates cannot be
	// chained to extend the pre-auth window.
	ConvertToMfa(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, reason model.MfaReason) error
	// ConvertToDuplicateLogin re-scopes a resolved agreement row for
	// POST /auth/sessions/confirm-duplicate, which needs existing_session_id.
	ConvertToDuplicateLogin(ctx context.Context, svc coreService.PostgreSQLServicer, id, existingSessionID int64) error
}

var _ PreAuthSessionRepositor = (*PreAuthSessionRepository)(nil)

type PreAuthSessionRepository struct{}

func NewPreAuthSessionRepository() *PreAuthSessionRepository {
	return &PreAuthSessionRepository{}
}

func (r *PreAuthSessionRepository) InvalidateActive(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string, platform model.Platform) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		preAuthSessionTableName,
		sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"platform":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platform},
			"status":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.PreAuthStatusActive},
		},
		sql_query.UpdateQuery{
			"status":     constant.PreAuthStatusInvalidated,
			"updated_at": time.Now(),
		},
	)
	return err
}

func (r *PreAuthSessionRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.PreAuthSession) (int64, error) {
	id, err := svc.InsertOneWithData(ctx, preAuthSessionTableName, row)
	if err != nil {
		return 0, err
	}
	return toID(id), nil
}

func (r *PreAuthSessionRepository) GetActiveByTokenHash(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.PreAuthSession, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.PreAuthSession](preAuthSessionTableName).
		Where(sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: tokenHash},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.PreAuthSession
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *PreAuthSessionRepository) Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		preAuthSessionTableName,
		sql_query.WhereQuery{
			"id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
			"status": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.PreAuthStatusActive},
		},
		sql_query.UpdateQuery{
			"status":            constant.PreAuthStatusConsumed,
			"consumed_at":       time.Now(),
			"agreement_pending": false,
			"updated_at":        time.Now(),
		},
	)
	return err
}

func (r *PreAuthSessionRepository) ConvertToMfa(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, reason model.MfaReason) error {
	return r.update(ctx, svc, id, sql_query.UpdateQuery{
		"purpose":           constant.PreAuthPurposeMfa,
		"mfa_reason":        reason,
		"agreement_pending": false,
		"updated_at":        time.Now(),
	})
}

func (r *PreAuthSessionRepository) ConvertToDuplicateLogin(ctx context.Context, svc coreService.PostgreSQLServicer, id, existingSessionID int64) error {
	return r.update(ctx, svc, id, sql_query.UpdateQuery{
		"purpose":             constant.PreAuthPurposeDuplicateLogin,
		"existing_session_id": existingSessionID,
		"agreement_pending":   false,
		"updated_at":          time.Now(),
	})
}

func (r *PreAuthSessionRepository) update(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, body sql_query.UpdateQuery) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		preAuthSessionTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		body,
	)
	return err
}
