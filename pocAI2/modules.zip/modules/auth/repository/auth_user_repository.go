package repository

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// AuthUserRepositor defines the strict subset of User repository methods
// that the Auth module requires. This follows the Interface Segregation Principle
// (Accept Interfaces, Return Structs), protecting the Auth module from compilation
// breaks when unrelated methods are added to the global User repository.
type AuthUserRepositor interface {
	GetOneByEmail(ctx context.Context, svc service.PostgreSQLServicer, email string) (*userDto.UserListItem, error)
	GetOneByID(ctx context.Context, svc service.PostgreSQLServicer, id int64) (*userDto.UserListItem, error)
	UpdateActivationStatus(ctx context.Context, svc service.PostgreSQLServicer, id int64, status string) error
}
