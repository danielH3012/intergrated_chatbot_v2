package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const userPrivacyConsentTableName = "user_privacy_consent"

// UserPrivacyConsentRepositor reads and writes the tenant-schema consent
// table. It has no client_code column — tenancy is the schema the svc is
// bound to, so every method takes a tenant servicer.
type UserPrivacyConsentRepositor interface {
	GetOneByUserID(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) (*model.UserPrivacyConsent, error)
	// Upsert keeps the latest accepted version per user (arbiter:
	// unq_user_privacy_consent_user_id), never an append-only history.
	Upsert(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, version string, acceptedAt time.Time) error
}

var _ UserPrivacyConsentRepositor = (*UserPrivacyConsentRepository)(nil)

type UserPrivacyConsentRepository struct{}

func NewUserPrivacyConsentRepository() *UserPrivacyConsentRepository {
	return &UserPrivacyConsentRepository{}
}

func (r *UserPrivacyConsentRepository) GetOneByUserID(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) (*model.UserPrivacyConsent, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.UserPrivacyConsent](userPrivacyConsentTableName).
		Where(sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.UserPrivacyConsent
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *UserPrivacyConsentRepository) Upsert(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, version string, acceptedAt time.Time) error {
	_, err := svc.UpsertManyWithData(
		ctx,
		userPrivacyConsentTableName,
		[]model.UserPrivacyConsent{{
			UserID:          userID,
			AcceptedVersion: &version,
			AcceptedAt:      &acceptedAt,
		}},
		"(user_id)",
		[]string{"accepted_version", "accepted_at", "updated_at"},
	)
	return err
}
