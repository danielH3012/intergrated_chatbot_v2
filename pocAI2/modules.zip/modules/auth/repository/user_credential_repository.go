package repository

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	utilDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

type UserCredentialRepositor interface {
	GetOneByEmail(ctx context.Context, svc coreService.PostgreSQLServicer, email string) (*model.UserCredential, error)
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, cred model.UserCredential) error
	// UpdatePasswordHash rewrites the credential's hash — the only in-place
	// mutation a credential ever gets, from a successful password reset.
	UpdatePasswordHash(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, hash string) error
}

var _ UserCredentialRepositor = (*UserCredentialRepository)(nil)

type UserCredentialRepository struct{}

func NewUserCredentialRepository() *UserCredentialRepository {
	return &UserCredentialRepository{}
}

func (r *UserCredentialRepository) GetOneByEmail(ctx context.Context, svc coreService.PostgreSQLServicer, email string) (*model.UserCredential, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.UserCredential](utilDb.UserCredentialTableName).
		Where(sql_query.WhereQuery{
			"email": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: email},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var cred model.UserCredential
	if err := svc.SelectOne(&cred, ctx, query, args...); err != nil {
		return nil, err
	}
	return &cred, nil
}

// InsertOne generates id and timestamps server-side (via the insert builder);
// leave those fields zero on cred.
func (r *UserCredentialRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, cred model.UserCredential) error {
	_, err := svc.InsertOneWithData(ctx, utilDb.UserCredentialTableName, cred)
	return err
}

func (r *UserCredentialRepository) UpdatePasswordHash(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, hash string) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		utilDb.UserCredentialTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"password_hash": hash,
		},
	)
	return err
}
