package repository

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const knownCountryPairTableName = "known_country_pairs"

type KnownCountryPairRepositor interface {
	GetOneByCorridor(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string, countryA, countryB string) (*model.KnownCountryPair, error)
	Upsert(ctx context.Context, svc coreService.PostgreSQLServicer, row model.KnownCountryPair) error
	ResetDecayed(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, now time.Time) error
}

var _ KnownCountryPairRepositor = (*KnownCountryPairRepository)(nil)

type KnownCountryPairRepository struct{}

func NewKnownCountryPairRepository() *KnownCountryPairRepository {
	return &KnownCountryPairRepository{}
}

func (r *KnownCountryPairRepository) GetOneByCorridor(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string, countryA, countryB string) (*model.KnownCountryPair, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.KnownCountryPair](knownCountryPairTableName).
		Where(sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"country_a":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: countryA},
			"country_b":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: countryB},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.KnownCountryPair
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *KnownCountryPairRepository) Upsert(ctx context.Context, svc coreService.PostgreSQLServicer, row model.KnownCountryPair) error {
	existing, err := r.GetOneByCorridor(ctx, svc, row.UserID, row.ClientCode, row.CountryA, row.CountryB)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return err
	}

	now := time.Now()
	if existing == nil {
		if row.FirstSeenAt.IsZero() {
			row.FirstSeenAt = now
		}
		if row.WindowStartedAt.IsZero() {
			row.WindowStartedAt = now
		}
		if row.LastSeenAt.IsZero() {
			row.LastSeenAt = now
		}
		if row.CreatedAt.IsZero() {
			row.CreatedAt = now
		}
		if row.UpdatedAt.IsZero() {
			row.UpdatedAt = now
		}
		_, err := svc.InsertOneWithData(ctx, knownCountryPairTableName, row)
		return err
	}

	_, err = svc.UpdateOneWithData(
		ctx,
		knownCountryPairTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: existing.ID},
		},
		sql_query.UpdateQuery{
			"frequency":         row.Frequency,
			"is_trusted":        row.IsTrusted,
			"window_started_at": row.WindowStartedAt,
			"last_seen_at":      row.LastSeenAt,
			"updated_at":        now,
		},
	)
	return err
}

func (r *KnownCountryPairRepository) ResetDecayed(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, now time.Time) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		knownCountryPairTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"frequency":         1,
			"is_trusted":        false,
			"window_started_at": now,
			"updated_at":        now,
		},
	)
	return err
}
