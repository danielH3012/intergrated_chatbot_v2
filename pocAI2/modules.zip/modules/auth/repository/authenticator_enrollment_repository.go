package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const authenticatorEnrollmentTableName = "authenticator_enrollments"

type AuthenticatorEnrollmentRepositor interface {
	GetOneByUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string) (*model.AuthenticatorEnrollment, error)
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.AuthenticatorEnrollment) (int64, error)
	Activate(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, enrolledAt time.Time) error
	DeleteByUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string) error
}

var _ AuthenticatorEnrollmentRepositor = (*AuthenticatorEnrollmentRepository)(nil)

type AuthenticatorEnrollmentRepository struct{}

func NewAuthenticatorEnrollmentRepository() *AuthenticatorEnrollmentRepository {
	return &AuthenticatorEnrollmentRepository{}
}

func (r *AuthenticatorEnrollmentRepository) GetOneByUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string) (*model.AuthenticatorEnrollment, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.AuthenticatorEnrollment](authenticatorEnrollmentTableName).
		Where(sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.AuthenticatorEnrollment
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *AuthenticatorEnrollmentRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, row model.AuthenticatorEnrollment) (int64, error) {
	now := time.Now()
	if row.CreatedAt.IsZero() {
		row.CreatedAt = now
	}
	if row.UpdatedAt.IsZero() {
		row.UpdatedAt = now
	}
	id, err := svc.InsertOneWithData(ctx, authenticatorEnrollmentTableName, row)
	if err != nil {
		return 0, err
	}
	return toID(id), nil
}

func (r *AuthenticatorEnrollmentRepository) Activate(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, enrolledAt time.Time) error {
	now := time.Now()
	_, err := svc.UpdateOneWithData(
		ctx,
		authenticatorEnrollmentTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"is_active":   true,
			"enrolled_at": enrolledAt,
			"updated_at":  now,
		},
	)
	return err
}

func (r *AuthenticatorEnrollmentRepository) DeleteByUser(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string) error {
	_, err := svc.DeleteOneWithFilter(
		ctx,
		authenticatorEnrollmentTableName,
		sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
		},
	)
	return err
}
