package repository_test

import (
	"context"
	"strings"
	"testing"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/repository"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeDB embeds the servicer interface so only the methods a repository calls
// need scripting; anything else panics with a nil-pointer, which is the signal
// that a new call sneaked in.
type fakeDB struct {
	coreService.PostgreSQLServicer

	// last write
	table    string
	where    sql_query.WhereQuery
	update   sql_query.UpdateQuery
	body     any
	conflict string
	updateOn []string

	// last read
	query string
	args  []any

	selectOne func(v any) error
}

func (f *fakeDB) SelectOne(v any, _ context.Context, q string, args ...any) error {
	f.query, f.args = q, args
	if f.selectOne != nil {
		return f.selectOne(v)
	}
	return nil
}

func (f *fakeDB) UpdateOneWithData(_ context.Context, table string, where sql_query.WhereQuery, body sql_query.UpdateQuery, _ ...coreService.ReturningConfig) (any, error) {
	f.table, f.where, f.update = table, where, body
	return nil, nil
}

func (f *fakeDB) UpsertManyWithData(_ context.Context, table string, body any, conflict string, updateColumns []string, _ ...coreService.ReturningConfig) (any, error) {
	f.table, f.body, f.conflict, f.updateOn = table, body, conflict, updateColumns
	return nil, nil
}

func (f *fakeDB) InsertOneWithData(_ context.Context, table string, body any, _ ...coreService.ReturningConfig) (any, error) {
	f.table, f.body = table, body
	return int64(1), nil
}

// Consuming a handoff must also clear agreement_pending: a row left pending
// after consumption is one the expiry sweeper would re-report as an abandoned
// gate, and one loadAgreementHandoff would still authorise on status alone if
// the status guard ever regressed.
func TestPreAuthSessionRepository_ConsumeClearsAgreementPending(t *testing.T) {
	db := &fakeDB{}
	repo := repository.NewPreAuthSessionRepository()

	if err := repo.Consume(context.Background(), db, 42); err != nil {
		t.Fatalf("Consume: %v", err)
	}

	if db.table != "pre_auth_sessions" {
		t.Fatalf("table = %q, want pre_auth_sessions", db.table)
	}
	if got := db.where["id"].Value; got != int64(42) {
		t.Errorf("where id = %v, want 42", got)
	}
	if got := db.where["status"].Value; got != constant.PreAuthStatusActive {
		t.Errorf("where status = %v, want Active", got)
	}
	if got := db.update["status"]; got != constant.PreAuthStatusConsumed {
		t.Errorf("status = %v, want %q", got, constant.PreAuthStatusConsumed)
	}
	if got, ok := db.update["agreement_pending"]; !ok || got != false {
		t.Errorf("agreement_pending = %v (set: %v), want false", got, ok)
	}
	if _, ok := db.update["consumed_at"]; !ok {
		t.Error("consumed_at must be stamped")
	}
}

// Convert-in-place re-scopes the row for MFA without touching expires_at: the
// two gates share one 10-minute budget, so extending it here would let a user
// chain gates to lengthen the pre-auth window.
func TestPreAuthSessionRepository_ConvertToMfa(t *testing.T) {
	db := &fakeDB{}
	repo := repository.NewPreAuthSessionRepository()

	if err := repo.ConvertToMfa(context.Background(), db, 42, constant.MfaReasonUnusualLogin); err != nil {
		t.Fatalf("ConvertToMfa: %v", err)
	}

	if got := db.update["purpose"]; got != constant.PreAuthPurposeMfa {
		t.Errorf("purpose = %v, want mfa", got)
	}
	if got := db.update["mfa_reason"]; got != constant.MfaReasonUnusualLogin {
		t.Errorf("mfa_reason = %v, want unusual_login", got)
	}
	if got, ok := db.update["agreement_pending"]; !ok || got != false {
		t.Errorf("agreement_pending = %v, want false — the gate is resolved", got)
	}
	if _, ok := db.update["expires_at"]; ok {
		t.Error("expires_at must not be rewritten: one handoff, one TTL")
	}
	if _, ok := db.update["status"]; ok {
		t.Error("status must stay Active for the MFA leg")
	}
}

// confirm-duplicate dereferences existing_session_id, so the convert must set
// it — a nil there is a panic in that flow, not a graceful failure.
func TestPreAuthSessionRepository_ConvertToDuplicateLogin(t *testing.T) {
	db := &fakeDB{}
	repo := repository.NewPreAuthSessionRepository()

	if err := repo.ConvertToDuplicateLogin(context.Background(), db, 42, 99); err != nil {
		t.Fatalf("ConvertToDuplicateLogin: %v", err)
	}

	if got := db.update["purpose"]; got != constant.PreAuthPurposeDuplicateLogin {
		t.Errorf("purpose = %v, want duplicate_login", got)
	}
	if got := db.update["existing_session_id"]; got != int64(99) {
		t.Errorf("existing_session_id = %v, want 99", got)
	}
	if _, ok := db.update["status"]; ok {
		t.Error("the row must stay Active until confirm-duplicate consumes it")
	}
}

// Consent is one row per user, kept current — the upsert must name (user_id)
// as its arbiter and refresh the version, or a second login appends a second
// row and the trigger comparison turns ambiguous.
func TestUserPrivacyConsentRepository_Upsert(t *testing.T) {
	db := &fakeDB{}
	repo := repository.NewUserPrivacyConsentRepository()
	acceptedAt := time.Now()

	if err := repo.Upsert(context.Background(), db, 7, "2.0", acceptedAt); err != nil {
		t.Fatalf("Upsert: %v", err)
	}

	if db.table != "user_privacy_consent" {
		t.Fatalf("table = %q, want user_privacy_consent", db.table)
	}
	if db.conflict != "(user_id)" {
		t.Errorf("conflict target = %q, want (user_id)", db.conflict)
	}
	for _, col := range []string{"accepted_version", "accepted_at", "updated_at"} {
		if !containsString(db.updateOn, col) {
			t.Errorf("update columns %v missing %q", db.updateOn, col)
		}
	}

	rows, ok := db.body.([]model.UserPrivacyConsent)
	if !ok || len(rows) != 1 {
		t.Fatalf("body = %#v, want one consent row", db.body)
	}
	if rows[0].UserID != 7 {
		t.Errorf("userID = %d, want 7", rows[0].UserID)
	}
	if rows[0].AcceptedVersion == nil || *rows[0].AcceptedVersion != "2.0" {
		t.Errorf("acceptedVersion = %v, want 2.0", rows[0].AcceptedVersion)
	}
	if rows[0].AcceptedAt == nil || !rows[0].AcceptedAt.Equal(acceptedAt) {
		t.Errorf("acceptedAt = %v, want %v", rows[0].AcceptedAt, acceptedAt)
	}
}

// The consent read is keyed on user_id alone: the table has no client_code
// column, tenancy comes from the schema the servicer is bound to.
func TestUserPrivacyConsentRepository_GetOneByUserID(t *testing.T) {
	db := &fakeDB{}
	repo := repository.NewUserPrivacyConsentRepository()

	if _, err := repo.GetOneByUserID(context.Background(), db, 7); err != nil {
		t.Fatalf("GetOneByUserID: %v", err)
	}

	if !strings.Contains(db.query, "user_privacy_consent") {
		t.Fatalf("query does not select the consent table: %s", db.query)
	}
	if strings.Contains(db.query, "client_code") {
		t.Errorf("query filters on client_code, which the table does not have: %s", db.query)
	}
	if len(db.args) != 1 || db.args[0] != int64(7) {
		t.Errorf("args = %v, want [7]", db.args)
	}
}

func containsString(haystack []string, needle string) bool {
	for _, s := range haystack {
		if s == needle {
			return true
		}
	}
	return false
}
