package repository

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const trustedDeviceTableName = "trusted_devices"

type TrustedDeviceRepositor interface {
	GetOneByIdentity(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string, platform model.Platform, deviceID string) (*model.TrustedDevice, error)
	Upsert(ctx context.Context, svc coreService.PostgreSQLServicer, row model.TrustedDevice) error
}

var _ TrustedDeviceRepositor = (*TrustedDeviceRepository)(nil)

type TrustedDeviceRepository struct{}

func NewTrustedDeviceRepository() *TrustedDeviceRepository {
	return &TrustedDeviceRepository{}
}

func (r *TrustedDeviceRepository) GetOneByIdentity(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, clientCode string, platform model.Platform, deviceID string) (*model.TrustedDevice, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[model.TrustedDevice](trustedDeviceTableName).
		Where(sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"platform":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platform},
			"device_id":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: deviceID},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var row model.TrustedDevice
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}
	return &row, nil
}

func (r *TrustedDeviceRepository) Upsert(ctx context.Context, svc coreService.PostgreSQLServicer, row model.TrustedDevice) error {
	existing, err := r.GetOneByIdentity(ctx, svc, row.UserID, row.ClientCode, row.Platform, row.DeviceID)
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return err
	}

	now := time.Now()
	if existing == nil {
		if row.TrustedAt.IsZero() {
			row.TrustedAt = now
		}
		if row.LastUsedAt.IsZero() {
			row.LastUsedAt = now
		}
		if row.CreatedAt.IsZero() {
			row.CreatedAt = now
		}
		if row.UpdatedAt.IsZero() {
			row.UpdatedAt = now
		}
		_, err := svc.InsertOneWithData(ctx, trustedDeviceTableName, row)
		return err
	}

	_, err = svc.UpdateOneWithData(
		ctx,
		trustedDeviceTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: existing.ID},
		},
		sql_query.UpdateQuery{
			"last_login_lat":     row.LastLoginLat,
			"last_login_lon":     row.LastLoginLon,
			"last_login_country": row.LastLoginCountry,
			"last_used_at":       now,
			"updated_at":         now,
		},
	)
	return err
}
