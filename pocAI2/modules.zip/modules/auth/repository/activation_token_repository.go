// Package repository reads and writes the auth-domain tables. Repositories
// are pure passthroughs: whatever the DB layer returns is propagated
// untouched (pgx.ErrNoRows included). Error interpretation happens in the
// service layer. The svc argument must already be scoped to the right
// schema and carry the active transaction when called within one.
package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	utilDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

type ActivationTokenRepositor interface {
	GetOneByHash(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.ActivationToken, error)
	GetOneByHashForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.ActivationToken, error)
	Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error
}

var _ ActivationTokenRepositor = (*ActivationTokenRepository)(nil)

type ActivationTokenRepository struct{}

func NewActivationTokenRepository() *ActivationTokenRepository {
	return &ActivationTokenRepository{}
}

func (r *ActivationTokenRepository) GetOneByHash(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.ActivationToken, error) {
	return r.getOneByHash(ctx, svc, hash, false)
}

func (r *ActivationTokenRepository) GetOneByHashForUpdate(ctx context.Context, svc coreService.PostgreSQLServicer, hash string) (*model.ActivationToken, error) {
	return r.getOneByHash(ctx, svc, hash, true)
}

func (r *ActivationTokenRepository) getOneByHash(ctx context.Context, svc coreService.PostgreSQLServicer, hash string, forUpdate bool) (*model.ActivationToken, error) {
	builder := sql_query.NewSQLSelectBuilder[model.ActivationToken](utilDb.ActivationTokenTableName).
		Where(sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: hash},
		}).
		SetLimit(1)
	if forUpdate {
		builder = builder.ForUpdate(nil)
	}

	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var token model.ActivationToken
	if err := svc.SelectOne(&token, ctx, query, args...); err != nil {
		return nil, err
	}
	return &token, nil
}

func (r *ActivationTokenRepository) Consume(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		utilDb.ActivationTokenTableName,
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"status":      constant.TokenStatusConsumed,
			"consumed_at": time.Now(),
		},
	)
	return err
}
