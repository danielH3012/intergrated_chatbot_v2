package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

const productSessionTableName = "product_sessions"

type ProductSessionRepositor interface {
	// EndByPlatformSession ends all active product sessions for a platform
	// session — cascade on platform-session termination.
	EndByPlatformSession(ctx context.Context, svc coreService.PostgreSQLServicer, platformSessionID int64, reason model.TerminatedReason, now time.Time) (int64, error)
	// EndForSubscription ends all active product sessions for a user +
	// subscription — access-revoke cascade.
	EndForSubscription(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, subscriptionID int64, reason model.TerminatedReason, now time.Time) (int64, error)
}

var _ ProductSessionRepositor = (*ProductSessionRepository)(nil)

type ProductSessionRepository struct{}

func NewProductSessionRepository() *ProductSessionRepository {
	return &ProductSessionRepository{}
}

func (r *ProductSessionRepository) EndByPlatformSession(ctx context.Context, svc coreService.PostgreSQLServicer, platformSessionID int64, reason model.TerminatedReason, now time.Time) (int64, error) {
	return svc.UpdateManyWithData(
		ctx,
		productSessionTableName,
		sql_query.WhereQuery{
			"platform_session_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: platformSessionID},
			"status":              sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.ProductSessionStatusActive},
		},
		sql_query.UpdateQuery{
			"status":            constant.ProductSessionStatusEnded,
			"terminated_reason": reason,
			"ended_at":          now,
			"updated_at":        now,
		},
	)
}

func (r *ProductSessionRepository) EndForSubscription(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, subscriptionID int64, reason model.TerminatedReason, now time.Time) (int64, error) {
	return svc.UpdateManyWithData(
		ctx,
		productSessionTableName,
		sql_query.WhereQuery{
			"user_id":         sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"subscription_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: subscriptionID},
			"status":          sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: constant.ProductSessionStatusActive},
		},
		sql_query.UpdateQuery{
			"status":            constant.ProductSessionStatusEnded,
			"terminated_reason": reason,
			"ended_at":          now,
			"updated_at":        now,
		},
	)
}
