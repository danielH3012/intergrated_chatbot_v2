package dto

// ResetPasswordRequestRequest is the shared body of POST
// /auth/reset-password/request and /auth/reset-password/resend. Resend is a
// request with the same shape — the two endpoints differ only in behaviour.
//
// Email has no validate tag on purpose: empty/format/length are checked in
// the service (RequestResetPassword), which answers the TC-mandated caption
// in the response body instead of a generic 400, and trims before checking
// length/format so a padded valid address is not rejected.
type ResetPasswordRequestRequest struct {
	Email          string `json:"email"`
	RecaptchaToken string `json:"recaptchaToken"`
}

// ResetPasswordRequestResponse is what both request and resend answer. The
// budget-exceeded and unknown-email branches answer status "sent" on purpose:
// a masked 200 that never mails, so an email's existence is not probeable.
type ResetPasswordRequestResponse struct {
	Status               string  `json:"status"`
	Email                string  `json:"email"`
	ResendAvailableInSec int     `json:"resendAvailableInSec"`
	ErrorCode            *string `json:"errorCode,omitempty"`
	Message              *string `json:"message,omitempty"`
}

// ValidateResetTokenResponse is GET /auth/reset-password/validate/:token.
type ValidateResetTokenResponse struct {
	Valid     bool    `json:"valid"`
	Email     string  `json:"email"`
	Reason    *string `json:"reason"`
	ErrorCode *string `json:"errorCode,omitempty"`
}

// ConfirmResetPasswordRequest is POST /auth/reset-password/confirm.
type ConfirmResetPasswordRequest struct {
	Token           string `json:"token"           validate:"required"`
	Password        string `json:"password"`
	ConfirmPassword string `json:"confirmPassword"`
}

type ConfirmResetPasswordResponse struct {
	Status      string   `json:"status"`
	Message     string   `json:"message"`
	ErrorCode   *string  `json:"errorCode,omitempty"`
	FailedRules []string `json:"failedRules,omitempty"`
}
