package dto

// The /me response shapes. They follow
// Dokumentasi-TAG-Samurai/auth/me/API/openapi.yaml exactly, including the
// BIGINT-as-string convention: every _id is a JSON string, because a snowflake
// loses precision in a JavaScript number.

// MePermissions is GET /me/permissions.
type MePermissions struct {
	ID             string                       `json:"_id"`
	ProfilePicture *string                      `json:"profilePicture"`
	FullName       string                       `json:"fullName"`
	Email          string                       `json:"email"`
	Position       *string                      `json:"position"`
	Division       *string                      `json:"division"`
	ModuleAccess   map[string]ModuleAccessEntry `json:"moduleAccess"`
	SystemRoles    []SystemRole                 `json:"systemRoles"`
}

// ModuleAccessEntry is one module's tile in the shell.
//
// hasAccess and the two level flags answer different questions: hasAccess says
// the module is switched on for this user at all, the flags say how much they
// may do once inside. A user can have access with neither flag set.
type ModuleAccessEntry struct {
	IsTotalControl bool `json:"isTotalControl"`
	IsReadOnly     bool `json:"isReadOnly"`
	HasAccess      bool `json:"hasAccess"`
}

type SystemRole struct {
	Key        string     `json:"key"`
	Product    string     `json:"product"`
	Permission Permission `json:"permission"`
}

// Permission is the CRUD tuple. `edit` is deliberate: the UI verb is edit, the
// IAM column is permission_update, and the rename happens in exactly one place
// (mapSystemRole) so it cannot drift.
type Permission struct {
	Create bool `json:"create"`
	View   bool `json:"view"`
	Edit   bool `json:"edit"`
	Delete bool `json:"delete"`
}

// MeSettings is GET /me/settings.
type MeSettings struct {
	GeneralSettings GeneralSettings `json:"generalSettings"`
	SystemLimits    SystemLimits    `json:"systemLimits"`
}

type GeneralSettings struct {
	CurrencyCode          string `json:"currencyCode"`
	CurrencySymbol        string `json:"currencySymbol"`
	CurrencyDecimalPlaces int16  `json:"currencyDecimalPlaces"`
	Timezone              string `json:"timezone"`
	DateFormat            string `json:"dateFormat"`
	TimeFormat            string `json:"timeFormat"`
	SessionIdleTimeout    int    `json:"sessionIdleTimeout"`
}

type SystemLimits struct {
	BulkTransactionRowLimit int `json:"bulkTransactionRowLimit"`
	SelectionLimit          int `json:"selectionLimit"`
	RegisterAssetBulkLimit  int `json:"registerAssetBulkLimit"`
	HierarchyDepthLimit     int `json:"hierarchyDepthLimit"`
	MasterDataCountLimit    int `json:"masterDataCountLimit"`
}

// MeEntity is GET /me/entity.
type MeEntity struct {
	Entity         Entity   `json:"entity"`
	ActiveProducts []string `json:"activeProducts"`
}

type Entity struct {
	ID   string `json:"_id"`
	Name string `json:"name"`
	Code string `json:"code"`
}
