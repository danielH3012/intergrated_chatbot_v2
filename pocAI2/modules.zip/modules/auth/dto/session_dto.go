package dto

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

type ConfirmDuplicateRequest struct {
	PreAuthToken string `json:"preAuthToken" validate:"required"`
}

type ConfirmDuplicateResponse struct {
	Outcome   string  `json:"outcome"`
	SessionID *string `json:"sessionId,omitempty"`
}

type LogoutResponse struct {
	Outcome string `json:"outcome"`
}

type HeartbeatResponse struct {
	Status             model.SessionStatus `json:"status"`
	ExpiresAt          time.Time           `json:"expiresAt"`
	IdleTimeoutMinutes int                 `json:"idleTimeoutMinutes"`
}
