package dto

type ValidateActivationTokenResponse struct {
	Valid bool   `json:"valid"`
	Email string `json:"email"`
}
