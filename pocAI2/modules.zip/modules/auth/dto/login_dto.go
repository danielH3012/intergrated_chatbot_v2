package dto

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

type LoginRequest struct {
	// No validation, validated elsewhere for custom error response
	Email          string         `json:"email"`
	Password       string         `json:"password"`
	RecaptchaToken string         `json:"recaptchaToken"`
	Platform       model.Platform `json:"platform"       validate:"required,oneof=web mobile"`
	DeviceID       string         `json:"deviceId"       validate:"required"`
}

type ExistingSessionInfo struct {
	DeviceInfo        string         `json:"deviceInfo"`
	Platform          model.Platform `json:"platform"`
	LastActivityAt    time.Time      `json:"lastActivityAt"`
	ExistingSessionID *int64         `json:"existingSessionId,omitempty"`
}

type LoginResponse struct {
	Outcome    string  `json:"outcome"`
	RedirectTo *string `json:"redirectTo,omitempty"`

	// MFA handoff, all set together when Outcome is mfa_required. Resolved
	// server-side by beginMfa so the client can route to the right factor-2
	// page without an evaluate round trip (mfa/low-level-design.md §2).
	MfaReason             *model.MfaReason     `json:"mfaReason,omitempty"`
	PreAuthToken          *string              `json:"preAuthToken,omitempty"`
	Factor1Method         *model.Factor1Method `json:"factor1Method,omitempty"`
	AuthenticatorEnrolled *bool                `json:"authenticatorEnrolled,omitempty"`
	MfaEmail              *string              `json:"mfaEmail,omitempty"`

	ErrorCode            *string              `json:"errorCode,omitempty"`
	CaptionField         *string              `json:"captionField,omitempty"`
	LockLevel            *model.LockLevel     `json:"lockLevel,omitempty"`
	LockUntil            *time.Time           `json:"lockUntil,omitempty"`
	CaptchaRequired      bool                 `json:"captchaRequired"`
	PrivacyPolicyVersion *string              `json:"privacyPolicyVersion,omitempty"`
	SessionID            *string              `json:"sessionId,omitempty"`
	ExistingSession      *ExistingSessionInfo `json:"existingSession,omitempty"`
}
