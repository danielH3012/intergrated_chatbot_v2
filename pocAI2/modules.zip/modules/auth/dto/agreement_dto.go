package dto

import "gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"

// ConfirmAgreementRequest is POST /auth/confirm-agreement. It deliberately
// carries no acceptedVersion: the version consented to is the one the server
// stamped as shown on the handoff row, never one the client asserts.
type ConfirmAgreementRequest struct {
	PreAuthToken string `json:"preAuthToken" validate:"required"`
	// Pointer so an absent field is distinguishable from an explicit false
	// only for validation — both decline, per the contract.
	AgreementAccepted *bool `json:"agreementAccepted"`
}

// ConfirmAgreementResponse is whatever the calling login endpoint would have
// returned had the gate never fired.
type ConfirmAgreementResponse struct {
	Outcome         string               `json:"outcome"`
	RedirectTo      *string              `json:"redirectTo,omitempty"`
	MfaReason       *model.MfaReason     `json:"mfaReason,omitempty"`
	PreAuthToken    *string              `json:"preAuthToken,omitempty"`
	ExistingSession *ExistingSessionInfo `json:"existingSession,omitempty"`
	// SessionID is the raw session token, set on success — the handler also
	// writes it as the session cookie, same as login and confirm-duplicate.
	SessionID *string `json:"sessionId,omitempty"`
}
