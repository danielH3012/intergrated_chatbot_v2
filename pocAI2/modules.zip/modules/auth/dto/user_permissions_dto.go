package dto

import "gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"

// UserProfileRow is the users row plus the two names /me/permissions displays.
// position/division are joined, so both are nullable here even though
// users.division_id is NOT NULL — a soft-deleted division still leaves the FK.
type UserProfileRow struct {
	ID             int64   `json:"_id"            column:"users.id"`
	FirstName      string  `json:"firstName"      column:"users.first_name"`
	LastName       string  `json:"lastName"       column:"users.last_name"`
	Email          string  `json:"email"          column:"users.email"`
	ProfilePicture *string `json:"profilePicture" column:"users.profile_picture"`
	Position       *string `json:"position"       column:"positions.name"`
	Division       *string `json:"division"       column:"divisions.name"`
}

// UserPermissionRows is one user's authorization state: everything
// /me/permissions and the RolesSnapshot are built from, read together so both
// projections agree.
type UserPermissionRows struct {
	Profile      UserProfileRow
	ModuleStatus []model.UserModuleStatus
	AccessLevels []model.UserAccessLevel
	SystemRoles  []model.UserSystemRole
}
