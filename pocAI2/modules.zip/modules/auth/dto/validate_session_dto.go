package dto

// ValidateSessionResponse is what the gateway turns into the X-User-ID /
// X-Client-ID headers it stamps on the request it forwards to the backend
// services. ClientCode is the tenant schema name, which is what every service
// downstream means by "client id". SessionID is the numeric session id the
// gateway stamps as X-Session-ID.
type ValidateSessionResponse struct {
	UserID     int64  `json:"userId"`
	ClientCode string `json:"clientCode"`
	SessionID  *int64 `json:"sessionId,omitempty"`
}
