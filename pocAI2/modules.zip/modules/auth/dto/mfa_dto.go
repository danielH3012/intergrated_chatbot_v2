package dto

// MfaOtpSendRequest is the payload for POST /v2/auth/mfa/otp/send.
type MfaOtpSendRequest struct {
	PreAuthToken string  `json:"preAuthToken" validate:"required"`
	OtpSessionID *string `json:"otpSessionId" validate:"omitempty,numeric"`
}

// MfaOtpSendResponse is the response data for POST /v2/auth/mfa/otp/send.
type MfaOtpSendResponse struct {
	Outcome               string  `json:"outcome"`
	Email                 *string `json:"email,omitempty"`
	OtpSessionID          *string `json:"otpSessionId,omitempty"`
	ResendCooldownSeconds *int    `json:"resendCooldownSeconds,omitempty"`
	ResendExhausted       *bool   `json:"resendExhausted,omitempty"`
	ErrorCode             *string `json:"errorCode,omitempty"`
}

// MfaOtpVerifyRequest is the payload for POST /v2/auth/mfa/otp/verify.
type MfaOtpVerifyRequest struct {
	PreAuthToken string `json:"preAuthToken" validate:"required"`
	OtpCode      string `json:"otpCode"      validate:"required"`
	DeviceID     string `json:"deviceId"     validate:"required"`
}

// MfaAuthenticatorVerifyRequest is the payload for POST /v2/auth/mfa/authenticator/verify.
type MfaAuthenticatorVerifyRequest struct {
	PreAuthToken string `json:"preAuthToken" validate:"required"`
	TotpCode     string `json:"totpCode"     validate:"required"`
	DeviceID     string `json:"deviceId"     validate:"required"`
}

// MfaVerifyResponse is the shared response data for factor-2 verification endpoints
// (POST /v2/auth/mfa/otp/verify and POST /v2/auth/mfa/authenticator/verify).
type MfaVerifyResponse struct {
	Outcome      string  `json:"outcome"`
	RedirectTo   *string `json:"redirectTo,omitempty"`
	ErrorCode    *string `json:"errorCode,omitempty"`
	SessionToken *string `json:"sessionToken,omitempty"`
}

// MfaEnrollRequest is the payload for POST /v2/auth/mfa/authenticator/enroll.
type MfaEnrollRequest struct {
	PreAuthToken string `json:"preAuthToken" validate:"required"`
}

// MfaEnrollResponse is the response data for POST /v2/auth/mfa/authenticator/enroll.
type MfaEnrollResponse struct {
	QrCodeURI    string `json:"qrCodeUri"`
	SecretKey    string `json:"secretKey"`
	PreAuthToken string `json:"preAuthToken"`
}

// MfaEnrollVerifyRequest is the payload for POST /v2/auth/mfa/authenticator/enroll/verify.
type MfaEnrollVerifyRequest struct {
	PreAuthToken string `json:"preAuthToken" validate:"required"`
	VerifyCode   string `json:"verifyCode"   validate:"required"`
}

// MfaEnrollVerifyResponse is the response data for POST /v2/auth/mfa/authenticator/enroll/verify.
type MfaEnrollVerifyResponse struct {
	Outcome   string  `json:"outcome"`
	ErrorCode *string `json:"errorCode,omitempty"`
}
