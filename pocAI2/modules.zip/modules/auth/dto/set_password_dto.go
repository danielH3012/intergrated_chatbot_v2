package dto

type SetPasswordRequest struct {
	Password        string `json:"password"        validate:"required"`
	ConfirmPassword string `json:"confirmPassword" validate:"required"`
}

type SetPasswordResponse struct {
	Success      bool    `json:"success"`
	RedirectHint *string `json:"redirectHint"`
}
