package dto

import "gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"

// OtpRequestRequest is POST /auth/otp/request. OtpSessionId absent = start a
// new resend chain; present = resend inside that chain.
type OtpRequestRequest struct {
	// No validation, validated elsewhere for custom error response
	Email          string         `json:"email"`
	Platform       model.Platform `json:"platform"       validate:"required,oneof=web mobile"`
	RecaptchaToken string         `json:"recaptchaToken"`
	OtpSessionId   *string        `json:"otpSessionId"   validate:"omitempty,numeric"`
}

type OtpRequestResponse struct {
	Outcome               string  `json:"outcome,omitempty"`
	Email                 string  `json:"email,omitempty"`
	OtpSessionId          *string `json:"otpSessionId,omitempty"`
	CaptchaRequired       bool    `json:"captchaRequired"`
	ResendCooldownSeconds int     `json:"resendCooldownSeconds,omitempty"`
	ResendExhausted       bool    `json:"resendExhausted"`
	ErrorCode             *string `json:"errorCode,omitempty"`
	CaptionField          *string `json:"captionField,omitempty"`
}

// OtpVerifyRequest is POST /auth/otp/verify.
type OtpVerifyRequest struct {
	// See LoginRequest.Email — the service owns the email contract.
	Email    string         `json:"email"`
	Platform model.Platform `json:"platform" validate:"required,oneof=web mobile"`
	DeviceID string         `json:"deviceId"`
	// Likewise OtpCode: VerifyOtp matches it against ^\d{6}$ and answers
	// OTP_EMPTY (422) for anything else, empty and short alike.
	OtpCode string `json:"otpCode"`
}

type OtpVerifyResponse struct {
	// Omitted on the 401/422 paths, which carry only errorCode / captionField.
	Outcome string `json:"outcome,omitempty"`

	// MFA handoff, all set together when Outcome is mfa_required.
	// Factor1Method is always "otp" here, which is why the client skips the
	// Choose Verification Method page and routes straight to the
	// authenticator (mfa/02-ui-design.md §2.1).
	MfaReason             *model.MfaReason     `json:"mfaReason,omitempty"`
	PreAuthToken          *string              `json:"preAuthToken,omitempty"`
	Factor1Method         *model.Factor1Method `json:"factor1Method,omitempty"`
	AuthenticatorEnrolled *bool                `json:"authenticatorEnrolled,omitempty"`

	ErrorCode       *string              `json:"errorCode,omitempty"`
	CaptionField    *string              `json:"captionField,omitempty"`
	CaptchaRequired bool                 `json:"captchaRequired"`
	SessionID       *string              `json:"sessionId,omitempty"`
	ExistingSession *ExistingSessionInfo `json:"existingSession,omitempty"`
}
