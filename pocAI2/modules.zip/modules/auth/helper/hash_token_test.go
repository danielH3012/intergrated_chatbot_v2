package helper

import (
	"crypto/sha256"
	"encoding/hex"
	"testing"
)

// TestHashToken pins the stored format: SHA-256 hex of the raw token. Writers
// (SendActivationEmail, RequestResetPassword, createPlatformSession) and every
// lookup go through this function, so the only way to break the contract is to
// change what it returns.
func TestHashToken(t *testing.T) {
	raw := "deadbeefcafebabe"
	sum := sha256.Sum256([]byte(raw))
	want := hex.EncodeToString(sum[:])

	if got := HashToken(raw); got != want {
		t.Errorf("HashToken(%q) = %q, want %q", raw, got, want)
	}
}
