package helper

import (
	"crypto/sha256"
	"encoding/hex"
)

// HashToken derives the stored lookup key for a raw, client-held secret:
// SHA-256 hex. Activation tokens, password-reset tokens, and platform session
// bearer tokens all store and look up through this one function, so writers and
// readers cannot drift apart. Not salted on purpose — token_hash has to be
// searchable by equality, which bcrypt/argon2 would not be.
func HashToken(raw string) string {
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
