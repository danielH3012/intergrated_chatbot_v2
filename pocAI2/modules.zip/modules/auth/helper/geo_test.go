package helper

import (
	"math"
	"testing"
)

func TestHaversineDistance(t *testing.T) {
	// Distance between Jakarta (-6.2088, 106.8456) and Bandung (-6.9175, 107.6191) is ~120 km (>100km threshold)
	distJktBdg := HaversineDistance(-6.2088, 106.8456, -6.9175, 107.6191)
	if math.Abs(distJktBdg-120.0) > 10.0 {
		t.Errorf("expected ~120km for Jakarta to Bandung, got %.2fkm", distJktBdg)
	}

	// Same coordinates -> 0 km
	distSame := HaversineDistance(-6.2088, 106.8456, -6.2088, 106.8456)
	if distSame != 0 {
		t.Errorf("expected 0km for identical coordinates, got %.2fkm", distSame)
	}

	// Close distance: Monas (-6.1754, 106.8272) to Bundaran HI (-6.1950, 106.8230) is ~2.2 km (<100km)
	distClose := HaversineDistance(-6.1754, 106.8272, -6.1950, 106.8230)
	if distClose > 10.0 || distClose < 1.0 {
		t.Errorf("expected ~2.2km for Monas to Bundaran HI, got %.2fkm", distClose)
	}
}

func TestSortCountryPair(t *testing.T) {
	c1, c2 := SortCountryPair("SG", "ID")
	if c1 != "ID" || c2 != "SG" {
		t.Errorf("expected (ID, SG), got (%s, %s)", c1, c2)
	}

	c3, c4 := SortCountryPair("id", "sg")
	if c3 != "ID" || c4 != "SG" {
		t.Errorf("expected (ID, SG) uppercase, got (%s, %s)", c3, c4)
	}

	c5, c6 := SortCountryPair("US", "CA")
	if c5 != "CA" || c6 != "US" {
		t.Errorf("expected (CA, US), got (%s, %s)", c5, c6)
	}
}
