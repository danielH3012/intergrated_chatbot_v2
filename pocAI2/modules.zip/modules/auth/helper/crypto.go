package helper

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
)

// EncryptSecret encrypts plaintext bytes using AES-256-GCM with a random 12-byte nonce
// and returns a base64-encoded string combining nonce and ciphertext.
func EncryptSecret(plaintext []byte, key []byte) (string, error) {
	if len(key) == 0 {
		return "", errors.New("encryption key must not be empty")
	}

	derivedKey := sha256.Sum256(key)
	block, err := aes.NewCipher(derivedKey[:])
	if err != nil {
		return "", fmt.Errorf("create cipher block: %w", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", fmt.Errorf("create GCM: %w", err)
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", fmt.Errorf("generate nonce: %w", err)
	}

	ciphertext := gcm.Seal(nonce, nonce, plaintext, nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

// DecryptSecret decrypts a base64-encoded AES-256-GCM ciphertext string using the provided key.
func DecryptSecret(encodedCiphertext string, key []byte) ([]byte, error) {
	if len(key) == 0 {
		return nil, errors.New("encryption key must not be empty")
	}

	data, err := base64.StdEncoding.DecodeString(encodedCiphertext)
	if err != nil {
		return nil, fmt.Errorf("decode base64 ciphertext: %w", err)
	}

	derivedKey := sha256.Sum256(key)
	block, err := aes.NewCipher(derivedKey[:])
	if err != nil {
		return nil, fmt.Errorf("create cipher block: %w", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("create GCM: %w", err)
	}

	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		return nil, errors.New("ciphertext too short")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, fmt.Errorf("decrypt ciphertext: %w", err)
	}

	return plaintext, nil
}
