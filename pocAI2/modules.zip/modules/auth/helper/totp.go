package helper

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha1"
	"crypto/subtle"
	"encoding/base32"
	"encoding/binary"
	"fmt"
	"net/url"
	"strings"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/constant"
)

// GenerateTOTPSecret generates 20 bytes of entropy (160 bits, standard for SHA-1 TOTP)
// and returns both the raw bytes and base32 string without padding.
func GenerateTOTPSecret() ([]byte, string, error) {
	buf := make([]byte, 20)
	if _, err := rand.Read(buf); err != nil {
		return nil, "", fmt.Errorf("generate TOTP secret: %w", err)
	}
	encoded := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(buf)
	return buf, encoded, nil
}

// DecodeTOTPSecret decodes a base32-encoded TOTP secret string, ignoring whitespace and handling both padded and unpadded formats.
func DecodeTOTPSecret(secretBase32 string) ([]byte, error) {
	cleaned := strings.ToUpper(strings.ReplaceAll(secretBase32, " ", ""))
	// Try unpadded first, then padded
	raw, err := base32.StdEncoding.WithPadding(base32.NoPadding).DecodeString(cleaned)
	if err == nil {
		return raw, nil
	}
	return base32.StdEncoding.DecodeString(cleaned)
}

// GenerateTOTPCode calculates the 6-digit TOTP code for a given timestamp according to RFC 6238 (SHA-1, 30s period).
func GenerateTOTPCode(secretKey []byte, t time.Time) string {
	counter := uint64(t.Unix() / int64(constant.TotpPeriod.Seconds()))
	return GenerateHOTPCode(secretKey, counter)
}

// GenerateHOTPCode calculates a 6-digit code for a counter according to RFC 4226.
func GenerateHOTPCode(secretKey []byte, counter uint64) string {
	buf := make([]byte, 8)
	binary.BigEndian.PutUint64(buf, counter)

	mac := hmac.New(sha1.New, secretKey)
	mac.Write(buf)
	digest := mac.Sum(nil)

	offset := digest[len(digest)-1] & 0x0f
	binaryCode := (binary.BigEndian.Uint32(digest[offset:offset+4]) & 0x7fffffff) % 1000000

	return fmt.Sprintf("%06d", binaryCode)
}

// VerifyTOTP verifies a 6-digit TOTP code against a base32 secret with drift window tolerance (±driftSteps, standard ±1 step).
func VerifyTOTP(secretBase32 string, code string, t time.Time, driftSteps int) bool {
	if len(code) != constant.TotpDigits {
		return false
	}
	secretKey, err := DecodeTOTPSecret(secretBase32)
	if err != nil {
		return false
	}

	currentCounter := int64(t.Unix() / int64(constant.TotpPeriod.Seconds()))
	for step := -driftSteps; step <= driftSteps; step++ {
		counter := uint64(currentCounter + int64(step))
		expectedCode := GenerateHOTPCode(secretKey, counter)
		if subtle.ConstantTimeCompare([]byte(expectedCode), []byte(code)) == 1 {
			return true
		}
	}
	return false
}

// BuildOtpauthURI formats the standard otpauth URI for QR code generation.
func BuildOtpauthURI(issuer, email, secretBase32 string) string {
	cleanedSecret := strings.ToUpper(strings.ReplaceAll(secretBase32, " ", ""))
	label := fmt.Sprintf("%s:%s", url.PathEscape(issuer), email)

	params := url.Values{}
	params.Set("secret", cleanedSecret)
	params.Set("issuer", issuer)
	params.Set("algorithm", constant.TotpAlgorithm)
	params.Set("digits", fmt.Sprintf("%d", constant.TotpDigits))
	params.Set("period", fmt.Sprintf("%d", int(constant.TotpPeriod.Seconds())))

	return fmt.Sprintf("otpauth://totp/%s?%s", label, params.Encode())
}
