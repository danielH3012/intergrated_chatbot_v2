package helper

import (
	"testing"
)

func TestCrypto_EncryptAndDecryptSecret(t *testing.T) {
	key := []byte("secret-platform-encryption-key-12345")
	secret := []byte("MY_TOTP_SECRET_BYTES_12345")

	encrypted, err := EncryptSecret(secret, key)
	if err != nil {
		t.Fatalf("EncryptSecret failed: %v", err)
	}
	if len(encrypted) == 0 {
		t.Fatalf("expected non-empty encrypted string")
	}

	decrypted, err := DecryptSecret(encrypted, key)
	if err != nil {
		t.Fatalf("DecryptSecret failed: %v", err)
	}
	if string(decrypted) != string(secret) {
		t.Fatalf("expected decrypted %q, got %q", string(secret), string(decrypted))
	}

	// Wrong key fails decryption
	wrongKey := []byte("wrong-platform-key")
	if _, err := DecryptSecret(encrypted, wrongKey); err == nil {
		t.Fatalf("expected decryption error with wrong key, got nil")
	}

	// Empty key errors
	if _, err := EncryptSecret(secret, nil); err == nil {
		t.Fatalf("expected error on empty key for encrypt")
	}
	if _, err := DecryptSecret(encrypted, nil); err == nil {
		t.Fatalf("expected error on empty key for decrypt")
	}
}
