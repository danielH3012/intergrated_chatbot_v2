package helper

import (
	"math"
	"strings"
)

const earthRadiusKm = 6371.0

// HaversineDistance calculates the great-circle distance between two geographic coordinates in kilometers.
func HaversineDistance(lat1, lon1, lat2, lon2 float64) float64 {
	dLat := (lat2 - lat1) * math.Pi / 180.0
	dLon := (lon2 - lon1) * math.Pi / 180.0

	lat1Rad := lat1 * math.Pi / 180.0
	lat2Rad := lat2 * math.Pi / 180.0

	a := math.Sin(dLat/2)*math.Sin(dLat/2) +
		math.Cos(lat1Rad)*math.Cos(lat2Rad)*math.Sin(dLon/2)*math.Sin(dLon/2)
	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	return earthRadiusKm * c
}

// SortCountryPair normalizes two country codes to uppercase and returns them sorted (countryA < countryB).
func SortCountryPair(c1, c2 string) (countryA, countryB string) {
	u1 := strings.ToUpper(strings.TrimSpace(c1))
	u2 := strings.ToUpper(strings.TrimSpace(c2))
	if u1 < u2 {
		return u1, u2
	}
	return u2, u1
}
