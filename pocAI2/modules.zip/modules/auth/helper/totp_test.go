package helper

import (
	"strings"
	"testing"
	"time"
)

func TestTOTP_SecretGenerationAndDecoding(t *testing.T) {
	raw, encoded, err := GenerateTOTPSecret()
	if err != nil {
		t.Fatalf("GenerateTOTPSecret failed: %v", err)
	}
	if len(raw) != 20 {
		t.Fatalf("expected 20 bytes entropy, got %d", len(raw))
	}
	if len(encoded) == 0 {
		t.Fatalf("expected non-empty base32 secret")
	}

	decoded, err := DecodeTOTPSecret(encoded)
	if err != nil {
		t.Fatalf("DecodeTOTPSecret failed: %v", err)
	}
	if string(decoded) != string(raw) {
		t.Fatalf("decoded secret did not match original bytes")
	}
}

func TestTOTP_RFC6238Vectors(t *testing.T) {
	// RFC 6238 test secret "12345678901234567890" in ASCII -> "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ" in Base32
	secretKey := []byte("12345678901234567890")
	secretBase32 := "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"

	// Known RFC 6238 vector for SHA-1 at T=59s (counter=1): "287082"
	t59 := time.Unix(59, 0)
	code := GenerateTOTPCode(secretKey, t59)
	if code != "287082" {
		t.Fatalf("expected RFC 6238 code 287082 at T=59s, got %s", code)
	}

	// Verify at T=59s
	if !VerifyTOTP(secretBase32, "287082", t59, 1) {
		t.Fatalf("VerifyTOTP failed to verify valid code at exact time")
	}

	// Verify drift ±1 step (30s drift forward at T=89s -> counter=2, step -1 is counter=1)
	t89 := time.Unix(89, 0)
	if !VerifyTOTP(secretBase32, "287082", t89, 1) {
		t.Fatalf("VerifyTOTP failed to verify valid code within +1 drift window")
	}

	// Verify drift ±1 step (30s drift backward at T=29s -> counter=0, step +1 is counter=1)
	t29 := time.Unix(29, 0)
	if !VerifyTOTP(secretBase32, "287082", t29, 1) {
		t.Fatalf("VerifyTOTP failed to verify valid code within -1 drift window")
	}

	// Out of drift window (T=120s -> counter=4, diff > 1)
	t120 := time.Unix(120, 0)
	if VerifyTOTP(secretBase32, "287082", t120, 1) {
		t.Fatalf("VerifyTOTP should have rejected code outside drift window")
	}

	// Invalid code length / format
	if VerifyTOTP(secretBase32, "123", t59, 1) {
		t.Fatalf("VerifyTOTP should reject code with length != 6")
	}
}

func TestBuildOtpauthURI(t *testing.T) {
	uri := BuildOtpauthURI("TAG Samurai", "john@email.com", "JBSWY3DPEHPK3PXP")
	if !strings.HasPrefix(uri, "otpauth://totp/TAG%20Samurai:john@email.com?") {
		t.Errorf("unexpected URI prefix: %s", uri)
	}
	if !strings.Contains(uri, "secret=JBSWY3DPEHPK3PXP") {
		t.Errorf("URI missing secret: %s", uri)
	}
	if !strings.Contains(uri, "issuer=TAG+Samurai") && !strings.Contains(uri, "issuer=TAG%20Samurai") {
		t.Errorf("URI missing issuer: %s", uri)
	}
	if !strings.Contains(uri, "algorithm=SHA1") {
		t.Errorf("URI missing algorithm: %s", uri)
	}
	if !strings.Contains(uri, "digits=6") {
		t.Errorf("URI missing digits: %s", uri)
	}
	if !strings.Contains(uri, "period=30") {
		t.Errorf("URI missing period: %s", uri)
	}
}
