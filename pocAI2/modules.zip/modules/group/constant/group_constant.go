// Package constant defines constants for the group user module.
package constant

import "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"

const (
	// SystemRoleKeyManageGroup is the key used for Settings > Group role checks.
	SystemRoleKeyManageGroup enum.SystemRoleKey = "manage_group"

	// Products supported by the group user endpoints.
	ProductAdminConsole = "admin_console"
	ProductFixedAsset   = "fixed_asset"

	// Tier keys for groupRole filter.
	GroupRoleFilterTotalControl = "total_control"
	GroupRoleFilterReadOnly     = "read_only"
	GroupRoleFilterGroupManager = "group_manager"
	GroupRoleFilterManageGroup  = "manage_group"

	// Default pagination values.
	DefaultPage      = 1
	DefaultLimit     = 10
	DefaultSortBy    = "fullName"
	DefaultSortOrder = 1 // 1 for ASC, -1 for DESC

	// Temporary status strings.
	TemporaryStatusYes = "Yes"
	TemporaryStatusNo  = "No"

	// Group role badges.
	GroupRoleBadgeTotalControl = "Total Control"
	GroupRoleBadgeReadOnly     = "Read Only"
	GroupRoleBadgeGroupManager = "Group Manager"
	GroupRoleBadgeManageGroup  = "Manage group"
)

// AllowedSortFields maps the API camelCase sort keys to the CTE column identifiers.
var AllowedSortFields = map[string]string{
	"fullName":          "full_name",
	"email":             "email",
	"position":          "position_name",
	"division":          "division_name",
	"groupRole":         "group_role",
	"activationStatus":  "activation_status",
	"temporaryStatus":   "temporary_status",
	"activePeriodUntil": "active_period_until",
}
