// Package group wires the settings-group HTTP surface.
package group

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
)

// SetupRoutes mounts the public group routes.
func SetupRoutes(app *fiber.App, rolesFetcher tsMiddleware.RolesFetcher, svc *service.GroupService) {
	h := handler.NewGroupHandler(svc)

	productRead := func(c fiber.Ctx, roles tsMiddleware.UserAccessCache) (bool, error) {
		product := c.Params("product")
		switch product {
		case constant.ProductFixedAsset:
			return rbac.Any(
				rbac.FixedAssetSeeAll(),
				rbac.FixedAssetSystemRole(tsMiddleware.PermView, constant.SystemRoleKeyManageGroup),
			)(c, roles)
		case constant.ProductAdminConsole:
			return rbac.Any(
				rbac.AdminConsoleSeeAll(),
				rbac.AdminConsoleSystemRole(tsMiddleware.PermView, constant.SystemRoleKeyManageGroup),
			)(c, roles)
		default:
			return true, nil
		}
	}

	// Group routes under /groups
	groups := app.Group("/groups")
	groups.Use(tsMiddleware.LoadUserRolesFrom(rolesFetcher))

	groups.Post("/:product/:id/users/list", rbac.Require(productRead), h.HandleListGroupUsers)
	groups.Post("/:product/:id/users/options", rbac.Require(productRead), h.HandleGetGroupUserOptions)
}
