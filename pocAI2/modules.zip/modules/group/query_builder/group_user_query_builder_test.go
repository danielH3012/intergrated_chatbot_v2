package query_builder

import (
	"strings"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
)

func TestBuildListGroupUsersQuery_Defaults(t *testing.T) {
	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	q, args := BuildListGroupUsersQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "admin_console_group_id = $2") {
		t.Fatalf("expected admin_console_group_id = $2 in query, got:\n%s", q)
	}
	if !strings.Contains(q, `u.full_name COLLATE "en-US-x-icu" AS sort_val`) || !strings.Contains(q, "ORDER BY sort_val ASC") {
		t.Fatalf("expected default order by full_name ASC, got:\n%s", q)
	}
	if len(args) < 4 {
		t.Fatalf("expected at least 4 args (product, groupID, limit, offset), got %d: %v", len(args), args)
	}
	if args[0] != constant.ProductAdminConsole {
		t.Errorf("expected product %s, got %v", constant.ProductAdminConsole, args[0])
	}
	if args[1] != int64(12345) {
		t.Errorf("expected groupID 12345, got %v", args[1])
	}
}

func TestBuildListGroupUsersQuery_FixedAssetProduct(t *testing.T) {
	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	q, _ := BuildListGroupUsersQuery(constant.ProductFixedAsset, 67890, req)

	if !strings.Contains(q, "fixed_asset_group_id = $2") {
		t.Fatalf("expected fixed_asset_group_id = $2 in query, got:\n%s", q)
	}
}

func TestBuildListGroupUsersQuery_GroupRoleFilter(t *testing.T) {
	req := dto.ListGroupUsersRequest{
		GroupRole: []string{"total_control", "group_manager"},
	}
	req.Defaults()

	q, _ := BuildListGroupUsersQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "(up.is_tc = TRUE OR up.is_gm = TRUE)") {
		t.Fatalf("expected groupRole filter with OR, got:\n%s", q)
	}
}

func TestBuildListGroupUsersQuery_Filters(t *testing.T) {
	req := dto.ListGroupUsersRequest{
		Position:          []string{"Manager", "Developer"},
		Division:          []string{"IT", "Finance"},
		ActivationStatus:  []string{"Activated"},
		TemporaryStatus:   []string{"Yes"},
		ActivePeriodUntil: []int64{1000000, 2000000},
		Search:            "john",
		SortBy:            "email",
		SortOrder:         -1,
	}
	req.Defaults()

	q, args := BuildListGroupUsersQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "p.name = ANY(") {
		t.Errorf("missing position filter in query")
	}
	if !strings.Contains(q, "(d.name = ANY(") {
		t.Errorf("missing division filter in query")
	}
	if !strings.Contains(q, "u.activation_status = ANY(") {
		t.Errorf("missing activation_status filter in query")
	}
	if !strings.Contains(q, "u.is_temporary = TRUE") {
		t.Errorf("missing temporaryStatus filter in query")
	}
	if !strings.Contains(q, "BETWEEN to_timestamp(") {
		t.Errorf("missing activePeriodUntil filter in query")
	}
	if !strings.Contains(q, "u.full_name ILIKE") {
		t.Errorf("missing search filter in query")
	}
	if !strings.Contains(q, `u.email COLLATE "en-US-x-icu" AS sort_val`) || !strings.Contains(q, "ORDER BY sort_val DESC") {
		t.Errorf("expected sort by email DESC, got query:\n%s", q)
	}

	foundSearch := false
	for _, a := range args {
		if s, ok := a.(string); ok && s == "%john%" {
			foundSearch = true
			break
		}
	}
	if !foundSearch {
		t.Errorf("expected %%john%% in args, got: %v", args)
	}
}

func TestBuildGroupUserOptionsQuery_AllOptions(t *testing.T) {
	req := dto.GroupUserOptionsRequest{
		PositionOptions:         true,
		DivisionOptions:         true,
		GroupRoleOptions:        true,
		ActivationStatusOptions: true,
		TemporaryStatusOptions:  true,
	}

	q, args := BuildGroupUserOptionsQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "position_options_cte AS (") {
		t.Errorf("missing position_options_cte in query")
	}
	if !strings.Contains(q, "division_options_cte AS (") {
		t.Errorf("missing division_options_cte in query")
	}
	if !strings.Contains(q, "group_role_options_cte AS (") {
		t.Errorf("missing group_role_options_cte in query")
	}
	if !strings.Contains(q, "activation_status_options_cte AS (") {
		t.Errorf("missing activation_status_options_cte in query")
	}
	if !strings.Contains(q, "temporary_status_options_cte AS (") {
		t.Errorf("missing temporary_status_options_cte in query")
	}
	if len(args) != 2 || args[0] != constant.ProductAdminConsole || args[1] != int64(12345) {
		t.Errorf("unexpected args: %v", args)
	}
}

func TestBuildListGroupUsersQuery_LiteralGroupRoleFilter(t *testing.T) {
	req := dto.ListGroupUsersRequest{
		GroupRole: []string{"total_control", "Manage group"},
	}
	req.Defaults()

	q, args := BuildListGroupUsersQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "up.is_tc = TRUE") {
		t.Fatalf("expected up.is_tc = TRUE in query, got:\n%s", q)
	}
	if !strings.Contains(q, "EXISTS (") || !strings.Contains(q, "FROM user_system_roles usr") {
		t.Fatalf("expected EXISTS subquery on user_system_roles for literal role, got:\n%s", q)
	}

	foundLiteralArg := false
	for _, a := range args {
		if slice, ok := a.([]string); ok {
			for _, s := range slice {
				if s == "Manage group" {
					foundLiteralArg = true
				}
			}
		}
	}
	if !foundLiteralArg {
		t.Errorf("expected 'Manage group' in args slice, got args: %v", args)
	}
}

func TestBuildGroupUserOptionsQuery_NoOptions(t *testing.T) {
	req := dto.GroupUserOptionsRequest{}
	q, args := BuildGroupUserOptionsQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "SELECT '{}'::jsonb;") {
		t.Errorf("expected empty select, got: %s", q)
	}
	if len(args) != 0 {
		t.Errorf("expected empty args, got: %v", args)
	}
}

func TestBuildGroupUserOptionsQuery_IncludesLiteralGroupRoles(t *testing.T) {
	req := dto.GroupUserOptionsRequest{
		GroupRoleOptions: true,
	}
	q, _ := BuildGroupUserOptionsQuery(constant.ProductAdminConsole, 12345, req)

	if !strings.Contains(q, "FROM user_system_roles usr") {
		t.Errorf("expected group_role_options_cte to query user_system_roles, got:\n%s", q)
	}
	if !strings.Contains(q, "usr.admin_console_group_id = $2") {
		t.Errorf("expected usr.admin_console_group_id = $2 in query, got:\n%s", q)
	}
}
