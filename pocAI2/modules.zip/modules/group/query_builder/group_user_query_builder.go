package query_builder

import (
	"fmt"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
)

// BuildListGroupUsersQuery constructs the parameterized SQL query for POST /v2/iam/groups/{product}/{id}/users/list.
func BuildListGroupUsersQuery(product string, groupID int64, req dto.ListGroupUsersRequest) (string, []any) {
	groupCol := "admin_console_group_id"
	if product == constant.ProductFixedAsset {
		groupCol = "fixed_asset_group_id"
	}

	var args []any
	argIdx := 1

	args = append(args, product)
	productParam := fmt.Sprintf("$%d", argIdx)
	argIdx++

	args = append(args, groupID)
	groupParam := fmt.Sprintf("$%d", argIdx)
	argIdx++

	var whereClauses []string

	// groupRole filter (evaluates underlying tier flags: total_control, read_only, group_manager, or literal role names)
	if len(req.GroupRole) > 0 {
		var roleOrs []string
		var literalRoles []string
		for _, gr := range req.GroupRole {
			switch strings.ToLower(strings.ReplaceAll(gr, " ", "_")) {
			case constant.GroupRoleFilterTotalControl:
				roleOrs = append(roleOrs, "up.is_tc = TRUE")
			case constant.GroupRoleFilterReadOnly:
				roleOrs = append(roleOrs, "up.is_ro = TRUE")
			case constant.GroupRoleFilterGroupManager:
				roleOrs = append(roleOrs, "up.is_gm = TRUE")
			default:
				literalRoles = append(literalRoles, gr)
			}
		}
		if len(literalRoles) > 0 {
			args = append(args, literalRoles)
			roleOrs = append(roleOrs, fmt.Sprintf(`EXISTS (
				SELECT 1 FROM user_system_roles usr
				WHERE usr.user_id = u.id
				  AND usr.product = %s
				  AND usr.scope_level = 'group'
				  AND usr.%s = %s
				  AND (usr.key = ANY($%d) OR (
					CASE usr.key
						WHEN 'manage_distributor' THEN 'Manage distributor'
						WHEN 'manage_partner' THEN 'Manage partner'
						WHEN 'manage_group' THEN 'Manage group'
						WHEN 'manage_user_and_role' THEN 'Manage user and role'
						WHEN 'manage_active_client' THEN 'Manage active client'
						WHEN 'manage_archived_client' THEN 'Manage archived client'
						WHEN 'manage_allocation' THEN 'Manage allocation'
						WHEN 'manage_wallet_and_pricing' THEN 'Manage wallet & pricing'
						ELSE usr.key
					END
				  ) = ANY($%d))
			)`, productParam, groupCol, groupParam, argIdx, argIdx))
			argIdx++
		}
		if len(roleOrs) > 0 {
			whereClauses = append(whereClauses, "("+strings.Join(roleOrs, " OR ")+")")
		}
	}

	// position filter
	if len(req.Position) > 0 {
		args = append(args, req.Position)
		whereClauses = append(whereClauses, fmt.Sprintf("p.name = ANY($%d)", argIdx))
		argIdx++
	}

	// division filter (support name and id)
	if len(req.Division) > 0 {
		args = append(args, req.Division)
		whereClauses = append(whereClauses, fmt.Sprintf("(d.name = ANY($%d) OR d.id::text = ANY($%d))", argIdx, argIdx))
		argIdx++
	}

	// activationStatus filter
	if len(req.ActivationStatus) > 0 {
		args = append(args, req.ActivationStatus)
		whereClauses = append(whereClauses, fmt.Sprintf("u.activation_status = ANY($%d)", argIdx))
		argIdx++
	}

	// temporaryStatus filter ("Yes" / "No")
	if len(req.TemporaryStatus) > 0 {
		hasYes := false
		hasNo := false
		for _, ts := range req.TemporaryStatus {
			if strings.EqualFold(ts, constant.TemporaryStatusYes) {
				hasYes = true
			} else if strings.EqualFold(ts, constant.TemporaryStatusNo) {
				hasNo = true
			}
		}
		if hasYes && !hasNo {
			whereClauses = append(whereClauses, "u.is_temporary = TRUE")
		} else if hasNo && !hasYes {
			whereClauses = append(whereClauses, "(u.is_temporary = FALSE OR u.is_temporary IS NULL)")
		}
	}

	// activePeriodUntil filter (epoch milliseconds range)
	if len(req.ActivePeriodUntil) == 1 {
		args = append(args, float64(req.ActivePeriodUntil[0])/1000.0)
		whereClauses = append(whereClauses, fmt.Sprintf("(u.is_temporary = TRUE AND u.active_period_until >= to_timestamp($%d))", argIdx))
		argIdx++
	} else if len(req.ActivePeriodUntil) >= 2 {
		args = append(args, float64(req.ActivePeriodUntil[0])/1000.0)
		p1 := argIdx
		argIdx++
		args = append(args, float64(req.ActivePeriodUntil[1])/1000.0)
		p2 := argIdx
		argIdx++
		whereClauses = append(whereClauses, fmt.Sprintf("(u.is_temporary = TRUE AND u.active_period_until BETWEEN to_timestamp($%d) AND to_timestamp($%d))", p1, p2))
	}

	// search filter
	if search := strings.TrimSpace(req.Search); search != "" {
		args = append(args, "%"+search+"%")
		searchParam := fmt.Sprintf("$%d", argIdx)
		argIdx++
		whereClauses = append(whereClauses, fmt.Sprintf(`(
			u.full_name ILIKE %s OR
			u.email ILIKE %s OR
			p.name ILIKE %s OR
			d.name ILIKE %s OR
			(CASE 
				WHEN up.is_tc THEN 'Total Control'
				WHEN up.is_ro THEN 'Read Only'
				WHEN up.is_gm THEN 'Group Manager'
				WHEN up.role_count = 1 THEN '1 role'
				ELSE up.role_count || ' roles'
			END) ILIKE %s
		)`, searchParam, searchParam, searchParam, searchParam, searchParam))
	}

	whereSQL := ""
	if len(whereClauses) > 0 {
		whereSQL = "WHERE " + strings.Join(whereClauses, " AND ")
	}

	// Sort mapping with ICU collation
	orderCol := `u.full_name COLLATE "en-US-x-icu"`
	switch req.SortBy {
	case "fullName":
		orderCol = `u.full_name COLLATE "en-US-x-icu"`
	case "email":
		orderCol = `u.email COLLATE "en-US-x-icu"`
	case "position":
		orderCol = `COALESCE(p.name, '') COLLATE "en-US-x-icu"`
	case "division":
		orderCol = `COALESCE(d.name, '') COLLATE "en-US-x-icu"`
	case "groupRole":
		orderCol = `(CASE 
			WHEN up.is_tc THEN 'Total Control'
			WHEN up.is_ro THEN 'Read Only'
			WHEN up.is_gm THEN 'Group Manager'
			WHEN up.role_count = 1 THEN '1 role'
			ELSE up.role_count || ' roles'
		END)`
	case "activationStatus":
		orderCol = "u.activation_status"
	case "temporaryStatus":
		orderCol = "u.is_temporary"
	case "activePeriodUntil":
		orderCol = "u.active_period_until"
	}

	orderDir := "ASC"
	if req.SortOrder == -1 {
		orderDir = "DESC"
	}

	// Pagination
	limit := req.Limit
	if limit <= 0 {
		limit = constant.DefaultLimit
	}
	page := req.Page
	if page <= 0 {
		page = constant.DefaultPage
	}
	offset := (page - 1) * limit

	args = append(args, limit)
	limitParam := fmt.Sprintf("$%d", argIdx)
	argIdx++

	args = append(args, offset)
	offsetParam := fmt.Sprintf("$%d", argIdx)

	query := fmt.Sprintf(`WITH pop AS (
    SELECT 
        usr.user_id, 
        COUNT(*)::int AS role_count, 
        FALSE AS is_gm, 
        FALSE AS is_tc, 
        FALSE AS is_ro
    FROM user_system_roles usr
    WHERE usr.product = %s 
      AND usr.scope_level = 'group' 
      AND usr.%s = %s
    GROUP BY usr.user_id

    UNION ALL

    SELECT 
        ugm.user_id, 
        0 AS role_count, 
        TRUE AS is_gm, 
        FALSE AS is_tc, 
        FALSE AS is_ro
    FROM user_group_managers ugm
    WHERE ugm.product = %s 
      AND ugm.%s = %s

    UNION ALL

    SELECT 
        ual.user_id, 
        0 AS role_count, 
        FALSE AS is_gm, 
        (ual.access_level = 'total_control') AS is_tc, 
        (ual.access_level = 'read_only') AS is_ro
    FROM user_access_levels ual
    WHERE ual.product = %s 
      AND ual.access_level IN ('total_control', 'read_only')
),
user_pop AS (
    SELECT 
        pop.user_id,
        SUM(pop.role_count)::int AS role_count,
        BOOL_OR(pop.is_gm) AS is_gm,
        BOOL_OR(pop.is_tc) AS is_tc,
        BOOL_OR(pop.is_ro) AS is_ro
    FROM pop
    GROUP BY pop.user_id
),
filtered_data AS (
    SELECT 
        u.id::text AS _id,
        u.profile_picture AS "profilePicture",
        u.full_name AS "fullName",
        u.email,
        p.name AS position,
        d.name AS division,
        CASE 
            WHEN up.is_tc THEN 'Total Control'
            WHEN up.is_ro THEN 'Read Only'
            WHEN up.is_gm THEN 'Group Manager'
            WHEN up.role_count = 1 THEN '1 role'
            ELSE up.role_count || ' roles'
        END AS "groupRole",
        u.activation_status AS "activationStatus",
        CASE WHEN u.is_temporary THEN 'Yes' ELSE 'No' END AS "temporaryStatus",
        CASE WHEN u.is_temporary THEN u.active_period_until ELSE NULL END AS "activePeriodUntil",
        u.tag_code AS "tagCode",
        u.id AS raw_user_id,
        %s AS sort_val
    FROM user_pop up
    JOIN users u ON u.id = up.user_id AND u.deleted_at IS NULL
    LEFT JOIN positions p ON p.id = u.position_id
    LEFT JOIN divisions d ON d.id = u.division_id
    %s
),
total_count AS (
    SELECT COUNT(*) AS count FROM filtered_data
),
paginated_data AS (
    SELECT 
        _id,
        "profilePicture",
        "fullName",
        email,
        position,
        division,
        "groupRole",
        "activationStatus",
        "temporaryStatus",
        "activePeriodUntil",
        "tagCode"
    FROM filtered_data
    ORDER BY sort_val %s, raw_user_id ASC
    LIMIT %s OFFSET %s
)
SELECT 
    COALESCE((SELECT jsonb_agg(paginated_data) FROM paginated_data), '[]'::jsonb) AS data,
    COALESCE((SELECT count FROM total_count), 0) AS "totalRecords";`,
		productParam, groupCol, groupParam,
		productParam, groupCol, groupParam,
		productParam,
		orderCol,
		whereSQL,
		orderDir,
		limitParam, offsetParam,
	)

	return query, args
}

// BuildGroupUserOptionsQuery constructs the parameterized SQL query for POST /v2/iam/groups/{product}/{id}/users/options.
func BuildGroupUserOptionsQuery(product string, groupID int64, req dto.GroupUserOptionsRequest) (string, []any) {
	groupCol := "admin_console_group_id"
	if product == constant.ProductFixedAsset {
		groupCol = "fixed_asset_group_id"
	}

	var ctes []string
	baseCTE := fmt.Sprintf(`WITH
pop AS (
    SELECT 
        usr.user_id, 
        1 AS role_count, 
        FALSE AS is_gm, 
        FALSE AS is_tc, 
        FALSE AS is_ro
    FROM user_system_roles usr
    WHERE usr.product = $1 
      AND usr.scope_level = 'group' 
      AND usr.%s = $2

    UNION ALL

    SELECT 
        ugm.user_id, 
        0 AS role_count, 
        TRUE AS is_gm, 
        FALSE AS is_tc, 
        FALSE AS is_ro
    FROM user_group_managers ugm
    WHERE ugm.product = $1 
      AND ugm.%s = $2

    UNION ALL

    SELECT 
        ual.user_id, 
        0 AS role_count, 
        FALSE AS is_gm, 
        (ual.access_level = 'total_control') AS is_tc, 
        (ual.access_level = 'read_only') AS is_ro
    FROM user_access_levels ual
    WHERE ual.product = $1 
      AND ual.access_level IN ('total_control', 'read_only')
),
user_population AS (
    SELECT 
        u.id, 
        u.position_id, 
        u.division_id, 
        BOOL_OR(pop.is_gm) AS is_gm, 
        BOOL_OR(pop.is_tc) AS is_tc, 
        BOOL_OR(pop.is_ro) AS is_ro
    FROM pop
    JOIN users u ON u.id = pop.user_id AND u.deleted_at IS NULL
    GROUP BY u.id, u.position_id, u.division_id
)`, groupCol, groupCol)

	ctes = append(ctes, baseCTE)

	var selectCols []string

	if req.PositionOptions {
		ctes = append(ctes, `position_options_cte AS (
    SELECT DISTINCT p.name AS label, p.name AS value
    FROM user_population up
    JOIN positions p ON p.id = up.position_id
    WHERE p.name IS NOT NULL AND p.name != ''
    ORDER BY p.name ASC
)`)
		selectCols = append(selectCols, `COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', value)) FROM position_options_cte), '[]'::jsonb) AS "positionOptions"`)
	}

	if req.DivisionOptions {
		ctes = append(ctes, `division_options_cte AS (
    SELECT DISTINCT d.name AS label, d.id::text AS value
    FROM user_population up
    JOIN divisions d ON d.id = up.division_id
    WHERE d.name IS NOT NULL AND d.name != ''
    ORDER BY d.name ASC
)`)
		selectCols = append(selectCols, `COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', value)) FROM division_options_cte), '[]'::jsonb) AS "divisionOptions"`)
	}

	if req.GroupRoleOptions {
		ctes = append(ctes, fmt.Sprintf(`group_role_options_cte AS (
    SELECT 'Total Control' AS label, 'total_control' AS value, 1 AS ord
    WHERE EXISTS (SELECT 1 FROM user_population WHERE is_tc)
    UNION ALL
    SELECT 'Read Only' AS label, 'read_only' AS value, 2 AS ord
    WHERE EXISTS (SELECT 1 FROM user_population WHERE is_ro)
    UNION ALL
    SELECT 'Group Manager' AS label, 'group_manager' AS value, 3 AS ord
    WHERE EXISTS (SELECT 1 FROM user_population WHERE is_gm)
    UNION ALL
    SELECT DISTINCT
        CASE usr.key 
            WHEN 'manage_distributor' THEN 'Manage distributor' 
            WHEN 'manage_partner' THEN 'Manage partner' 
            WHEN 'manage_group' THEN 'Manage group' 
            WHEN 'manage_user_and_role' THEN 'Manage user and role' 
            WHEN 'manage_active_client' THEN 'Manage active client' 
            WHEN 'manage_archived_client' THEN 'Manage archived client' 
            WHEN 'manage_allocation' THEN 'Manage allocation' 
            WHEN 'manage_wallet_and_pricing' THEN 'Manage wallet & pricing' 
            ELSE usr.key 
        END AS label,
        usr.key AS value,
        4 AS ord
    FROM user_system_roles usr
    WHERE usr.product = $1
      AND usr.scope_level = 'group'
      AND usr.%s = $2
    ORDER BY ord ASC, label ASC
)`, groupCol))
		selectCols = append(selectCols, `COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', value)) FROM group_role_options_cte), '[]'::jsonb) AS "groupRoleOptions"`)
	}

	if req.ActivationStatusOptions {
		ctes = append(ctes, `activation_status_options_cte AS (
    SELECT 'Activated' AS label, 'Activated' AS value, 1 AS ord
    UNION ALL
    SELECT 'Pending Activation' AS label, 'Pending Activation' AS value, 2 AS ord
    ORDER BY ord ASC
)`)
		selectCols = append(selectCols, `COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', value)) FROM activation_status_options_cte), '[]'::jsonb) AS "activationStatusOptions"`)
	}

	if req.TemporaryStatusOptions {
		ctes = append(ctes, `temporary_status_options_cte AS (
    SELECT 'Yes' AS label, 'Yes' AS value, 1 AS ord
    UNION ALL
    SELECT 'No' AS label, 'No' AS value, 2 AS ord
    ORDER BY ord ASC
)`)
		selectCols = append(selectCols, `COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', value)) FROM temporary_status_options_cte), '[]'::jsonb) AS "temporaryStatusOptions"`)
	}

	if len(selectCols) == 0 {
		return "SELECT '{}'::jsonb;", []any{}
	}

	fullQuery := strings.Join(ctes, ",\n") + "\nSELECT " + strings.Join(selectCols, ",\n       ") + ";"
	return fullQuery, []any{product, groupID}
}
