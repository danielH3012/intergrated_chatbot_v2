package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleGetGroupUserOptions serves POST /v2/iam/groups/:product/:id/users/options.
func (h *GroupHandler) HandleGetGroupUserOptions(c fiber.Ctx) error {
	product, err := productFromPath(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	groupID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil || groupID <= 0 {
		return coreEntity.BadRequest("Invalid group id").SendResponse(c)
	}

	clientID, roles, _, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.GroupUserOptionsRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	res, err := h.svc.GetGroupUserOptions(c.Context(), clientID, product, groupID, roles, body)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Data retrieved", res)
}
