package handler

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/service"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// GroupHandler handles HTTP requests for group endpoints.
type GroupHandler struct {
	svc *service.GroupService
}

// NewGroupHandler instantiates a GroupHandler.
func NewGroupHandler(svc *service.GroupService) *GroupHandler {
	return &GroupHandler{svc: svc}
}

// productFromPath resolves and validates the {product} path segment.
// Allowed products are admin_console and fixed_asset.
func productFromPath(c fiber.Ctx) (string, error) {
	product := c.Params("product")
	switch product {
	case constant.ProductAdminConsole, constant.ProductFixedAsset:
		return product, nil
	default:
		return "", coreEntity.BadRequest("Unknown product")
	}
}
