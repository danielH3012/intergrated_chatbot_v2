package handler_test

import (
	"encoding/json"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/service"
	tsEnum "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func newTestApp(t *testing.T, repo repository.GroupUserRepository, customRoles *tsMiddleware.UserAccessCache) *fiber.App {
	t.Helper()

	svc := service.NewGroupService("tagsamurai_iam", repo, nil)
	svc.SetServiceFactoryForTest(func(_ string) coreService.PostgreSQLServicer {
		return nil
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		if customRoles != nil {
			c.Locals(tsMiddleware.UserRolesKey, *customRoles)
		} else {
			c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
				FullName: "Test Super Admin",
				ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
					tsEnum.ModuleAccessAdminConsole: {IsTotalControl: true},
					tsEnum.ModuleAccessFixedAsset:   {IsTotalControl: true},
				},
			})
		}
		return c.Next()
	})

	h := handler.NewGroupHandler(svc)
	groupV2 := app.Group("/v2/iam/groups")
	groupV2.Post("/:product/:id/users/list", h.HandleListGroupUsers)
	groupV2.Post("/:product/:id/users/options", h.HandleGetGroupUserOptions)

	groupLegacy := app.Group("/groups")
	groupLegacy.Post("/:product/:id/users/list", h.HandleListGroupUsers)
	groupLegacy.Post("/:product/:id/users/options", h.HandleGetGroupUserOptions)

	return app
}

func do(app *fiber.App, method, path, body, clientID, userID string) (int, string, string) {
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	if clientID != "" {
		req.Header.Set("X-Client-ID", clientID)
	}
	if userID != "" {
		req.Header.Set("X-User-ID", userID)
	}
	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	raw, _ := io.ReadAll(res.Body)
	return res.StatusCode, string(raw), res.Header.Get("Content-Type")
}

func TestHandleListGroupUsers_Success(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	fakeRepo.Users[10] = repository.FakeUser{
		ID: 10, FullName: "John Doe", Email: "john@example.com",
	}
	fakeRepo.UserAccessLevels = append(fakeRepo.UserAccessLevels, repository.FakeUserAccessLevel{
		UserID: 10, Product: constant.ProductAdminConsole, AccessLevel: "total_control",
	})

	app := newTestApp(t, fakeRepo, nil)

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/100/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}

	var resp struct {
		StatusCode int    `json:"statusCode"`
		Message    string `json:"message"`
		Data       struct {
			TotalRecords int                 `json:"totalRecords"`
			Data         []dto.GroupUserItem `json:"data"`
		} `json:"data"`
	}
	if err := json.Unmarshal([]byte(body), &resp); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}

	if resp.Message != "Users retrieved" {
		t.Errorf("expected 'Users retrieved', got %q", resp.Message)
	}
	if resp.Data.TotalRecords != 1 {
		t.Errorf("expected 1 record, got %d", resp.Data.TotalRecords)
	}
	if len(resp.Data.Data) != 1 || resp.Data.Data[0].FullName != "John Doe" {
		t.Errorf("unexpected user item: %+v", resp.Data.Data)
	}
}

func TestHandleListGroupUsers_LegacyRoute(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	status, _, _ := do(app, fiber.MethodPost, "/groups/admin_console/100/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200 on legacy route, got %d", status)
	}
}

func TestHandleListGroupUsers_UnknownProduct(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/unknown_product/100/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
	if !strings.Contains(body, "Unknown product") {
		t.Errorf("expected 'Unknown product' in error, got %s", body)
	}
}

func TestHandleListGroupUsers_InvalidGroupID(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	// String id
	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/abc/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for non-numeric id, got %d: %s", status, body)
	}

	// Zero id
	status, body, _ = do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/0/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for zero id, got %d: %s", status, body)
	}

	// Negative id
	status, body, _ = do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/-5/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for negative id, got %d: %s", status, body)
	}
}

func TestHandleListGroupUsers_MalformedBody(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	status, _, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/100/users/list", `{"page":`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for malformed json, got %d", status)
	}
}

func TestHandleListGroupUsers_ValidationFailure(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	// limit > 100 violates max=100
	status, _, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/100/users/list", `{"limit":101}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for limit over cap, got %d", status)
	}
}

func TestHandleListGroupUsers_OutOfScope_Returns404(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	var scopedRoles tsMiddleware.UserAccessCache
	scopedRoles.AdminConsoleSystemRole.GroupRoles = map[tsEnum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"100"},
		},
	}

	app := newTestApp(t, fakeRepo, &scopedRoles)

	// Accessing group 200 (out of scope) should return 404
	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/200/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusNotFound {
		t.Errorf("expected 404, got %d: %s", status, body)
	}
	if !strings.Contains(body, "Group not found") {
		t.Errorf("expected 'Group not found' in response, got %s", body)
	}
}

func TestHandleListGroupUsers_MissingIdentity_Returns401(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	// App without UserRolesKey in Locals
	svc := service.NewGroupService("tagsamurai_iam", fakeRepo, nil)
	svc.SetServiceFactoryForTest(func(_ string) coreService.PostgreSQLServicer {
		return nil
	})

	app := fiber.New()
	h := handler.NewGroupHandler(svc)
	app.Post("/v2/iam/groups/:product/:id/users/list", h.HandleListGroupUsers)

	status, _, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/100/users/list", `{}`, "tenant1", "1")
	if status != fiber.StatusUnauthorized {
		t.Errorf("expected 401 when UserRolesKey is absent, got %d", status)
	}
}

func TestHandleGetGroupUserOptions_Success(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	posDev := int64(10)
	fakeRepo.Positions[posDev] = "Engineer"
	fakeRepo.Users[10] = repository.FakeUser{
		ID: 10, FullName: "John Doe", Email: "john@example.com", PositionID: &posDev,
	}
	fakeRepo.UserAccessLevels = append(fakeRepo.UserAccessLevels, repository.FakeUserAccessLevel{
		UserID: 10, Product: constant.ProductAdminConsole, AccessLevel: "total_control",
	})

	app := newTestApp(t, fakeRepo, nil)

	payload := `{"positionOptions":true,"activationStatusOptions":true}`
	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/100/users/options", payload, "tenant1", "1")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}

	var resp struct {
		StatusCode int                          `json:"statusCode"`
		Message    string                       `json:"message"`
		Data       dto.GroupUserOptionsResponse `json:"data"`
	}
	if err := json.Unmarshal([]byte(body), &resp); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}

	if resp.Message != "Data retrieved" {
		t.Errorf("expected 'Data retrieved', got %q", resp.Message)
	}
	if len(resp.Data.PositionOptions) != 1 || resp.Data.PositionOptions[0].Value != "Engineer" {
		t.Errorf("unexpected position options: %+v", resp.Data.PositionOptions)
	}
	if len(resp.Data.ActivationStatusOptions) != 2 {
		t.Errorf("expected 2 activation status options, got %d", len(resp.Data.ActivationStatusOptions))
	}
}

func TestHandleGetGroupUserOptions_UnknownProduct(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/unknown/100/users/options", `{}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for unknown product, got %d: %s", status, body)
	}
}

func TestHandleGetGroupUserOptions_InvalidGroupID(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	app := newTestApp(t, fakeRepo, nil)

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/0/users/options", `{}`, "tenant1", "1")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400 for invalid group id, got %d: %s", status, body)
	}
}

func TestHandleGetGroupUserOptions_OutOfScope_Returns404(t *testing.T) {
	fakeRepo := repository.NewFakeGroupUserRepository()
	var scopedRoles tsMiddleware.UserAccessCache
	scopedRoles.AdminConsoleSystemRole.GroupRoles = map[tsEnum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"100"},
		},
	}

	app := newTestApp(t, fakeRepo, &scopedRoles)

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/groups/admin_console/200/users/options", `{}`, "tenant1", "1")
	if status != fiber.StatusNotFound {
		t.Errorf("expected 404 for out of scope group, got %d: %s", status, body)
	}
}
