package service

import (
	"context"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/repository"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func newTestGroupService(repo repository.GroupUserRepository) *GroupService {
	svc := NewGroupService("test_db", repo, nil)
	svc.SetServiceFactoryForTest(func(_ string) coreService.PostgreSQLServicer {
		return nil
	})
	return svc
}

func TestListGroupUsers_TotalControl(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	repo.Users[1] = repository.FakeUser{
		ID: 1, FullName: "Admin User", Email: "admin@test.local",
	}
	repo.UserAccessLevels = append(repo.UserAccessLevels, repository.FakeUserAccessLevel{
		UserID: 1, Product: constant.ProductAdminConsole, AccessLevel: "total_control",
	})

	svc := newTestGroupService(repo)
	ctx := context.Background()

	roles := tsMiddleware.UserAccessCache{
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	res, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 999, roles, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.TotalRecords != 1 {
		t.Errorf("expected 1 record, got %d", res.TotalRecords)
	}
}

func TestListGroupUsers_ReadOnly(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	roles := tsMiddleware.UserAccessCache{
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsReadOnly: true},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	res, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 999, roles, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res.TotalRecords != 0 {
		t.Errorf("expected 0 records, got %d", res.TotalRecords)
	}
}

func TestListGroupUsers_ScopedUser_AssignedNode_Allowed(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	var roles tsMiddleware.UserAccessCache
	roles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"100", "101"},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	res, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 100, roles, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil response")
	}
}

func TestListGroupUsers_ScopedUser_OutOfScopeNode_Returns404(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	var roles tsMiddleware.UserAccessCache
	roles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"100", "101"},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	// 999 is not in View list ["100", "101"]
	_, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 999, roles, req)
	if err == nil {
		t.Fatal("expected error, got nil")
	}

	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok {
		t.Fatalf("expected HttpError, got %T: %v", err, err)
	}
	if httpErr.Code != 404 {
		t.Errorf("expected status code 404, got %d", httpErr.Code)
	}
	if httpErr.Message != "Group not found" {
		t.Errorf("expected 'Group not found', got %q", httpErr.Message)
	}
}

func TestListGroupUsers_NoRole_Returns404(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	roles := tsMiddleware.UserAccessCache{}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	_, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 100, roles, req)
	if err == nil {
		t.Fatal("expected error, got nil")
	}

	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok {
		t.Fatalf("expected HttpError, got %T: %v", err, err)
	}
	if httpErr.Code != 404 {
		t.Errorf("expected status code 404, got %d", httpErr.Code)
	}
}

func TestListGroupUsers_FixedAsset_Scoped(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	var roles tsMiddleware.UserAccessCache
	roles.FixedAssetSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"200"},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	// 200 is in scope
	res, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductFixedAsset, 200, roles, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil response")
	}

	// 300 is out of scope -> 404
	_, err = svc.ListGroupUsers(ctx, "tenant1", constant.ProductFixedAsset, 300, roles, req)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != 404 {
		t.Fatalf("expected 404 HttpError, got %v", err)
	}
}

func TestGetGroupUserOptions_Service_TotalControl(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	roles := tsMiddleware.UserAccessCache{
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	req := dto.GroupUserOptionsRequest{
		PositionOptions: true,
	}

	res, err := svc.GetGroupUserOptions(ctx, "tenant1", constant.ProductAdminConsole, 100, roles, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil response")
	}
}

func TestGetGroupUserOptions_Service_OutOfScope_Returns404(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	var roles tsMiddleware.UserAccessCache
	roles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"100"},
		},
	}

	req := dto.GroupUserOptionsRequest{
		PositionOptions: true,
	}

	// 999 is out of scope
	_, err := svc.GetGroupUserOptions(ctx, "tenant1", constant.ProductAdminConsole, 999, roles, req)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != 404 {
		t.Fatalf("expected 404 HttpError, got %v", err)
	}
}

func TestListGroupUsers_NonExistentGroup_Returns404_EvenForTotalControl(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	// Simulate EMS reporting group does not exist
	svc.SetGroupValidatorForTest(func(_ context.Context, _ string, groupID int64) (bool, error) {
		if groupID == 999999999 {
			return false, nil
		}
		return true, nil
	})

	ctx := context.Background()
	roles := tsMiddleware.UserAccessCache{
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	_, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 999999999, roles, req)
	if err == nil {
		t.Fatal("expected 404 error for non-existent group, got nil")
	}
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != 404 {
		t.Fatalf("expected 404 HttpError, got %v", err)
	}
	if httpErr.Message != "Group not found" {
		t.Errorf("expected 'Group not found', got %q", httpErr.Message)
	}
}

func TestGetGroupUserOptions_NonExistentGroup_Returns404(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	svc.SetGroupValidatorForTest(func(_ context.Context, _ string, groupID int64) (bool, error) {
		return false, nil
	})

	ctx := context.Background()
	roles := tsMiddleware.UserAccessCache{
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsReadOnly: true},
		},
	}

	req := dto.GroupUserOptionsRequest{PositionOptions: true}
	_, err := svc.GetGroupUserOptions(ctx, "tenant1", constant.ProductAdminConsole, 123, roles, req)
	if err == nil {
		t.Fatal("expected 404 error for non-existent group, got nil")
	}
	httpErr, ok := err.(*coreEntity.HttpError)
	if !ok || httpErr.Code != 404 {
		t.Fatalf("expected 404 HttpError, got %v", err)
	}
}

func TestListGroupUsers_ScopedUser_AncestorNode_Allowed(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	// Ancestor node 50 is not in user's direct assignment [100], but scopeValidator confirms it is an ancestor
	svc.SetScopeValidatorForTest(func(_ context.Context, _ string, groupID int64, assignedIDs []string) (bool, error) {
		if groupID == 50 {
			return true, nil
		}
		return false, nil
	})

	ctx := context.Background()
	var roles tsMiddleware.UserAccessCache
	roles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		constant.SystemRoleKeyManageGroup: {
			View: []string{"100"},
		},
	}

	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	res, err := svc.ListGroupUsers(ctx, "tenant1", constant.ProductAdminConsole, 50, roles, req)
	if err != nil {
		t.Fatalf("expected ancestor node 50 to be allowed, got error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil response")
	}
}

func TestAssignCreatorRole_Service(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	param := dto.AssignCreatorGroupRoleParam{
		EntityID:  1001,
		GroupID:   555,
		GroupName: "Engineering",
		ActorID:   42,
		ActorName: "Creator User",
	}

	err := svc.AssignCreatorRole(ctx, "1001", param)
	if err != nil {
		t.Fatalf("unexpected error assigning creator role: %v", err)
	}

	if len(repo.UserSystemRoles) != 1 {
		t.Fatalf("expected 1 role assigned, got %d", len(repo.UserSystemRoles))
	}
	assigned := repo.UserSystemRoles[0]
	if assigned.UserID != 42 || assigned.Key != "manage_group" || *assigned.AdminConsoleGroupID != 555 {
		t.Errorf("unexpected assigned role data: %+v", assigned)
	}

	// Total control actor should be skipped
	repo.UserAccessLevels = append(repo.UserAccessLevels, repository.FakeUserAccessLevel{
		UserID:      99,
		Product:     constant.ProductAdminConsole,
		AccessLevel: "total_control",
	})
	paramTC := dto.AssignCreatorGroupRoleParam{
		EntityID: 1001, GroupID: 556, GroupName: "Marketing", ActorID: 99,
	}
	err = svc.AssignCreatorRole(ctx, "1001", paramTC)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(repo.UserSystemRoles) != 1 {
		t.Errorf("expected no additional role for total_control actor, got %d", len(repo.UserSystemRoles))
	}
}

func TestRevokeGroupRoles_Service(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	svc := newTestGroupService(repo)
	ctx := context.Background()

	gid1 := int64(100)
	gid2 := int64(101)
	repo.Users[1] = repository.FakeUser{ID: 1, FullName: "Alice Baker"}
	repo.UserSystemRoles = append(repo.UserSystemRoles, repository.FakeUserSystemRole{
		UserID: 1, Product: constant.ProductAdminConsole, Key: "manage_group", AdminConsoleGroupID: &gid1,
	})
	repo.UserGroupManagers = append(repo.UserGroupManagers, repository.FakeUserGroupManager{
		UserID: 1, Product: constant.ProductAdminConsole, AdminConsoleGroupID: &gid2,
	})

	res, err := svc.RevokeGroupRoles(ctx, "1001", dto.RevokeGroupRolesParam{
		EntityID:       1001,
		SafeSubtreeIDs: []int64{100, 101},
	})
	if err != nil {
		t.Fatalf("unexpected error revoking roles: %v", err)
	}

	if len(res.RevokedUsers) != 1 || res.RevokedUsers[0].UserID != 1 {
		t.Errorf("unexpected revoked users: %+v", res.RevokedUsers)
	}
	if len(repo.UserSystemRoles) != 0 {
		t.Errorf("expected 0 user system roles after revoke, got %d", len(repo.UserSystemRoles))
	}
	if len(repo.UserGroupManagers) != 0 {
		t.Errorf("expected 0 user group managers after revoke, got %d", len(repo.UserGroupManagers))
	}
}
