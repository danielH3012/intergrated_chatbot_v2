package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// GetGroupUserOptions enforces node scope and retrieves filter options for the Total User popup.
func (s *GroupService) GetGroupUserOptions(
	ctx context.Context,
	clientID string,
	product string,
	groupID int64,
	roles tsMiddleware.UserAccessCache,
	req dto.GroupUserOptionsRequest,
) (*dto.GroupUserOptionsResponse, error) {
	if err := s.CheckGroupExists(ctx, clientID, groupID); err != nil {
		return nil, err
	}

	if product == constant.ProductFixedAsset {
		isTC := roles.IsTotalControl(enum.ModuleAccessFixedAsset)
		isRO := roles.IsReadOnly(enum.ModuleAccessFixedAsset)
		if !isTC && !isRO {
			if !roles.HasGroupPermissionFixedAsset(constant.SystemRoleKeyManageGroup, groupID, tsMiddleware.PermView) {
				assignedIDs := roles.FixedAssetSystemRole.GroupRoles[constant.SystemRoleKeyManageGroup].View
				if len(assignedIDs) == 0 {
					return nil, coreEntity.NotFound("Group not found")
				}
				inScope, err := s.CheckGroupScope(ctx, clientID, groupID, assignedIDs)
				if err != nil || !inScope {
					return nil, coreEntity.NotFound("Group not found")
				}
			}
		}
	} else {
		isTC := roles.IsTotalControl(enum.ModuleAccessAdminConsole)
		isRO := roles.IsReadOnly(enum.ModuleAccessAdminConsole)
		if !isTC && !isRO {
			if !roles.HasGroupPermissionAdminConsole(constant.SystemRoleKeyManageGroup, groupID, tsMiddleware.PermView) {
				assignedIDs := roles.AdminConsoleSystemRole.GroupRoles[constant.SystemRoleKeyManageGroup].View
				if len(assignedIDs) == 0 {
					return nil, coreEntity.NotFound("Group not found")
				}
				inScope, err := s.CheckGroupScope(ctx, clientID, groupID, assignedIDs)
				if err != nil || !inScope {
					return nil, coreEntity.NotFound("Group not found")
				}
			}
		}
	}

	return s.repo.GetGroupUserOptions(ctx, s.tenantSvc(clientID), product, groupID, req)
}
