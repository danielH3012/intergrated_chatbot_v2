package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/repository"
	tsDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// GroupService coordinates group user operations and enforces node scoping.
type GroupService struct {
	dbName         string
	repo           repository.GroupUserRepository
	settingsClient *client.EnterpriseManagementClient
	makeTenantSvc  func(clientID string) coreService.PostgreSQLServicer
	groupValidator func(ctx context.Context, clientID string, groupID int64) (bool, error)
	scopeValidator func(ctx context.Context, clientID string, groupID int64, assignedIDs []string) (bool, error)
}

// NewGroupService constructs a new GroupService with dependency injection.
func NewGroupService(
	dbName string,
	repo repository.GroupUserRepository,
	settingsClient *client.EnterpriseManagementClient,
) *GroupService {
	return &GroupService{
		dbName:         dbName,
		repo:           repo,
		settingsClient: settingsClient,
	}
}

// SetServiceFactoryForTest replaces the DB factory with a stub so unit tests never
// hit a real PostgreSQL server.
func (s *GroupService) SetServiceFactoryForTest(factory func(clientID string) coreService.PostgreSQLServicer) {
	s.makeTenantSvc = factory
}

// SetGroupValidatorForTest overrides group existence checks for unit tests.
func (s *GroupService) SetGroupValidatorForTest(validator func(ctx context.Context, clientID string, groupID int64) (bool, error)) {
	s.groupValidator = validator
}

// SetScopeValidatorForTest overrides group hierarchy/scope checks for unit tests.
func (s *GroupService) SetScopeValidatorForTest(validator func(ctx context.Context, clientID string, groupID int64, assignedIDs []string) (bool, error)) {
	s.scopeValidator = validator
}

// CheckGroupExists verifies that a group exists in the entity.
func (s *GroupService) CheckGroupExists(ctx context.Context, clientID string, groupID int64) error {
	if s.groupValidator != nil {
		exists, err := s.groupValidator(ctx, clientID, groupID)
		if err != nil {
			return err
		}
		if !exists {
			return coreEntity.NotFound("Group not found")
		}
		return nil
	}
	if s.settingsClient != nil {
		exists, err := s.settingsClient.ValidateGroupExists(ctx, clientID, groupID)
		if err != nil {
			return err
		}
		if !exists {
			return coreEntity.NotFound("Group not found")
		}
	}
	return nil
}

// CheckGroupScope verifies that groupID is in the assigned groups' ancestor chain or subtree.
func (s *GroupService) CheckGroupScope(ctx context.Context, clientID string, groupID int64, assignedIDs []string) (bool, error) {
	if s.scopeValidator != nil {
		return s.scopeValidator(ctx, clientID, groupID, assignedIDs)
	}
	if s.settingsClient != nil {
		return s.settingsClient.ValidateGroupInScope(ctx, clientID, groupID, assignedIDs)
	}
	return false, nil
}

// AssignCreatorRole assigns full manage_group permissions to the group creator.
func (s *GroupService) AssignCreatorRole(ctx context.Context, clientID string, param dto.AssignCreatorGroupRoleParam) error {
	svc := s.tenantSvc(clientID)
	isTC, err := s.repo.IsActorTotalControlOrDefault(ctx, svc, param.ActorID)
	if err != nil {
		return err
	}
	if isTC {
		return nil
	}

	coreDb.InitSnowflake()
	roleID := coreDb.Node.Generate().Int64()

	role := model.UserSystemRole{
		ID:                    roleID,
		UserID:                param.ActorID,
		Product:               model.Product(constant.ProductAdminConsole),
		ScopeLevel:            model.ScopeLevelGroup,
		Key:                   model.SystemRoleKey(constant.SystemRoleKeyManageGroup),
		PermissionView:        true,
		PermissionCreate:      true,
		PermissionUpdate:      true,
		PermissionDelete:      true,
		AdminConsoleGroupID:   &param.GroupID,
		AdminConsoleGroupName: &param.GroupName,
		ModifiedBy:            &param.ActorID,
	}

	return s.repo.AssignCreatorGroupRole(ctx, svc, role)
}

// RevokeGroupRoles removes group role assignments and manager rows for a deleted subtree.
func (s *GroupService) RevokeGroupRoles(ctx context.Context, clientID string, param dto.RevokeGroupRolesParam) (*dto.RevokeGroupRolesResult, error) {
	svc := s.tenantSvc(clientID)
	if len(param.SafeSubtreeIDs) == 0 {
		return &dto.RevokeGroupRolesResult{RevokedUsers: []dto.RevokedUserInfo{}}, nil
	}

	revoked, err := s.repo.FindRevokedUsersBySubtree(ctx, svc, constant.ProductAdminConsole, param.SafeSubtreeIDs)
	if err != nil {
		return nil, err
	}

	if err := s.repo.RevokeSubtreeGroupRoles(ctx, svc, constant.ProductAdminConsole, param.SafeSubtreeIDs); err != nil {
		return nil, err
	}

	return &dto.RevokeGroupRolesResult{RevokedUsers: revoked}, nil
}

// tenantSvc resolves a PostgreSQL service routed to the client's own schema.
func (s *GroupService) tenantSvc(clientID string) coreService.PostgreSQLServicer {
	if s.makeTenantSvc != nil {
		return s.makeTenantSvc(clientID)
	}
	return coreService.MakePostgreSQLService(string(tsDb.DBName(s.dbName).CompanyDBName(clientID)))
}
