package dto

// AssignCreatorGroupRoleParam holds parameters for assigning the creator's group role.
type AssignCreatorGroupRoleParam struct {
	EntityID  int64  `json:"entityId"`
	ClientID  string `json:"clientId"`
	GroupID   int64  `json:"groupId"`
	GroupName string `json:"groupName"`
	ActorID   int64  `json:"actorId"`
	ActorName string `json:"actorName"`
}

// RevokeSubtreeGroupRolesParam holds parameters for revoking roles in a subtree.
type RevokeSubtreeGroupRolesParam struct {
	EntityID       int64   `json:"entityId"`
	ClientID       string  `json:"clientId"`
	SafeSubtreeIDs []int64 `json:"safeSubtreeIds"`
}

type RevokeGroupRolesParam = RevokeSubtreeGroupRolesParam

type RevokedUserInfo struct {
	UserID       int64  `json:"userId"`
	UserFullName string `json:"userFullName"`
	RoleName     string `json:"roleName"`
}

type RevokeGroupRolesResult struct {
	RevokedUsers []RevokedUserInfo `json:"revokedUsers"`
}
