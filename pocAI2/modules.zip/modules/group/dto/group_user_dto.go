// Package dto defines data transfer objects for group user operations.
package dto

import "time"

// GroupUserItem represents a user in the Total User popup list.
// Strictly matches the OpenAPI UserPopupItem schema.
type GroupUserItem struct {
	ID                string     `json:"_id"                column:"_id"`
	ProfilePicture    *string    `json:"profilePicture"    column:"profile_picture"`
	FullName          string     `json:"fullName"          column:"full_name"`
	Email             string     `json:"email"             column:"email"`
	Position          *string    `json:"position"          column:"position"`
	Division          *string    `json:"division"          column:"division"`
	GroupRole         string     `json:"groupRole"         column:"group_role"`
	ActivationStatus  string     `json:"activationStatus"  column:"activation_status"`
	TemporaryStatus   string     `json:"temporaryStatus"   column:"temporary_status"`
	ActivePeriodUntil *time.Time `json:"activePeriodUntil" column:"active_period_until"`
	TagCode           *string    `json:"tagCode"           column:"tag_code"`
}
