package dto

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
)

// ListGroupUsersRequest represents the payload for POST /v2/iam/groups/{product}/{id}/users/list.
// Matches OpenAPI UserPopupListBody schema.
type ListGroupUsersRequest struct {
	Page              int      `json:"page" validate:"omitempty,min=1"`
	Limit             int      `json:"limit" validate:"omitempty,min=1,max=100"`
	SortBy            string   `json:"sortBy"`
	SortOrder         int      `json:"sortOrder" validate:"omitempty,oneof=1 -1"`
	Columns           []string `json:"columns"`
	Search            string   `json:"search"`
	Position          []string `json:"position"`
	Division          []string `json:"division"`
	GroupRole         []string `json:"groupRole"`
	ActivationStatus  []string `json:"activationStatus"`
	TemporaryStatus   []string `json:"temporaryStatus"`
	ActivePeriodUntil []int64  `json:"activePeriodUntil"`
}

// Defaults applies default pagination and sorting when not supplied.
func (r *ListGroupUsersRequest) Defaults() {
	if r.Page <= 0 {
		r.Page = constant.DefaultPage
	}
	if r.Limit <= 0 {
		r.Limit = constant.DefaultLimit
	}
	if r.SortBy == "" {
		r.SortBy = constant.DefaultSortBy
	}
	if r.SortOrder != 1 && r.SortOrder != -1 {
		r.SortOrder = constant.DefaultSortOrder
	}
}
