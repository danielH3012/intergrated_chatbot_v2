package dto

// OptionItem represents a standard label/value pair for filter dropdowns.
type OptionItem struct {
	Label string `json:"label"`
	Value string `json:"value"`
}

// GroupUserOptionsRequest represents the request payload for POST /v2/iam/groups/{product}/{id}/users/options.
type GroupUserOptionsRequest struct {
	PositionOptions         bool `json:"positionOptions"`
	DivisionOptions         bool `json:"divisionOptions"`
	GroupRoleOptions        bool `json:"groupRoleOptions"`
	ActivationStatusOptions bool `json:"activationStatusOptions"`
	TemporaryStatusOptions  bool `json:"temporaryStatusOptions"`
}

// GroupUserOptionsResponse represents the response containing the requested option arrays.
type GroupUserOptionsResponse struct {
	PositionOptions         []OptionItem `json:"positionOptions,omitempty"`
	DivisionOptions         []OptionItem `json:"divisionOptions,omitempty"`
	GroupRoleOptions        []OptionItem `json:"groupRoleOptions,omitempty"`
	ActivationStatusOptions []OptionItem `json:"activationStatusOptions,omitempty"`
	TemporaryStatusOptions  []OptionItem `json:"temporaryStatusOptions,omitempty"`
}
