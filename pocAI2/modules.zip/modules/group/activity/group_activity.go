package activity

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/repository"
	tsDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// Activities holds the dependencies for group Temporal activities.
type Activities struct {
	dbName        string
	repo          repository.GroupUserRepository
	makeTenantSvc func(clientID string) coreService.PostgreSQLServicer
}

// NewActivities instantiates group lifecycle Temporal activities.
func NewActivities(dbName string, repo repository.GroupUserRepository) *Activities {
	return &Activities{dbName: dbName, repo: repo}
}

// tenantSvc opens the tenant's own schema for the activity's client.
func (a *Activities) tenantSvc(clientID string) coreService.PostgreSQLServicer {
	if a.makeTenantSvc != nil {
		return a.makeTenantSvc(clientID)
	}
	return coreService.MakePostgreSQLService(string(tsDb.DBName(a.dbName).CompanyDBName(clientID)))
}

// SetServiceFactoryForTest replaces the DB factory with a stub for testing.
func (a *Activities) SetServiceFactoryForTest(factory func(clientID string) coreService.PostgreSQLServicer) {
	a.makeTenantSvc = factory
}
