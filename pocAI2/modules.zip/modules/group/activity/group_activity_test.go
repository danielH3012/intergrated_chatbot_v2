package activity

import (
	"context"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/repository"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func newTestActivities(repo repository.GroupUserRepository) *Activities {
	act := NewActivities("test_db", repo)
	act.SetServiceFactoryForTest(func(_ string) coreService.PostgreSQLServicer {
		return nil
	})
	return act
}

func TestAssignCreatorGroupRoleActivity(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	act := newTestActivities(repo)
	ctx := context.Background()

	param := dto.AssignCreatorGroupRoleParam{
		EntityID:  1001,
		GroupID:   200,
		GroupName: "Headquarters",
		ActorID:   15,
		ActorName: "Normal Creator",
	}

	err := act.AssignCreatorGroupRoleActivity(ctx, param)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if len(repo.UserSystemRoles) != 1 {
		t.Fatalf("expected 1 user system role assigned, got %d", len(repo.UserSystemRoles))
	}
	r := repo.UserSystemRoles[0]
	if r.UserID != 15 || r.Key != "manage_group" || *r.AdminConsoleGroupID != 200 {
		t.Errorf("unexpected role assignment: %+v", r)
	}

	// Total control actor
	repo.UserAccessLevels = append(repo.UserAccessLevels, repository.FakeUserAccessLevel{
		UserID:      99,
		Product:     constant.ProductAdminConsole,
		AccessLevel: "total_control",
	})
	paramTC := dto.AssignCreatorGroupRoleParam{
		EntityID: 1001, GroupID: 201, GroupName: "Branch", ActorID: 99,
	}
	err = act.AssignCreatorGroupRoleActivity(ctx, paramTC)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(repo.UserSystemRoles) != 1 {
		t.Errorf("expected no role added for total_control user, got %d", len(repo.UserSystemRoles))
	}
}

func TestRevokeSubtreeGroupRolesActivity(t *testing.T) {
	repo := repository.NewFakeGroupUserRepository()
	act := newTestActivities(repo)
	ctx := context.Background()

	gid1 := int64(100)
	gid2 := int64(101)
	repo.Users[1] = repository.FakeUser{ID: 1, FullName: "Alice Baker"}
	repo.UserSystemRoles = append(repo.UserSystemRoles, repository.FakeUserSystemRole{
		UserID: 1, Product: constant.ProductAdminConsole, Key: "manage_group", AdminConsoleGroupID: &gid1,
	})
	repo.UserGroupManagers = append(repo.UserGroupManagers, repository.FakeUserGroupManager{
		UserID: 1, Product: constant.ProductAdminConsole, AdminConsoleGroupID: &gid2,
	})

	res, err := act.RevokeSubtreeGroupRolesActivity(ctx, dto.RevokeSubtreeGroupRolesParam{
		EntityID:       1001,
		SafeSubtreeIDs: []int64{100, 101},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if len(res.RevokedUsers) != 1 || res.RevokedUsers[0].UserID != 1 {
		t.Errorf("unexpected revoked users: %+v", res.RevokedUsers)
	}
	if len(repo.UserSystemRoles) != 0 {
		t.Errorf("expected 0 user system roles, got %d", len(repo.UserSystemRoles))
	}
	if len(repo.UserGroupManagers) != 0 {
		t.Errorf("expected 0 user group managers, got %d", len(repo.UserGroupManagers))
	}
}
