package activity

import (
	"context"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
)

// AssignCreatorGroupRoleActivity grants the Manage group role on a newly created group to its creator.
// Total control users and the default user are skipped as they already possess full system authority.
func (a *Activities) AssignCreatorGroupRoleActivity(ctx context.Context, param dto.AssignCreatorGroupRoleParam) error {
	clientID := param.ClientID
	if clientID == "" && param.EntityID > 0 {
		clientID = strconv.FormatInt(param.EntityID, 10)
	}

	svc := a.tenantSvc(clientID)

	isTC, err := a.repo.IsActorTotalControlOrDefault(ctx, svc, param.ActorID)
	if err != nil {
		return err
	}
	if isTC {
		return nil
	}

	coreDb.InitSnowflake()
	roleID := coreDb.Node.Generate().Int64()

	role := model.UserSystemRole{
		ID:                    roleID,
		UserID:                param.ActorID,
		Product:               model.Product(constant.ProductAdminConsole),
		ScopeLevel:            model.ScopeLevelGroup,
		Key:                   model.SystemRoleKey(constant.SystemRoleKeyManageGroup),
		PermissionView:        true,
		PermissionCreate:      true,
		PermissionUpdate:      true,
		PermissionDelete:      true,
		AdminConsoleGroupID:   &param.GroupID,
		AdminConsoleGroupName: &param.GroupName,
		ModifiedBy:            &param.ActorID,
	}

	return a.repo.AssignCreatorGroupRole(ctx, svc, role)
}
