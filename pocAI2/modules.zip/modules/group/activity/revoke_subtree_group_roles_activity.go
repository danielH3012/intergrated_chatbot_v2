package activity

import (
	"context"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
)

// RevokeSubtreeGroupRolesActivity removes all group-scoped user_system_roles and user_group_managers
// for the given deleted subtree node IDs in Admin Console.
func (a *Activities) RevokeSubtreeGroupRolesActivity(ctx context.Context, param dto.RevokeSubtreeGroupRolesParam) (dto.RevokeGroupRolesResult, error) {
	if len(param.SafeSubtreeIDs) == 0 {
		return dto.RevokeGroupRolesResult{RevokedUsers: []dto.RevokedUserInfo{}}, nil
	}

	clientID := param.ClientID
	if clientID == "" && param.EntityID > 0 {
		clientID = strconv.FormatInt(param.EntityID, 10)
	}

	svc := a.tenantSvc(clientID)

	revoked, err := a.repo.FindRevokedUsersBySubtree(ctx, svc, constant.ProductAdminConsole, param.SafeSubtreeIDs)
	if err != nil {
		return dto.RevokeGroupRolesResult{}, err
	}

	if err := a.repo.RevokeSubtreeGroupRoles(ctx, svc, constant.ProductAdminConsole, param.SafeSubtreeIDs); err != nil {
		return dto.RevokeGroupRolesResult{}, err
	}

	return dto.RevokeGroupRolesResult{RevokedUsers: revoked}, nil
}

// RevokeGroupRolesActivity is an alias for RevokeSubtreeGroupRolesActivity to support EMS workflow naming.
func (a *Activities) RevokeGroupRolesActivity(ctx context.Context, param dto.RevokeGroupRolesParam) (dto.RevokeGroupRolesResult, error) {
	return a.RevokeSubtreeGroupRolesActivity(ctx, param)
}
