package repository

import (
	"context"
	"fmt"
	"slices"
	"strings"
	"sync"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type FakeUser struct {
	ID                int64
	FullName          string
	Email             string
	ProfilePicture    *string
	PositionID        *int64
	DivisionID        *int64
	ActivationStatus  string
	IsTemporary       bool
	IsDefault         bool
	ActivePeriodUntil *time.Time
	TagCode           *string
	DeletedAt         *time.Time
}

type FakeUserSystemRole struct {
	ID                    int64
	UserID                int64
	Product               string
	ScopeLevel            string
	Key                   string
	AdminConsoleGroupID   *int64
	AdminConsoleGroupName *string
	FixedAssetGroupID     *int64
	PermissionView        bool
	PermissionCreate      bool
	PermissionUpdate      bool
	PermissionDelete      bool
}

type FakeUserGroupManager struct {
	UserID              int64
	Product             string
	AdminConsoleGroupID *int64
	FixedAssetGroupID   *int64
}

type FakeUserAccessLevel struct {
	UserID      int64
	Product     string
	AccessLevel string
}

type FakeGroupUserRepository struct {
	mu                sync.RWMutex
	Users             map[int64]FakeUser
	UserSystemRoles   []FakeUserSystemRole
	UserGroupManagers []FakeUserGroupManager
	UserAccessLevels  []FakeUserAccessLevel
	Positions         map[int64]string
	Divisions         map[int64]string
}

func NewFakeGroupUserRepository() *FakeGroupUserRepository {
	return &FakeGroupUserRepository{
		Users:     make(map[int64]FakeUser),
		Positions: make(map[int64]string),
		Divisions: make(map[int64]string),
	}
}

func (f *FakeGroupUserRepository) PaginatedListGroupUsers(
	_ context.Context,
	_ coreService.PostgreSQLServicer,
	product string,
	groupID int64,
	req dto.ListGroupUsersRequest,
) (*coreDto.PaginationResult[dto.GroupUserItem], error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	type popData struct {
		roleCount int
		isGM      bool
		isTC      bool
		isRO      bool
	}
	population := make(map[int64]*popData)

	getPop := func(uid int64) *popData {
		if p, ok := population[uid]; ok {
			return p
		}
		p := &popData{}
		population[uid] = p
		return p
	}

	// 1. Group Role holders
	for _, usr := range f.UserSystemRoles {
		if usr.Product == product && usr.ScopeLevel == "group" {
			var matchGroup bool
			if product == constant.ProductAdminConsole && usr.AdminConsoleGroupID != nil && *usr.AdminConsoleGroupID == groupID {
				matchGroup = true
			} else if product == constant.ProductFixedAsset && usr.FixedAssetGroupID != nil && *usr.FixedAssetGroupID == groupID {
				matchGroup = true
			}
			if matchGroup {
				getPop(usr.UserID).roleCount++
			}
		}
	}

	// 2. Group Managers
	for _, ugm := range f.UserGroupManagers {
		if ugm.Product == product {
			var matchGroup bool
			if product == constant.ProductAdminConsole && ugm.AdminConsoleGroupID != nil && *ugm.AdminConsoleGroupID == groupID {
				matchGroup = true
			} else if product == constant.ProductFixedAsset && ugm.FixedAssetGroupID != nil && *ugm.FixedAssetGroupID == groupID {
				matchGroup = true
			}
			if matchGroup {
				getPop(ugm.UserID).isGM = true
			}
		}
	}

	// 3. TC / RO users
	for _, ual := range f.UserAccessLevels {
		if ual.Product == product {
			if ual.AccessLevel == "total_control" {
				getPop(ual.UserID).isTC = true
			} else if ual.AccessLevel == "read_only" {
				getPop(ual.UserID).isRO = true
			}
		}
	}

	var items []dto.GroupUserItem

	for userID, pop := range population {
		u, ok := f.Users[userID]
		if !ok || u.DeletedAt != nil {
			continue
		}

		var posName *string
		if u.PositionID != nil {
			if name, exists := f.Positions[*u.PositionID]; exists {
				posName = &name
			}
		}

		var divName *string
		if u.DivisionID != nil {
			if name, exists := f.Divisions[*u.DivisionID]; exists {
				divName = &name
			}
		}

		var groupRole string
		if pop.isTC {
			groupRole = constant.GroupRoleBadgeTotalControl
		} else if pop.isRO {
			groupRole = constant.GroupRoleBadgeReadOnly
		} else if pop.isGM {
			groupRole = constant.GroupRoleBadgeGroupManager
		} else if pop.roleCount == 1 {
			groupRole = "1 role"
		} else {
			groupRole = fmt.Sprintf("%d roles", pop.roleCount)
		}

		tempStatus := constant.TemporaryStatusNo
		if u.IsTemporary {
			tempStatus = constant.TemporaryStatusYes
		}

		// Filters
		// groupRole
		if len(req.GroupRole) > 0 {
			matchRole := false
			for _, gr := range req.GroupRole {
				switch strings.ToLower(strings.ReplaceAll(gr, " ", "_")) {
				case constant.GroupRoleFilterTotalControl:
					if pop.isTC {
						matchRole = true
					}
				case constant.GroupRoleFilterReadOnly:
					if pop.isRO {
						matchRole = true
					}
				case constant.GroupRoleFilterGroupManager:
					if pop.isGM {
						matchRole = true
					}
				default:
					for _, usr := range f.UserSystemRoles {
						if usr.UserID == userID && usr.Product == product && usr.ScopeLevel == "group" {
							var matchGroup bool
							if product == constant.ProductAdminConsole && usr.AdminConsoleGroupID != nil && *usr.AdminConsoleGroupID == groupID {
								matchGroup = true
							} else if product == constant.ProductFixedAsset && usr.FixedAssetGroupID != nil && *usr.FixedAssetGroupID == groupID {
								matchGroup = true
							}
							if matchGroup {
								display := groupRoleDisplayLabel(string(usr.Key))
								if strings.EqualFold(string(usr.Key), gr) || strings.EqualFold(display, gr) {
									matchRole = true
									break
								}
							}
						}
					}
				}
			}
			if !matchRole {
				continue
			}
		}

		// position
		if len(req.Position) > 0 {
			if posName == nil || !slices.Contains(req.Position, *posName) {
				continue
			}
		}

		// division
		if len(req.Division) > 0 {
			var divIDStr string
			if u.DivisionID != nil {
				divIDStr = fmt.Sprintf("%d", *u.DivisionID)
			}
			matchDiv := false
			if divName != nil && slices.Contains(req.Division, *divName) {
				matchDiv = true
			}
			if divIDStr != "" && slices.Contains(req.Division, divIDStr) {
				matchDiv = true
			}
			if !matchDiv {
				continue
			}
		}

		// activationStatus
		if len(req.ActivationStatus) > 0 {
			if !slices.Contains(req.ActivationStatus, u.ActivationStatus) {
				continue
			}
		}

		// temporaryStatus
		if len(req.TemporaryStatus) > 0 {
			hasYes := slices.Contains(req.TemporaryStatus, constant.TemporaryStatusYes)
			hasNo := slices.Contains(req.TemporaryStatus, constant.TemporaryStatusNo)
			if hasYes && !hasNo && !u.IsTemporary {
				continue
			}
			if hasNo && !hasYes && u.IsTemporary {
				continue
			}
		}

		// search
		if search := strings.TrimSpace(req.Search); search != "" {
			s := strings.ToLower(search)
			matchSearch := strings.Contains(strings.ToLower(u.FullName), s) ||
				strings.Contains(strings.ToLower(u.Email), s) ||
				(posName != nil && strings.Contains(strings.ToLower(*posName), s)) ||
				(divName != nil && strings.Contains(strings.ToLower(*divName), s)) ||
				strings.Contains(strings.ToLower(groupRole), s)
			if !matchSearch {
				continue
			}
		}

		item := dto.GroupUserItem{
			ID:                fmt.Sprintf("%d", u.ID),
			ProfilePicture:    u.ProfilePicture,
			FullName:          u.FullName,
			Email:             u.Email,
			Position:          posName,
			Division:          divName,
			GroupRole:         groupRole,
			ActivationStatus:  u.ActivationStatus,
			TemporaryStatus:   tempStatus,
			ActivePeriodUntil: u.ActivePeriodUntil,
			TagCode:           u.TagCode,
		}
		items = append(items, item)
	}

	// Default sort by fullName
	slices.SortFunc(items, func(a, b dto.GroupUserItem) int {
		cmp := strings.Compare(strings.ToLower(a.FullName), strings.ToLower(b.FullName))
		if req.SortOrder == -1 {
			return -cmp
		}
		return cmp
	})

	totalRecords := len(items)

	// Pagination
	limit := req.Limit
	if limit <= 0 {
		limit = constant.DefaultLimit
	}
	page := req.Page
	if page <= 0 {
		page = constant.DefaultPage
	}
	offset := (page - 1) * limit
	if offset > totalRecords {
		offset = totalRecords
	}
	end := offset + limit
	if end > totalRecords {
		end = totalRecords
	}

	pagedItems := items[offset:end]
	if pagedItems == nil {
		pagedItems = []dto.GroupUserItem{}
	}

	return &coreDto.PaginationResult[dto.GroupUserItem]{
		Data:         pagedItems,
		TotalRecords: totalRecords,
	}, nil
}

func (f *FakeGroupUserRepository) GetGroupUserOptions(
	_ context.Context,
	_ coreService.PostgreSQLServicer,
	product string,
	groupID int64,
	req dto.GroupUserOptionsRequest,
) (*dto.GroupUserOptionsResponse, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	type popData struct {
		isGM bool
		isTC bool
		isRO bool
	}
	population := make(map[int64]*popData)

	getPop := func(uid int64) *popData {
		if p, ok := population[uid]; ok {
			return p
		}
		p := &popData{}
		population[uid] = p
		return p
	}

	// 1. Group Role holders
	for _, usr := range f.UserSystemRoles {
		if usr.Product == product && usr.ScopeLevel == "group" {
			var matchGroup bool
			if product == constant.ProductFixedAsset {
				matchGroup = usr.FixedAssetGroupID != nil && *usr.FixedAssetGroupID == groupID
			} else {
				matchGroup = usr.AdminConsoleGroupID != nil && *usr.AdminConsoleGroupID == groupID
			}
			if matchGroup {
				getPop(usr.UserID)
			}
		}
	}

	// 2. Group Managers
	for _, ugm := range f.UserGroupManagers {
		if ugm.Product == product {
			var matchGroup bool
			if product == constant.ProductFixedAsset {
				matchGroup = ugm.FixedAssetGroupID != nil && *ugm.FixedAssetGroupID == groupID
			} else {
				matchGroup = ugm.AdminConsoleGroupID != nil && *ugm.AdminConsoleGroupID == groupID
			}
			if matchGroup {
				getPop(ugm.UserID).isGM = true
			}
		}
	}

	// 3. Total Control & Read Only
	for _, ual := range f.UserAccessLevels {
		if ual.Product == product {
			if ual.AccessLevel == "total_control" {
				getPop(ual.UserID).isTC = true
			} else if ual.AccessLevel == "read_only" {
				getPop(ual.UserID).isRO = true
			}
		}
	}

	res := &dto.GroupUserOptionsResponse{}

	// Filter valid users in population
	var validUsers []FakeUser
	var hasTC, hasRO, hasGM bool
	for uid, pop := range population {
		u, exists := f.Users[uid]
		if !exists || u.DeletedAt != nil {
			continue
		}
		validUsers = append(validUsers, u)
		if pop.isTC {
			hasTC = true
		}
		if pop.isRO {
			hasRO = true
		}
		if pop.isGM {
			hasGM = true
		}
	}

	if req.PositionOptions {
		posMap := make(map[string]struct{})
		for _, u := range validUsers {
			if u.PositionID != nil {
				if posName, ok := f.Positions[*u.PositionID]; ok && strings.TrimSpace(posName) != "" {
					posMap[posName] = struct{}{}
				}
			}
		}
		var posList []string
		for p := range posMap {
			posList = append(posList, p)
		}
		slices.Sort(posList)
		res.PositionOptions = make([]dto.OptionItem, 0, len(posList))
		for _, p := range posList {
			res.PositionOptions = append(res.PositionOptions, dto.OptionItem{Label: p, Value: p})
		}
	}

	if req.DivisionOptions {
		type divEntry struct {
			id   int64
			name string
		}
		divMap := make(map[int64]string)
		for _, u := range validUsers {
			if u.DivisionID != nil {
				if divName, ok := f.Divisions[*u.DivisionID]; ok && strings.TrimSpace(divName) != "" {
					divMap[*u.DivisionID] = divName
				}
			}
		}
		var divList []divEntry
		for id, name := range divMap {
			divList = append(divList, divEntry{id: id, name: name})
		}
		slices.SortFunc(divList, func(a, b divEntry) int {
			return strings.Compare(a.name, b.name)
		})
		res.DivisionOptions = make([]dto.OptionItem, 0, len(divList))
		for _, d := range divList {
			res.DivisionOptions = append(res.DivisionOptions, dto.OptionItem{
				Label: d.name,
				Value: fmt.Sprintf("%d", d.id),
			})
		}
	}

	if req.GroupRoleOptions {
		res.GroupRoleOptions = make([]dto.OptionItem, 0)
		if hasTC {
			res.GroupRoleOptions = append(res.GroupRoleOptions, dto.OptionItem{Label: "Total Control", Value: "total_control"})
		}
		if hasRO {
			res.GroupRoleOptions = append(res.GroupRoleOptions, dto.OptionItem{Label: "Read Only", Value: "read_only"})
		}
		if hasGM {
			res.GroupRoleOptions = append(res.GroupRoleOptions, dto.OptionItem{Label: "Group Manager", Value: "group_manager"})
		}
		seenLiteral := make(map[string]bool)
		for _, usr := range f.UserSystemRoles {
			if usr.Product == product && usr.ScopeLevel == "group" {
				var matchGroup bool
				if product == constant.ProductAdminConsole && usr.AdminConsoleGroupID != nil && *usr.AdminConsoleGroupID == groupID {
					matchGroup = true
				} else if product == constant.ProductFixedAsset && usr.FixedAssetGroupID != nil && *usr.FixedAssetGroupID == groupID {
					matchGroup = true
				}
				if matchGroup && usr.Key != "" {
					roleKey := string(usr.Key)
					if !seenLiteral[roleKey] {
						seenLiteral[roleKey] = true
						label := groupRoleDisplayLabel(roleKey)
						res.GroupRoleOptions = append(res.GroupRoleOptions, dto.OptionItem{
							Label: label,
							Value: roleKey,
						})
					}
				}
			}
		}
	}

	if req.ActivationStatusOptions {
		res.ActivationStatusOptions = []dto.OptionItem{
			{Label: "Activated", Value: "Activated"},
			{Label: "Pending Activation", Value: "Pending Activation"},
		}
	}

	if req.TemporaryStatusOptions {
		res.TemporaryStatusOptions = []dto.OptionItem{
			{Label: "Yes", Value: "Yes"},
			{Label: "No", Value: "No"},
		}
	}

	return res, nil
}

func (f *FakeGroupUserRepository) IsActorTotalControlOrDefault(ctx context.Context, svc coreService.PostgreSQLServicer, actorID int64) (bool, error) {
	for _, ual := range f.UserAccessLevels {
		if ual.UserID == actorID && ual.Product == constant.ProductAdminConsole && ual.AccessLevel == "total_control" {
			return true, nil
		}
	}
	if u, ok := f.Users[actorID]; ok && u.IsDefault {
		return true, nil
	}
	return false, nil
}

func (f *FakeGroupUserRepository) AssignCreatorGroupRole(ctx context.Context, svc coreService.PostgreSQLServicer, role model.UserSystemRole) error {
	for i, existing := range f.UserSystemRoles {
		if existing.UserID == role.UserID &&
			string(existing.Product) == string(role.Product) &&
			string(existing.Key) == string(role.Key) &&
			((existing.AdminConsoleGroupID == nil && role.AdminConsoleGroupID == nil) ||
				(existing.AdminConsoleGroupID != nil && role.AdminConsoleGroupID != nil && *existing.AdminConsoleGroupID == *role.AdminConsoleGroupID)) {
			f.UserSystemRoles[i].PermissionView = true
			f.UserSystemRoles[i].PermissionCreate = true
			f.UserSystemRoles[i].PermissionUpdate = true
			f.UserSystemRoles[i].PermissionDelete = true
			f.UserSystemRoles[i].AdminConsoleGroupName = role.AdminConsoleGroupName
			return nil
		}
	}

	f.UserSystemRoles = append(f.UserSystemRoles, FakeUserSystemRole{
		ID:                    role.ID,
		UserID:                role.UserID,
		Product:               string(role.Product),
		ScopeLevel:            string(role.ScopeLevel),
		Key:                   string(role.Key),
		AdminConsoleGroupID:   role.AdminConsoleGroupID,
		AdminConsoleGroupName: role.AdminConsoleGroupName,
	})
	return nil
}

func (f *FakeGroupUserRepository) FindRevokedUsersBySubtree(ctx context.Context, svc coreService.PostgreSQLServicer, product string, subtreeIDs []int64) ([]dto.RevokedUserInfo, error) {
	var revoked []dto.RevokedUserInfo
	type revokedKey struct {
		userID   int64
		roleName string
	}
	seen := make(map[revokedKey]bool)
	for _, usr := range f.UserSystemRoles {
		if usr.Product == product && usr.AdminConsoleGroupID != nil && slices.Contains(subtreeIDs, *usr.AdminConsoleGroupID) {
			roleName := groupRoleDisplayLabel(string(usr.Key))
			k := revokedKey{userID: usr.UserID, roleName: roleName}
			if !seen[k] {
				seen[k] = true
				fullName := ""
				if u, ok := f.Users[usr.UserID]; ok {
					fullName = u.FullName
				}
				revoked = append(revoked, dto.RevokedUserInfo{
					UserID:       usr.UserID,
					UserFullName: fullName,
					RoleName:     roleName,
				})
			}
		}
	}
	return revoked, nil
}

func (f *FakeGroupUserRepository) RevokeSubtreeGroupRoles(ctx context.Context, svc coreService.PostgreSQLServicer, product string, subtreeIDs []int64) error {
	var keptRoles []FakeUserSystemRole
	for _, usr := range f.UserSystemRoles {
		if usr.Product == product && usr.AdminConsoleGroupID != nil && slices.Contains(subtreeIDs, *usr.AdminConsoleGroupID) {
			continue
		}
		keptRoles = append(keptRoles, usr)
	}
	f.UserSystemRoles = keptRoles

	var keptManagers []FakeUserGroupManager
	for _, ugm := range f.UserGroupManagers {
		if ugm.AdminConsoleGroupID != nil && slices.Contains(subtreeIDs, *ugm.AdminConsoleGroupID) {
			continue
		}
		keptManagers = append(keptManagers, ugm)
	}
	f.UserGroupManagers = keptManagers

	return nil
}

func groupRoleDisplayLabel(key string) string {
	switch key {
	case "manage_distributor":
		return "Manage distributor"
	case "manage_partner":
		return "Manage partner"
	case "manage_group":
		return "Manage group"
	case "manage_user_and_role":
		return "Manage user and role"
	case "manage_active_client":
		return "Manage active client"
	case "manage_archived_client":
		return "Manage archived client"
	case "manage_allocation":
		return "Manage allocation"
	case "manage_wallet_and_pricing":
		return "Manage wallet & pricing"
	default:
		return key
	}
}
