package repository

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/query_builder"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// GroupUserRepository defines database operations for the group user domain.
type GroupUserRepository interface {
	PaginatedListGroupUsers(
		ctx context.Context,
		svc coreService.PostgreSQLServicer,
		product string,
		groupID int64,
		req dto.ListGroupUsersRequest,
	) (*coreDto.PaginationResult[dto.GroupUserItem], error)

	GetGroupUserOptions(
		ctx context.Context,
		svc coreService.PostgreSQLServicer,
		product string,
		groupID int64,
		req dto.GroupUserOptionsRequest,
	) (*dto.GroupUserOptionsResponse, error)

	IsActorTotalControlOrDefault(ctx context.Context, svc coreService.PostgreSQLServicer, actorID int64) (bool, error)
	AssignCreatorGroupRole(ctx context.Context, svc coreService.PostgreSQLServicer, role model.UserSystemRole) error
	FindRevokedUsersBySubtree(ctx context.Context, svc coreService.PostgreSQLServicer, product string, subtreeIDs []int64) ([]dto.RevokedUserInfo, error)
	RevokeSubtreeGroupRoles(ctx context.Context, svc coreService.PostgreSQLServicer, product string, subtreeIDs []int64) error
}

var _ GroupUserRepository = (*groupUserRepository)(nil)

type groupUserRepository struct{}

// NewGroupUserRepository creates a new PostgreSQL-backed GroupUserRepository.
func NewGroupUserRepository() GroupUserRepository {
	return &groupUserRepository{}
}

func (r *groupUserRepository) PaginatedListGroupUsers(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	product string,
	groupID int64,
	req dto.ListGroupUsersRequest,
) (*coreDto.PaginationResult[dto.GroupUserItem], error) {
	query, args := query_builder.BuildListGroupUsersQuery(product, groupID, req)

	results := []coreDto.PaginationResult[dto.GroupUserItem]{}
	if err := svc.SelectMany(&results, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "groupUser.PaginatedListGroupUsers select failed", "err", err)
		return nil, fmt.Errorf("groupUser.PaginatedListGroupUsers: %w", err)
	}

	paged := coreHelper.FormatPaginationResult(results)
	return &paged, nil
}

func (r *groupUserRepository) GetGroupUserOptions(
	ctx context.Context,
	svc coreService.PostgreSQLServicer,
	product string,
	groupID int64,
	req dto.GroupUserOptionsRequest,
) (*dto.GroupUserOptionsResponse, error) {
	query, args := query_builder.BuildGroupUserOptionsQuery(product, groupID, req)

	var results []dto.GroupUserOptionsResponse
	if err := svc.SelectMany(&results, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "groupUser.GetGroupUserOptions select failed", "err", err)
		return nil, fmt.Errorf("groupUser.GetGroupUserOptions: %w", err)
	}

	if len(results) > 0 {
		return &results[0], nil
	}

	return &dto.GroupUserOptionsResponse{}, nil
}

func (r *groupUserRepository) IsActorTotalControlOrDefault(ctx context.Context, svc coreService.PostgreSQLServicer, actorID int64) (bool, error) {
	query := `SELECT (
		EXISTS (SELECT 1 FROM user_access_levels WHERE user_id = $1 AND product = 'admin_console' AND access_level = 'total_control')
		OR EXISTS (SELECT 1 FROM users WHERE id = $1 AND is_default = TRUE)
	) AS is_tc_or_default;`
	var isTCOrDefault bool
	if err := svc.SelectOne(&isTCOrDefault, ctx, query, actorID); err != nil {
		slog.ErrorContext(ctx, "groupUser.IsActorTotalControlOrDefault select failed", "err", err)
		return false, fmt.Errorf("groupUser.IsActorTotalControlOrDefault: %w", err)
	}
	return isTCOrDefault, nil
}

func (r *groupUserRepository) AssignCreatorGroupRole(ctx context.Context, svc coreService.PostgreSQLServicer, role model.UserSystemRole) error {
	query := `INSERT INTO user_system_roles (
		id, user_id, product, scope_level, key,
		permission_view, permission_create, permission_update, permission_delete,
		admin_console_group_id, admin_console_group_name,
		modified_by, created_at, updated_at
	) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW(), NOW())
	ON CONFLICT (user_id, product, key, fixed_asset_group_id, admin_console_group_id) DO UPDATE SET
		permission_view = TRUE,
		permission_create = TRUE,
		permission_update = TRUE,
		permission_delete = TRUE,
		admin_console_group_name = EXCLUDED.admin_console_group_name,
		updated_at = NOW();`

	if _, err := svc.InsertOne(ctx, query,
		role.ID, role.UserID, role.Product, role.ScopeLevel, role.Key,
		role.PermissionView, role.PermissionCreate, role.PermissionUpdate, role.PermissionDelete,
		role.AdminConsoleGroupID, role.AdminConsoleGroupName,
		role.ModifiedBy,
	); err != nil {
		slog.ErrorContext(ctx, "groupUser.AssignCreatorGroupRole insert failed", "err", err)
		return fmt.Errorf("groupUser.AssignCreatorGroupRole: %w", err)
	}
	return nil
}

func (r *groupUserRepository) FindRevokedUsersBySubtree(ctx context.Context, svc coreService.PostgreSQLServicer, product string, subtreeIDs []int64) ([]dto.RevokedUserInfo, error) {
	query := `SELECT DISTINCT usr.user_id AS "userId", COALESCE(u.full_name, '') AS "userFullName",
		CASE usr.key
			WHEN 'manage_distributor' THEN 'Manage distributor'
			WHEN 'manage_partner' THEN 'Manage partner'
			WHEN 'manage_group' THEN 'Manage group'
			WHEN 'manage_user_and_role' THEN 'Manage user and role'
			WHEN 'manage_active_client' THEN 'Manage active client'
			WHEN 'manage_archived_client' THEN 'Manage archived client'
			WHEN 'manage_allocation' THEN 'Manage allocation'
			WHEN 'manage_wallet_and_pricing' THEN 'Manage wallet & pricing'
			ELSE usr.key
		END AS "roleName"
	FROM user_system_roles usr
	LEFT JOIN users u ON u.id = usr.user_id
	WHERE usr.product = $1
	  AND usr.admin_console_group_id = ANY($2);`

	var results []dto.RevokedUserInfo
	if err := svc.SelectMany(&results, ctx, query, product, subtreeIDs); err != nil {
		slog.ErrorContext(ctx, "groupUser.FindRevokedUsersBySubtree select failed", "err", err)
		return nil, fmt.Errorf("groupUser.FindRevokedUsersBySubtree: %w", err)
	}
	return results, nil
}

func (r *groupUserRepository) RevokeSubtreeGroupRoles(ctx context.Context, svc coreService.PostgreSQLServicer, product string, subtreeIDs []int64) error {
	if _, err := svc.DeleteManyWithFilter(ctx, "user_system_roles", sql_query.WhereQuery{
		"product":                {Operator: sql_query.SQLOperatorEqual, Value: product},
		"admin_console_group_id": {Operator: sql_query.SQLOperatorIn, Value: subtreeIDs},
	}); err != nil {
		slog.ErrorContext(ctx, "groupUser.RevokeSubtreeGroupRoles delete user_system_roles failed", "err", err)
		return fmt.Errorf("groupUser.RevokeSubtreeGroupRoles user_system_roles: %w", err)
	}

	if _, err := svc.DeleteManyWithFilter(ctx, "user_group_managers", sql_query.WhereQuery{
		"admin_console_group_id": {Operator: sql_query.SQLOperatorIn, Value: subtreeIDs},
	}); err != nil {
		slog.ErrorContext(ctx, "groupUser.RevokeSubtreeGroupRoles delete user_group_managers failed", "err", err)
		return fmt.Errorf("groupUser.RevokeSubtreeGroupRoles user_group_managers: %w", err)
	}

	return nil
}
