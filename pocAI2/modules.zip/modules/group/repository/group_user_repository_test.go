package repository

import (
	"context"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/group/dto"
)

func TestFakeGroupUserRepository_PaginatedList(t *testing.T) {
	repo := NewFakeGroupUserRepository()
	ctx := context.Background()

	// Seed positions & divisions
	posDev := int64(10)
	repo.Positions[posDev] = "Developer"
	divIT := int64(20)
	repo.Divisions[divIT] = "IT"

	// Seed users
	// User 1: Has 2 roles in group 100
	repo.Users[1] = FakeUser{
		ID: 1, FullName: "Alice Baker", Email: "alice@test.local",
		PositionID: &posDev, DivisionID: &divIT, ActivationStatus: "Activated",
	}
	repo.UserSystemRoles = append(repo.UserSystemRoles,
		FakeUserSystemRole{UserID: 1, Product: constant.ProductAdminConsole, ScopeLevel: "group", AdminConsoleGroupID: ptr(int64(100))},
		FakeUserSystemRole{UserID: 1, Product: constant.ProductAdminConsole, ScopeLevel: "group", AdminConsoleGroupID: ptr(int64(100))},
	)

	// User 2: Group Manager in group 100 + 1 role
	repo.Users[2] = FakeUser{
		ID: 2, FullName: "Bob Charlie", Email: "bob@test.local",
		ActivationStatus: "Activated",
	}
	repo.UserGroupManagers = append(repo.UserGroupManagers,
		FakeUserGroupManager{UserID: 2, Product: constant.ProductAdminConsole, AdminConsoleGroupID: ptr(int64(100))},
	)
	repo.UserSystemRoles = append(repo.UserSystemRoles,
		FakeUserSystemRole{UserID: 2, Product: constant.ProductAdminConsole, ScopeLevel: "group", AdminConsoleGroupID: ptr(int64(100))},
	)

	// User 3: Total Control entity-wide
	repo.Users[3] = FakeUser{
		ID: 3, FullName: "Charlie Delta", Email: "charlie@test.local",
		ActivationStatus: "Activated",
	}
	repo.UserAccessLevels = append(repo.UserAccessLevels,
		FakeUserAccessLevel{UserID: 3, Product: constant.ProductAdminConsole, AccessLevel: "total_control"},
	)

	// User 4: In group 200 (not 100)
	repo.Users[4] = FakeUser{
		ID: 4, FullName: "David Echo", Email: "david@test.local",
		ActivationStatus: "Activated",
	}
	repo.UserSystemRoles = append(repo.UserSystemRoles,
		FakeUserSystemRole{UserID: 4, Product: constant.ProductAdminConsole, ScopeLevel: "group", AdminConsoleGroupID: ptr(int64(200))},
	)

	// Query group 100
	req := dto.ListGroupUsersRequest{}
	req.Defaults()

	res, err := repo.PaginatedListGroupUsers(ctx, nil, constant.ProductAdminConsole, 100, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if res.TotalRecords != 3 {
		t.Fatalf("expected 3 total records, got %d", res.TotalRecords)
	}

	roleMap := make(map[string]string)
	for _, item := range res.Data {
		roleMap[item.FullName] = item.GroupRole
	}

	if roleMap["Alice Baker"] != "2 roles" {
		t.Errorf("expected Alice to have '2 roles', got %s", roleMap["Alice Baker"])
	}
	if roleMap["Bob Charlie"] != "Group Manager" {
		t.Errorf("expected Bob to have 'Group Manager', got %s", roleMap["Bob Charlie"])
	}
	if roleMap["Charlie Delta"] != "Total Control" {
		t.Errorf("expected Charlie to have 'Total Control', got %s", roleMap["Charlie Delta"])
	}
}

func TestFakeGroupUserRepository_GetGroupUserOptions(t *testing.T) {
	repo := NewFakeGroupUserRepository()
	ctx := context.Background()

	posDev := int64(10)
	repo.Positions[posDev] = "Developer"
	divIT := int64(20)
	repo.Divisions[divIT] = "IT"

	repo.Users[1] = FakeUser{
		ID: 1, FullName: "Alice Baker", Email: "alice@test.local",
		PositionID: &posDev, DivisionID: &divIT, ActivationStatus: "Activated",
	}
	repo.UserSystemRoles = append(repo.UserSystemRoles,
		FakeUserSystemRole{UserID: 1, Product: constant.ProductAdminConsole, ScopeLevel: "group", AdminConsoleGroupID: ptr(int64(100))},
	)

	repo.Users[2] = FakeUser{
		ID: 2, FullName: "Bob Charlie", Email: "bob@test.local",
		ActivationStatus: "Activated",
	}
	repo.UserGroupManagers = append(repo.UserGroupManagers,
		FakeUserGroupManager{UserID: 2, Product: constant.ProductAdminConsole, AdminConsoleGroupID: ptr(int64(100))},
	)

	repo.Users[3] = FakeUser{
		ID: 3, FullName: "Charlie Delta", Email: "charlie@test.local",
		ActivationStatus: "Activated",
	}
	repo.UserAccessLevels = append(repo.UserAccessLevels,
		FakeUserAccessLevel{UserID: 3, Product: constant.ProductAdminConsole, AccessLevel: "total_control"},
	)

	req := dto.GroupUserOptionsRequest{
		PositionOptions:         true,
		DivisionOptions:         true,
		GroupRoleOptions:        true,
		ActivationStatusOptions: true,
		TemporaryStatusOptions:  true,
	}

	opts, err := repo.GetGroupUserOptions(ctx, nil, constant.ProductAdminConsole, 100, req)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if len(opts.PositionOptions) != 1 || opts.PositionOptions[0].Value != "Developer" {
		t.Errorf("unexpected position options: %+v", opts.PositionOptions)
	}
	if len(opts.DivisionOptions) != 1 || opts.DivisionOptions[0].Label != "IT" || opts.DivisionOptions[0].Value != "20" {
		t.Errorf("unexpected division options: %+v", opts.DivisionOptions)
	}
	if len(opts.GroupRoleOptions) != 2 { // Total Control & Group Manager
		t.Errorf("expected 2 group role options, got %d: %+v", len(opts.GroupRoleOptions), opts.GroupRoleOptions)
	}
	if len(opts.ActivationStatusOptions) != 2 {
		t.Errorf("expected 2 activation status options, got %d", len(opts.ActivationStatusOptions))
	}
	if len(opts.TemporaryStatusOptions) != 2 {
		t.Errorf("expected 2 temporary status options, got %d", len(opts.TemporaryStatusOptions))
	}
}

func ptr[T any](v T) *T { return &v }
