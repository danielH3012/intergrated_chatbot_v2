package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type InsertPositionActivityParam struct {
	ClientID string
	Name     string
	UserID   string
}

type InsertPositionActivityResult struct {
	ID   int64
	Name string
}

type CreatePositionWorkflowParam struct {
	ClientID     string
	Name         string
	UserID       string
	UserFullName string
	TaskQueue    string
}

type CreatePositionWorkflowResult struct {
	ID string
}

func CreatePositionWorkflow(ctx workflow.Context, param CreatePositionWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	compensation := coreService.NewWorkflowCompensation()
	defer func() {
		if err != nil {
			disconnectedCtx, cancel := workflow.NewDisconnectedContext(activityCtx)
			defer cancel()
			compensation.Compensate(disconnectedCtx, false)
		}
	}()

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientID,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    param.TaskQueue,
		}

		var inserted InsertPositionActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityInsertPosition,
			InsertPositionActivityParam{
				ClientID: param.ClientID,
				Name:     param.Name,
				UserID:   param.UserID,
			},
		).Get(activityCtx, &inserted); err != nil {
			return nil, err
		}

		compensation.AddCompensation(constant.ActivityDeletePosition, DeletePositionsActivityParam{
			ClientID: param.ClientID,
			IDs:      []int64{inserted.ID},
		})

		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{
			positionChangelog(arModel.ChangeLogActionCreate, inserted.ID, inserted.Name, "Name", dash(), inserted.Name, identity),
		})

		return CreatePositionWorkflowResult{ID: strconv.FormatInt(inserted.ID, 10)}, nil
	})
}
