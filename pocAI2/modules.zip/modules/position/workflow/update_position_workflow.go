package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type UpdatePositionActivityParam struct {
	ClientID string
	ID       int64
	Name     string
	UserID   string
}

type UpdatePositionActivityResult struct {
	OldName string
	NewName string
}

type UpdatePositionWorkflowParam struct {
	ClientID     string
	ID           int64
	Name         string
	UserID       string
	UserFullName string
	TaskQueue    string
}

type UpdatePositionWorkflowResult struct{}

func UpdatePositionWorkflow(ctx workflow.Context, param UpdatePositionWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		var updated UpdatePositionActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityUpdatePosition,
			UpdatePositionActivityParam{
				ClientID: param.ClientID,
				ID:       param.ID,
				Name:     param.Name,
				UserID:   param.UserID,
			},
		).Get(activityCtx, &updated); err != nil {
			return nil, err
		}

		identity := changelogIdentity{
			ClientID:     param.ClientID,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    param.TaskQueue,
		}

		var logs []arModel.Changelog
		if updated.OldName != updated.NewName {
			logs = append(logs, positionChangelog(arModel.ChangeLogActionEdit, param.ID, updated.NewName, "Name", updated.OldName, updated.NewName, identity))
		}
		spawnChangeLogWorkflow(ctx, identity, logs)

		return UpdatePositionWorkflowResult{}, nil
	})
}
