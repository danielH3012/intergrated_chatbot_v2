package workflow

import (
	"strconv"

	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	arDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

// changelogIdentity is the subset of a workflow param the changelog child needs:
// which tenant the logs belong to and who made the change.
type changelogIdentity struct {
	ClientID     string
	UserID       string
	UserFullName string
	TaskQueue    string
}

// positionChangelog builds one changelog row for a position field.
//
// OldValue/NewValue are literal "-" on the absent side, never null: the FE renders
// the "-" as "no previous value". ObjectName is always the position name.
// The tenant is always a client here — this service only writes tenant-scoped
// masters — and Product marks the row as written by Global Settings.
func positionChangelog(
	action arModel.ChangeLogAction,
	objectID int64,
	objectName, field, oldValue, newValue string,
	identity changelogIdentity,
) arModel.Changelog {
	objectIDStr := strconv.FormatInt(objectID, 10)
	product := arModel.ProductGlobalSettings
	return arModel.Changelog{
		Action:            action,
		Field:             &field,
		OldValue:          &oldValue,
		NewValue:          &newValue,
		LogTable:          "Position",
		CreatedById:       identity.UserID,
		CreatedBySnapshot: identity.UserFullName,
		EntityID:          identity.ClientID,
		EntityType:        arModel.EntityTypeClient,
		Product:           &product,
		Object:            "Position",
		ObjectId:          &objectIDStr,
		ObjectName:        &objectName,
	}
}

// spawnChangeLogWorkflow hands the rows to the analytics-reporting
// RecordChangeLogsWorkflow child without waiting for it. The child is spawned with
// ABANDON parent-close policy and runs on the AR task queue, where its own
// unbounded retry delivers the rows at-least-once even across an AR outage.
// Failing to spawn logs and returns — the DB write must not roll back because
// the changelog sink is down.
func spawnChangeLogWorkflow(ctx workflow.Context, identity changelogIdentity, logs []arModel.Changelog) {
	if len(logs) == 0 {
		return
	}
	opts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, "", identity.TaskQueue)
	childCtx := workflow.WithChildOptions(ctx, opts)
	future := workflow.ExecuteChildWorkflow(
		childCtx,
		tsConstant.AnalyticsReportingRecordChangeLogsWorkflow,
		arDto.CreateChangeLogActivityParam{
			ClientID:   identity.ClientID,
			ChangeLogs: logs,
		},
	)
	var childExecution workflow.Execution
	if err := future.GetChildWorkflowExecution().Get(ctx, &childExecution); err != nil {
		workflow.GetLogger(ctx).Error("failed to spawn changelog child workflow", "error", err)
	}
}

// dash is the literal placeholder for a value that did not exist before (create)
// or no longer exists (delete).
func dash() string { return "-" }
