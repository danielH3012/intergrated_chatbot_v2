package workflow

import (
	"context"
	"testing"

	"github.com/stretchr/testify/suite"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/testsuite"
	"go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	arDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
)

type PositionWorkflowTestSuite struct {
	suite.Suite
	testsuite.WorkflowTestSuite
}

func TestPositionWorkflowTestSuite(t *testing.T) {
	suite.Run(t, new(PositionWorkflowTestSuite))
}

// testEnv wires one workflow under test with stubbed activities and a capturing
// RecordChangeLogsWorkflow child.
type testEnv struct {
	suite   *PositionWorkflowTestSuite
	env     *testsuite.TestWorkflowEnvironment
	payload []arDto.CreateChangeLogActivityParam
}

func (s *PositionWorkflowTestSuite) newEnv() *testEnv {
	e := &testEnv{suite: s}
	e.env = s.NewTestWorkflowEnvironment()

	e.env.RegisterWorkflowWithOptions(
		func(ctx workflow.Context, payload arDto.CreateChangeLogActivityParam) error {
			e.payload = append(e.payload, payload)
			return nil
		},
		workflow.RegisterOptions{Name: tsConstant.AnalyticsReportingRecordChangeLogsWorkflow},
	)
	return e
}

func (e *testEnv) stubActivity(name string, fn any) {
	e.env.RegisterActivityWithOptions(fn, activity.RegisterOptions{Name: name})
}

func (e *testEnv) run(wf any, param any) {
	e.env.ExecuteWorkflow(wf, param)
	e.suite.True(e.env.IsWorkflowCompleted())
	e.suite.NoError(e.env.GetWorkflowError())
}

const testTaskQueue = "iam-service"

func (s *PositionWorkflowTestSuite) Test_CreatePositionWorkflow_EmitsOneChangelogRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityInsertPosition, func(
		ctx context.Context, param InsertPositionActivityParam,
	) (InsertPositionActivityResult, error) {
		return InsertPositionActivityResult{ID: 177013, Name: "Manager"}, nil
	})
	e.env.RegisterWorkflow(CreatePositionWorkflow)

	e.run(CreatePositionWorkflow, CreatePositionWorkflowParam{
		ClientID:     "acme",
		Name:         "Manager",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	var result CreatePositionWorkflowResult
	s.NoError(e.env.GetWorkflowResult(&result))
	s.Equal("177013", result.ID)

	s.Len(e.payload, 1, "create emits one child workflow")
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 1, "create emits one changelog row (Name only)")
	s.Equal("acme", e.payload[0].ClientID)
	for _, log := range logs {
		s.Equal("Position", log.LogTable)
		s.Equal(arModel.ChangeLogActionCreate, log.Action)
		s.Equal("177013", *log.ObjectId)
		s.Equal("Manager", *log.ObjectName)
		s.Equal("acme", log.EntityID)
		s.Equal(arModel.EntityTypeClient, log.EntityType)
		s.Equal(arModel.ProductGlobalSettings, *log.Product)
		s.Equal("Position", log.Object)
		s.Equal("42", log.CreatedById)
		s.Equal("Budi", log.CreatedBySnapshot)
	}
	s.Equal("Name", *logs[0].Field)
	s.Equal("-", *logs[0].OldValue)
	s.Equal("Manager", *logs[0].NewValue)
}

func (s *PositionWorkflowTestSuite) Test_UpdatePositionWorkflow_ChangedNameEmitsOneRow() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityUpdatePosition, func(
		ctx context.Context, param UpdatePositionActivityParam,
	) (UpdatePositionActivityResult, error) {
		return UpdatePositionActivityResult{
			OldName: "Manager",
			NewName: "Senior Manager",
		}, nil
	})
	e.env.RegisterWorkflow(UpdatePositionWorkflow)

	e.run(UpdatePositionWorkflow, UpdatePositionWorkflowParam{
		ClientID:     "acme",
		ID:           177013,
		Name:         "Senior Manager",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 1)
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 1, "one changed field emits one row")
	s.Equal(arModel.ChangeLogActionEdit, logs[0].Action)
	s.Equal("Name", *logs[0].Field)
	s.Equal("Manager", *logs[0].OldValue)
	s.Equal("Senior Manager", *logs[0].NewValue)
	s.Equal("177013", *logs[0].ObjectId)
}

func (s *PositionWorkflowTestSuite) Test_UpdatePositionWorkflow_NoOpEmitsZeroRows() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityUpdatePosition, func(
		ctx context.Context, param UpdatePositionActivityParam,
	) (UpdatePositionActivityResult, error) {
		return UpdatePositionActivityResult{
			OldName: "Manager",
			NewName: "Manager",
		}, nil
	})
	e.env.RegisterWorkflow(UpdatePositionWorkflow)

	e.run(UpdatePositionWorkflow, UpdatePositionWorkflowParam{
		ClientID:     "acme",
		ID:           177013,
		Name:         "Manager",
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 0, "no-op edit spawns no changelog child")
}

func (s *PositionWorkflowTestSuite) Test_DeletePositionWorkflow_EmitsOneBatchedChild() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityDeletePosition, func(
		ctx context.Context, param DeletePositionsActivityParam,
	) (DeletePositionsActivityResult, error) {
		inUse := "in_use"
		return DeletePositionsActivityResult{
			Results: []dto.DeletePositionResult{
				{ID: "1", Status: "deleted"},
				{ID: "2", Status: "deleted"},
				{ID: "3", Status: "blocked"},
				{ID: "4", Status: "blocked", Reason: &inUse},
			},
			Deleted: []DeletedPosition{
				{ID: 1, Name: "Manager"},
				{ID: 2, Name: "Supervisor"},
			},
		}, nil
	})
	e.env.RegisterWorkflow(DeletePositionWorkflow)

	e.run(DeletePositionWorkflow, DeletePositionWorkflowParam{
		ClientID:     "acme",
		IDs:          []int64{1, 2, 3, 4},
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 1, "bulk delete emits ONE batched child")
	logs := e.payload[0].ChangeLogs
	s.Len(logs, 2, "2 deleted ids × 1 field (Name)")
	for _, log := range logs {
		s.Equal(arModel.ChangeLogActionDelete, log.Action)
		s.Equal("Position", log.LogTable)
		s.Equal("Position", log.Object)
	}
	s.Equal("1", *logs[0].ObjectId)
	s.Equal("Manager", *logs[0].ObjectName)
	s.Equal("Name", *logs[0].Field)
	s.Equal("Manager", *logs[0].OldValue)
	s.Equal("-", *logs[0].NewValue)
	s.Equal("2", *logs[1].ObjectId)
	s.Equal("Supervisor", *logs[1].OldValue)
}

func (s *PositionWorkflowTestSuite) Test_DeletePositionWorkflow_AllBlockedEmitsNoChild() {
	e := s.newEnv()
	e.stubActivity(constant.ActivityDeletePosition, func(
		ctx context.Context, param DeletePositionsActivityParam,
	) (DeletePositionsActivityResult, error) {
		inUse := "in_use"
		return DeletePositionsActivityResult{
			Results: []dto.DeletePositionResult{
				{ID: "1", Status: "blocked", Reason: &inUse},
			},
			Deleted: nil,
		}, nil
	})
	e.env.RegisterWorkflow(DeletePositionWorkflow)

	e.run(DeletePositionWorkflow, DeletePositionWorkflowParam{
		ClientID:     "acme",
		IDs:          []int64{1},
		UserID:       "42",
		UserFullName: "Budi",
		TaskQueue:    testTaskQueue,
	})

	s.Len(e.payload, 0, "blocked deletes spawn no changelog child")
}
