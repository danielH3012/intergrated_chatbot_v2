package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type DeletePositionsActivityParam struct {
	ClientID string
	IDs      []int64
}

type DeletePositionsActivityResult struct {
	Results []dto.DeletePositionResult
	Deleted []DeletedPosition
}

type DeletePositionWorkflowParam struct {
	ClientID     string
	IDs          []int64
	UserID       string
	UserFullName string
	TaskQueue    string
}

type DeletePositionWorkflowResult struct {
	Results []dto.DeletePositionResult
}

type DeletedPosition struct {
	ID   int64
	Name string
}

func DeletePositionWorkflow(ctx workflow.Context, param DeletePositionWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		var deleted DeletePositionsActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityDeletePosition,
			DeletePositionsActivityParam{
				ClientID: param.ClientID,
				IDs:      param.IDs,
			},
		).Get(activityCtx, &deleted); err != nil {
			return nil, err
		}

		identity := changelogIdentity{
			ClientID:     param.ClientID,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    param.TaskQueue,
		}

		var logs []arModel.Changelog
		for _, d := range deleted.Deleted {
			logs = append(logs,
				positionChangelog(arModel.ChangeLogActionDelete, d.ID, d.Name, "Name", d.Name, dash(), identity),
			)
		}
		spawnChangeLogWorkflow(ctx, identity, logs)

		return DeletePositionWorkflowResult{Results: deleted.Results}, nil
	})
}
