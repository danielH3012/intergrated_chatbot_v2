package query_builder

import (
	"strings"
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
)

func TestBuildListQuery_Search_EmitsILike(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.Search = "kilo"

	query, args, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, "positions.name ILIKE") {
		t.Errorf("expected ILIKE over name, got query:\n%s", query)
	}
	if len(args) != 1 || args[0] != "%kilo%" {
		t.Errorf("expected one %%%%kilo%%%% arg, got %v", args)
	}
}

func TestBuildListQuery_Search_UnknownColumnDropped(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.Search = "kilo"
	q.Columns = []string{"updatedAt", "unknown"}

	query, _, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if strings.Contains(query, "positions.updated_at ILIKE") {
		t.Errorf("search must never span dates, got query:\n%s", query)
	}
	if !strings.Contains(query, "positions.name ILIKE") {
		t.Errorf("expected fallback to the searchable set, got query:\n%s", query)
	}
}

func TestBuildListQuery_UserCountSubqueryProjected(t *testing.T) {
	q := dto.ListPositionsRequest{}

	query, _, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, `WHERE u.position_id = positions.id`) || !strings.Contains(query, `AS "userCount"`) {
		t.Errorf("expected userCount COUNT subquery, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_AllowlistApplied(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.SortBy = "name"
	q.SortOrder = 1

	query, _, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, "ORDER BY positions.name ASC") {
		t.Errorf("expected allowlisted name sort, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_UnknownSortByFallsBackToName(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.SortBy = "id"
	q.SortOrder = 1

	query, _, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, "lower(trim(positions.name)) ASC") {
		t.Errorf("expected name-sort fallback, got query:\n%s", query)
	}
	if strings.Contains(query, `"id"`) {
		t.Errorf("request key must never be interpolated, got query:\n%s", query)
	}
}

func TestBuildListQuery_Sort_Descending(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.SortBy = "updatedAt"
	q.SortOrder = -1

	query, _, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, "positions.updated_at DESC") || !strings.Contains(query, "CASE WHEN positions.updated_at IS NULL THEN 1 ELSE 0 END") {
		t.Errorf("expected descending updated_at sort with nulls last, got query:\n%s", query)
	}
}

func TestBuildListQuery_UpdatedAt_Between(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.UpdatedAt = []int64{1700000000000, 1700003600000}

	query, args, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, `"positions"."updated_at" BETWEEN`) {
		t.Errorf("expected BETWEEN filter on updated_at, got query:\n%s", query)
	}
	if len(args) != 2 {
		t.Fatalf("expected two BETWEEN args, got %v", args)
	}
}

func TestBuildListQuery_UpdatedAt_SingleBoundIsOpenEnded(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.UpdatedAt = []int64{1700000000000}

	query, args, err := GetPositionListQuery(q, true)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if !strings.Contains(query, `"positions"."updated_at" >=`) {
		t.Errorf("expected open-ended >= filter, got query:\n%s", query)
	}
	if len(args) != 1 {
		t.Fatalf("expected one bound arg, got %v", args)
	}
}

func TestBuildListQuery_Unpaginated_HasNoOffset(t *testing.T) {
	q := dto.ListPositionsRequest{}
	q.Search = "kilo"

	query, _, err := GetPositionListQuery(q, false)
	if err != nil {
		t.Fatalf("GetPositionListQuery: %v", err)
	}
	if strings.Contains(query, "OFFSET") {
		t.Errorf("unpaginated export must have no OFFSET, got query:\n%s", query)
	}
	if strings.Contains(query, "LIMIT") {
		t.Errorf("unpaginated export must have no LIMIT, got query:\n%s", query)
	}
}

func TestResolveSortColumn(t *testing.T) {
	if got := resolveSortColumn("name"); got != "positions.name" {
		t.Errorf("resolveSortColumn(name) = %q", got)
	}
	if got := resolveSortColumn("updatedAt"); got != "positions.updated_at" {
		t.Errorf("resolveSortColumn(updatedAt) = %q", got)
	}
	if got := resolveSortColumn("notAKey"); got != DefaultNameSort {
		t.Errorf("resolveSortColumn(unknown) = %q, want default", got)
	}
}
