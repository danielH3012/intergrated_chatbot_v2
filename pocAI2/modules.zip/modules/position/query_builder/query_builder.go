package query_builder

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

var listColumns = map[string]string{
	"name":      "positions.name",
	"updatedAt": "positions.updated_at",
}

var searchableColumns = map[string]string{
	"name": "positions.name",
}

const DefaultNameSort = "lower(trim(positions.name))"

func GetPositionListQuery(q dto.ListPositionsRequest, paginate bool) (string, []any, error) {
	builder := sql_query.NewSQLSelectBuilder[dto.PositionItem]("positions", "positions")

	builder.Select(`(
		SELECT COUNT(*) FROM users u
		WHERE u.position_id = positions.id AND u.deleted_at IS NULL
	) AS "userCount"`)

	if q.Search != "" {
		builder.Search(q.Search, resolveSearchColumns(q.Columns))
	}

	switch len(q.UpdatedAt) {
	case 1:
		builder.Where(sql_query.WhereQuery{
			"positions.updated_at": {
				Operator: sql_query.SQLOperatorGTE,
				Value:    time.UnixMilli(q.UpdatedAt[0]),
			},
		})
	case 2:
		builder.Where(sql_query.WhereQuery{
			"positions.updated_at": {
				Operator: sql_query.SQLOperatorBetween,
				Value:    []time.Time{time.UnixMilli(q.UpdatedAt[0]), time.UnixMilli(q.UpdatedAt[1])},
			},
		})
	}

	if paginate {
		sortOrder := q.SortOrder
		if sortOrder == 0 {
			sortOrder = 1
		}
		pagination := sql_query.Pagination{
			Page:  q.Page,
			Limit: q.Limit,
		}
		if q.SortBy == "updatedAt" {
			pagination.MultiSort = []sql_query.Sort{
				{SortBy: "(CASE WHEN positions.updated_at IS NULL THEN 1 ELSE 0 END)", SortOrder: 1},
				{SortBy: "positions.updated_at", SortOrder: sortOrder},
			}
		} else {
			pagination.SortBy = resolveSortColumn(q.SortBy)
			pagination.SortOrder = sortOrder
		}
		builder.Paginate(pagination)
	}

	return builder.Build()
}

func resolveSearchColumns(columns []string) []string {
	if len(columns) == 0 {
		return []string{"positions.name"}
	}

	out := make([]string, 0, len(columns))
	for _, c := range columns {
		if expr, ok := searchableColumns[c]; ok {
			out = append(out, expr)
		}
	}
	if len(out) == 0 {
		return []string{"positions.name"}
	}
	return out
}

func resolveSortColumn(sortBy string) string {
	if expr, ok := listColumns[sortBy]; ok {
		return expr
	}
	return DefaultNameSort
}
