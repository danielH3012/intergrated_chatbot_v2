package handler_test

import (
	"context"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/service"
	tsEnum "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRepo mirrors the repository interface with func fields; only the read paths
// the handler tests touch are scripted.
type fakeRepo struct {
	listFn                  func(ctx context.Context, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error)
	listAllFn               func(ctx context.Context, q dto.ListPositionsRequest) ([]dto.PositionItem, error)
	existsByNameFn          func(ctx context.Context, name string, excludeID *int64) (bool, error)
	hasActiveRefsFn         func(ctx context.Context, id int64) (bool, error)
	countReferencingUsersFn func(ctx context.Context, id int64) (int64, error)
	dropdownFn              func(ctx context.Context) ([]coreDto.InterfaceOptionDTO, error)
	countFn                 func(ctx context.Context) (int64, error)
	findByIDFn              func(ctx context.Context, id int64) (*model.Position, error)
	insertOneFn             func(ctx context.Context, d model.Position) (int64, error)
	updateOneFn             func(ctx context.Context, id int64, updates sql_query.UpdateQuery) (int64, error)
	deleteByIDFn            func(ctx context.Context, id int64) (int64, error)
	lockForDeleteFn         func(ctx context.Context, id int64) (*model.Position, error)
}

func (f *fakeRepo) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Position) (int64, error) {
	if f.insertOneFn != nil {
		return f.insertOneFn(ctx, d)
	}
	return 0, nil
}
func (f *fakeRepo) FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	if f.findByIDFn != nil {
		return f.findByIDFn(ctx, id)
	}
	return nil, nil
}
func (f *fakeRepo) PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error) {
	return f.listFn(ctx, q)
}
func (f *fakeRepo) List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) ([]dto.PositionItem, error) {
	return f.listAllFn(ctx, q)
}
func (f *fakeRepo) Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error) {
	if f.dropdownFn != nil {
		return f.dropdownFn(ctx)
	}
	return nil, nil
}
func (f *fakeRepo) UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error) {
	if f.updateOneFn != nil {
		return f.updateOneFn(ctx, id, updates)
	}
	return 0, nil
}
func (f *fakeRepo) LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	if f.lockForDeleteFn != nil {
		return f.lockForDeleteFn(ctx, id)
	}
	return nil, nil
}
func (f *fakeRepo) DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	if f.deleteByIDFn != nil {
		return f.deleteByIDFn(ctx, id)
	}
	return 0, nil
}
func (f *fakeRepo) HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error) {
	if f.hasActiveRefsFn != nil {
		return f.hasActiveRefsFn(ctx, id)
	}
	return false, nil
}
func (f *fakeRepo) CountReferencingUsers(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	if f.countReferencingUsersFn != nil {
		return f.countReferencingUsersFn(ctx, id)
	}
	return 0, nil
}
func (f *fakeRepo) ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error) {
	if f.existsByNameFn != nil {
		return f.existsByNameFn(ctx, name, excludeID)
	}
	return false, nil
}
func (f *fakeRepo) Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error) {
	if f.countFn != nil {
		return f.countFn(ctx)
	}
	return 0, nil
}

// newTestApp builds the app the handler tests hit: the real routes, with the RBAC
// snapshot injected directly (no iam, no Valkey) and the DB factory stubbed.
func newTestApp(t *testing.T, repo *fakeRepo) *fiber.App {
	t.Helper()

	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})

	h := handler.NewPositionHandler(svc)

	const key = tsEnum.SystemRoleKeyManageUserAndRole
	read := rbac.Any(rbac.GlobalSettingsSeeAll(), rbac.GlobalSettingsSystemRole(tsMiddleware.PermView, key))
	create := rbac.GlobalSettingsSystemRole(tsMiddleware.PermCreate, key)
	update := rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, key)
	delete := rbac.GlobalSettingsSystemRole(tsMiddleware.PermDelete, key)

	checkAvail := rbac.Any(
		rbac.GlobalSettingsSeeAll(),
		rbac.GlobalSettingsSystemRole(tsMiddleware.PermView, key),
		rbac.GlobalSettingsSystemRole(tsMiddleware.PermCreate, key),
		rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, key),
	)

	group := app.Group("/v2/iam/positions")
	group.Post("/list", rbac.Require(read), h.HandleListPositions)
	group.Post("/dropdown", rbac.Require(read), h.HandleDropdownPositions)
	group.Post("/export", rbac.Require(read), h.HandleExportPositions)
	group.Post("/check-availability", rbac.Require(checkAvail), h.HandleCheckAvailability)
	group.Post("/", rbac.Require(create), h.HandleCreatePosition)
	group.Patch("/:position_id", rbac.Require(update), h.HandleUpdatePosition)
	group.Delete("/", rbac.Require(delete), h.HandleDeletePositions)

	return app
}

// do sends one request with the given client/user headers and returns status, body
// and content type.
func do(app *fiber.App, method, path, body, clientID, userID string) (int, string, string) {
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	if clientID != "" {
		req.Header.Set("X-Client-ID", clientID)
	}
	if userID != "" {
		req.Header.Set("X-User-ID", userID)
	}
	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	raw, _ := io.ReadAll(res.Body)
	return res.StatusCode, string(raw), res.Header.Get("Content-Type")
}

func TestListPositions_MalformedJSON_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions/list", `{"page":`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestCreatePosition_MissingName_Returns422(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions", `{}`, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("expected 422, got %d: %s", status, body)
	}
}

func TestCreatePosition_NameTooLong_Returns422(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	longName := strings.Repeat("a", 121)
	payload := `{"name":"` + longName + `"}`

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions", payload, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("expected 422, got %d: %s", status, body)
	}
}

func TestExportPositions_InvalidFormat_Returns422(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions/export", `{"format":"pdf"}`, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("expected 422, got %d: %s", status, body)
	}
	if !strings.Contains(body, "Validation failed") {
		t.Errorf("expected 'Validation failed', got %s", body)
	}
}

func TestExportPositions_CSV_ContentTypeAndHeader(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListPositionsRequest) ([]dto.PositionItem, error) {
			return []dto.PositionItem{
				{ID: "177013", Name: "Manager"},
			}, nil
		},
	}
	app := newTestApp(t, repo)

	status, body, contentType := do(app, fiber.MethodPost, "/v2/iam/positions/export", `{"format":"csv"}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if contentType != "text/csv" {
		t.Errorf("expected text/csv, got %q", contentType)
	}
	if !strings.Contains(body, "Position Name,Total Users,Last Updated") {
		t.Errorf("expected header row, got %q", body)
	}
	if !strings.Contains(body, "Manager") {
		t.Errorf("expected data row, got %q", body)
	}
}

func TestExportPositions_XLSX_ContentType(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListPositionsRequest) ([]dto.PositionItem, error) {
			return []dto.PositionItem{{ID: "177013", Name: "Manager"}}, nil
		},
	}
	app := newTestApp(t, repo)

	status, body, contentType := do(app, fiber.MethodPost, "/v2/iam/positions/export", `{}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if contentType != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" {
		t.Errorf("expected xlsx content type, got %q", contentType)
	}
}

func TestDeletePositions_MalformedJSON_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/positions/", `{"ids":`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestDeletePositions_EmptyIDs_Returns400(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/positions/", `{"ids":[]}`, "acme", "42")
	if status != fiber.StatusBadRequest {
		t.Errorf("expected 400, got %d: %s", status, body)
	}
}

func TestCheckAvailability_Handler(t *testing.T) {
	app := newTestApp(t, &fakeRepo{})

	t.Run("malformed json returns 400", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions/check-availability", `{"name":`, "acme", "42")
		if status != fiber.StatusBadRequest {
			t.Errorf("expected 400, got %d: %s", status, body)
		}
	})

	t.Run("success check returns 200", func(t *testing.T) {
		status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions/check-availability", `{"name":"Senior Manager"}`, "acme", "42")
		if status != fiber.StatusOK {
			t.Errorf("expected 200, got %d: %s", status, body)
		}
		if !strings.Contains(body, "Availability retrieved") {
			t.Errorf("unexpected response body: %s", body)
		}
		if !strings.Contains(body, `"available":true`) {
			t.Errorf("expected available:true, got %s", body)
		}
	})
}

func TestCheckAvailability_Permissions(t *testing.T) {
	buildAppWithUserAccess := func(cache tsMiddleware.UserAccessCache) *fiber.App {
		repo := &fakeRepo{}
		svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
		svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
			return &coreService.FakePostgreSQLService{}
		})

		app := fiber.New()
		app.Use(func(c fiber.Ctx) error {
			c.Locals(tsMiddleware.UserRolesKey, cache)
			return c.Next()
		})

		h := handler.NewPositionHandler(svc)
		const key = tsEnum.SystemRoleKeyManageUserAndRole
		checkAvail := rbac.Any(
			rbac.GlobalSettingsSeeAll(),
			rbac.GlobalSettingsSystemRole(tsMiddleware.PermView, key),
			rbac.GlobalSettingsSystemRole(tsMiddleware.PermCreate, key),
			rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, key),
		)

		group := app.Group("/v2/iam/positions")
		group.Post("/check-availability", rbac.Require(checkAvail), h.HandleCheckAvailability)
		return app
	}

	// Capability Create=true allowed
	cacheCreate := tsMiddleware.UserAccessCache{FullName: "Budi"}
	cacheCreate.GlobalSettingsSystemRole.GlobalRole = map[tsEnum.SystemRoleKey]tsMiddleware.Permissions[bool]{
		tsEnum.SystemRoleKeyManageUserAndRole: {Create: true},
	}
	appCreate := buildAppWithUserAccess(cacheCreate)
	status, _, _ := do(appCreate, fiber.MethodPost, "/v2/iam/positions/check-availability", `{"name":"Dev"}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Errorf("expected 200 for Create=true, got %d", status)
	}

	// Capability Edit=true allowed
	cacheEdit := tsMiddleware.UserAccessCache{FullName: "Budi"}
	cacheEdit.GlobalSettingsSystemRole.GlobalRole = map[tsEnum.SystemRoleKey]tsMiddleware.Permissions[bool]{
		tsEnum.SystemRoleKeyManageUserAndRole: {Edit: true},
	}
	appEdit := buildAppWithUserAccess(cacheEdit)
	status, _, _ = do(appEdit, fiber.MethodPost, "/v2/iam/positions/check-availability", `{"name":"Dev"}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Errorf("expected 200 for Edit=true, got %d", status)
	}

	// No permission -> 403
	appNone := buildAppWithUserAccess(tsMiddleware.UserAccessCache{
		FullName: "Budi",
	})
	status, _, _ = do(appNone, fiber.MethodPost, "/v2/iam/positions/check-availability", `{"name":"Dev"}`, "acme", "42")
	if status != fiber.StatusForbidden {
		t.Errorf("expected 403 for no permissions, got %d", status)
	}
}

func TestCreatePosition_SuccessMessage(t *testing.T) {
	repo := &fakeRepo{}
	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	svc.SetCreateWorkflowForTest(func(ctx context.Context, param service.CreatePositionParam) (*dto.CreatePositionResponse, error) {
		return &dto.CreatePositionResponse{ID: "1773248399003"}, nil
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})
	h := handler.NewPositionHandler(svc)
	app.Post("/v2/iam/positions", h.HandleCreatePosition)

	status, body, _ := do(app, fiber.MethodPost, "/v2/iam/positions", `{"name":"Manager"}`, "acme", "42")
	if status != fiber.StatusCreated {
		t.Fatalf("expected 201, got %d: %s", status, body)
	}
	if !strings.Contains(body, `"message":"Position has been created"`) {
		t.Errorf("expected message 'Position has been created', got %s", body)
	}
}

func TestUpdatePosition_SuccessMessage(t *testing.T) {
	repo := &fakeRepo{}
	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	svc.SetUpdateWorkflowForTest(func(ctx context.Context, param service.UpdatePositionParam) error {
		return nil
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})
	h := handler.NewPositionHandler(svc)
	app.Patch("/v2/iam/positions/:position_id", h.HandleUpdatePosition)

	status, body, _ := do(app, fiber.MethodPatch, "/v2/iam/positions/1773248399001", `{"name":"Senior Manager"}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if !strings.Contains(body, `"message":"Position has been updated"`) {
		t.Errorf("expected message 'Position has been updated', got %s", body)
	}
}

func TestDeletePositions_SingleNotFound_Returns404(t *testing.T) {
	repo := &fakeRepo{}
	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	svc.SetDeleteWorkflowForTest(func(ctx context.Context, param service.DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
		return &dto.DeletePositionsResponse{
			Results: []dto.DeletePositionResult{
				{ID: "9999999999999", Status: "blocked", Reason: nil},
			},
		}, nil
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})
	h := handler.NewPositionHandler(svc)
	app.Delete("/v2/iam/positions", h.HandleDeletePositions)

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/positions", `{"ids":["9999999999999"]}`, "acme", "42")
	if status != fiber.StatusNotFound {
		t.Fatalf("expected 404, got %d: %s", status, body)
	}
	if !strings.Contains(body, "Position not found") {
		t.Errorf("expected 'Position not found', got %s", body)
	}
}

func TestDeletePositions_SingleInUse_Returns422(t *testing.T) {
	inUseReason := "in_use"
	repo := &fakeRepo{}
	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	svc.SetDeleteWorkflowForTest(func(ctx context.Context, param service.DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
		return &dto.DeletePositionsResponse{
			Results: []dto.DeletePositionResult{
				{ID: "1773248399001", Status: "blocked", Reason: &inUseReason},
			},
		}, nil
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})
	h := handler.NewPositionHandler(svc)
	app.Delete("/v2/iam/positions", h.HandleDeletePositions)

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/positions", `{"ids":["1773248399001"]}`, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Fatalf("expected 422, got %d: %s", status, body)
	}
	if !strings.Contains(body, "Cannot Delete Data.") || !strings.Contains(body, "user(s) are using this position.") {
		t.Errorf("expected Cannot Delete Data message, got %s", body)
	}
}

func TestDeletePositions_BulkAllInUse_Returns422(t *testing.T) {
	inUseReason := "in_use"
	repo := &fakeRepo{}
	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	svc.SetDeleteWorkflowForTest(func(ctx context.Context, param service.DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
		return &dto.DeletePositionsResponse{
			Results: []dto.DeletePositionResult{
				{ID: "1773248399001", Status: "blocked", Reason: &inUseReason},
				{ID: "1773248399002", Status: "blocked", Reason: &inUseReason},
			},
		}, nil
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})
	h := handler.NewPositionHandler(svc)
	app.Delete("/v2/iam/positions", h.HandleDeletePositions)

	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/positions", `{"ids":["1773248399001","1773248399002"]}`, "acme", "42")
	if status != fiber.StatusUnprocessableEntity {
		t.Fatalf("expected 422, got %d: %s", status, body)
	}
	expectedMsg := "These positions are still in use or must remain (at least one is required). Remove the references or keep at least one before deleting."
	if !strings.Contains(body, expectedMsg) {
		t.Errorf("expected bulk blocked message, got %s", body)
	}
}

func TestDeletePositions_SuccessMessages(t *testing.T) {
	inUseReason := "in_use"
	repo := &fakeRepo{}
	svc := service.NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, tsMiddleware.UserAccessCache{
			FullName: "Budi",
			ModuleAccess: map[tsEnum.ModuleAccess]tsMiddleware.ModuleFlags{
				tsEnum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		})
		return c.Next()
	})
	h := handler.NewPositionHandler(svc)
	app.Delete("/v2/iam/positions", h.HandleDeletePositions)

	// Single item deleted -> "1 deleted, 0 failed"
	svc.SetDeleteWorkflowForTest(func(ctx context.Context, param service.DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
		return &dto.DeletePositionsResponse{
			Results: []dto.DeletePositionResult{
				{ID: "1773248399001", Status: "deleted", Reason: nil},
			},
		}, nil
	})
	status, body, _ := do(app, fiber.MethodDelete, "/v2/iam/positions", `{"ids":["1773248399001"]}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if !strings.Contains(body, `"message":"1 deleted, 0 failed"`) {
		t.Errorf("expected '1 deleted, 0 failed', got %s", body)
	}
	if !strings.Contains(body, `"reason":null`) {
		t.Errorf("expected 'reason: null' in json envelope, got %s", body)
	}

	// Bulk partial -> "1 deleted, 1 failed"
	svc.SetDeleteWorkflowForTest(func(ctx context.Context, param service.DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
		return &dto.DeletePositionsResponse{
			Results: []dto.DeletePositionResult{
				{ID: "1773248399001", Status: "deleted", Reason: nil},
				{ID: "1773248399002", Status: "blocked", Reason: &inUseReason},
			},
		}, nil
	})
	status, body, _ = do(app, fiber.MethodDelete, "/v2/iam/positions", `{"ids":["1773248399001","1773248399002"]}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if !strings.Contains(body, `"message":"1 deleted, 1 failed"`) {
		t.Errorf("expected '1 deleted, 1 failed', got %s", body)
	}

	// Bulk all deleted -> "2 deleted, 0 failed"
	svc.SetDeleteWorkflowForTest(func(ctx context.Context, param service.DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
		return &dto.DeletePositionsResponse{
			Results: []dto.DeletePositionResult{
				{ID: "1773248399001", Status: "deleted", Reason: nil},
				{ID: "1773248399002", Status: "deleted", Reason: nil},
			},
		}, nil
	})
	status, body, _ = do(app, fiber.MethodDelete, "/v2/iam/positions", `{"ids":["1773248399001","1773248399002"]}`, "acme", "42")
	if status != fiber.StatusOK {
		t.Fatalf("expected 200, got %d: %s", status, body)
	}
	if !strings.Contains(body, `"message":"2 deleted, 0 failed"`) {
		t.Errorf("expected '2 deleted, 0 failed', got %s", body)
	}
}

