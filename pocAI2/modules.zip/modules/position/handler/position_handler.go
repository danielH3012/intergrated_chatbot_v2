package handler

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/service"
)

type PositionHandler struct {
	PositionSvc *service.PositionService
}

func NewPositionHandler(PositionSvc *service.PositionService) *PositionHandler {
	return &PositionHandler{PositionSvc: PositionSvc}
}
