package handler

import (
	"fmt"
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleDeletePositions serves DELETE /v2/iam/positions.
func (h *PositionHandler) HandleDeletePositions(c fiber.Ctx) error {
	clientID, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.DeletePositionsRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if len(body.IDs) == 0 {
		return coreEntity.BadRequest("IDs are required").SendResponse(c)
	}

	resp, err := h.PositionSvc.Delete(c.Context(), service.DeletePositionsParam{
		ClientID:     clientID,
		IDs:          body.IDs,
		UserID:       strconv.FormatInt(callerID, 10),
		UserFullName: roles.FullName,
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	deleted := 0
	for _, r := range resp.Results {
		if r.Status == "deleted" {
			deleted++
		}
	}
	failed := len(resp.Results) - deleted

	msg := fmt.Sprintf("%d deleted, %d failed", deleted, failed)
	return coreHelper.Success(c, msg, resp)
}
