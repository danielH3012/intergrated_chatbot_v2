package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *PositionHandler) HandleCreatePosition(c fiber.Ctx) error {
	clientID, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.CreatePositionRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	trimmedName := helper.TrimPositionName(body.Name)
	if trimmedName == "" {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Name must not be empty"}).SendResponse(c)
	}
	if len(trimmedName) > 120 {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Max. 120 characters for attribute 'name'"}).SendResponse(c)
	}
	if helper.HasEmoji(trimmedName) {
		return (&coreEntity.HttpError{Code: fiber.StatusUnprocessableEntity, Message: "Name contains invalid characters"}).SendResponse(c)
	}

	resp, err := h.PositionSvc.Create(c.Context(), service.CreatePositionParam{
		ClientID:     clientID,
		Name:         trimmedName,
		UserID:       strconv.FormatInt(callerID, 10),
		UserFullName: roles.FullName,
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Created(c, "Position has been created", resp)
}
