package handler

import (
	"github.com/gofiber/fiber/v3"

	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// HandleDropdownPositions serves POST /v2/iam/positions/dropdown.
func (h *PositionHandler) HandleDropdownPositions(c fiber.Ctx) error {
	clientID, _, _, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	items, err := h.PositionSvc.Dropdown(c.Context(), clientID)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Data retrieved", items)
}
