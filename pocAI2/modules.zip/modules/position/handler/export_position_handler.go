package handler

import (
	"fmt"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleExportPositions serves POST /v2/iam/positions/export.
func (h *PositionHandler) HandleExportPositions(c fiber.Ctx) error {
	clientID, _, _, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var body dto.ExportPositionsRequest
	if err := c.Bind().Body(&body); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if err := validator.Validate.Struct(&body); err != nil {
		return coreEntity.UnprocessableEntity("Validation failed", validator.ParseValidationErrors(err)).SendResponse(c)
	}
	body.Defaults()

	file, err := h.PositionSvc.Export(c.Context(), service.ExportPositionParam{
		ClientID: clientID,
		Format:   body.Format,
		List:     body.ListPositionsRequest,
	})
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	c.Set("Content-Type", file.ContentType)
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, file.Filename))
	return c.Send(file.Data)
}
