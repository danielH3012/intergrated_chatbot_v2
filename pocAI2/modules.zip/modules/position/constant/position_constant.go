package constant

const (
	WorkflowCreatePosition = "CreatePositionWorkflow"
	WorkflowUpdatePosition = "UpdatePositionWorkflow"
	WorkflowDeletePosition = "DeletePositionWorkflow"

	ActivityInsertPosition = "InsertPositionActivity"
	ActivityUpdatePosition = "UpdatePositionActivity"
	ActivityDeletePosition = "DeletePositionsActivity"
)

const (
	MsgInternalServerError = "Internal server error"
)
