package activity

import (
	"context"
	"errors"
	"testing"

	"github.com/jackc/pgx/v5/pgconn"
	"go.temporal.io/sdk/temporal"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/workflow"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRepo implements repository.PositionRepository with func fields; every call
// the tested activity makes can be scripted per-test. The read paths the
// activities don't touch (PaginatedList/List/Dropdown/ExistsByName) are stubbed
// to nil so they panic loudly if an activity reaches them unexpectedly.
type fakeRepo struct {
	insertOneFn     func(ctx context.Context, d model.Position) (int64, error)
	findByIDFn      func(ctx context.Context, id int64) (*model.Position, error)
	lockFn          func(ctx context.Context, id int64) (*model.Position, error)
	deleteFn        func(ctx context.Context, id int64) (int64, error)
	updateFn        func(ctx context.Context, id int64, updates sql_query.UpdateQuery) (int64, error)
	hasActiveRefsFn func(ctx context.Context, id int64) (bool, error)
}

func (f *fakeRepo) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Position) (int64, error) {
	return f.insertOneFn(ctx, d)
}
func (f *fakeRepo) FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	return f.findByIDFn(ctx, id)
}
func (f *fakeRepo) PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error) {
	return nil, nil
}
func (f *fakeRepo) List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) ([]dto.PositionItem, error) {
	return nil, nil
}
func (f *fakeRepo) Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error) {
	return nil, nil
}
func (f *fakeRepo) UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error) {
	return f.updateFn(ctx, id, updates)
}
func (f *fakeRepo) LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	return f.lockFn(ctx, id)
}
func (f *fakeRepo) DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	return f.deleteFn(ctx, id)
}
func (f *fakeRepo) HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error) {
	return f.hasActiveRefsFn(ctx, id)
}
func (f *fakeRepo) CountReferencingUsers(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error) {
	return false, nil
}
func (f *fakeRepo) Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error) {
	return 0, nil
}

func newTestActivities(repo *fakeRepo) *Activities {
	a := NewActivities("tagsamurai_iam", repo)
	a.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	return a
}

// --- conflict mapping -------------------------------------------------------

func TestMapPositionConflict_UniqueViolation_ReturnsNonRetryableConflict(t *testing.T) {
	err := MapPositionConflict(&pgconn.PgError{Code: "23505"})

	var appErr *temporal.ApplicationError
	if !errors.As(err, &appErr) {
		t.Fatalf("expected *temporal.ApplicationError, got %T: %v", err, err)
	}
	if !appErr.NonRetryable() {
		t.Error("expected the error to be non-retryable")
	}
	if appErr.Type() != "Conflict" {
		t.Errorf("expected error type Conflict, got %q", appErr.Type())
	}
}

func TestMapPositionConflict_OtherError_PassesThrough(t *testing.T) {
	original := errors.New("connection reset")
	if err := MapPositionConflict(original); !errors.Is(err, original) {
		t.Errorf("expected the original error to pass through, got %v", err)
	}
}

// --- insert -----------------------------------------------------------------

func TestInsertPositionActivity_TrimsAndReturnsInserted(t *testing.T) {
	repo := &fakeRepo{
		insertOneFn: func(_ context.Context, d model.Position) (int64, error) {
			if d.Name != "Manager" {
				t.Errorf("expected trimmed name, got %q", d.Name)
			}
			if d.CreatedBy == nil || *d.CreatedBy != 42 {
				t.Errorf("expected created_by 42, got %v", d.CreatedBy)
			}
			return 177013, nil
		},
	}
	a := newTestActivities(repo)

	result, err := a.InsertPositionActivity(context.Background(), workflow.InsertPositionActivityParam{
		ClientID: "acme",
		Name:     " Manager ",
		UserID:   "42",
	})
	if err != nil {
		t.Fatalf("InsertPositionActivity: %v", err)
	}
	if result.ID != 177013 || result.Name != "Manager" {
		t.Errorf("unexpected result %+v", result)
	}
}

// --- update -----------------------------------------------------------------

func TestUpdatePositionActivity_ReturnsOldNewPair(t *testing.T) {
	var capturedUpdates sql_query.UpdateQuery
	repo := &fakeRepo{
		findByIDFn: func(_ context.Context, _ int64) (*model.Position, error) {
			return &model.Position{ID: 1, Name: "Manager"}, nil
		},
		updateFn: func(_ context.Context, _ int64, updates sql_query.UpdateQuery) (int64, error) {
			capturedUpdates = updates
			return 177013, nil
		},
	}
	a := newTestActivities(repo)

	result, err := a.UpdatePositionActivity(context.Background(), workflow.UpdatePositionActivityParam{
		ClientID: "acme",
		ID:       177013,
		Name:     "Senior Manager",
		UserID:   "42",
	})
	if err != nil {
		t.Fatalf("UpdatePositionActivity: %v", err)
	}
	if result.OldName != "Manager" || result.NewName != "Senior Manager" {
		t.Errorf("unexpected name pair %+v", result)
	}
	if capturedUpdates["name"] != "Senior Manager" {
		t.Errorf("expected only name to be updated, got %v", capturedUpdates)
	}
	if _, ok := capturedUpdates["created_by"]; ok {
		t.Error("created_by must never be rewritten on update")
	}
	if v, ok := capturedUpdates["modified_by"]; !ok {
		t.Error("expected modified_by to be set")
	} else if p, ok := v.(*int64); !ok || *p != 42 {
		t.Errorf("expected modified_by to be *int64(42), got %T = %v", v, v)
	}
	if _, ok := capturedUpdates["updated_at"]; !ok {
		t.Error("expected updated_at to be set")
	}
}

func TestUpdatePositionActivity_NoOpEdit_WritesNothing(t *testing.T) {
	updateCalled := false
	repo := &fakeRepo{
		findByIDFn: func(_ context.Context, _ int64) (*model.Position, error) {
			return &model.Position{ID: 1, Name: "Manager"}, nil
		},
		updateFn: func(_ context.Context, _ int64, _ sql_query.UpdateQuery) (int64, error) {
			updateCalled = true
			return 0, nil
		},
	}
	a := newTestActivities(repo)

	result, err := a.UpdatePositionActivity(context.Background(), workflow.UpdatePositionActivityParam{
		ClientID: "acme",
		ID:       177013,
		Name:     " Manager ", // trims to "Manager" == current.Name → no-op
		UserID:   "42",
	})
	if err != nil {
		t.Fatalf("UpdatePositionActivity: %v", err)
	}
	if updateCalled {
		t.Error("no-op edit must not reach the DB")
	}
	if result.OldName != result.NewName {
		t.Errorf("no-op edit must return unchanged values, got %+v", result)
	}
}

func TestUpdatePositionActivity_MissingRow_NonRetryableNotFound(t *testing.T) {
	repo := &fakeRepo{
		findByIDFn: func(_ context.Context, _ int64) (*model.Position, error) {
			return nil, repository.ErrPositionNotFound
		},
	}
	a := newTestActivities(repo)

	_, err := a.UpdatePositionActivity(context.Background(), workflow.UpdatePositionActivityParam{
		ClientID: "acme",
		ID:       999,
		Name:     "Manager",
		UserID:   "42",
	})
	var appErr *temporal.ApplicationError
	if !errors.As(err, &appErr) || !appErr.NonRetryable() || appErr.Type() != "NotFound" {
		t.Errorf("expected non-retryable NotFound, got %v", err)
	}
}

func TestDeletePositionActivity_GuardBlocksInUse(t *testing.T) {
	deleteCalled := false
	repo := &fakeRepo{
		lockFn: func(_ context.Context, _ int64) (*model.Position, error) {
			return &model.Position{ID: 1, Name: "Manager"}, nil
		},
		hasActiveRefsFn: func(_ context.Context, _ int64) (bool, error) {
			return true, nil // position still referenced by ≥1 user → TC-DELETE-02 / TC-SEC-03
		},
		deleteFn: func(_ context.Context, _ int64) (int64, error) {
			deleteCalled = true
			return 1, nil
		},
	}
	a := newTestActivities(repo)

	result, err := a.DeletePositionsActivity(context.Background(), workflow.DeletePositionsActivityParam{
		ClientID: "acme",
		IDs:      []int64{1},
	})
	if err != nil {
		t.Fatalf("DeletePositionsActivity: %v", err)
	}
	if deleteCalled {
		t.Error("referenced position must not be deleted")
	}
	if len(result.Results) != 1 {
		t.Fatalf("expected one result, got %+v", result.Results)
	}
	r := result.Results[0]
	if r.Status != "blocked" {
		t.Errorf("expected status 'blocked', got %q", r.Status)
	}
	if r.Reason == nil || *r.Reason != "in_use" {
		t.Errorf("expected in_use reason, got %+v", r)
	}
	if len(result.Deleted) != 0 {
		t.Errorf("no changelog rows for a blocked delete, got %+v", result.Deleted)
	}
}

func TestDeletePositionActivity_MissingID_SkippedWithError(t *testing.T) {
	repo := &fakeRepo{
		lockFn: func(_ context.Context, _ int64) (*model.Position, error) {
			return nil, repository.ErrPositionNotFound
		},
	}
	a := newTestActivities(repo)

	result, err := a.DeletePositionsActivity(context.Background(), workflow.DeletePositionsActivityParam{
		ClientID: "acme",
		IDs:      []int64{999},
	})
	if err != nil {
		t.Fatalf("DeletePositionsActivity: %v", err)
	}
	r := result.Results[0]
	if r.Status != "blocked" || r.Reason != nil {
		t.Errorf("expected blocked with nil reason, got %+v", r)
	}
	if len(result.Deleted) != 0 {
		t.Errorf("no changelog rows for a skipped delete, got %+v", result.Deleted)
	}
}

func TestDeletePositionActivity_DeletesAndCollectsRows(t *testing.T) {
	repo := &fakeRepo{
		lockFn: func(_ context.Context, _ int64) (*model.Position, error) {
			return &model.Position{ID: 1, Name: "Manager"}, nil
		},
		hasActiveRefsFn: func(_ context.Context, _ int64) (bool, error) {
			return false, nil // no references → safe to delete → TC-DELETE-01
		},
		deleteFn: func(_ context.Context, _ int64) (int64, error) { return 1, nil },
	}
	a := newTestActivities(repo)

	result, err := a.DeletePositionsActivity(context.Background(), workflow.DeletePositionsActivityParam{
		ClientID: "acme",
		IDs:      []int64{1},
	})
	if err != nil {
		t.Fatalf("DeletePositionsActivity: %v", err)
	}
	r := result.Results[0]
	if r.Status != "deleted" || r.Reason != nil {
		t.Errorf("expected deleted status without reason, got %+v", r)
	}
	if len(result.Deleted) != 1 {
		t.Fatalf("expected one changelog row, got %+v", result.Deleted)
	}
	if result.Deleted[0].ID != 1 || result.Deleted[0].Name != "Manager" {
		t.Errorf("expected the full deleted row for changelogs, got %+v", result.Deleted[0])
	}
}
