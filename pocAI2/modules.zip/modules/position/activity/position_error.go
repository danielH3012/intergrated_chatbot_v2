package activity

import (
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5/pgconn"
	"go.temporal.io/sdk/temporal"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// MapPositionConflict turns a Postgres unique-violation into a non-retryable
// Conflict ApplicationError so the workflow layer can map it to HTTP 409.
// All other errors pass through unchanged.
func MapPositionConflict(err error) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "23505" {
		return temporal.NewNonRetryableApplicationError(
			"Name already exists",
			coreEntity.ErrConflict,
			err,
		)
	}
	return err
}

// WrapPositionError maps a low-level DB/activity error to the user-facing
// message expected by the Position test cases. Conflict (duplicate name) is
// re-mapped to 409; everything else becomes the generic failure string.
func WrapPositionError(action string, err error) error {
	if err == nil {
		return nil
	}
	if conflict := MapPositionConflict(err); conflict != err {
		return conflict
	}
	return fmt.Errorf("error, failed to %s position", action)
}
