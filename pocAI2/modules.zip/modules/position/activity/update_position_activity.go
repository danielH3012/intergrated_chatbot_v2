package activity

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"go.temporal.io/sdk/temporal"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// UpdatePositionActivity loads the row and writes only the changed fields plus
// modified_by / updated_at, inside one transaction. The result carries old and new
// values so the workflow can emit one changelog row per changed field; a no-op
// edit returns unchanged values and writes (and logs) nothing.
func (a *Activities) UpdatePositionActivity(ctx context.Context, param workflow.UpdatePositionActivityParam) (workflow.UpdatePositionActivityResult, error) {
	svc := a.tenantSvc(param.ClientID)

	newName := strings.TrimSpace(param.Name)

	result := workflow.UpdatePositionActivityResult{
		NewName: newName,
	}

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)

		current, err := a.repo.FindByID(ctx, svc, param.ID)
		if err != nil {
			if errors.Is(err, repository.ErrPositionNotFound) {
				return nil, temporal.NewNonRetryableApplicationError(
					"Position not found",
					coreEntity.ErrNotFound,
					err,
				)
			}
			return nil, fmt.Errorf("UpdatePositionActivity: %w", err)
		}

		result.OldName = current.Name

		if newName == current.Name {
			return nil, nil
		}

		exists, err := a.repo.ExistsByName(ctx, svc, newName, &param.ID)
		if err != nil {
			return nil, fmt.Errorf("UpdatePositionActivity: check existsByName: %w", err)
		}
		if exists {
			return nil, temporal.NewNonRetryableApplicationError(
				"Name already exists",
				coreEntity.ErrConflict,
				errors.New("name already exists"),
			)
		}

		updates := sql_query.UpdateQuery{}
		updates["name"] = newName

		modifiedBy, err := strconv.ParseInt(param.UserID, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("UpdatePositionActivity: parse modified_by: %w", err)
		}
		updates["modified_by"] = &modifiedBy
		updates["updated_at"] = time.Now()

		if _, err := a.repo.UpdateOne(ctx, svc, param.ID, updates); err != nil {
			return nil, WrapPositionError("update", err)
		}

		return nil, nil
	})
	return result, err
}
