package repository_test

import (
	"context"
	"errors"
	"reflect"
	"strings"
	"testing"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/repository"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

type fakeDB struct {
	coreService.PostgreSQLServicer

	query string
	args  []any

	selectOne  func(v any) error
	selectMany func(v any) error
	writeRet   any
	writeErr   error
	deleted    int64
	countRet   int
	countErr   error
}

func (f *fakeDB) SelectOne(v any, ctx context.Context, q string, args ...any) error {
	f.query, f.args = q, args
	return f.selectOne(v)
}

func (f *fakeDB) SelectMany(v any, ctx context.Context, q string, args ...any) error {
	f.query, f.args = q, args
	return f.selectMany(v)
}

func (f *fakeDB) Count(ctx context.Context, q string, args ...any) (int, error) {
	f.query, f.args = q, args
	return f.countRet, f.countErr
}

func (f *fakeDB) InsertOneWithData(ctx context.Context, table string, body any, _ ...coreService.ReturningConfig) (any, error) {
	f.query = table
	return f.writeRet, f.writeErr
}

func (f *fakeDB) UpdateOneWithData(ctx context.Context, table string, where sql_query.WhereQuery, body sql_query.UpdateQuery, _ ...coreService.ReturningConfig) (any, error) {
	f.query = table
	f.args = []any{where, body}
	return f.writeRet, f.writeErr
}

func (f *fakeDB) DeleteManyWithFilter(ctx context.Context, table string, where sql_query.WhereQuery) (int64, error) {
	f.query = table
	f.args = []any{where}
	return f.deleted, f.writeErr
}

var (
	repo      = repository.NewPositionRepository()
	ctx       = context.Background()
	errDBFail = errors.New("boom")
)

func TestInsertOne(t *testing.T) {
	tests := []struct {
		name    string
		ret     any
		err     error
		want    int64
		wantErr bool
	}{
		{name: "int64", ret: int64(7), want: 7},
		{name: "int", ret: 7, want: 7},
		{name: "string", ret: "7", want: 7},
		{name: "unexpected type", ret: 1.5, wantErr: true},
		{name: "db error", err: errDBFail, wantErr: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			db := &fakeDB{writeRet: tt.ret, writeErr: tt.err}
			got, err := repo.InsertOne(ctx, db, model.Position{Name: "Manager"})
			if (err != nil) != tt.wantErr {
				t.Fatalf("err = %v, wantErr %v", err, tt.wantErr)
			}
			if err == nil && got != tt.want {
				t.Fatalf("id = %d, want %d", got, tt.want)
			}
			if db.query != "positions" {
				t.Fatalf("table = %q", db.query)
			}
		})
	}
}

func TestFindOneReads(t *testing.T) {
	calls := map[string]func(db coreService.PostgreSQLServicer) (*model.Position, error){
		"FindByID": func(db coreService.PostgreSQLServicer) (*model.Position, error) { return repo.FindByID(ctx, db, 1) },
		"LockForDelete": func(db coreService.PostgreSQLServicer) (*model.Position, error) {
			return repo.LockForDelete(ctx, db, 1)
		},
	}

	for name, call := range calls {
		t.Run(name+"/found", func(t *testing.T) {
			db := &fakeDB{selectOne: func(v any) error {
				*(v.(*model.Position)) = model.Position{ID: 1, Name: "Manager"}
				return nil
			}}
			got, err := call(db)
			if err != nil {
				t.Fatalf("err = %v", err)
			}
			if got.ID != 1 || got.Name != "Manager" {
				t.Fatalf("got %+v", got)
			}
		})

		t.Run(name+"/no rows", func(t *testing.T) {
			db := &fakeDB{selectOne: func(any) error { return pgx.ErrNoRows }}
			if _, err := call(db); !errors.Is(err, repository.ErrPositionNotFound) {
				t.Fatalf("err = %v, want ErrPositionNotFound", err)
			}
		})

		t.Run(name+"/db error", func(t *testing.T) {
			db := &fakeDB{selectOne: func(any) error { return errDBFail }}
			_, err := call(db)
			if err == nil || !strings.Contains(err.Error(), "boom") {
				t.Fatalf("err = %v, want wrapped boom", err)
			}
		})
	}
}

func TestLockForDeleteLocksRow(t *testing.T) {
	db := &fakeDB{selectOne: func(any) error { return pgx.ErrNoRows }}
	_, _ = repo.LockForDelete(ctx, db, 1)
	if !strings.Contains(strings.ToUpper(db.query), "FOR UPDATE") {
		t.Fatalf("query missing FOR UPDATE: %s", db.query)
	}
}

func TestPaginatedList(t *testing.T) {
	db := &fakeDB{selectMany: func(v any) error {
		*(v.(*[]coreDto.PaginationResult[dto.PositionItem])) = []coreDto.PaginationResult[dto.PositionItem]{{
			Data:         []dto.PositionItem{{ID: "1", Name: "Manager", IsDefault: true}},
			TotalRecords: 1,
		}}
		return nil
	}}
	got, err := repo.PaginatedList(ctx, db, dto.ListPositionsRequest{})
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if len(got.Data) != 1 || got.Data[0].Name != "Manager" {
		t.Fatalf("got %+v", got)
	}

	db = &fakeDB{selectMany: func(any) error { return errDBFail }}
	if _, err := repo.PaginatedList(ctx, db, dto.ListPositionsRequest{}); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

func TestList(t *testing.T) {
	db := &fakeDB{selectMany: func(v any) error {
		*(v.(*[]dto.PositionItem)) = []dto.PositionItem{{ID: "1", Name: "Manager"}}
		return nil
	}}
	got, err := repo.List(ctx, db, dto.ListPositionsRequest{})
	if err != nil || len(got) != 1 {
		t.Fatalf("got %v, err %v", got, err)
	}

	db = &fakeDB{selectMany: func(any) error { return errDBFail }}
	if _, err := repo.List(ctx, db, dto.ListPositionsRequest{}); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

func TestDropdown(t *testing.T) {
	db := &fakeDB{selectMany: func(v any) error {
		slice := reflect.ValueOf(v).Elem()
		row := reflect.New(slice.Type().Elem()).Elem()
		row.FieldByName("ID").SetInt(42)
		row.FieldByName("Name").SetString("Manager")
		slice.Set(reflect.Append(slice, row))
		return nil
	}}
	got, err := repo.Dropdown(ctx, db)
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if len(got) != 1 || got[0].Value != "42" || got[0].Label != "Manager" {
		t.Fatalf("got %+v", got)
	}

	db = &fakeDB{selectMany: func(any) error { return errDBFail }}
	if _, err := repo.Dropdown(ctx, db); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

func TestUpdateOne(t *testing.T) {
	db := &fakeDB{writeRet: int64(5)}
	got, err := repo.UpdateOne(ctx, db, 5, sql_query.UpdateQuery{"name": "Senior Manager"})
	if err != nil || got != 5 {
		t.Fatalf("got %d, err %v", got, err)
	}

	db = &fakeDB{writeErr: errDBFail}
	if _, err := repo.UpdateOne(ctx, db, 5, sql_query.UpdateQuery{}); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

func TestDeleteByID(t *testing.T) {
	db := &fakeDB{deleted: 1}
	got, err := repo.DeleteByID(ctx, db, 5)
	if err != nil || got != 1 {
		t.Fatalf("got %d, err %v", got, err)
	}

	db = &fakeDB{writeErr: errDBFail}
	if _, err := repo.DeleteByID(ctx, db, 5); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

// TC-DELETE-02 / TC-SEC-03: HasActiveReferences drives the "in use" delete guard.
func TestHasActiveReferences(t *testing.T) {
	// count > 0 → referenced (position still in use by ≥1 active user)
	db := &fakeDB{countRet: 3}
	got, err := repo.HasActiveReferences(ctx, db, 1)
	if err != nil || !got {
		t.Fatalf("HasActiveReferences = %v, %v; want true, nil", got, err)
	}

	// count == 0 → safe to delete
	db = &fakeDB{countRet: 0}
	got, err = repo.HasActiveReferences(ctx, db, 1)
	if err != nil || got {
		t.Fatalf("HasActiveReferences = %v, %v; want false, nil", got, err)
	}

	// db error
	db = &fakeDB{countErr: errDBFail}
	_, err = repo.HasActiveReferences(ctx, db, 1)
	if err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

// TC-CREATE-05 / TC-EDIT-04 (duplicate name) & TC-EDIT-05 (exclude self on edit).
func TestExistsByName(t *testing.T) {
	// a matching name already exists
	db := &fakeDB{selectOne: func(v any) error {
		*(v.(*model.Position)) = model.Position{ID: 1}
		return nil
	}}
	got, err := repo.ExistsByName(ctx, db, "Team Lead", nil)
	if err != nil || !got {
		t.Fatalf("ExistsByName = %v, %v; want true, nil", got, err)
	}

	// no match → pgx.ErrNoRows maps to false, nil
	db = &fakeDB{selectOne: func(any) error { return pgx.ErrNoRows }}
	got, err = repo.ExistsByName(ctx, db, "zzz", nil)
	if err != nil || got {
		t.Fatalf("ExistsByName = %v, %v; want false, nil", got, err)
	}

	// edit (excludeID set): a different row still matches → true
	db = &fakeDB{selectOne: func(v any) error {
		*(v.(*model.Position)) = model.Position{ID: 1}
		return nil
	}}
	exclude := int64(5)
	got, err = repo.ExistsByName(ctx, db, "Supervisor", &exclude)
	if err != nil || !got {
		t.Fatalf("ExistsByName(excludeID) = %v, %v; want true, nil", got, err)
	}

	// edit (excludeID set): only the self row matches → excluded → pgx.ErrNoRows → false
	db = &fakeDB{selectOne: func(any) error { return pgx.ErrNoRows }}
	got, err = repo.ExistsByName(ctx, db, "Manager", &exclude)
	if err != nil || got {
		t.Fatalf("ExistsByName(self-excluded) = %v, %v; want false, nil", got, err)
	}

	// db error
	db = &fakeDB{selectOne: func(any) error { return errDBFail }}
	_, err = repo.ExistsByName(ctx, db, "Supervisor", &exclude)
	if err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

func TestCount(t *testing.T) {
	db := &fakeDB{countRet: 7}
	got, err := repo.Count(ctx, db)
	if err != nil || got != 7 {
		t.Fatalf("Count = %d, %v; want 7, nil", got, err)
	}

	db = &fakeDB{countErr: errDBFail}
	if _, err := repo.Count(ctx, db); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

func TestCountReferencingUsers(t *testing.T) {
	db := &fakeDB{countRet: 4}
	got, err := repo.CountReferencingUsers(ctx, db, 1)
	if err != nil || got != 4 {
		t.Fatalf("CountReferencingUsers = %d, %v; want 4, nil", got, err)
	}
	if !strings.Contains(db.query, "users") {
		t.Fatalf("query did not target users: %s", db.query)
	}

	db = &fakeDB{countErr: errDBFail}
	if _, err := repo.CountReferencingUsers(ctx, db, 1); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("err = %v, want wrapped boom", err)
	}
}

