package repository

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/query_builder"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// ErrPositionNotFound marks a missing row (pgx.ErrNoRows mapped by the repo).
var ErrPositionNotFound = errors.New("position not found")

type PositionRepository interface {
	InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Position) (int64, error)
	FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error)
	PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error)
	List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) ([]dto.PositionItem, error)
	Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error)
	UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error)
	LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error)
	DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error)
	HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error)
	CountReferencingUsers(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error)
	ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error)
	// Count returns the total number of position rows for the tenant.
	Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error)
}

var _ PositionRepository = (*positionRepository)(nil)

type positionRepository struct{}

func NewPositionRepository() PositionRepository { return &positionRepository{} }

func (r *positionRepository) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Position) (int64, error) {
	inserted, err := svc.InsertOneWithData(ctx, "positions", d)
	if err != nil {
		slog.ErrorContext(ctx, "position.InsertOne insert failed", "err", err)
		return 0, fmt.Errorf("position.InsertOne: %w", err)
	}
	id, err := toID(inserted)
	if err != nil {
		slog.ErrorContext(ctx, "position.InsertOne toID failed", "err", err)
		return 0, fmt.Errorf("position.InsertOne: %w", err)
	}
	return id, nil
}

func (r *positionRepository) FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	var d model.Position
	query, args, err := sql_query.NewSQLSelectBuilder[model.Position]("positions", "positions").
		Where(sql_query.WhereQuery{
			"positions.id": {Operator: sql_query.SQLOperatorEqual, Value: id},
		}).
		Build()
	if err != nil {
		slog.ErrorContext(ctx, "position.FindByID build failed", "err", err)
		return nil, fmt.Errorf("position.FindByID: %w", err)
	}
	if err := svc.SelectOne(&d, ctx, query, args...); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrPositionNotFound
		}
		slog.ErrorContext(ctx, "position.FindByID select failed", "err", err)
		return nil, fmt.Errorf("position.FindByID: %w", err)
	}
	return &d, nil
}

func (r *positionRepository) PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error) {
	query, args, err := query_builder.GetPositionListQuery(q, true)
	if err != nil {
		slog.ErrorContext(ctx, "position.PaginatedList build failed", "err", err)
		return nil, fmt.Errorf("position.PaginatedList: %w", err)
	}

	results := []coreDto.PaginationResult[dto.PositionItem]{}
	if err := svc.SelectMany(&results, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "position.PaginatedList select failed", "err", err)
		return nil, fmt.Errorf("position.PaginatedList: %w", err)
	}
	paged := coreHelper.FormatPaginationResult(results)
	return &paged, nil
}

func (r *positionRepository) List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) ([]dto.PositionItem, error) {
	query, args, err := query_builder.GetPositionListQuery(q, false)
	if err != nil {
		slog.ErrorContext(ctx, "position.List build failed", "err", err)
		return nil, fmt.Errorf("position.List: %w", err)
	}

	rows := []dto.PositionItem{}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "position.List select failed", "err", err)
		return nil, fmt.Errorf("position.List: %w", err)
	}
	return rows, nil
}

func (r *positionRepository) Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error) {
	type row struct {
		ID   int64  `json:"id"   column:"positions.id"`
		Name string `json:"name" column:"positions.name"`
	}

	rows := []row{}
	query, args, err := sql_query.NewSQLSelectBuilder[row]("positions", "positions").
		OrderBy([]string{query_builder.DefaultNameSort}, true).
		Build()
	if err != nil {
		slog.ErrorContext(ctx, "position.Dropdown build failed", "err", err)
		return nil, fmt.Errorf("position.Dropdown: %w", err)
	}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		slog.ErrorContext(ctx, "position.Dropdown select failed", "err", err)
		return nil, fmt.Errorf("position.Dropdown: %w", err)
	}

	options := make([]coreDto.InterfaceOptionDTO, 0, len(rows))
	for _, row := range rows {
		options = append(options, coreDto.InterfaceOptionDTO{
			Value: strconv.FormatInt(row.ID, 10),
			Label: row.Name,
		})
	}
	return options, nil
}

func (r *positionRepository) UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error) {
	updated, err := svc.UpdateOneWithData(ctx, "positions", sql_query.WhereQuery{
		"positions.id": {Operator: sql_query.SQLOperatorEqual, Value: id},
	}, updates)
	if err != nil {
		slog.ErrorContext(ctx, "position.UpdateOne failed", "err", err)
		return 0, fmt.Errorf("position.UpdateOne: %w", err)
	}
	return toID(updated)
}

func (r *positionRepository) LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	var d model.Position
	query, args, err := sql_query.NewSQLSelectBuilder[model.Position]("positions", "positions").
		Where(sql_query.WhereQuery{
			"positions.id": {Operator: sql_query.SQLOperatorEqual, Value: id},
		}).
		ForUpdate(nil).
		Build()
	if err != nil {
		slog.ErrorContext(ctx, "position.LockForDelete build failed", "err", err)
		return nil, fmt.Errorf("position.LockForDelete: %w", err)
	}
	if err := svc.SelectOne(&d, ctx, query, args...); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrPositionNotFound
		}
		slog.ErrorContext(ctx, "position.LockForDelete select failed", "err", err)
		return nil, fmt.Errorf("position.LockForDelete: %w", err)
	}
	return &d, nil
}

func (r *positionRepository) DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	deleted, err := svc.DeleteManyWithFilter(ctx, "positions", sql_query.WhereQuery{
		"positions.id": {Operator: sql_query.SQLOperatorEqual, Value: id},
	})
	if err != nil {
		slog.ErrorContext(ctx, "position.DeleteByID failed", "err", err)
		return 0, fmt.Errorf("position.DeleteByID: %w", err)
	}
	return deleted, nil
}

// HasActiveReferences returns true if the position is still referenced by any user (active or inactive).
func (r *positionRepository) HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error) {
	count, err := r.CountReferencingUsers(ctx, svc, id)
	if err != nil {
		slog.ErrorContext(ctx, "position.HasActiveReferences failed", "err", err)
		return false, fmt.Errorf("position.HasActiveReferences: %w", err)
	}
	return count > 0, nil
}

// CountReferencingUsers counts users (login and non-login, active and inactive) that reference the given position.
func (r *positionRepository) CountReferencingUsers(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	builder := sql_query.NewSQLCountBuilder("users", "u").
		Where(sql_query.WhereQuery{
			"u.position_id": {Operator: sql_query.SQLOperatorEqual, Value: id},
			"u.deleted_at":  {Operator: sql_query.SQLOperatorIsNull},
		})
	query, args, err := builder.Build()
	if err != nil {
		slog.ErrorContext(ctx, "position.CountReferencingUsers build failed", "err", err)
		return 0, fmt.Errorf("position.CountReferencingUsers: %w", err)
	}
	count, err := svc.Count(ctx, query, args...)
	if err != nil {
		slog.ErrorContext(ctx, "position.CountReferencingUsers failed", "err", err)
		return 0, fmt.Errorf("position.CountReferencingUsers: %w", err)
	}
	return int64(count), nil
}

// ExistsByName checks whether a position with the given name already exists.
// Pass excludeID to ignore a specific id during uniqueness checks (e.g. update).
func (r *positionRepository) ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error) {
	builder := sql_query.NewSQLSelectBuilder[model.Position]("positions", "positions").
		ClearSelects().
		Select("positions.id").
		Where(sql_query.WhereQuery{
			"LOWER(TRIM(positions.name))": {Operator: sql_query.SQLOperatorEqual, Value: strings.ToLower(strings.TrimSpace(name))},
		})

	if excludeID != nil {
		builder.Where(sql_query.WhereQuery{
			"positions.id": {Operator: sql_query.SQLOperatorNotEqual, Value: *excludeID},
		})
	}

	query, args, err := builder.Build()
	if err != nil {
		slog.ErrorContext(ctx, "position.ExistsByName build failed", "err", err)
		return false, fmt.Errorf("position.ExistsByName: %w", err)
	}

	var existing model.Position
	if err := svc.SelectOne(&existing, ctx, query, args...); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return false, nil
		}
		slog.ErrorContext(ctx, "position.ExistsByName select failed", "err", err)
		return false, fmt.Errorf("position.ExistsByName: %w", err)
	}
	return true, nil
}

// Count returns the total number of position rows for the tenant.
func (r *positionRepository) Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error) {
	query, args, err := sql_query.NewSQLCountBuilder("positions", "positions").Build()
	if err != nil {
		slog.ErrorContext(ctx, "position.Count failed", "err", err)
		return 0, fmt.Errorf("position.Count: %w", err)
	}
	count, err := svc.Count(ctx, query, args...)
	if err != nil {
		slog.ErrorContext(ctx, "position.Count failed", "err", err)
		return 0, fmt.Errorf("position.Count: %w", err)
	}
	return int64(count), nil
}

// toID normalises the any returned by InsertOne/UpdateOneWithData (int or int64,
// depending on the driver) into the int64 the domain uses.
func toID(inserted any) (int64, error) {
	switch v := inserted.(type) {
	case int64:
		return v, nil
	case int:
		return int64(v), nil
	case string:
		return strconv.ParseInt(v, 10, 64)
	default:
		return 0, fmt.Errorf("unexpected inserted id type %T", inserted)
	}
}
