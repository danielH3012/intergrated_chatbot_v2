package service

import (
	"context"
	"log/slog"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// CheckAvailability verifies whether position name is available (not taken).
func (s *PositionService) CheckAvailability(ctx context.Context, clientID string, req dto.CheckPositionAvailabilityRequest) (*dto.CheckPositionAvailabilityResponse, error) {
	resp := &dto.CheckPositionAvailabilityResponse{}

	if req.Name != nil && strings.TrimSpace(*req.Name) != "" {
		trimmedName := strings.TrimSpace(*req.Name)
		exists, err := s.repo.ExistsByName(ctx, s.tenantSvc(clientID), trimmedName, nil)
		if err != nil {
			slog.ErrorContext(ctx, "position.CheckAvailability existsByName failed", "err", err)
			return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
		}
		available := !exists
		resp.Name = &dto.FieldAvailability{Available: &available}
	} else {
		resp.Name = &dto.FieldAvailability{Available: nil}
	}

	return resp, nil
}
