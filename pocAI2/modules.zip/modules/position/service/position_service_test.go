package service

import (
	"context"
	"slices"
	"strconv"
	"strings"
	"testing"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

// fakeRepo implements repository.PositionRepository with func fields; the read
// paths this suite doesn't exercise are stubbed to nil-return so they panic
// loudly if a service method reaches them unexpectedly.
type fakeRepo struct {
	listFn                  func(ctx context.Context, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error)
	listAllFn               func(ctx context.Context, q dto.ListPositionsRequest) ([]dto.PositionItem, error)
	dropdownFn              func(ctx context.Context) ([]coreDto.InterfaceOptionDTO, error)
	existsByNameFn          func(ctx context.Context, name string, excludeID *int64) (bool, error)
	countReferencingUsersFn func(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error)
}

func (f *fakeRepo) InsertOne(ctx context.Context, svc coreService.PostgreSQLServicer, d model.Position) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) FindByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	return nil, nil
}
func (f *fakeRepo) PaginatedList(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error) {
	return f.listFn(ctx, q)
}
func (f *fakeRepo) List(ctx context.Context, svc coreService.PostgreSQLServicer, q dto.ListPositionsRequest) ([]dto.PositionItem, error) {
	return f.listAllFn(ctx, q)
}
func (f *fakeRepo) Dropdown(ctx context.Context, svc coreService.PostgreSQLServicer) ([]coreDto.InterfaceOptionDTO, error) {
	return f.dropdownFn(ctx)
}
func (f *fakeRepo) UpdateOne(ctx context.Context, svc coreService.PostgreSQLServicer, id int64, updates sql_query.UpdateQuery) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) LockForDelete(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*model.Position, error) {
	return nil, nil
}
func (f *fakeRepo) DeleteByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	return 0, nil
}
func (f *fakeRepo) HasActiveReferences(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (bool, error) {
	return false, nil
}
func (f *fakeRepo) CountReferencingUsers(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
	if f.countReferencingUsersFn != nil {
		return f.countReferencingUsersFn(ctx, svc, id)
	}
	return 0, nil
}
func (f *fakeRepo) ExistsByName(ctx context.Context, svc coreService.PostgreSQLServicer, name string, excludeID *int64) (bool, error) {
	if f.existsByNameFn != nil {
		return f.existsByNameFn(ctx, name, excludeID)
	}
	return false, nil
}
func (f *fakeRepo) Count(ctx context.Context, svc coreService.PostgreSQLServicer) (int64, error) {
	return 0, nil
}

func newTestService(repo *fakeRepo) *PositionService {
	svc := NewPositionService("tagsamurai_iam", repo, nil, "analytics-reporting-service", nil, nil)
	svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	return svc
}

func TestPaginatedList_PassesThrough(t *testing.T) {
	called := false
	repo := &fakeRepo{
		listFn: func(_ context.Context, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error) {
			called = true
			return &coreDto.PaginationResult[dto.PositionItem]{TotalRecords: 1, Data: []dto.PositionItem{{ID: "1", Name: "Manager"}}}, nil
		},
	}
	svc := newTestService(repo)

	paged, err := svc.PaginatedList(context.Background(), "acme", dto.ListPositionsRequest{})
	if err != nil {
		t.Fatalf("PaginatedList: %v", err)
	}
	if !called {
		t.Error("repo.PaginatedList was not called")
	}
	if paged.TotalRecords != 1 || len(paged.Data) != 1 {
		t.Errorf("unexpected result %+v", paged)
	}
}

func TestList_PassesThrough(t *testing.T) {
	called := false
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListPositionsRequest) ([]dto.PositionItem, error) {
			called = true
			return []dto.PositionItem{{ID: "1", Name: "Manager"}}, nil
		},
	}
	svc := newTestService(repo)

	got, err := svc.List(context.Background(), "acme", dto.ListPositionsRequest{})
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if !called {
		t.Error("repo.List was not called")
	}
	if len(got) != 1 || got[0].Name != "Manager" {
		t.Errorf("unexpected result %+v", got)
	}
}

func TestDropdown_PassesThrough(t *testing.T) {
	repo := &fakeRepo{
		dropdownFn: func(_ context.Context) ([]coreDto.InterfaceOptionDTO, error) {
			return []coreDto.InterfaceOptionDTO{{Value: "177013", Label: "Manager"}}, nil
		},
	}
	svc := newTestService(repo)

	options, err := svc.Dropdown(context.Background(), "acme")
	if err != nil {
		t.Fatalf("Dropdown: %v", err)
	}
	if len(options) != 1 || options[0].ID != "177013" || options[0].Name != "Manager" {
		t.Errorf("unexpected options %+v", options)
	}
}

func TestExportColumns_ReflectsExportTagsInOrder(t *testing.T) {
	headers, cells := helper.ExportColumns[dto.PositionItem]()
	wantHeaders := []string{"Position Name", "Total Users", "Last Updated"}
	if len(headers) != len(wantHeaders) {
		t.Fatalf("expected %v, got %v", wantHeaders, headers)
	}
	for i := range wantHeaders {
		if headers[i] != wantHeaders[i] {
			t.Errorf("header %d = %q, want %q", i, headers[i], wantHeaders[i])
		}
	}

	updatedAt := time.Date(2026, 8, 7, 16, 30, 0, 0, time.UTC)
	row := cells(dto.PositionItem{ID: "177013", Name: "Manager", UpdatedAt: &updatedAt})
	wantRow := []string{"Manager", "0", "2026-08-07 16:30:00"}
	for i := range wantRow {
		if row[i] != wantRow[i] {
			t.Errorf("cell %d = %q, want %q (row %v)", i, row[i], wantRow[i], row)
		}
	}
}

func TestExport_CSV(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListPositionsRequest) ([]dto.PositionItem, error) {
			return []dto.PositionItem{
				{ID: "177013", Name: "Manager"},
				{ID: "177014", Name: "Supervisor"},
			}, nil
		},
	}
	svc := newTestService(repo)

	result, err := svc.Export(context.Background(), ExportPositionParam{
		ClientID: "acme",
		Format:   "csv",
	})
	if err != nil {
		t.Fatalf("Export: %v", err)
	}
	if result.ContentType != "text/csv" {
		t.Errorf("expected text/csv, got %q", result.ContentType)
	}
	got := string(result.Data)
	if got != "Position Name,Total Users,Last Updated\nManager,0,\nSupervisor,0,\n" {
		t.Errorf("unexpected csv:\n%q", got)
	}
}

func TestExport_XLSX_IsValidFile(t *testing.T) {
	repo := &fakeRepo{
		listAllFn: func(_ context.Context, _ dto.ListPositionsRequest) ([]dto.PositionItem, error) {
			return []dto.PositionItem{{ID: "177013", Name: "Manager"}}, nil
		},
	}
	svc := newTestService(repo)

	result, err := svc.Export(context.Background(), ExportPositionParam{
		ClientID: "acme",
		Format:   "xlsx",
	})
	if err != nil {
		t.Fatalf("Export: %v", err)
	}
	if result.ContentType != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" {
		t.Errorf("unexpected content type %q", result.ContentType)
	}
	if len(result.Data) == 0 {
		t.Error("expected non-empty xlsx payload")
	}
	if len(result.Filename) == 0 {
		t.Error("expected a filename")
	}
}

func TestIDsDigest_StableAndBounded(t *testing.T) {
	ids := make([]string, 100)
	for i := range ids {
		ids[i] = strconv.FormatInt(1773248399000+int64(i), 10)
	}
	shuffled := slices.Clone(ids)
	slices.Reverse(shuffled)

	got := idsDigest(ids)
	if got != idsDigest(shuffled) {
		t.Error("digest must not depend on the order ids arrive in")
	}
	if got == idsDigest(ids[:99]) {
		t.Error("a different id set must produce a different digest")
	}
	if wf := "position-delete-acme-" + got; len(wf) > 1000 {
		t.Errorf("workflow id too long: %d bytes", len(wf))
	}
}

func TestCheckAvailability(t *testing.T) {
	repo := &fakeRepo{
		existsByNameFn: func(_ context.Context, name string, _ *int64) (bool, error) {
			if name == "Existing Name" {
				return true, nil
			}
			return false, nil
		},
	}
	svc := newTestService(repo)

	t.Run("name available", func(t *testing.T) {
		name := "New Position"
		resp, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckPositionAvailabilityRequest{
			Name: &name,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if resp.Name == nil || resp.Name.Available == nil || !*resp.Name.Available {
			t.Errorf("expected name available true, got %+v", resp.Name)
		}
	})

	t.Run("name taken", func(t *testing.T) {
		name := "Existing Name"
		resp, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckPositionAvailabilityRequest{
			Name: &name,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if resp.Name == nil || resp.Name.Available == nil || *resp.Name.Available {
			t.Errorf("expected name available false, got %+v", resp.Name)
		}
	})

	t.Run("empty/omitted returns null", func(t *testing.T) {
		emptyStr := ""
		resp, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckPositionAvailabilityRequest{
			Name: &emptyStr,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if resp.Name == nil || resp.Name.Available != nil {
			t.Errorf("expected name available null, got %+v", resp.Name)
		}

		respNil, err := svc.CheckAvailability(context.Background(), "acme", dto.CheckPositionAvailabilityRequest{
			Name: nil,
		})
		if err != nil {
			t.Fatalf("CheckAvailability: %v", err)
		}
		if respNil.Name == nil || respNil.Name.Available != nil {
			t.Errorf("expected name available null, got %+v", respNil.Name)
		}
	})
}

func TestPositionService_EntitySuspended(t *testing.T) {
	svc := newTestService(&fakeRepo{})
	svc.SetEntitySuspendedForTest(true)

	// Create should return 403 Forbidden
	_, err := svc.Create(context.Background(), CreatePositionParam{
		ClientID: "acme",
		Name:     "Test",
	})
	if err == nil || !slices.Contains([]string{"Forbidden"}, err.Error()) {
		if err != nil && err.Error() != "Forbidden" {
			t.Errorf("expected Forbidden error, got %v", err)
		}
	}

	// Update should return 403 Forbidden
	err = svc.Update(context.Background(), UpdatePositionParam{
		ClientID: "acme",
		ID:       1,
		Name:     "Test",
	})
	if err == nil || err.Error() != "Forbidden" {
		t.Errorf("expected Forbidden error, got %v", err)
	}

	// Delete should return 403 Forbidden
	_, err = svc.Delete(context.Background(), DeletePositionsParam{
		ClientID: "acme",
		IDs:      []string{"1"},
	})
	if err == nil || err.Error() != "Forbidden" {
		t.Errorf("expected Forbidden error, got %v", err)
	}
}

func TestPositionService_Delete_Outcomes(t *testing.T) {
	inUseReason := "in_use"

	t.Run("single not found returns 404", func(t *testing.T) {
		repo := &fakeRepo{}
		svc := NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
		svc.SetDeleteWorkflowForTest(func(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
			return &dto.DeletePositionsResponse{
				Results: []dto.DeletePositionResult{
					{ID: "999", Status: "blocked", Reason: nil},
				},
			}, nil
		})
		_, err := svc.Delete(context.Background(), DeletePositionsParam{
			ClientID: "acme",
			IDs:      []string{"999"},
		})
		if err == nil || !strings.Contains(err.Error(), "Position not found") {
			t.Fatalf("expected Position not found error, got %v", err)
		}
	})

	t.Run("single in-use returns 422 with count", func(t *testing.T) {
		repo := &fakeRepo{
			countReferencingUsersFn: func(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (int64, error) {
				return 3, nil
			},
		}
		svc := NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
		svc.SetServiceFactoryForTest(func(clientID string) coreService.PostgreSQLServicer {
			return &coreService.FakePostgreSQLService{}
		})
		svc.SetDeleteWorkflowForTest(func(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
			return &dto.DeletePositionsResponse{
				Results: []dto.DeletePositionResult{
					{ID: "100", Status: "blocked", Reason: &inUseReason},
				},
			}, nil
		})
		_, err := svc.Delete(context.Background(), DeletePositionsParam{
			ClientID: "acme",
			IDs:      []string{"100"},
		})
		if err == nil || !strings.Contains(err.Error(), "Cannot Delete Data. 3 user(s) are using this position.") {
			t.Fatalf("expected Cannot Delete Data error with count 3, got %v", err)
		}
	})

	t.Run("bulk all in-use returns 422", func(t *testing.T) {
		repo := &fakeRepo{}
		svc := NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
		svc.SetDeleteWorkflowForTest(func(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
			return &dto.DeletePositionsResponse{
				Results: []dto.DeletePositionResult{
					{ID: "101", Status: "blocked", Reason: &inUseReason},
					{ID: "102", Status: "blocked", Reason: &inUseReason},
				},
			}, nil
		})
		_, err := svc.Delete(context.Background(), DeletePositionsParam{
			ClientID: "acme",
			IDs:      []string{"101", "102"},
		})
		if err == nil || !strings.Contains(err.Error(), "These positions are still in use") {
			t.Fatalf("expected all in-use error, got %v", err)
		}
	})

	t.Run("partial or full success returns resp", func(t *testing.T) {
		repo := &fakeRepo{}
		svc := NewPositionService("tagsamurai_iam", repo, nil, "iam-service", nil, nil)
		svc.SetDeleteWorkflowForTest(func(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
			return &dto.DeletePositionsResponse{
				Results: []dto.DeletePositionResult{
					{ID: "101", Status: "deleted"},
					{ID: "102", Status: "blocked", Reason: &inUseReason},
				},
			}, nil
		})
		resp, err := svc.Delete(context.Background(), DeletePositionsParam{
			ClientID: "acme",
			IDs:      []string{"101", "102"},
		})
		if err != nil {
			t.Fatalf("expected success, got %v", err)
		}
		if len(resp.Results) != 2 {
			t.Fatalf("expected 2 results, got %d", len(resp.Results))
		}
	})
}

