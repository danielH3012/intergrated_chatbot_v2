package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
)

// List is the export read: same filters as PaginatedList, unpaginated.
func (s *PositionService) List(ctx context.Context, clientID string, q dto.ListPositionsRequest) ([]dto.PositionItem, error) {
	return s.repo.List(ctx, s.tenantSvc(clientID), q)
}
