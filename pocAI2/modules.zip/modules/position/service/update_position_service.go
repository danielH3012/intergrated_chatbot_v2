package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/workflow"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

// UpdatePositionParam is the service-level update request.
type UpdatePositionParam struct {
	ClientID     string
	ID           int64
	Name         string
	UserID       string
	UserFullName string
}

// Update starts the update workflow and waits for completion.
func (s *PositionService) Update(ctx context.Context, param UpdatePositionParam) error {
	if err := s.checkEntityState(ctx, param.ClientID); err != nil {
		return err
	}

	if s.updateWorkflowFn != nil {
		return s.updateWorkflowFn(ctx, param)
	}

	result := &workflow.UpdatePositionWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowUpdatePosition,
		TemporalService: s.temporalSvc,
		Param: workflow.UpdatePositionWorkflowParam{
			ClientID:     param.ClientID,
			ID:           param.ID,
			Name:         param.Name,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("position-update-%s-%d", param.ClientID, param.ID),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
	})
	if httpErr != nil {
		return httpErr
	}
	if err := s.notifier.SendSSE(ctx, param.ClientID, []string{}, "position.updated"); err != nil {
		slog.WarnContext(ctx, "position: sse push failed", "error", err)
	}
	return nil
}
