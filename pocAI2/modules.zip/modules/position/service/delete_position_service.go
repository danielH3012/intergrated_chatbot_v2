package service

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"log/slog"
	"slices"
	"strconv"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

// DeletePositionsParam is the service-level bulk-delete request.
type DeletePositionsParam struct {
	ClientID     string
	IDs          []string
	UserID       string
	UserFullName string
}

// Delete starts the delete workflow and waits for the per-id results.
func (s *PositionService) Delete(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error) {
	if err := s.checkEntityState(ctx, param.ClientID); err != nil {
		return nil, err
	}

	ids, err := parseIDs(param.IDs)
	if err != nil {
		return nil, err
	}

	var resp *dto.DeletePositionsResponse
	if s.deleteWorkflowFn != nil {
		var wfErr error
		resp, wfErr = s.deleteWorkflowFn(ctx, param)
		if wfErr != nil {
			return nil, wfErr
		}
	} else {
		result := &workflow.DeletePositionWorkflowResult{}
		httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
			WorkflowName:    constant.WorkflowDeletePosition,
			TemporalService: s.temporalSvc,
			Param: workflow.DeletePositionWorkflowParam{
				ClientID:     param.ClientID,
				IDs:          ids,
				UserID:       param.UserID,
				UserFullName: param.UserFullName,
				TaskQueue:    s.arTaskQueue,
			},
		}, result, client.StartWorkflowOptions{
			ID: fmt.Sprintf("position-delete-%s-%s", param.ClientID, idsDigest(param.IDs)),
			RetryPolicy: &temporal.RetryPolicy{
				MaximumAttempts: 1,
			},
		})
		if httpErr != nil {
			return nil, httpErr
		}
		if err := s.notifier.SendSSE(ctx, param.ClientID, []string{}, "position.deleted"); err != nil {
			slog.WarnContext(ctx, "position: sse push failed", "error", err)
		}
		resp = &dto.DeletePositionsResponse{Results: result.Results}
	}

	if resp == nil {
		return nil, coreEntity.InternalServerError("No delete results returned")
	}

	deleted := 0
	inUse := 0
	for _, r := range resp.Results {
		if r.Status == "deleted" {
			deleted++
		} else if r.Reason != nil && *r.Reason == "in_use" {
			inUse++
		}
	}

	if len(param.IDs) == 1 && len(resp.Results) == 1 {
		r := resp.Results[0]
		if r.Status == "blocked" {
			if r.Reason != nil && *r.Reason == "in_use" {
				id, _ := strconv.ParseInt(r.ID, 10, 64)
				userCount, _ := s.CountReferencingUsers(ctx, param.ClientID, id)
				if userCount <= 0 {
					userCount = 1
				}
				return nil, coreEntity.UnprocessableEntity(fmt.Sprintf("Cannot Delete Data. %d user(s) are using this position.", userCount))
			}
			return nil, coreEntity.NotFound("Position not found")
		}
	}

	if len(param.IDs) >= 2 && deleted == 0 && inUse == len(resp.Results) {
		return nil, coreEntity.UnprocessableEntity("These positions are still in use or must remain (at least one is required). Remove the references or keep at least one before deleting.")
	}

	return resp, nil
}

// parseIDs converts the string snowflake ids (as carried by the query string) to
// int64. A non-numeric id is a caller bug, not a DB concern: reject it up front.
func parseIDs(raw []string) ([]int64, error) {
	ids := make([]int64, 0, len(raw))
	for _, r := range raw {
		id, err := strconv.ParseInt(r, 10, 64)
		if err != nil {
			return nil, coreEntity.BadRequest(fmt.Sprintf("Invalid position id %q", r))
		}
		ids = append(ids, id)
	}
	return ids, nil
}

// idsDigest names an id set in fixed width. The raw ids cannot go in the workflow ID:
// 100 snowflakes joined is ~2KB and Temporal rejects an ID over 1000 bytes. Sorted
// first so the same selection submitted in a different order is the same workflow,
// which is what the double-submit guard wants.
func idsDigest(ids []string) string {
	sorted := slices.Clone(ids)
	slices.Sort(sorted)
	sum := sha256.Sum256([]byte(strings.Join(sorted, ",")))
	return hex.EncodeToString(sum[:8])
}
