package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

type CreatePositionParam struct {
	ClientID     string
	Name         string
	UserID       string
	UserFullName string
}

func (s *PositionService) Create(ctx context.Context, param CreatePositionParam) (*dto.CreatePositionResponse, error) {
	if err := s.checkEntityState(ctx, param.ClientID); err != nil {
		return nil, err
	}

	if s.settingsClient != nil {
		limit := s.settingsClient.GetMasterDataCountLimit(ctx)
		if limit > 0 {
			count, err := s.repo.Count(ctx, s.tenantSvc(param.ClientID))
			if err != nil {
				slog.ErrorContext(ctx, "position.Create count failed", "err", err)
				return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
			}
			if int(count) >= limit {
				return nil, coreEntity.Conflict(fmt.Sprintf("You've reached the platform limit of %d positions. Contact support if you need a higher limit.", limit))
			}
		}
	}

	exists, err := s.repo.ExistsByName(ctx, s.tenantSvc(param.ClientID), param.Name, nil)
	if err != nil {
		slog.ErrorContext(ctx, "position.Create existsByName failed", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if exists {
		return nil, coreEntity.Conflict("Name already exists")
	}

	if s.createWorkflowFn != nil {
		return s.createWorkflowFn(ctx, param)
	}

	result := &workflow.CreatePositionWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowCreatePosition,
		TemporalService: s.temporalSvc,
		Param: workflow.CreatePositionWorkflowParam{
			ClientID:     param.ClientID,
			Name:         param.Name,
			UserID:       param.UserID,
			UserFullName: param.UserFullName,
			TaskQueue:    s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("position-create-%s-%s", param.ClientID, param.Name),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1,
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})
	if httpErr != nil {
		return nil, httpErr
	}
	if err := s.notifier.SendSSE(ctx, param.ClientID, []string{}, "position.created"); err != nil {
		slog.WarnContext(ctx, "position: sse push failed", "error", err)
	}
	return &dto.CreatePositionResponse{ID: result.ID}, nil
}
