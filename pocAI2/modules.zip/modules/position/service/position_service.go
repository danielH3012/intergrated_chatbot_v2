package service

import (
	"context"
	"fmt"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/client"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/repository"
	tsDb "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/db"
	notificationClient "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/notification_service/client"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// PositionService is the use-case layer for position. It delegates DB reads to
// the repository and writes to Temporal workflows.
type PositionService struct {
	temporalSvc       *coreService.TemporalService
	dbName            string
	arTaskQueue       string
	repo              repository.PositionRepository
	notifier          *notificationClient.NotificationClient
	settingsClient    *client.EnterpriseManagementClient
	makeTenantSvc     func(clientID string) coreService.PostgreSQLServicer
	isEntitySuspended bool
	createWorkflowFn  func(ctx context.Context, param CreatePositionParam) (*dto.CreatePositionResponse, error)
	updateWorkflowFn  func(ctx context.Context, param UpdatePositionParam) error
	deleteWorkflowFn  func(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error)
}

func NewPositionService(dbName string, repo repository.PositionRepository, temporalSvc *coreService.TemporalService, arTaskQueue string, notifier *notificationClient.NotificationClient, settingsClient *client.EnterpriseManagementClient) *PositionService {
	return &PositionService{
		dbName:         dbName,
		repo:           repo,
		temporalSvc:    temporalSvc,
		arTaskQueue:    arTaskQueue,
		notifier:       notifier,
		settingsClient: settingsClient,
	}
}

// tenantSvc routes queries into the client's own schema.
func (s *PositionService) tenantSvc(clientID string) coreService.PostgreSQLServicer {
	if s.makeTenantSvc != nil {
		return s.makeTenantSvc(clientID)
	}
	return coreService.MakePostgreSQLService(string(tsDb.DBName(s.dbName).CompanyDBName(clientID)))
}

// PaginatedList is a direct DB read.
func (s *PositionService) PaginatedList(ctx context.Context, clientID string, q dto.ListPositionsRequest) (*coreDto.PaginationResult[dto.PositionItem], error) {
	return s.repo.PaginatedList(ctx, s.tenantSvc(clientID), q)
}

// Dropdown is a direct DB read.
func (s *PositionService) Dropdown(ctx context.Context, clientID string) ([]dto.DropdownItem, error) {
	options, err := s.repo.Dropdown(ctx, s.tenantSvc(clientID))
	if err != nil {
		return nil, err
	}
	items := make([]dto.DropdownItem, 0, len(options))
	for _, opt := range options {
		items = append(items, dto.DropdownItem{
			ID:   fmt.Sprintf("%v", opt.Value),
			Name: fmt.Sprintf("%v", opt.Label),
		})
	}
	return items, nil
}

// SetServiceFactoryForTest replaces the DB factory with a stub so unit tests never
// touch Postgres.
func (s *PositionService) SetServiceFactoryForTest(factory func(clientID string) coreService.PostgreSQLServicer) {
	s.makeTenantSvc = factory
}

// SetEntitySuspendedForTest toggles the entity suspended state for test isolation (D1).
func (s *PositionService) SetEntitySuspendedForTest(v bool) {
	s.isEntitySuspended = v
}

func (s *PositionService) checkEntityState(_ context.Context, _ string) error {
	if s.isEntitySuspended {
		return coreEntity.Forbidden("Forbidden")
	}
	return nil
}

// CountReferencingUsers returns the count of all users referencing the position id.
func (s *PositionService) CountReferencingUsers(ctx context.Context, clientID string, id int64) (int64, error) {
	return s.repo.CountReferencingUsers(ctx, s.tenantSvc(clientID), id)
}

func (s *PositionService) SetCreateWorkflowForTest(fn func(ctx context.Context, param CreatePositionParam) (*dto.CreatePositionResponse, error)) {
	s.createWorkflowFn = fn
}

func (s *PositionService) SetUpdateWorkflowForTest(fn func(ctx context.Context, param UpdatePositionParam) error) {
	s.updateWorkflowFn = fn
}

func (s *PositionService) SetDeleteWorkflowForTest(fn func(ctx context.Context, param DeletePositionsParam) (*dto.DeletePositionsResponse, error)) {
	s.deleteWorkflowFn = fn
}


