package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// ExportPositionParam is the service-level export request.
type ExportPositionParam struct {
	ClientID string
	Format   string // "csv" | "xlsx"
	List     dto.ListPositionsRequest
}

// ExportPositionResult is the rendered file: bytes ready to stream, plus the
// content type and attachment filename the handler echoes.
type ExportPositionResult = helper.ExportResult

// Export renders the list rows as csv or xlsx using be-core-utils/helper.Export.
func (s *PositionService) Export(ctx context.Context, param ExportPositionParam) (*ExportPositionResult, error) {
	rows, err := s.List(ctx, param.ClientID, param.List)
	if err != nil {
		return nil, err
	}

	return helper.Export(rows, helper.ExportParam{
		Format:       param.Format,
		FallbackName: "Position",
	})
}
