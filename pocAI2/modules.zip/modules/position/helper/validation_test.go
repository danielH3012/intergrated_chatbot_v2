package helper_test

import (
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/position/helper"
	"github.com/stretchr/testify/assert"
)

func TestHasEmoji(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected bool
	}{
		{"empty string", "", false},
		{"plain ASCII name", "Software Engineer", false},
		{"name with punctuation", "VP - Operations & Logistics", false},
		{"name with accents", "Attaché de Direction", false},
		{"legacy emoji", "Manager 😀", true},
		{"party emoji", "🎉 Lead", true},
		{"modern melting face emoji", "Staff 🫠", true},
		{"modern saluting face emoji", "🫡 Officer", true},
		{"star emoji", "⭐ Star Performer", true},
		{"colored circle emoji", "Status 🟢", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.expected, helper.HasEmoji(tt.input))
		})
	}
}

func TestTrimPositionName(t *testing.T) {
	assert.Equal(t, "Manager", helper.TrimPositionName("   Manager   "))
	assert.Equal(t, "VP of Engineering", helper.TrimPositionName("VP of Engineering"))
}
