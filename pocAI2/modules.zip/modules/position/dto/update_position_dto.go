package dto

type UpdatePositionRequest struct {
	PositionBody
}
