package dto

type DeletePositionsRequest struct {
	IDs []string `json:"ids" validate:"required"`
}

type Reference struct {
	Module string `json:"module"`
	Name   string `json:"name"`
}

type DeletePositionResult struct {
	ID     string  `json:"_id"`
	Status string  `json:"status"`
	Reason *string `json:"reason"`
}

type DeletePositionsResponse struct {
	Results []DeletePositionResult `json:"results"`
}
