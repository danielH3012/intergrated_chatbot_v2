package dto

type ExportPositionsRequest struct {
	ListPositionsRequest
	Format string `json:"format" validate:"omitempty,oneof=csv xlsx"`
}

func (r *ExportPositionsRequest) Defaults() {
	r.ListPositionsRequest.Defaults()
	if r.Format == "" {
		r.Format = "xlsx"
	}
}
