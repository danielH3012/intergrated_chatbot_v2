package dto

import "time"

type PositionItem struct {
	ID        string     `json:"_id"         column:"positions.id::text"`
	Name      string     `json:"name"        column:"positions.name"   export:"Position Name"`
	IsDefault bool       `json:"isDefault"   column:"positions.is_default"`
	UserCount int        `json:"userCount"   column:"-"                    export:"Total Users"`
	UpdatedAt *time.Time `json:"updatedAt"   column:"positions.updated_at" export:"Last Updated"`
}

type PositionBody struct {
	Name string `json:"name" validate:"position_name"`
}
