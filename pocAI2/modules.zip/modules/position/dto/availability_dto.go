package dto

// CheckPositionAvailabilityRequest is the request body for POST /v2/iam/positions/check-availability.
type CheckPositionAvailabilityRequest struct {
	Name *string `json:"name"`
}

// FieldAvailability reports availability for a single field (true=free, false=taken, null=not checked).
type FieldAvailability struct {
	Available *bool `json:"available"`
}

// CheckPositionAvailabilityResponse is the data payload for availability response.
type CheckPositionAvailabilityResponse struct {
	Name *FieldAvailability `json:"name"`
}
