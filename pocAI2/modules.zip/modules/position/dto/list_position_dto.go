package dto

import (
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
)

type ListPositionsRequest struct {
	coreDto.PaginationQuery
	UpdatedAt []int64 `json:"updatedAt" validate:"omitempty,max=2"`
}

func (r *ListPositionsRequest) Defaults() {
	r.PaginationQuery.Defaults()
}
