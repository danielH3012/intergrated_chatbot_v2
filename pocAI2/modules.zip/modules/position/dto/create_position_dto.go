package dto

type CreatePositionRequest struct {
	PositionBody
}

type CreatePositionResponse struct {
	ID string `json:"_id"`
}
