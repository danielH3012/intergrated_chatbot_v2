package repository

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"github.com/jackc/pgx/v5"
)

func (r *UserRepository) StageEmailChange(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, newEmail string, clientCode string) (*model.UserEmailChange, error) {
	// Cancel existing live row
	_, err := svc.UpdateManyWithData(
		ctx,
		"public.user_email_changes",
		sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"consumed_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
			"canceled_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		},
		sql_query.UpdateQuery{
			"canceled_at": sql_query.UpdateRawSQL{Expr: "NOW()", Args: nil},
		},
	)
	if err != nil {
		return nil, err
	}

	// Generate token
	tokenBytes := make([]byte, 32)
	if _, err := rand.Read(tokenBytes); err != nil {
		return nil, err
	}
	rawToken := hex.EncodeToString(tokenBytes)
	h := sha256.New()
	h.Write([]byte(rawToken))
	hashedToken := hex.EncodeToString(h.Sum(nil))

	// Insert new row
	expiresAt := time.Now().Add(24 * time.Hour)
	changeRecord := model.UserEmailChange{
		UserID:     userID,
		NewEmail:   newEmail,
		TokenHash:  hashedToken,
		ClientCode: clientCode,
		ExpiresAt:  expiresAt,
	}
	if _, err := svc.InsertOneWithData(ctx, "public.user_email_changes", changeRecord, coreService.ReturningConfig{
		Destination: &changeRecord,
	}); err != nil {
		return nil, err
	}

	changeRecord.TokenHash = rawToken
	return &changeRecord, nil
}

func (r *UserRepository) CancelEmailChange(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64) error {
	rows, err := svc.UpdateManyWithData(
		ctx,
		"public.user_email_changes",
		sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"consumed_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
			"canceled_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		},
		sql_query.UpdateQuery{
			"canceled_at": sql_query.UpdateRawSQL{Expr: "NOW()", Args: nil},
		},
	)
	if err != nil {
		return err
	}
	if rows == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

func (r *UserRepository) GetPendingEmailChangeByToken(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) (*model.UserEmailChange, error) {
	builder := sql_query.NewSQLSelectBuilder[model.UserEmailChange]("public.user_email_changes").
		Where(sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: tokenHash},
		})

	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var m model.UserEmailChange
	if err := svc.SelectOne(&m, ctx, query, args...); err != nil {
		if err == pgx.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}

	return &m, nil
}

func (r *UserRepository) ConfirmEmailChangePublic(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"public.user_email_changes",
		sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: tokenHash},
		},
		sql_query.UpdateQuery{
			"consumed_at": sql_query.UpdateRawSQL{Expr: "NOW()", Args: nil},
		},
	)
	if err != nil {
		return err
	}
	return nil
}

func (r *UserRepository) UnconsumeEmailChangePublic(ctx context.Context, svc coreService.PostgreSQLServicer, tokenHash string) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"public.user_email_changes",
		sql_query.WhereQuery{
			"token_hash": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: tokenHash},
		},
		sql_query.UpdateQuery{
			"consumed_at": nil,
		},
	)
	if err != nil {
		return err
	}
	return nil
}

func (r *UserRepository) UpdateUserEmail(ctx context.Context, svc coreService.PostgreSQLServicer, userID int64, newEmail string) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		},
		sql_query.UpdateQuery{
			"email": newEmail,
		},
	)
	if err != nil {
		return err
	}
	return nil
}
