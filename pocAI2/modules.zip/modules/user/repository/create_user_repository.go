package repository

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *UserRepository) Create(ctx context.Context, svc service.PostgreSQLServicer, user model.User, access []string) error {
	_, err := svc.InsertOneWithData(ctx, "users", user)
	if err != nil {
		return err
	}

	for _, mod := range access {
		ums := model.UserModuleStatus{
			UserID:    user.ID,
			ModuleKey: model.Product(mod),
			IsActive:  true,
		}
		_, err := svc.InsertOneWithData(ctx, "user_module_status", ums)
		if err != nil {
			return err
		}
	}

	return nil
}
