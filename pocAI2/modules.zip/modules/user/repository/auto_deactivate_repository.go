package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *UserRepository) GetExpiredTemporaryUserIDs(ctx context.Context, svc service.PostgreSQLServicer, now time.Time) ([]int64, error) {
	// Find users that are temporary, active_period_until is before 'now' (midnight), not deleted,
	// and have global status that is currently Active.
	query := `
		SELECT u.id AS id
		FROM users u
		WHERE u.is_temporary = true
		  AND u.is_global_active = true
		  AND u.active_period_until < $1
		  AND u.deleted_at IS NULL
	`

	var users []struct {
		ID int64 `json:"id"`
	}
	var ids []int64

	midnight := now.UTC().Truncate(24 * time.Hour)
	if err := svc.SelectMany(&users, ctx, query, midnight); err != nil {
		return nil, err
	}

	for _, user := range users {
		ids = append(ids, user.ID)
	}

	return ids, nil
}
