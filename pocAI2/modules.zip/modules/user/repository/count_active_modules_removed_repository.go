package repository

import (
	"context"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// CountActiveModulesRemoved counts how many active modules for a user would be deactivated/removed
// based on the new keepAccess list.
func (r *UserRepository) CountActiveModulesRemoved(ctx context.Context, svc service.PostgreSQLServicer, userID int64, keepAccess []string) (int, error) {
	var query string
	var args []any

	if len(keepAccess) > 0 {
		query = `
			SELECT COUNT(*) 
			FROM user_module_status 
			WHERE user_id = $1 AND is_active = true AND NOT (module_key = ANY($2))
		`
		args = []any{userID, keepAccess}
	} else {
		query = `
			SELECT COUNT(*) 
			FROM user_module_status 
			WHERE user_id = $1 AND is_active = true
		`
		args = []any{userID}
	}

	return svc.Count(ctx, query, args...)
}
