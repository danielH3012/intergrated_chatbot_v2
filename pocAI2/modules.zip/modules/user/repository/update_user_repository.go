package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) Update(ctx context.Context, svc service.PostgreSQLServicer, user model.User, access []string) error {
	updateData := sql_query.UpdateQuery{
		"first_name":              user.FirstName,
		"last_name":               user.LastName,
		"email":                   user.Email,
		"employee_id":             user.EmployeeID,
		"position_id":             user.PositionID,
		"division_id":             user.DivisionID,
		"tag_id":                  user.TagID,
		"custom_fields":           user.CustomFields,
		"profile_picture":         user.ProfilePicture,
		"profile_picture_file_id": user.ProfilePictureFileID,
		"is_temporary":            user.IsTemporary,
		"active_period_until":     user.ActivePeriodUntil,
		"modified_by":             user.ModifiedBy,
		"updated_at":              time.Now(),
	}

	_, err := svc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: user.ID},
		},
		updateData,
	)
	if err != nil {
		return err
	}

	// For access, apply differential sync (diff)
	var existingModules []model.UserModuleStatus
	query, args, err := sql_query.NewSQLSelectBuilder[model.UserModuleStatus]("user_module_status").
		Select("module_key").
		Where(sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: user.ID},
		}).Build()
	if err != nil {
		return err
	}

	if err := svc.SelectMany(&existingModules, ctx, query, args...); err != nil {
		return err
	}

	existingMap := make(map[string]bool)
	for _, em := range existingModules {
		existingMap[string(em.ModuleKey)] = true
	}

	newMap := make(map[string]bool)
	for _, mod := range access {
		newMap[mod] = true
	}

	var toDelete []string
	for _, em := range existingModules {
		if !newMap[string(em.ModuleKey)] {
			toDelete = append(toDelete, string(em.ModuleKey))
		}
	}

	if len(toDelete) > 0 {
		_, err = svc.DeleteManyWithFilter(ctx, "user_module_status", sql_query.WhereQuery{
			"user_id":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: user.ID},
			"module_key": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: toDelete},
		})
		if err != nil {
			return err
		}
	}

	for _, mod := range access {
		if !existingMap[mod] {
			ums := model.UserModuleStatus{
				UserID:    user.ID,
				ModuleKey: model.Product(mod),
				IsActive:  true, // Default to true only for newly inserted modules
			}
			_, err := svc.InsertOneWithData(ctx, "user_module_status", ums)
			if err != nil {
				return err
			}
		}
	}

	return nil
}
