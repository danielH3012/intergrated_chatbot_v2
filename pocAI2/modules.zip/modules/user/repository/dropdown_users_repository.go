package repository

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *UserRepository) Dropdown(ctx context.Context, svc service.PostgreSQLServicer, req userDto.UserDropdownQuery) (userDto.UserDropdownResponse, error) {
	query, args, err := query_builder.GetUserDropdownQuery(req)
	if err != nil {
		return userDto.UserDropdownResponse{}, err
	}

	var rows []userDto.UserDropdownItem
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return userDto.UserDropdownResponse{}, err
	}

	if rows == nil {
		rows = []userDto.UserDropdownItem{}
	}

	return userDto.UserDropdownResponse{Data: rows}, nil
}
