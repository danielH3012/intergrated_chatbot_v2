package repository

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) GetOneByID(ctx context.Context, svc coreService.PostgreSQLServicer, id int64) (*userDto.UserListItem, error) {
	query, args, err := sql_query.NewSQLSelectBuilder[userDto.UserListItem]("users").
		Where(sql_query.WhereQuery{
			"users.id":         sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
			"users.deleted_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		}).
		SetLimit(1).
		Build()
	if err != nil {
		return nil, err
	}

	var user userDto.UserListItem
	if err := svc.SelectOne(&user, ctx, query, args...); err != nil {
		return nil, err
	}
	return &user, nil
}
