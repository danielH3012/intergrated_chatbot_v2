package repository

import (
	"context"
	"fmt"
	"sync"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

var _ UserRepositor = (*FakeUserRepository)(nil)

type FakeUserRepository struct {
	mu                sync.RWMutex
	users             map[int64]*model.User
	idSeq             int64
	activeRoles       map[int64][]userDto.AcUserActiveRolesRawRow
	userGroups        map[int64][]int64
	accessLevels      map[int64]string
	isEntitySuspended bool
	moduleStatuses    map[string]*model.UserModuleStatus
	activationTokens  map[int64]*model.ActivationToken
	emailChanges      map[int64]*model.UserEmailChange
}

func NewFakeUserRepository() *FakeUserRepository {
	return &FakeUserRepository{
		users:            make(map[int64]*model.User),
		idSeq:            1,
		activeRoles:      make(map[int64][]userDto.AcUserActiveRolesRawRow),
		userGroups:       make(map[int64][]int64),
		accessLevels:     make(map[int64]string),
		moduleStatuses:   make(map[string]*model.UserModuleStatus),
		activationTokens: make(map[int64]*model.ActivationToken),
		emailChanges:     make(map[int64]*model.UserEmailChange),
	}
}

func (f *FakeUserRepository) SetUserActiveRoles(userID int64, rows []userDto.AcUserActiveRolesRawRow) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.activeRoles[userID] = rows
}

func (f *FakeUserRepository) SetUserAdminConsoleGroups(userID int64, groupIDs []int64) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.userGroups[userID] = groupIDs
}

func (f *FakeUserRepository) SetUserAccessLevel(userID int64, level string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.accessLevels[userID] = level
}

func (f *FakeUserRepository) AddUser(u *model.User) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.users[u.ID] = u
}

func (f *FakeUserRepository) List(ctx context.Context, svc service.PostgreSQLServicer, callerID int64, req userDto.UserListBody) (userDto.UserListResponseData, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	var res []userDto.UserListResponseItem
	disabledCount := 0
	for _, u := range f.users {
		isDef := u.IsDefault != nil && *u.IsDefault
		if isDef || u.ID == callerID {
			disabledCount++
		}
		res = append(res, userDto.UserListResponseItem{
			ID:        fmt.Sprint(u.ID),
			FullName:  u.FirstName + " " + u.LastName,
			Email:     u.Email,
			IsDefault: isDef,
		})
	}
	return userDto.UserListResponseData{
		TotalRecords:         len(res),
		TotalDisabledRecords: disabledCount,
		Data:                 res,
	}, nil
}

func (f *FakeUserRepository) GenerateOptions(ctx context.Context, svc service.PostgreSQLServicer, req userDto.UserOptionsBody) (userDto.UserOptionsResponse, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	return userDto.UserOptionsResponse{}, nil
}

func (f *FakeUserRepository) Dropdown(ctx context.Context, svc service.PostgreSQLServicer, req userDto.UserDropdownQuery) (userDto.UserDropdownResponse, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	var res []userDto.UserDropdownItem
	for _, u := range f.users {
		res = append(res, userDto.UserDropdownItem{
			ID:       fmt.Sprint(u.ID),
			FullName: u.FirstName + " " + u.LastName,
		})
	}
	return userDto.UserDropdownResponse{Data: res}, nil
}

func (f *FakeUserRepository) ProductDropdown(ctx context.Context, svc service.PostgreSQLServicer, req userDto.ProductUserDropdownQuery) (userDto.UserDropdownResponse, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	var res []userDto.UserDropdownItem
	for _, u := range f.users {
		if req.ActivationStatus != "" && u.ActivationStatus != req.ActivationStatus {
			continue
		}
		res = append(res, userDto.UserDropdownItem{
			ID:       fmt.Sprint(u.ID),
			FullName: u.FirstName + " " + u.LastName,
		})
	}
	return userDto.UserDropdownResponse{Data: res}, nil
}

func (f *FakeUserRepository) AdminConsoleList(ctx context.Context, svc service.PostgreSQLServicer, req userDto.AcUserListBody) ([]userDto.AcUserListItem, int, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	var res []userDto.AcUserListItem
	for _, u := range f.users {
		if len(req.ActivationStatus) > 0 {
			match := false
			for _, st := range req.ActivationStatus {
				if u.ActivationStatus == st {
					match = true
					break
				}
			}
			if !match {
				continue
			}
		}
		isDef := false
		if u.IsDefault != nil {
			isDef = *u.IsDefault
		}
		res = append(res, userDto.AcUserListItem{
			ID:               fmt.Sprint(u.ID),
			FullName:         u.FirstName + " " + u.LastName,
			Email:            u.Email,
			IsDefault:        isDef,
			ActivationStatus: u.ActivationStatus,
			Role:             "0",
			EntityType:       "principal",
		})
	}
	return res, len(res), nil
}

func (f *FakeUserRepository) AdminConsoleOptions(ctx context.Context, svc service.PostgreSQLServicer, req userDto.AcUserOptionsBody) (userDto.AcUserOptionsResponse, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	var resp userDto.AcUserOptionsResponse
	if req.PositionOptions {
		resp.PositionOptions = []userDto.OptionItem{}
	}
	if req.DivisionOptions {
		resp.DivisionOptions = []userDto.OptionItem{}
	}
	if req.StatusOptions {
		resp.StatusOptions = []userDto.OptionItem{
			{Label: "Active", Value: "Active"},
			{Label: "Inactive", Value: "Inactive"},
		}
	}
	if req.ActivationStatusOptions {
		resp.ActivationStatusOptions = []userDto.OptionItem{
			{Label: "Activated", Value: "Activated"},
			{Label: "Pending", Value: "Pending"},
			{Label: "Pending Email Confirmation", Value: "Pending Email Confirmation"},
		}
	}
	if req.TemporaryStatusOptions {
		resp.TemporaryStatusOptions = []userDto.OptionItem{
			{Label: "Yes", Value: "Yes"},
			{Label: "No", Value: "No"},
		}
	}
	if req.ModifiedByOptions {
		resp.ModifiedByOptions = []userDto.OptionItem{}
	}
	return resp, nil
}

func (f *FakeUserRepository) GetDetail(ctx context.Context, svc service.PostgreSQLServicer, id int64) (*userDto.UserDetailItem, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	u, ok := f.users[id]
	if !ok {
		return nil, coreEntity.NotFound(constant.MsgUserNotFound)
	}
	var posID *string
	if u.PositionID != nil {
		s := fmt.Sprint(*u.PositionID)
		posID = &s
	}
	return &userDto.UserDetailItem{
		ID:                   fmt.Sprint(u.ID),
		FirstName:            u.FirstName,
		LastName:             u.LastName,
		FullName:             u.FirstName + " " + u.LastName,
		Email:                u.Email,
		EmployeeID:           u.EmployeeID,
		PositionID:           posID,
		DivisionID:           fmt.Sprint(u.DivisionID),
		TagCode:              u.TagCode,
		TagID:                u.TagID,
		ProfilePicture:       u.ProfilePicture,
		ProfilePictureFileID: u.ProfilePictureFileID,
		CustomFields:         u.CustomFields,
		ActivePeriodUntil:    u.ActivePeriodUntil,
		ActivationStatus:     u.ActivationStatus,
		IsDefault:            u.IsDefault,
	}, nil
}

func (f *FakeUserRepository) CheckEmailUniqueness(ctx context.Context, svc service.PostgreSQLServicer, email string) (bool, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	for _, u := range f.users {
		if u.Email == email {
			return false, nil
		}
	}
	return true, nil
}

func (f *FakeUserRepository) Create(ctx context.Context, svc service.PostgreSQLServicer, user model.User, access []string) error {
	f.mu.Lock()
	defer f.mu.Unlock()

	if user.ID == 0 {
		f.idSeq++
		user.ID = f.idSeq
	}
	user.CreatedAt = time.Now()
	user.IsGlobalActive = true
	f.users[user.ID] = &user
	return nil
}

func (f *FakeUserRepository) Update(ctx context.Context, svc service.PostgreSQLServicer, user model.User, access []string) error {
	f.mu.Lock()
	defer f.mu.Unlock()

	f.users[user.ID] = &user
	return nil
}

func (f *FakeUserRepository) Delete(ctx context.Context, svc service.PostgreSQLServicer, id int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()

	delete(f.users, id)
	return nil
}

func (f *FakeUserRepository) GetOneByEmail(ctx context.Context, svc service.PostgreSQLServicer, email string) (*userDto.UserListItem, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	for _, u := range f.users {
		if u.Email == email {
			return &userDto.UserListItem{
				ID:               u.ID,
				Email:            u.Email,
				FirstName:        u.FirstName,
				LastName:         u.LastName,
				ActivationStatus: u.ActivationStatus,
				IsActive:         u.IsGlobalActive,
				IsDefault:        u.IsDefault,
			}, nil
		}
	}
	return nil, nil // Or return not found error
}

func (f *FakeUserRepository) UpdateActivationStatus(ctx context.Context, svc service.PostgreSQLServicer, id int64, status string) error {
	f.mu.Lock()
	defer f.mu.Unlock()

	if u, ok := f.users[id]; ok {
		u.ActivationStatus = status
	}
	return nil
}

func (f *FakeUserRepository) GetOneByID(ctx context.Context, svc service.PostgreSQLServicer, id int64) (*userDto.UserListItem, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	u, ok := f.users[id]
	if !ok {
		return nil, coreEntity.NotFound(constant.MsgUserNotFound)
	}
	return &userDto.UserListItem{
		ID:               u.ID,
		Email:            u.Email,
		FirstName:        u.FirstName,
		LastName:         u.LastName,
		ActivationStatus: u.ActivationStatus,
		IsActive:         u.IsGlobalActive,
		IsDefault:        u.IsDefault,
	}, nil
}

func (f *FakeUserRepository) StageEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64, newEmail string, clientCode string) (*model.UserEmailChange, error) {
	return &model.UserEmailChange{ID: 1, UserID: userID, NewEmail: newEmail, ClientCode: clientCode, ExpiresAt: time.Now().Add(24 * time.Hour), CreatedAt: time.Now()}, nil
}

func (f *FakeUserRepository) CancelEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) GetPendingEmailChangeByToken(ctx context.Context, svc service.PostgreSQLServicer, tokenHash string) (*model.UserEmailChange, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	return nil, nil
}

func (f *FakeUserRepository) ConfirmEmailChangePublic(ctx context.Context, svc service.PostgreSQLServicer, tokenHash string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) UnconsumeEmailChangePublic(ctx context.Context, svc service.PostgreSQLServicer, tokenHash string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) UpdateUserEmail(ctx context.Context, svc service.PostgreSQLServicer, userID int64, newEmail string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if u, ok := f.users[userID]; ok {
		u.Email = newEmail
	}
	return nil
}

func (f *FakeUserRepository) IsAuthenticatorEnrolled(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (bool, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	if u, ok := f.users[userID]; ok {
		return u.IsAuthenticatorEnrolled, nil
	}
	return false, nil
}

func (f *FakeUserRepository) ResetAuthenticatorPublic(ctx context.Context, pubSvc service.PostgreSQLServicer, userID int64, clientCode string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) ResetAuthenticatorTenant(ctx context.Context, tenSvc service.PostgreSQLServicer, userID int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if u, ok := f.users[userID]; ok {
		u.IsAuthenticatorEnrolled = false
	}
	return nil
}

func (f *FakeUserRepository) CheckEmployeeIDUniqueness(ctx context.Context, svc service.PostgreSQLServicer, employeeID string, excludeID *int64) (bool, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	for id, u := range f.users {
		if u.EmployeeID != nil && *u.EmployeeID == employeeID {
			if excludeID != nil && id == *excludeID {
				continue
			}
			return false, nil
		}
	}
	return true, nil
}

func (f *FakeUserRepository) CheckDivisionAndPositionExist(ctx context.Context, svc service.PostgreSQLServicer, divisionID int64, positionID *int64) (bool, bool, error) {
	return true, true, nil
}

func (f *FakeUserRepository) InsertUserCredentialPublic(ctx context.Context, svc service.PostgreSQLServicer, email string, clientCode string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) UpdateUserCredentialEmailPublic(ctx context.Context, svc service.PostgreSQLServicer, oldEmail string, newEmail string, clientCode string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) DeleteUserCredentialPublic(ctx context.Context, svc service.PostgreSQLServicer, email string, clientCode string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return nil
}

func (f *FakeUserRepository) UpdateFirstLoginAt(ctx context.Context, svc service.PostgreSQLServicer, id int64, firstLoginAt time.Time) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if u, ok := f.users[id]; ok {
		u.FirstLoginAt = &firstLoginAt
	}
	return nil
}

func (f *FakeUserRepository) UpdateAuthenticatorEnrolled(ctx context.Context, svc service.PostgreSQLServicer, id int64, enrolled bool) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if u, ok := f.users[id]; ok {
		u.IsAuthenticatorEnrolled = enrolled
	}
	return nil
}

func (f *FakeUserRepository) CheckAdminConsoleUserExists(ctx context.Context, svc service.PostgreSQLServicer, targetID int64) (bool, *string, []int64, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	u, ok := f.users[targetID]
	if !ok || u.DeletedAt != nil {
		return false, nil, nil, nil
	}

	var accessLevel *string
	if lvl, ok := f.accessLevels[targetID]; ok {
		accessLevel = &lvl
	}

	groups := f.userGroups[targetID]
	if groups == nil {
		groups = []int64{}
	}

	return true, accessLevel, groups, nil
}

func (f *FakeUserRepository) GetAdminConsoleUserActiveRoles(ctx context.Context, svc service.PostgreSQLServicer, targetID int64) ([]userDto.AcUserActiveRolesRawRow, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()

	rows, ok := f.activeRoles[targetID]
	if !ok {
		return []userDto.AcUserActiveRolesRawRow{}, nil
	}
	return rows, nil
}

func (f *FakeUserRepository) GetPositionNameByID(ctx context.Context, svc service.PostgreSQLServicer, positionID int64) (string, error) {
	return "Position " + fmt.Sprint(positionID), nil
}

func (f *FakeUserRepository) GetDivisionNameByID(ctx context.Context, svc service.PostgreSQLServicer, divisionID int64) (string, error) {
	return "Division " + fmt.Sprint(divisionID), nil
}
