package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) Delete(ctx context.Context, svc service.PostgreSQLServicer, id int64) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"deleted_at":              time.Now(),
			"profile_picture_file_id": nil,
			"profile_picture":         nil,
		},
	)
	return err
}
