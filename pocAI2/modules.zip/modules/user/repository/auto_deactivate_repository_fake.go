package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (f *FakeUserRepository) GetExpiredTemporaryUserIDs(ctx context.Context, svc service.PostgreSQLServicer, now time.Time) ([]int64, error) {
	return nil, nil // basic mock
}
