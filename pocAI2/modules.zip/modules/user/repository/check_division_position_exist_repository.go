package repository

import (
	"context"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *UserRepository) CheckDivisionAndPositionExist(ctx context.Context, svc service.PostgreSQLServicer, divisionID int64, positionID *int64) (bool, bool, error) {
	divExists := false
	posExists := true // True if not provided

	divCount, err := svc.Count(ctx, "SELECT COUNT(*) FROM divisions WHERE id = $1", divisionID)
	if err != nil {
		return false, false, err
	}
	divExists = divCount > 0

	if positionID != nil {
		posCount, err := svc.Count(ctx, "SELECT COUNT(*) FROM positions WHERE id = $1", *positionID)
		if err != nil {
			return false, false, err
		}
		posExists = posCount > 0
	}

	return divExists, posExists, nil
}
