package repository

import (
	"context"
	"errors"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"github.com/jackc/pgx/v5"
)

func (r *UserRepository) CheckEmployeeIDUniqueness(ctx context.Context, svc service.PostgreSQLServicer, employeeID string, excludeID *int64) (bool, error) {
	builder := sql_query.NewSQLSelectBuilder[model.User]("users").
		Where(sql_query.WhereQuery{
			"employee_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: employeeID},
			"deleted_at":  sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		}).SetLimit(1)

	if excludeID != nil {
		builder = builder.Where(sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorNotEqual, Value: *excludeID},
		})
	}

	query, args, err := builder.Build()
	if err != nil {
		return false, err
	}

	var user model.User
	err = svc.SelectOne(&user, ctx, query, args...)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) || strings.Contains(err.Error(), "not found") {
			return true, nil // Unique
		}
		return false, err
	}

	return false, nil // Conflict found
}
