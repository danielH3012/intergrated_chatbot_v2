package repository

import (
	"context"
	"time"

	"errors"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"github.com/jackc/pgx/v5"
)

func (r *UserRepository) GetUserModuleStatus(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (*model.UserModuleStatus, error) {
	builder := sql_query.NewSQLSelectBuilder[model.UserModuleStatus]("user_module_status").
		Where(sql_query.WhereQuery{
			"user_id":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"module_key": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: moduleKey},
		}).SetLimit(1)

	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var row model.UserModuleStatus
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}
	return &row, nil
}

func (r *UserRepository) UpdateUserModuleStatus(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string, isActive bool) error {
	_, err := svc.UpdateOneWithData(ctx, "user_module_status", sql_query.WhereQuery{
		"user_id":    sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		"module_key": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: moduleKey},
	}, sql_query.UpdateQuery{
		"is_active":  isActive,
		"updated_at": time.Now(),
	})
	return err
}

func (r *UserRepository) UpdateUserGlobalActive(ctx context.Context, svc service.PostgreSQLServicer, userID int64, isActive bool) error {
	_, err := svc.UpdateOneWithData(ctx, "users", sql_query.WhereQuery{
		"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
	}, sql_query.UpdateQuery{
		"is_global_active": isActive,
		"updated_at":       time.Now(),
	})
	return err
}

type countRow struct {
	Count int64 `column:"count"`
}

func (r *UserRepository) IsTargetProtectedTCRO(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (bool, error) {
	builder := sql_query.NewSQLSelectBuilder[countRow]("user_access_levels").
		Select("COUNT(id) AS count").
		Where(sql_query.WhereQuery{
			"user_id":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"product":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: moduleKey},
			"access_level": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: []string{"total_control", "read_only"}},
		})
	query, args, err := builder.Build()
	if err != nil {
		return false, err
	}
	var row countRow
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return false, err
	}
	return row.Count > 0, nil
}

func (r *UserRepository) IsActorTotalControl(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (bool, error) {
	builder := sql_query.NewSQLSelectBuilder[countRow]("user_access_levels").
		Select("COUNT(id) AS count").
		Where(sql_query.WhereQuery{
			"user_id":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"product":      sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: moduleKey},
			"access_level": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "total_control"},
		})
	query, args, err := builder.Build()
	if err != nil {
		return false, err
	}
	var row countRow
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return false, err
	}
	return row.Count > 0, nil
}

func (r *UserRepository) IsEntitySuspended(ctx context.Context, svc service.PostgreSQLServicer, clientCode string) (bool, error) {
	return false, nil
}

func (r *UserRepository) UpdateUserReactivation(ctx context.Context, svc service.PostgreSQLServicer, userID int64, isTemporary bool, activePeriodUntil *time.Time) error {
	update := sql_query.UpdateQuery{
		"is_temporary": isTemporary,
		"updated_at":   time.Now(),
	}
	update["active_period_until"] = activePeriodUntil

	_, err := svc.UpdateOneWithData(ctx, "users", sql_query.WhereQuery{
		"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
	}, update)
	return err
}
