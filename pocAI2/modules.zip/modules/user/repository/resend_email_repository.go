package repository

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) GetActiveActivationToken(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (*model.ActivationToken, error) {
	builder := sql_query.NewSQLSelectBuilder[model.ActivationToken]("activation_tokens").
		Where(sql_query.WhereQuery{
			"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"status":  sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "Active"},
		}).OrderBy([]string{"created_at"}, false).SetLimit(1)
	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var rows []model.ActivationToken
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, err
	}
	if len(rows) == 0 {
		return nil, nil
	}
	return &rows[0], nil
}

func (r *UserRepository) SupersedeActivationTokens(ctx context.Context, svc service.PostgreSQLServicer, userID int64) error {
	_, err := svc.UpdateManyWithData(ctx, "activation_tokens", sql_query.WhereQuery{
		"user_id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		"status":  sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "Active"},
	}, sql_query.UpdateQuery{
		"status":     "Superseded",
		"updated_at": time.Now(),
	})
	return err
}

func (r *UserRepository) GetPendingEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (*model.UserEmailChange, error) {
	builder := sql_query.NewSQLSelectBuilder[model.UserEmailChange]("user_email_changes").
		Where(sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"consumed_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
			"canceled_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		}).OrderBy([]string{"created_at"}, false).SetLimit(1)
	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var rows []model.UserEmailChange
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return nil, err
	}
	if len(rows) == 0 {
		return nil, nil
	}
	return &rows[0], nil
}

func (r *UserRepository) ExtendEmailChangeExpiry(ctx context.Context, svc service.PostgreSQLServicer, id int64) (string, error) {
	// Generate new token
	tokenBytes := make([]byte, 32)
	if _, err := rand.Read(tokenBytes); err != nil {
		return "", err
	}
	rawToken := hex.EncodeToString(tokenBytes)
	h := sha256.New()
	h.Write([]byte(rawToken))
	hashedToken := hex.EncodeToString(h.Sum(nil))

	_, err := svc.UpdateOneWithData(ctx, "user_email_changes", sql_query.WhereQuery{
		"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
	}, sql_query.UpdateQuery{
		"expires_at": time.Now().Add(24 * time.Hour),
		"token_hash": hashedToken,
		"updated_at": time.Now(),
	})
	return rawToken, err
}
