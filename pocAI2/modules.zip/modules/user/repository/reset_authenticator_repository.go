package repository

import (
	"context"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) IsAuthenticatorEnrolled(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (bool, error) {
	builder := sql_query.NewSQLSelectBuilder[model.User]("users").
		Where(sql_query.WhereQuery{
			"id":         sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"deleted_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		}).
		Select("is_authenticator_enrolled")

	query, args, err := builder.Build()
	if err != nil {
		return false, err
	}

	var user model.User
	if err := svc.SelectOne(&user, ctx, query, args...); err != nil {
		if err == pgx.ErrNoRows {
			return false, nil
		}
		return false, err
	}
	return user.IsAuthenticatorEnrolled, nil
}

func (r *UserRepository) ResetAuthenticatorPublic(ctx context.Context, pubSvc service.PostgreSQLServicer, userID int64, clientCode string) error {
	_, err := pubSvc.UpdateOneWithData(
		ctx,
		"public.authenticator_enrollments",
		sql_query.WhereQuery{
			"user_id":     sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
			"is_active":   sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: true},
		},
		sql_query.UpdateQuery{
			"is_active": false,
		},
	)
	if err != nil {
		return err
	}
	return nil
}

func (r *UserRepository) ResetAuthenticatorTenant(ctx context.Context, tenSvc service.PostgreSQLServicer, userID int64) error {
	_, err := tenSvc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: userID},
		},
		sql_query.UpdateQuery{
			"is_authenticator_enrolled": false,
		},
	)
	if err != nil {
		return err
	}

	return nil
}
