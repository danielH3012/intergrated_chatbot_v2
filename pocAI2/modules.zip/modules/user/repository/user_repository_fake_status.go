package repository

import (
	"context"
	"fmt"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (f *FakeUserRepository) SetUserModuleStatus(userID int64, moduleKey string, isActive bool) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.moduleStatuses[fmt.Sprintf("%d:%s", userID, moduleKey)] = &model.UserModuleStatus{
		UserID:    userID,
		ModuleKey: model.Product(moduleKey),
		IsActive:  isActive,
	}
}

func (f *FakeUserRepository) GetUserModuleStatus(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (*model.UserModuleStatus, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	if st, ok := f.moduleStatuses[fmt.Sprintf("%d:%s", userID, moduleKey)]; ok {
		return st, nil
	}
	return nil, nil
}

func (f *FakeUserRepository) UpdateUserModuleStatus(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string, isActive bool) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	k := fmt.Sprintf("%d:%s", userID, moduleKey)
	if st, ok := f.moduleStatuses[k]; ok {
		st.IsActive = isActive
	} else {
		f.moduleStatuses[k] = &model.UserModuleStatus{
			UserID:    userID,
			ModuleKey: model.Product(moduleKey),
			IsActive:  isActive,
		}
	}
	return nil
}

func (f *FakeUserRepository) UpdateUserGlobalActive(ctx context.Context, svc service.PostgreSQLServicer, userID int64, isActive bool) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if u, ok := f.users[userID]; ok {
		u.IsGlobalActive = isActive
	}
	return nil
}

func (f *FakeUserRepository) CountActiveModulesRemoved(ctx context.Context, svc service.PostgreSQLServicer, userID int64, keepAccess []string) (int, error) {
	return 0, nil
}

func (f *FakeUserRepository) IsTargetProtectedTCRO(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (bool, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	lvl, ok := f.accessLevels[userID]
	if !ok {
		return false, nil
	}
	return lvl == "total_control" || lvl == "read_only", nil
}

func (f *FakeUserRepository) IsActorTotalControl(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (bool, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	lvl, ok := f.accessLevels[userID]
	if !ok {
		return false, nil
	}
	return lvl == "total_control", nil
}

func (f *FakeUserRepository) UpdateUserReactivation(ctx context.Context, svc service.PostgreSQLServicer, userID int64, isTemporary bool, activePeriodUntil *time.Time) error {
	return nil
}

func (f *FakeUserRepository) SetActivationToken(userID int64, token *model.ActivationToken) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.activationTokens[userID] = token
}

func (f *FakeUserRepository) GetActiveActivationToken(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (*model.ActivationToken, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	if tok, ok := f.activationTokens[userID]; ok {
		return tok, nil
	}
	return nil, nil
}

func (f *FakeUserRepository) SupersedeActivationTokens(ctx context.Context, svc service.PostgreSQLServicer, userID int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if tok, ok := f.activationTokens[userID]; ok {
		tok.Status = "superseded"
	}
	return nil
}

func (f *FakeUserRepository) SetPendingEmailChange(userID int64, change *model.UserEmailChange) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.emailChanges[userID] = change
}

func (f *FakeUserRepository) GetPendingEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (*model.UserEmailChange, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	if ch, ok := f.emailChanges[userID]; ok {
		return ch, nil
	}
	return nil, nil
}

func (f *FakeUserRepository) ExtendEmailChangeExpiry(ctx context.Context, svc service.PostgreSQLServicer, id int64) (string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	for _, ch := range f.emailChanges {
		if ch.ID == id {
			ch.ExpiresAt = time.Now().Add(24 * time.Hour)
			return "mock-raw-token", nil
		}
	}
	return "mock-raw-token", nil
}

func (f *FakeUserRepository) SetEntitySuspended(suspended bool) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.isEntitySuspended = suspended
}

func (f *FakeUserRepository) IsEntitySuspended(ctx context.Context, svc service.PostgreSQLServicer, clientCode string) (bool, error) {
	f.mu.RLock()
	defer f.mu.RUnlock()
	return f.isEntitySuspended, nil
}
