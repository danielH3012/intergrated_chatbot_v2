package repository

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) InsertUserCredentialPublic(ctx context.Context, svc service.PostgreSQLServicer, email string, clientCode string) error {
	cred := model.UserCredential{
		Email:      email,
		ClientCode: clientCode,
	}

	_, err := svc.InsertOneWithData(ctx, "public.user_credentials", cred)
	return err
}

func (r *UserRepository) UpdateUserCredentialEmailPublic(ctx context.Context, svc service.PostgreSQLServicer, oldEmail string, newEmail string, clientCode string) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"public.user_credentials",
		sql_query.WhereQuery{
			"email":       sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: oldEmail},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
		},
		sql_query.UpdateQuery{
			"email": newEmail,
		},
	)
	return err
}

func (r *UserRepository) DeleteUserCredentialPublic(ctx context.Context, svc service.PostgreSQLServicer, email string, clientCode string) error {
	_, err := svc.DeleteManyWithFilter(
		ctx,
		"public.user_credentials",
		sql_query.WhereQuery{
			"email":       sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: email},
			"client_code": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: clientCode},
		},
	)
	return err
}
