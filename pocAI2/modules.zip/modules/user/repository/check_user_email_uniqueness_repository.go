package repository

import (
	"context"
	"errors"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"github.com/jackc/pgx/v5"
)

func (r *UserRepository) CheckEmailUniqueness(ctx context.Context, svc service.PostgreSQLServicer, email string) (bool, error) {
	builder := sql_query.NewSQLSelectBuilder[model.UserCredential]("user_credentials").
		Where(sql_query.WhereQuery{
			"email": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: email},
		}).SetLimit(1)

	query, args, err := builder.Build()
	if err != nil {
		return false, err
	}

	var user model.UserCredential
	err = svc.SelectOne(&user, ctx, query, args...)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) || strings.Contains(err.Error(), "not found") {
			return true, nil // Unique
		}
		return false, err
	}

	return false, nil // Conflict found
}
