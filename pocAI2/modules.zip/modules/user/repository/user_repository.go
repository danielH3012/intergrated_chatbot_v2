package repository

import (
	"context"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

type UserRepositor interface {
	List(ctx context.Context, svc service.PostgreSQLServicer, callerID int64, req userDto.UserListBody) (userDto.UserListResponseData, error)
	GetOneByID(ctx context.Context, svc service.PostgreSQLServicer, id int64) (*userDto.UserListItem, error)
	GetDetail(ctx context.Context, svc service.PostgreSQLServicer, id int64) (*userDto.UserDetailItem, error)
	GetOneByEmail(ctx context.Context, svc service.PostgreSQLServicer, email string) (*userDto.UserListItem, error)
	UpdateActivationStatus(ctx context.Context, svc service.PostgreSQLServicer, id int64, status string) error
	Create(ctx context.Context, svc service.PostgreSQLServicer, user model.User, access []string) error
	Update(ctx context.Context, svc service.PostgreSQLServicer, user model.User, access []string) error
	Delete(ctx context.Context, svc service.PostgreSQLServicer, id int64) error
	GenerateOptions(ctx context.Context, svc service.PostgreSQLServicer, req userDto.UserOptionsBody) (userDto.UserOptionsResponse, error)
	Dropdown(ctx context.Context, svc service.PostgreSQLServicer, req userDto.UserDropdownQuery) (userDto.UserDropdownResponse, error)
	ProductDropdown(ctx context.Context, svc service.PostgreSQLServicer, req userDto.ProductUserDropdownQuery) (userDto.UserDropdownResponse, error)
	AdminConsoleList(ctx context.Context, svc service.PostgreSQLServicer, req userDto.AcUserListBody) ([]userDto.AcUserListItem, int, error)
	AdminConsoleOptions(ctx context.Context, svc service.PostgreSQLServicer, req userDto.AcUserOptionsBody) (userDto.AcUserOptionsResponse, error)
	CheckAdminConsoleUserExists(ctx context.Context, svc service.PostgreSQLServicer, targetID int64) (exists bool, accessLevel *string, targetGroupIDs []int64, err error)
	GetAdminConsoleUserActiveRoles(ctx context.Context, svc service.PostgreSQLServicer, targetID int64) ([]userDto.AcUserActiveRolesRawRow, error)
	CheckEmailUniqueness(ctx context.Context, svc service.PostgreSQLServicer, email string) (bool, error)
	CheckEmployeeIDUniqueness(ctx context.Context, svc service.PostgreSQLServicer, employeeID string, excludeID *int64) (bool, error)
	CheckDivisionAndPositionExist(ctx context.Context, svc service.PostgreSQLServicer, divisionID int64, positionID *int64) (bool, bool, error)
	GetPositionNameByID(ctx context.Context, svc service.PostgreSQLServicer, positionID int64) (string, error)
	GetDivisionNameByID(ctx context.Context, svc service.PostgreSQLServicer, divisionID int64) (string, error)

	GetUserModuleStatus(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (*model.UserModuleStatus, error)
	UpdateUserModuleStatus(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string, isActive bool) error
	UpdateUserGlobalActive(ctx context.Context, svc service.PostgreSQLServicer, userID int64, isActive bool) error
	CountActiveModulesRemoved(ctx context.Context, svc service.PostgreSQLServicer, userID int64, keepAccess []string) (int, error)
	IsTargetProtectedTCRO(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (bool, error)
	IsActorTotalControl(ctx context.Context, svc service.PostgreSQLServicer, userID int64, moduleKey string) (bool, error)
	IsEntitySuspended(ctx context.Context, svc service.PostgreSQLServicer, clientCode string) (bool, error)
	UpdateUserReactivation(ctx context.Context, svc service.PostgreSQLServicer, userID int64, isTemporary bool, activePeriodUntil *time.Time) error

	GetActiveActivationToken(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (*model.ActivationToken, error)
	SupersedeActivationTokens(ctx context.Context, svc service.PostgreSQLServicer, userID int64) error
	GetPendingEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (*model.UserEmailChange, error)
	ExtendEmailChangeExpiry(ctx context.Context, svc service.PostgreSQLServicer, id int64) (string, error)
	StageEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64, newEmail string, clientCode string) (*model.UserEmailChange, error)
	CancelEmailChange(ctx context.Context, svc service.PostgreSQLServicer, userID int64) error
	GetPendingEmailChangeByToken(ctx context.Context, svc service.PostgreSQLServicer, tokenHash string) (*model.UserEmailChange, error)
	ConfirmEmailChangePublic(ctx context.Context, svc service.PostgreSQLServicer, tokenHash string) error
	UnconsumeEmailChangePublic(ctx context.Context, svc service.PostgreSQLServicer, tokenHash string) error
	UpdateUserEmail(ctx context.Context, svc service.PostgreSQLServicer, userID int64, newEmail string) error
	IsAuthenticatorEnrolled(ctx context.Context, svc service.PostgreSQLServicer, userID int64) (bool, error)
	ResetAuthenticatorPublic(ctx context.Context, pubSvc service.PostgreSQLServicer, userID int64, clientCode string) error
	ResetAuthenticatorTenant(ctx context.Context, tenSvc service.PostgreSQLServicer, userID int64) error

	InsertUserCredentialPublic(ctx context.Context, svc service.PostgreSQLServicer, email string, clientCode string) error
	UpdateUserCredentialEmailPublic(ctx context.Context, svc service.PostgreSQLServicer, oldEmail string, newEmail string, clientCode string) error
	DeleteUserCredentialPublic(ctx context.Context, svc service.PostgreSQLServicer, email string, clientCode string) error

	GetExpiredTemporaryUserIDs(ctx context.Context, svc service.PostgreSQLServicer, now time.Time) ([]int64, error)
	UpdateFirstLoginAt(ctx context.Context, svc service.PostgreSQLServicer, id int64, firstLoginAt time.Time) error
	UpdateAuthenticatorEnrolled(ctx context.Context, svc service.PostgreSQLServicer, id int64, enrolled bool) error
}

var _ UserRepositor = (*UserRepository)(nil)

type UserRepository struct{}

func NewUserRepository() *UserRepository {
	return &UserRepository{}
}

func (r *UserRepository) GetPositionNameByID(ctx context.Context, svc service.PostgreSQLServicer, positionID int64) (string, error) {
	var row struct {
		Name string `json:"name" column:"name"`
	}
	err := svc.SelectOne(&row, ctx, "SELECT name FROM positions WHERE id = $1", positionID)
	return row.Name, err
}

func (r *UserRepository) GetDivisionNameByID(ctx context.Context, svc service.PostgreSQLServicer, divisionID int64) (string, error) {
	var row struct {
		Name string `json:"name" column:"name"`
	}
	err := svc.SelectOne(&row, ctx, "SELECT name FROM divisions WHERE id = $1", divisionID)
	return row.Name, err
}

func (r *UserRepository) UpdateFirstLoginAt(ctx context.Context, svc service.PostgreSQLServicer, id int64, firstLoginAt time.Time) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"first_login_at": firstLoginAt,
		},
	)
	return err
}

func (r *UserRepository) UpdateAuthenticatorEnrolled(ctx context.Context, svc service.PostgreSQLServicer, id int64, enrolled bool) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"is_authenticator_enrolled": enrolled,
		},
	)
	return err
}
