package repository

import (
	"context"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) UpdateActivationStatus(ctx context.Context, svc service.PostgreSQLServicer, id int64, status string) error {
	_, err := svc.UpdateOneWithData(
		ctx,
		"users",
		sql_query.WhereQuery{
			"id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
		},
		sql_query.UpdateQuery{
			"activation_status": status,
		},
	)
	return err
}
