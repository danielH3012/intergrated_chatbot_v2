package repository

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
)

func (r *UserRepository) GetDetail(ctx context.Context, svc service.PostgreSQLServicer, id int64) (*userDto.UserDetailItem, error) {
	// The UserDetailItem struct has the same base as UserListItem, plus some fields like divisionId string.
	// Since GetUserListFilterBuilder creates a builder, we can cast it to build a different DTO.

	builder := query_builder.GetUserListFilterBuilder[userDto.UserDetailItem](userDto.UserListBody{})

	builder.Where(sql_query.WhereQuery{
		"users.id": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: id},
	})

	builder.SetLimit(1)

	query, args, err := builder.Build()
	if err != nil {
		return nil, err
	}

	var row userDto.UserDetailItem
	if err := svc.SelectOne(&row, ctx, query, args...); err != nil {
		return nil, err
	}

	return &row, nil
}
