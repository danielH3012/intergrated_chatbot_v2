package repository

import (
	"context"
	"errors"
	"strings"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
	coreDto "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/dto"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"github.com/jackc/pgx/v5"
)

func (r *UserRepository) ProductDropdown(ctx context.Context, svc service.PostgreSQLServicer, req userDto.ProductUserDropdownQuery) (userDto.UserDropdownResponse, error) {
	query, args, err := query_builder.GetProductUserDropdownQuery(req)
	if err != nil {
		return userDto.UserDropdownResponse{}, err
	}

	var rows []userDto.UserDropdownItem
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return userDto.UserDropdownResponse{}, err
	}

	if rows == nil {
		rows = []userDto.UserDropdownItem{}
	}

	return userDto.UserDropdownResponse{Data: rows}, nil
}

func (r *UserRepository) AdminConsoleList(ctx context.Context, svc service.PostgreSQLServicer, req userDto.AcUserListBody) ([]userDto.AcUserListItem, int, error) {
	paginate := req.Page > 0 && req.Limit > 0
	query, args, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, paginate)
	if err != nil {
		return nil, 0, err
	}

	var totalRecords int
	var rows []userDto.AcUserListItem

	if paginate {
		var paginatedRows []coreDto.PaginationResult[userDto.AcUserListItem]
		if err := svc.SelectMany(&paginatedRows, ctx, query, args...); err != nil {
			return nil, 0, err
		}
		res := coreHelper.FormatPaginationResult(paginatedRows)
		totalRecords = res.TotalRecords
		rows = res.Data
	} else {
		if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
			return nil, 0, err
		}
		totalRecords = len(rows)
	}

	if rows == nil {
		rows = []userDto.AcUserListItem{}
	}

	return rows, totalRecords, nil
}

func (r *UserRepository) AdminConsoleOptions(ctx context.Context, svc service.PostgreSQLServicer, req userDto.AcUserOptionsBody) (userDto.AcUserOptionsResponse, error) {
	var resp userDto.AcUserOptionsResponse
	query, args, err := query_builder.GetAdminConsoleUserListOptionsQuery(req)
	if err != nil {
		return resp, err
	}

	var rows []userDto.AcUserOptionsResponse
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return resp, err
	}

	if len(rows) == 0 {
		return resp, nil
	}

	return rows[0], nil
}

type userAdminConsoleMetaRow struct {
	ID          int64   `json:"id" column:"users.id"`
	AccessLevel *string `json:"access_level" column:"ual.access_level"`
}

type groupIDRow struct {
	GID int64 `json:"gid" column:"sub.gid"`
}

func (r *UserRepository) CheckAdminConsoleUserExists(ctx context.Context, svc service.PostgreSQLServicer, targetID int64) (bool, *string, []int64, error) {
	metaQuery := `SELECT users.id, ual.access_level
		FROM users
		JOIN user_module_status ums ON ums.user_id = users.id AND ums.module_key = 'admin_console'
		LEFT JOIN user_access_levels ual ON ual.user_id = users.id AND ual.product = 'admin_console'
		WHERE users.id = $1 AND users.deleted_at IS NULL
		LIMIT 1`

	var meta userAdminConsoleMetaRow
	if err := svc.SelectOne(&meta, ctx, metaQuery, targetID); err != nil {
		if errors.Is(err, pgx.ErrNoRows) || strings.Contains(err.Error(), "no rows in result set") {
			return false, nil, nil, nil
		}
		return false, nil, nil, err
	}
	if meta.ID == 0 {
		return false, nil, nil, nil
	}

	groupsQuery := `SELECT DISTINCT sub.gid FROM (
		SELECT admin_console_group_id AS gid
		FROM user_system_roles
		WHERE user_id = $1 AND product = 'admin_console' AND admin_console_group_id IS NOT NULL
		UNION
		SELECT admin_console_group_id AS gid
		FROM user_group_managers
		WHERE user_id = $1 AND product = 'admin_console' AND admin_console_group_id IS NOT NULL
	) sub`

	var groupRows []groupIDRow
	if err := svc.SelectMany(&groupRows, ctx, groupsQuery, targetID); err != nil {
		return false, nil, nil, err
	}

	gids := make([]int64, len(groupRows))
	for i, gr := range groupRows {
		gids[i] = gr.GID
	}

	return true, meta.AccessLevel, gids, nil
}

func (r *UserRepository) GetAdminConsoleUserActiveRoles(ctx context.Context, svc service.PostgreSQLServicer, targetID int64) ([]userDto.AcUserActiveRolesRawRow, error) {
	query := `SELECT 
		user_system_roles.scope_level,
		user_system_roles.key,
		user_system_roles.admin_console_group_id,
		user_system_roles.admin_console_group_name
		FROM user_system_roles
		WHERE user_system_roles.user_id = $1 AND user_system_roles.product = 'admin_console'
		ORDER BY user_system_roles.admin_console_group_name COLLATE "en-US-x-icu" ASC`

	var rows []userDto.AcUserActiveRolesRawRow
	if err := svc.SelectMany(&rows, ctx, query, targetID); err != nil {
		return nil, err
	}

	return rows, nil
}
