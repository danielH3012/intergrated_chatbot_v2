package repository

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *UserRepository) List(ctx context.Context, svc service.PostgreSQLServicer, callerID int64, req userDto.UserListBody) (userDto.UserListResponseData, error) {
	query, args, err := query_builder.GetUserListQuery(req, callerID, true)
	if err != nil {
		return userDto.UserListResponseData{}, err
	}

	var results []userDto.UserListResponseData
	if err := svc.SelectMany(&results, ctx, query, args...); err != nil {
		return userDto.UserListResponseData{}, err
	}
	if len(results) > 0 {
		res := results[0]
		if res.Data == nil {
			res.Data = []userDto.UserListResponseItem{}
		}
		return res, nil
	}

	return userDto.UserListResponseData{
		TotalRecords:         0,
		TotalDisabledRecords: 0,
		Data:                 []userDto.UserListResponseItem{},
	}, nil
}
