package repository

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func (r *UserRepository) GenerateOptions(ctx context.Context, svc service.PostgreSQLServicer, req userDto.UserOptionsBody) (userDto.UserOptionsResponse, error) {
	var resp userDto.UserOptionsResponse

	// We pass an empty UserListBody since UserOptionsBody doesn't currently contain filter criteria.
	// If the API design changes to support filtered options, we can pass the filter body here.
	query, args, err := query_builder.GetUserListOptionsQuery(userDto.UserListBody{}, req)
	if err != nil {
		return resp, err
	}

	rows := []userDto.UserOptionsResponse{}
	if err := svc.SelectMany(&rows, ctx, query, args...); err != nil {
		return resp, err
	}

	if len(rows) == 0 {
		return resp, nil
	}

	return rows[0], nil
}
