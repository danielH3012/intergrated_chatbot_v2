package handler

import (
	"fmt"
	"log/slog"
	"strconv"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleAdminConsoleUserDropdown handles GET /products/admin_console/users/dropdown
func (h *UserHandler) HandleAdminConsoleUserDropdown(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return coreEntity.BadRequest("Missing " + tsConstant.HEADER_CLIENT_ID).SendResponse(c)
	}

	roles, ok := tsMiddleware.GetUserRoles(c)
	if !ok {
		return coreEntity.Forbidden("Missing caller roles").SendResponse(c)
	}

	var req dto.ProductUserDropdownQuery
	if err := c.Bind().Query(&req); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	res, err := h.svc.ProductDropdown(ctx, clientCode, model.ProductAdminConsole, roles, req)
	if err != nil {
		slog.ErrorContext(ctx, "HandleAdminConsoleUserDropdown", "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Users retrieved", res.Data)
}

// HandleAdminConsoleUserList handles POST /products/admin_console/users/list
func (h *UserHandler) HandleAdminConsoleUserList(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var req dto.AcUserListBody
	if len(c.Body()) > 0 {
		if err := c.Bind().Body(&req); err != nil {
			return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
		}
	}

	res, err := h.svc.AdminConsoleList(ctx, clientCode, callerID, roles, req)
	if err != nil {
		slog.ErrorContext(ctx, "HandleAdminConsoleUserList", "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Users retrieved", res)
}

// HandleAdminConsoleUserExport handles POST /products/admin_console/users/export
func (h *UserHandler) HandleAdminConsoleUserExport(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var req dto.AcUserExportBody
	if len(c.Body()) > 0 {
		if err := c.Bind().Body(&req); err != nil {
			return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
		}
	}

	res, err := h.svc.AdminConsoleExport(ctx, clientCode, callerID, roles, req)
	if err != nil {
		slog.ErrorContext(ctx, "HandleAdminConsoleUserExport", "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	c.Set("Content-Type", res.ContentType)
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, res.Filename))

	return c.Send(res.Data)
}

// HandleAdminConsoleUserOptions handles POST /products/admin_console/users/options
func (h *UserHandler) HandleAdminConsoleUserOptions(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, _, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var req dto.AcUserOptionsBody
	if len(c.Body()) > 0 {
		if err := c.Bind().Body(&req); err != nil {
			return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
		}
	}

	res, err := h.svc.AdminConsoleOptions(ctx, clientCode, roles, req)
	if err != nil {
		slog.ErrorContext(ctx, "HandleAdminConsoleUserOptions", "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Options retrieved", res)
}

// HandleAdminConsoleUserActiveRoles handles GET /products/admin_console/users/:id/active-roles
func (h *UserHandler) HandleAdminConsoleUserActiveRoles(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, actorID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	rawID := c.Params("id")
	targetID, err := strconv.ParseInt(rawID, 10, 64)
	if err != nil || targetID <= 0 {
		return coreEntity.BadRequest("Invalid user ID").SendResponse(c)
	}

	res, err := h.svc.AdminConsoleUserActiveRoles(ctx, clientCode, actorID, roles, targetID)
	if err != nil {
		slog.ErrorContext(ctx, "HandleAdminConsoleUserActiveRoles", "targetId", targetID, "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Active roles retrieved", res)
}
