package handler

import (
	"fmt"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleResendEmail(c fiber.Ctx) error {
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	currentUserFullName := roles.FullName

	var req userDto.ResendEmailBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if len(req.IDs) == 0 {
		return coreEntity.BadRequest("ids must not be empty").SendResponse(c)
	}

	if len(req.IDs) > 1000 {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: fmt.Sprintf("You have selected %d rows, which exceeds the maximum of %d rows per bulk action. Please narrow your filter or select fewer rows.", len(req.IDs), 1000),
			Data: fiber.Map{
				"field":    "ids",
				"selected": len(req.IDs),
				"limit":    1000,
			},
		}).SendResponse(c)
	}

	res, msg, err := h.svc.ResendEmailBulk(c.Context(), clientCode, req, currentUserID, currentUserFullName)
	if err != nil {
		if len(err.Error()) > 9 && err.Error()[:9] == "cooldown:" {
			// Extract cooldown seconds
			var retryAfter int
			fmt.Sscanf(err.Error(), "cooldown:%d", &retryAfter)
			return (&coreEntity.HttpError{
				Code:    fiber.StatusTooManyRequests,
				Message: fmt.Sprintf("Please wait %d seconds before resending", retryAfter),
				Data: fiber.Map{
					"retryAfterSeconds": retryAfter,
				},
			}).SendResponse(c)
		}
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, msg, res)
}
