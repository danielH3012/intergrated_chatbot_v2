package handler

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleBulkProductStatus(c fiber.Ctx) error {
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	productId := c.Params("productId")
	if productId == "" {
		return coreEntity.BadRequest("product ID is required").SendResponse(c)
	}

	var req userDto.BulkStatusBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if len(req.IDs) == 0 {
		return coreEntity.BadRequest("ids must not be empty").SendResponse(c)
	}

	if len(req.IDs) > 1000 {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: fmt.Sprintf("You have selected %d rows, which exceeds the maximum of %d rows per bulk action. Please narrow your filter or select fewer rows.", len(req.IDs), 1000),
			Data: fiber.Map{
				"field":    "ids",
				"selected": len(req.IDs),
				"limit":    1000,
			},
		}).SendResponse(c)
	}

	isAll := true
	var allowedGroupIDs []int64
	if productId == string(model.ProductAdminConsole) {
		isActorTC := roles.IsTotalControl(enum.ModuleAccessAdminConsole)
		isActorRO := roles.IsReadOnly(enum.ModuleAccessAdminConsole)
		isAll = isActorTC || isActorRO || roles.AdminConsoleSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].Edit
		if !isAll {
			for _, g := range roles.AdminConsoleSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].Edit {
				if gid, err := strconv.ParseInt(strings.TrimSpace(g), 10, 64); err == nil {
					allowedGroupIDs = append(allowedGroupIDs, gid)
				}
			}
		}
	}

	res, msg, err := h.svc.UpdateStatusBulk(c.Context(), clientCode, req, productId, currentUserID, roles.FullName, isAll, allowedGroupIDs)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, msg, res)
}

func (h *UserHandler) HandleBulkGlobalStatus(c fiber.Ctx) error {
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var req userDto.BulkStatusBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if len(req.IDs) == 0 {
		return coreEntity.BadRequest("ids must not be empty").SendResponse(c)
	}

	if len(req.IDs) > 1000 {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: fmt.Sprintf("You have selected %d rows, which exceeds the maximum of %d rows per bulk action. Please narrow your filter or select fewer rows.", len(req.IDs), 1000),
			Data: fiber.Map{
				"field":    "ids",
				"selected": len(req.IDs),
				"limit":    1000,
			},
		}).SendResponse(c)
	}

	res, msg, err := h.svc.UpdateStatusBulk(c.Context(), clientCode, req, string(model.ProductGlobalSettings), currentUserID, roles.FullName, true, nil)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, msg, res)
}
