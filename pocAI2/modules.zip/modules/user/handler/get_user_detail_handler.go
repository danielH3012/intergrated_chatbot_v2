package handler

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"log/slog"
	"strconv"

	"github.com/gofiber/fiber/v3"

	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

func (h *UserHandler) HandleGetUserDetail(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)

	idStr := c.Params("id")
	userID, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return coreEntity.BadRequest("Invalid user ID").SendResponse(c)
	}

	res, err := h.svc.GetDetail(ctx, clientCode, userID)
	if err != nil {
		slog.ErrorContext(ctx, "user.GetDetail", "err", err)
		return coreEntity.InternalServerError(constant.MsgInternalServerError).SendResponse(c)
	}
	if res == nil {
		return coreEntity.NotFound(constant.MsgUserNotFound).SendResponse(c)
	}

	return coreHelper.Success(c, "User retrieved", res)
}
