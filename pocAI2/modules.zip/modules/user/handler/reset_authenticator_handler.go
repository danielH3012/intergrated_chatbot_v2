package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

func (h *UserHandler) HandleResetAuthenticator(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	currentUserFullName := roles.FullName

	userIDStr := c.Params("id")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil {
		return coreEntity.ToHttpError(coreEntity.BadRequest("Invalid user ID")).SendResponse(c)
	}

	outcome, err := h.svc.ResetAuthenticator(ctx, clientCode, userID, currentUserID, currentUserFullName)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Successfully resetted authenticator", fiber.Map{
		"outcome": outcome,
	})
}
