package handler

import (
	"log/slog"

	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

func (h *UserHandler) HandleUserDropdown(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return coreEntity.BadRequest("Missing " + tsConstant.HEADER_CLIENT_ID).SendResponse(c)
	}

	var req dto.UserDropdownQuery
	if err := c.Bind().Query(&req); err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	res, err := h.svc.Dropdown(ctx, clientCode, req)
	if err != nil {
		slog.ErrorContext(ctx, "HandleUserDropdown", "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Users retrieved", res.Data)
}
