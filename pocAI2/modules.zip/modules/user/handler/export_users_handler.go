package handler

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"log/slog"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleExportUsers(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return coreEntity.Unauthorized("Missing " + tsConstant.HEADER_CLIENT_ID).SendResponse(c)
	}

	var req userDto.UserExportBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	res, err := h.svc.Export(ctx, clientCode, req)
	if err != nil {
		slog.ErrorContext(ctx, "user.Export", "err", err)
		return coreEntity.InternalServerError(constant.MsgInternalServerError).SendResponse(c)
	}

	c.Set("Content-Type", res.ContentType)
	c.Set("Content-Disposition", "attachment; filename=\""+res.Filename+"\"")

	return c.Send(res.Data)
}
