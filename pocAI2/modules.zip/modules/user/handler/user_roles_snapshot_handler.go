package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// HandleUserRolesSnapshot serves GET /internal/users/:id/roles — the RBAC snapshot
// every other service fetches through ts-utils' LoadUserRoles middleware. Without
// it that middleware fails closed, so every authenticated route in every consumer
// service answers 401 no matter how valid the session is.
//
// The response must stay wrapped in the standard { status, message, data }
// envelope: LoadUserRoles unmarshals `data` into middleware.UserAccessCache.
func (h *UserHandler) HandleUserRolesSnapshot(c fiber.Ctx) error {
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return coreEntity.BadRequest("Invalid user id").SendResponse(c)
	}

	// The tenant is chosen by the caller's header, exactly as on every other
	// /internal route — the service token says which service is asking, not which
	// tenant it is asking about.
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return coreEntity.BadRequest("Missing " + tsConstant.HEADER_CLIENT_ID).SendResponse(c)
	}

	snapshot, err := h.svc.RolesSnapshot(c.Context(), userID, clientCode)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	return coreHelper.Success(c, "Successfully retrieve user roles", snapshot)
}
