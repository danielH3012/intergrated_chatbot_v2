package handler

import (
	"bytes"
	"mime/multipart"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"
	"github.com/stretchr/testify/require"
)

func multipartBody(t *testing.T, withFile bool) (*bytes.Buffer, string) {
	t.Helper()

	var body bytes.Buffer
	writer := multipart.NewWriter(&body)
	if withFile {
		part, err := writer.CreateFormFile("profilePicture", "photo.png")
		require.NoError(t, err)
		_, err = part.Write([]byte("png-bytes"))
		require.NoError(t, err)
	}
	require.NoError(t, writer.Close())

	return &body, writer.FormDataContentType()
}

func TestOptionalFormFile_Missing(t *testing.T) {
	app := fiber.New()
	var header *multipart.FileHeader
	var formErr error
	app.Post("/", func(c fiber.Ctx) error {
		header, formErr = optionalFormFile(c, "profilePicture")
		return c.SendStatus(fiber.StatusOK)
	})

	jsonReq := httptest.NewRequest(fiber.MethodPost, "/", strings.NewReader(`{}`))
	jsonReq.Header.Set(fiber.HeaderContentType, fiber.MIMEApplicationJSON)
	_, err := app.Test(jsonReq)
	require.NoError(t, err)
	require.NoError(t, formErr)
	require.Nil(t, header)

	body, contentType := multipartBody(t, false)
	formReq := httptest.NewRequest(fiber.MethodPost, "/", body)
	formReq.Header.Set(fiber.HeaderContentType, contentType)
	_, err = app.Test(formReq)
	require.NoError(t, err)
	require.NoError(t, formErr)
	require.Nil(t, header)
}

func TestOptionalFormFile_Present(t *testing.T) {
	app := fiber.New()
	var header *multipart.FileHeader
	var formErr error
	app.Post("/", func(c fiber.Ctx) error {
		header, formErr = optionalFormFile(c, "profilePicture")
		return c.SendStatus(fiber.StatusOK)
	})

	body, contentType := multipartBody(t, true)
	req := httptest.NewRequest(fiber.MethodPost, "/", body)
	req.Header.Set(fiber.HeaderContentType, contentType)

	_, err := app.Test(req)
	require.NoError(t, err)
	require.NoError(t, formErr)
	require.NotNil(t, header)
	require.Equal(t, "photo.png", header.Filename)
}
