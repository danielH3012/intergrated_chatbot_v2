package handler_test

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"github.com/gofiber/fiber/v3"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	authDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/service"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type fakePermissionsRepo struct {
	mu   sync.Mutex
	rows *authDto.UserPermissionRows
	err  error
}

func (f *fakePermissionsRepo) GetPermissionRows(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, product *model.Product) (*authDto.UserPermissionRows, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.err != nil {
		return nil, f.err
	}
	return f.rows, nil
}

func newTestApp(repo *fakePermissionsRepo) *fiber.App {
	svc := &service.UserService{}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	svc.SetPermissionsRepositoryForTest(repo)

	h := handler.NewUserHandler(svc)

	app := fiber.New()
	app.Get("/internal/users/:id/roles", h.HandleUserRolesSnapshot)
	return app
}

func samplePermissionRows(userID int64) *authDto.UserPermissionRows {
	return &authDto.UserPermissionRows{
		Profile: authDto.UserProfileRow{
			ID:        userID,
			FirstName: "Budi",
			LastName:  "Santoso",
			Email:     "budi@example.com",
		},
		ModuleStatus: []model.UserModuleStatus{
			{ModuleKey: model.ProductGlobalSettings, IsActive: true},
		},
		AccessLevels: []model.UserAccessLevel{
			{Product: model.ProductGlobalSettings, AccessLevel: model.AccessLevelTotalControl},
		},
	}
}

func doRequest(app *fiber.App, path string, clientID string) (*http.Response, string) {
	req := httptest.NewRequest(http.MethodGet, path, nil)
	if clientID != "" {
		req.Header.Set(tsConstant.HEADER_CLIENT_ID, clientID)
	}
	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	raw, _ := io.ReadAll(res.Body)
	return res, string(raw)
}

func TestHandleUserRolesSnapshot_200_Success(t *testing.T) {
	repo := &fakePermissionsRepo{rows: samplePermissionRows(42)}
	app := newTestApp(repo)

	res, body := doRequest(app, "/internal/users/42/roles", "client_acme")
	assert.Equal(t, fiber.StatusOK, res.StatusCode)

	var envelope struct {
		Message string                       `json:"message"`
		Data    tsMiddleware.UserAccessCache `json:"data"`
	}
	require.NoError(t, json.Unmarshal([]byte(body), &envelope))
	assert.Equal(t, "Successfully retrieve user roles", envelope.Message)
	assert.Equal(t, 42, envelope.Data.ID)
	assert.Equal(t, "Budi Santoso", envelope.Data.FullName)
	assert.Equal(t, "client_acme", envelope.Data.ClientID)
}

func TestHandleUserRolesSnapshot_400_InvalidUserID(t *testing.T) {
	repo := &fakePermissionsRepo{rows: samplePermissionRows(42)}
	app := newTestApp(repo)

	res, body := doRequest(app, "/internal/users/not-a-number/roles", "client_acme")
	assert.Equal(t, fiber.StatusBadRequest, res.StatusCode)
	assert.Contains(t, body, "Invalid user id")
}

func TestHandleUserRolesSnapshot_400_MissingClientID(t *testing.T) {
	repo := &fakePermissionsRepo{rows: samplePermissionRows(42)}
	app := newTestApp(repo)

	res, body := doRequest(app, "/internal/users/42/roles", "")
	assert.Equal(t, fiber.StatusBadRequest, res.StatusCode)
	assert.Contains(t, body, "Missing "+tsConstant.HEADER_CLIENT_ID)
}

func TestHandleUserRolesSnapshot_404_NotFound(t *testing.T) {
	repo := &fakePermissionsRepo{err: coreEntity.NotFound("User not found")}
	app := newTestApp(repo)

	res, body := doRequest(app, "/internal/users/999/roles", "client_acme")
	assert.Equal(t, fiber.StatusNotFound, res.StatusCode)
	assert.Contains(t, body, "User not found")
}

func TestHandleUserRolesSnapshot_500_InternalServerError(t *testing.T) {
	repo := &fakePermissionsRepo{err: coreEntity.InternalServerError("database connection error")}
	app := newTestApp(repo)

	res, body := doRequest(app, "/internal/users/42/roles", "client_acme")
	assert.Equal(t, fiber.StatusInternalServerError, res.StatusCode)
	assert.Contains(t, body, "database connection error")
}
