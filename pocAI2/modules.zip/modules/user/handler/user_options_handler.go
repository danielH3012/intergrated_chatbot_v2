package handler

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"log/slog"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleUserOptions(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return coreEntity.BadRequest("Missing " + tsConstant.HEADER_CLIENT_ID).SendResponse(c)
	}

	var req userDto.UserOptionsBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	res, err := h.svc.GenerateOptions(ctx, clientCode, req)
	if err != nil {
		slog.ErrorContext(ctx, "user.Options", "err", err)
		return coreEntity.InternalServerError(constant.MsgInternalServerError).SendResponse(c)
	}
	return coreHelper.Success(c, "Options retrieved", res)
}
