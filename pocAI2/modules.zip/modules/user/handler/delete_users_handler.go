package handler

import (
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleDeleteUsers(c fiber.Ctx) error {
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var req userDto.DeleteUsersBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	if len(req.IDs) > 1000 {
		return (&coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: "You have selected too many rows, which exceeds the maximum of 1000 rows per bulk action.",
			Data: fiber.Map{
				"field":    "ids",
				"selected": len(req.IDs),
				"limit":    1000,
			},
		}).SendResponse(c)
	}

	results, err := h.svc.Delete(c.Context(), clientCode, req, currentUserID, roles.FullName)
	if err != nil {
		slog.ErrorContext(c.Context(), "user.Delete", "err", err)
		return coreEntity.InternalServerError(constant.MsgInternalServerError).SendResponse(c)
	}

	deletedCount := 0
	failedCount := 0
	for _, r := range results {
		if r.Status == "deleted" {
			deletedCount++
		} else {
			failedCount++
		}
	}

	msg := ""
	if failedCount == 0 {
		msg = fmt.Sprintf("Success, %d users have been deleted.", deletedCount)
	} else if deletedCount == 0 {
		msg = fmt.Sprintf("Failed to delete %d users.", failedCount)
	} else {
		msg = fmt.Sprintf("%d deleted, %d failed.", deletedCount, failedCount)
	}

	return coreHelper.Success(c, msg, fiber.Map{"results": results})
}
