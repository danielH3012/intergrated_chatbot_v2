package handler_test

import (
	"encoding/json"
	"io"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	"github.com/gofiber/fiber/v3"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

var (
	testAppOnce   sync.Once
	sharedTestApp *fiber.App
)

func getSharedTestApp() *fiber.App {
	testAppOnce.Do(func() {
		fakeRepo := repository.NewFakeUserRepository()
		roles := tsMiddleware.UserAccessCache{
			ID:       1,
			FullName: "Super Admin",
			ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
				enum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		}
		sharedTestApp = newTestUserApp(fakeRepo, roles)
	})
	return sharedTestApp
}

func doUserRequest(app *fiber.App, method, path, body string) (int, map[string]any) {
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "testclient")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()

	raw, _ := io.ReadAll(res.Body)
	var resp map[string]any
	_ = json.Unmarshal(raw, &resp)
	return res.StatusCode, resp
}

func TestCreateUser_EmojiValidation(t *testing.T) {
	app := getSharedTestApp()

	t.Run("emoji in firstName returns 422", func(t *testing.T) {
		payload := `{
			"firstName": "John 😀",
			"lastName": "Doe",
			"email": "john.doe@example.com",
			"divisionId": 1,
			"access": ["global_settings"]
		}`
		status, body := doUserRequest(app, fiber.MethodPost, "/users", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "First Name contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "firstName", data["field"])
	})

	t.Run("emoji in lastName returns 422", func(t *testing.T) {
		payload := `{
			"firstName": "John",
			"lastName": "Doe 👍",
			"email": "john.doe@example.com",
			"divisionId": 1,
			"access": ["global_settings"]
		}`
		status, body := doUserRequest(app, fiber.MethodPost, "/users", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "Last Name contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "lastName", data["field"])
	})

	t.Run("emoji in employeeId returns 422", func(t *testing.T) {
		payload := `{
			"firstName": "John",
			"lastName": "Doe",
			"email": "john.doe@example.com",
			"divisionId": 1,
			"employeeId": "EMP-🔥",
			"access": ["global_settings"]
		}`
		status, body := doUserRequest(app, fiber.MethodPost, "/users", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "Employee ID contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "employeeId", data["field"])
	})
}

func TestUpdateUser_EmojiValidation(t *testing.T) {
	app := getSharedTestApp()

	t.Run("emoji in firstName returns 422", func(t *testing.T) {
		payload := `{
			"firstName": "Jane 🎉",
			"lastName": "Doe",
			"email": "jane.doe@example.com",
			"divisionId": 1,
			"access": ["global_settings"]
		}`
		status, body := doUserRequest(app, fiber.MethodPatch, "/users/100", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "First Name contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "firstName", data["field"])
	})

	t.Run("emoji in lastName returns 422", func(t *testing.T) {
		payload := `{
			"firstName": "Jane",
			"lastName": "Doe 🚀",
			"email": "jane.doe@example.com",
			"divisionId": 1,
			"access": ["global_settings"]
		}`
		status, body := doUserRequest(app, fiber.MethodPatch, "/users/100", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "Last Name contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "lastName", data["field"])
	})

	t.Run("emoji in employeeId returns 422", func(t *testing.T) {
		payload := `{
			"firstName": "Jane",
			"lastName": "Doe",
			"email": "jane.doe@example.com",
			"divisionId": 1,
			"employeeId": "EMP-🔥",
			"access": ["global_settings"]
		}`
		status, body := doUserRequest(app, fiber.MethodPatch, "/users/100", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "Employee ID contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "employeeId", data["field"])
	})
}

func TestCheckAvailability_EmojiValidation(t *testing.T) {
	app := getSharedTestApp()

	t.Run("emoji in employeeId returns 422", func(t *testing.T) {
		payload := `{"employeeId": "EMP-🔥"}`
		status, body := doUserRequest(app, fiber.MethodPost, "/users/check-availability", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "Employee ID contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "employeeId", data["field"])
	})

	t.Run("emoji in email returns 422", func(t *testing.T) {
		payload := `{"email": "john😀@example.com"}`
		status, body := doUserRequest(app, fiber.MethodPost, "/users/check-availability", payload)
		assert.Equal(t, fiber.StatusUnprocessableEntity, status)
		assert.Equal(t, "Email contains invalid characters", body["message"])
		data, ok := body["data"].(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "email", data["field"])
	})
}
