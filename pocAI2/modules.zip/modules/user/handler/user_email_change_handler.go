package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleCancelEmailChange(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	currentUserFullName := roles.FullName

	userIDStr := c.Params("id")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil {
		return coreEntity.ToHttpError(coreEntity.BadRequest("Invalid user ID")).SendResponse(c)
	}

	err = h.svc.CancelEmailChange(ctx, clientCode, userID, currentUserID, currentUserFullName)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return c.SendStatus(fiber.StatusNoContent)
}

func (h *UserHandler) HandleEmailChangeConfirm(c fiber.Ctx) error {
	ctx := c.Context()

	var req struct {
		Token string `json:"token"`
	}
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	if req.Token == "" {
		return coreEntity.ToHttpError(coreEntity.BadRequest("Invalid or malformed token.")).SendResponse(c)
	}

	newEmail, err := h.svc.ConfirmEmailChange(ctx, req.Token)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Email updated successfully", fiber.Map{
		"email": newEmail,
	})
}

func (h *UserHandler) HandleInitiateEmailChange(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}
	currentUserFullName := roles.FullName

	userIDStr := c.Params("id")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil {
		return coreEntity.ToHttpError(coreEntity.BadRequest("Invalid user ID")).SendResponse(c)
	}

	var req userDto.UpdateUserEmailBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	modelData, err := h.svc.InitiateEmailChange(ctx, clientCode, userID, req.NewEmail, currentUserID, currentUserFullName)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.SendResponse(c, fiber.StatusAccepted, modelData, "Confirmation email sent", nil)
}
