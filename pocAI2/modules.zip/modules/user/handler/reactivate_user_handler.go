package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleReactivateUser(c fiber.Ctx) error {
	clientCode, roles, currentUserID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	userIDStr := c.Params("userId")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil {
		return coreEntity.ToHttpError(coreEntity.BadRequest("Invalid user ID")).SendResponse(c)
	}

	var req userDto.ReactivateBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	err = h.svc.ReactivateUser(c.Context(), clientCode, userID, req, currentUserID, roles.FullName)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "User updated successfully.", nil)
}
