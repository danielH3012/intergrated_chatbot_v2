package handler

import (
	"strconv"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// HandleListUsers returns the full list of users in the caller's tenant.
func (h *UserHandler) HandleListUsers(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode := c.Get(tsConstant.HEADER_CLIENT_ID)
	if clientCode == "" {
		return coreEntity.BadRequest("Missing " + tsConstant.HEADER_CLIENT_ID).SendResponse(c)
	}

	var callerID int64
	if uidStr := c.Get(tsConstant.HEADER_USER_ID); uidStr != "" {
		callerID, _ = strconv.ParseInt(uidStr, 10, 64)
	}

	var req userDto.UserListBody
	if err := c.Bind().JSON(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}

	res, err := h.svc.List(ctx, clientCode, callerID, req)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.Success(c, "Users retrieved", res)
}
