package handler

import (
	"encoding/json"
	"log/slog"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v3"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreHelper "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

func (h *UserHandler) HandleCreateUser(c fiber.Ctx) error {
	ctx := c.Context()
	clientCode, roles, callerID, err := tsMiddleware.RequestIdentity(c)
	if err != nil {
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	var req userDto.UserBody
	if err := c.Bind().Body(&req); err != nil {
		return coreEntity.BadRequest("Invalid request body", validator.ParseBindError(err)).SendResponse(c)
	}
	accessStr := c.FormValue("access")
	if accessStr != "" {
		if err := json.Unmarshal([]byte(accessStr), &req.Access); err != nil {
			return coreEntity.BadRequest("Invalid access format").SendResponse(c)
		}
	}

	customFieldsStr := c.FormValue("customFields")
	if customFieldsStr != "" {
		if err := json.Unmarshal([]byte(customFieldsStr), &req.CustomFields); err != nil {
			return coreEntity.BadRequest("Invalid custom fields format").SendResponse(c)
		}
	}

	if err := validator.Validate.Struct(req); err != nil {
		return helper.ValidationError(err).SendResponse(c)
	}

	trimmedFirstName := strings.TrimSpace(req.FirstName)
	trimmedLastName := strings.TrimSpace(req.LastName)
	var employeeID *string
	if req.EmployeeID != nil && strings.TrimSpace(*req.EmployeeID) != "" {
		trimmedEmp := strings.TrimSpace(*req.EmployeeID)
		employeeID = &trimmedEmp
	}

	if httpErr := helper.ValidateUserEmojis(trimmedFirstName, trimmedLastName, employeeID); httpErr != nil {
		return httpErr.SendResponse(c)
	}

	fileHeader, err := optionalFormFile(c, "profilePicture")
	if err != nil {
		return coreEntity.BadRequest("Invalid profile picture").SendResponse(c)
	}

	var tagID *int64
	if req.TagID != nil && *req.TagID != "" {
		parsedTag, err := strconv.ParseInt(*req.TagID, 10, 64)
		if err != nil {
			return coreEntity.BadRequest("Invalid tag ID format").SendResponse(c)
		}
		tagID = &parsedTag
	}

	param := service.CreateUserParam{
		ClientCode:          clientCode,
		CurrentUserID:       &callerID,
		CurrentUserFullName: roles.FullName,
		FirstName:           trimmedFirstName,
		LastName:            trimmedLastName,
		Email:               strings.TrimSpace(req.Email),
		EmployeeID:          employeeID,
		PositionID:          req.PositionID,
		DivisionID:          req.DivisionID,
		TagID:               tagID,
		ActivePeriodUntil:   req.ActivePeriodUntil,
		Access:              req.Access,
		CustomFields:        req.CustomFields,
		ProfilePicture:      fileHeader,
	}

	id, err := h.svc.Create(ctx, param)
	if err != nil {
		slog.ErrorContext(ctx, "user.Create", "err", err)
		return coreEntity.ToHttpError(err).SendResponse(c)
	}

	return coreHelper.SendResponse(c, fiber.StatusCreated, map[string]any{"_id": id}, "User created successfully.", nil)
}
