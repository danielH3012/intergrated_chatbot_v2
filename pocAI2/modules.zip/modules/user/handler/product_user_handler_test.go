package handler_test

import (
	"context"
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v3"
	"github.com/stretchr/testify/assert"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/service"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

func newTestUserApp(fakeRepo *repository.FakeUserRepository, roles tsMiddleware.UserAccessCache) *fiber.App {
	svc := service.NewUserService("testdb", fakeRepo, nil, nil, nil, "", nil, nil)
	svc.SetServiceFactoryForTest(func(string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	app := fiber.New()
	rolesFetcher := func(ctx context.Context, userID, clientID string) (tsMiddleware.UserAccessCache, error) {
		return roles, nil
	}

	app.Use(func(c fiber.Ctx) error {
		c.Locals(tsMiddleware.UserRolesKey, roles)
		return c.Next()
	})

	user.SetupRoutes(app, rolesFetcher, svc)
	return app
}

func TestHandleProductUserDropdown_Success_TotalControl(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1001,
		FirstName:        "Budi",
		LastName:         "Santoso",
		ActivationStatus: "Activated",
	})

	roles := tsMiddleware.UserAccessCache{
		ID:       1,
		FullName: "Admin",
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/dropdown", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)

	var body struct {
		Message string `json:"message"`
		Data    []struct {
			ID       string `json:"_id"`
			FullName string `json:"fullName"`
		} `json:"data"`
	}
	err = json.NewDecoder(res.Body).Decode(&body)
	assert.NoError(t, err)
	assert.Equal(t, "Users retrieved", body.Message)
	assert.Len(t, body.Data, 1)
	assert.Equal(t, "1001", body.Data[0].ID)
	assert.Equal(t, "Budi Santoso", body.Data[0].FullName)
}

func TestHandleProductUserDropdown_Success_ReadOnly(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1002,
		FirstName:        "Siti",
		LastName:         "Rahma",
		ActivationStatus: "Activated",
	})

	roles := tsMiddleware.UserAccessCache{
		ID:       2,
		FullName: "Auditor",
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsReadOnly: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/dropdown", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "2")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)
}

func TestHandleProductUserDropdown_Forbidden_NoPermissions(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID:       99,
		FullName: "Regular User",
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: false, IsReadOnly: false},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/dropdown", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "99")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusForbidden, res.StatusCode)
}

func TestHandleProductUserDropdown_BadRequest_MissingClientID(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/dropdown", nil)
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusUnauthorized, res.StatusCode)
}

func TestHandleProductUserDropdown_Success_ManageUserAndRole(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1003,
		FirstName:        "Joko",
		LastName:         "Widodo",
		ActivationStatus: "Activated",
	})

	roles := tsMiddleware.UserAccessCache{
		ID:       3,
		FullName: "Role Manager",
	}
	roles.AdminConsoleSystemRole.GlobalRole = map[enum.SystemRoleKey]tsMiddleware.Permissions[bool]{
		enum.SystemRoleKeyManageUserAndRole: {View: true},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/dropdown", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "3")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)
}

func TestHandleProductUserDropdown_NotFound_UnknownRoute(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/unknown_product/users/dropdown", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusNotFound, res.StatusCode)
}

func TestHandleAdminConsoleUserList_Success_TotalControl(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1001,
		FirstName:        "Budi",
		LastName:         "Santoso",
		Email:            "budi@example.com",
		ActivationStatus: "Activated",
	})

	roles := tsMiddleware.UserAccessCache{
		ID:       1,
		FullName: "Admin",
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"page": 1, "limit": 10}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/list", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)

	var resp struct {
		Message string             `json:"message"`
		Data    dto.AcUserListData `json:"data"`
	}
	err = json.NewDecoder(res.Body).Decode(&resp)
	assert.NoError(t, err)
	assert.Equal(t, "Users retrieved", resp.Message)
	assert.Equal(t, 1, resp.Data.TotalRecords)
	assert.False(t, resp.Data.EntitySuspended)
	assert.Len(t, resp.Data.Data, 1)
	assert.Equal(t, "1001", resp.Data.Data[0].ID)
	assert.Equal(t, "Budi Santoso", resp.Data.Data[0].FullName)
	assert.True(t, resp.Data.Data[0].SystemPermissions.ManageUserAndRole.Update)
}

func TestHandleAdminConsoleUserList_GroupFilter_Forbidden(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID:       2,
		FullName: "Group Manager",
	}
	roles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"101"},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"group": ["999"]}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/list", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "2")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusForbidden, res.StatusCode)
}

func TestHandleAdminConsoleUserList_MissingClientID(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/list", nil)
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusUnauthorized, res.StatusCode)
}

func TestHandleAdminConsoleUserOptions_Success_TotalControl(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID:       1,
		FullName: "Admin",
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"roleOptions": true, "statusOptions": true}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/options", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)

	var resp struct {
		Message string                    `json:"message"`
		Data    dto.AcUserOptionsResponse `json:"data"`
	}
	err = json.NewDecoder(res.Body).Decode(&resp)
	assert.NoError(t, err)
	assert.Equal(t, "Options retrieved", resp.Message)
	assert.Equal(t, 15, len(resp.Data.RoleOptions))
	assert.Equal(t, 2, len(resp.Data.StatusOptions))
}

func TestHandleAdminConsoleUserOptions_Forbidden_GroupFilter(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID:       2,
		FullName: "Group Manager",
	}
	roles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"101"},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"group": ["999"]}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/options", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "2")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusForbidden, res.StatusCode)
}

func TestHandleAdminConsoleUserOptions_MissingClientID(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/options", nil)
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusUnauthorized, res.StatusCode)
}

func TestHandleAdminConsoleUserActiveRoles_Success(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	targetID := int64(2001)
	fakeRepo.AddUser(&model.User{
		ID:        targetID,
		FirstName: "John",
		LastName:  "Doe",
	})
	g1 := "Head Office"
	gid1 := int64(101)
	fakeRepo.SetUserActiveRoles(targetID, []dto.AcUserActiveRolesRawRow{
		{
			ScopeLevel: "global",
			Key:        "manage_device_master_data",
		},
		{
			ScopeLevel:            "group",
			Key:                   "manage_group",
			AdminConsoleGroupID:   &gid1,
			AdminConsoleGroupName: &g1,
		},
	})

	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/2001/active-roles", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)

	var resp struct {
		StatusCode int                           `json:"statusCode"`
		Message    string                        `json:"message"`
		Data       dto.AcUserActiveRolesResponse `json:"data"`
	}
	_ = json.NewDecoder(res.Body).Decode(&resp)
	assert.Equal(t, 2, resp.Data.ActiveRoles)
	assert.Equal(t, 1, len(resp.Data.GlobalRoles))
	assert.Equal(t, "Manage device master data", resp.Data.GlobalRoles[0])
	assert.Equal(t, 1, len(resp.Data.GroupRoles))
	assert.Equal(t, "Manage group", resp.Data.GroupRoles[0].Role)
	assert.Equal(t, 1, resp.Data.GroupRoles[0].GroupCount)
	assert.Equal(t, []string{"Head Office"}, resp.Data.GroupRoles[0].Groups)
}

func TestHandleAdminConsoleUserActiveRoles_InvalidID(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/invalid-id/active-roles", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusBadRequest, res.StatusCode)
}

func TestHandleAdminConsoleUserActiveRoles_NotFound(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodGet, "/products/admin_console/users/99999/active-roles", nil)
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusNotFound, res.StatusCode)
}

func TestHandleAdminConsoleUserExport_Success_CSV(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1001,
		FirstName:        "John",
		LastName:         "Doe",
		Email:            "john.doe@example.com",
		ActivationStatus: "Activated",
	})
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"format":"csv"}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/export", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)
	assert.Equal(t, "text/csv", res.Header.Get("Content-Type"))
	assert.Contains(t, res.Header.Get("Content-Disposition"), "attachment; filename=\"Users.csv\"")
}

func TestHandleAdminConsoleUserExport_Success_XLSX(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1001,
		FirstName:        "John",
		LastName:         "Doe",
		Email:            "john.doe@example.com",
		ActivationStatus: "Activated",
	})
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"format":"xlsx"}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/export", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusOK, res.StatusCode)
	assert.Equal(t, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", res.Header.Get("Content-Type"))
	assert.Contains(t, res.Header.Get("Content-Disposition"), "attachment; filename=\"Users.xlsx\"")
}

func TestHandleAdminConsoleUserExport_Forbidden(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	// Roles without admin console access
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
	}
	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"format":"csv"}`
	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/export", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusForbidden, res.StatusCode)
}

func TestHandleAdminConsoleUserExport_InvalidJSON(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/users/export", strings.NewReader(`{invalid`))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusBadRequest, res.StatusCode)
}

func TestHandleBulkProductStatus_Forbidden(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
	}
	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"ids":["100"],"isActive":false}`
	req := httptest.NewRequest(fiber.MethodPost, "/users/products/admin_console/status/bulk", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusForbidden, res.StatusCode)
}

func TestHandleBulkProductStatus_InvalidJSON(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodPost, "/users/products/admin_console/status/bulk", strings.NewReader(`{bad json`))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusBadRequest, res.StatusCode)
}

func TestHandleResendEmail_Forbidden(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
	}
	app := newTestUserApp(fakeRepo, roles)

	reqBody := `{"ids":["100"],"product":"admin_console"}`
	req := httptest.NewRequest(fiber.MethodPost, "/users/resend-email", strings.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusForbidden, res.StatusCode)
}

func TestHandleResendEmail_InvalidJSON(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	roles := tsMiddleware.UserAccessCache{
		ID: 1,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	app := newTestUserApp(fakeRepo, roles)

	req := httptest.NewRequest(fiber.MethodPost, "/users/resend-email", strings.NewReader(`{bad json`))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Client-ID", "client_1")
	req.Header.Set("X-User-ID", "1")

	res, err := app.Test(req)
	assert.NoError(t, err)
	assert.Equal(t, fiber.StatusBadRequest, res.StatusCode)
}
