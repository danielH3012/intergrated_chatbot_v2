package handler

import (
	"errors"
	"mime/multipart"

	"github.com/gofiber/fiber/v3"
	"github.com/valyala/fasthttp"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/service"
)

type UserHandler struct {
	svc *service.UserService
}

func NewUserHandler(svc *service.UserService) *UserHandler {
	return &UserHandler{svc: svc}
}

// optionalFormFile returns the file stored under key, or nil when the request has no multipart
// body or no part with that key — both normal for an optional upload.
func optionalFormFile(c fiber.Ctx, key string) (*multipart.FileHeader, error) {
	header, err := c.FormFile(key)
	if errors.Is(err, fasthttp.ErrNoMultipartForm) || errors.Is(err, fasthttp.ErrMissingFile) {
		return nil, nil
	}
	return header, err
}
