package dto

// DeleteUsersBody represents the payload for the bulk delete endpoint.
type DeleteUsersBody struct {
	IDs []string `json:"ids"`
}

// DeleteUserResult represents the result of a single user deletion.
type DeleteUserResult struct {
	ID     string  `json:"_id"`
	Status string  `json:"status"` // "deleted" or "blocked"
	Reason *string `json:"reason"` // null, "self_delete", "default_user", "pov_blocked", "not_found"
}
