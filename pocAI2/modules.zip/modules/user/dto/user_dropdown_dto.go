package dto

// UserDropdownQuery represents the payload for the GET /v2/iam/users/dropdown endpoint.
type UserDropdownQuery struct {
	ActivationStatus string `query:"activationStatus"`
	Status           *bool  `query:"status"`
}

// UserDropdownItem represents a single item in the dropdown response.
type UserDropdownItem struct {
	ID       string `json:"_id"            column:"users.id::text"`
	FullName string `json:"fullName"       column:"users.full_name"`
}

// UserDropdownResponse represents the wrapper object for dropdown.
type UserDropdownResponse struct {
	Data []UserDropdownItem `json:"data"`
}
