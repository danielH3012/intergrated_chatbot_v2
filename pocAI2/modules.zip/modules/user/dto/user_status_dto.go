package dto

type BulkStatusResult struct {
	ID     string  `json:"_id"`
	Status string  `json:"status"`
	Reason *string `json:"reason"`
}

type BulkStatusBody struct {
	IDs      []string `json:"ids" validate:"required,min=1,max=1000"`
	IsActive *bool    `json:"isActive" validate:"required"`
}

type BulkStatusResponse struct {
	Results []BulkStatusResult `json:"results"`
}

type BulkProductStatusBody struct {
	IDs      []string `json:"ids" validate:"required,min=1,max=1000"`
	IsActive *bool    `json:"isActive" validate:"required"`
}

type ResendEmailBody struct {
	IDs     []string `json:"ids" validate:"required,min=1,max=1000"`
	Product string   `json:"product"`
}

type ResendResult struct {
	ID                string  `json:"_id"`
	Status            string  `json:"status"`
	Type              *string `json:"type"`
	Reason            *string `json:"reason"`
	RetryAfterSeconds *int    `json:"retryAfterSeconds"`
}

type ResendResponse struct {
	Results []ResendResult `json:"results"`
}

type ReactivateBody struct {
	Action            string `json:"action" validate:"required,oneof=extend make_permanent"`
	ActivePeriodUntil *int64 `json:"activePeriodUntil"`
}
