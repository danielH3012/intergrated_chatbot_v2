package dto

// UserBody represents the multipart form payload for create and patch endpoints.
type UserBody struct {
	FirstName         string         `json:"firstName" form:"firstName" validate:"required,max=120"`
	LastName          string         `json:"lastName" form:"lastName" validate:"required,max=120"`
	Email             string         `json:"email" form:"email" validate:"required,email,max=120"`
	EmployeeID        *string        `json:"employeeId" form:"employeeId" validate:"omitempty,max=120"`
	PositionID        *int64         `json:"positionId" form:"positionId"`
	DivisionID        int64          `json:"divisionId" form:"divisionId" validate:"required"`
	TagID             *string        `json:"tagId" form:"tagId"`
	ActivePeriodUntil *int64         `json:"activePeriodUntil" form:"activePeriodUntil"`
	Access            []string       `json:"access" form:"access"`             // Parsed manually from JSON string
	CustomFields      map[string]any `json:"customFields" form:"customFields"` // Parsed manually from JSON string
}
