package dto

type UserAvailabilityBody struct {
	Email      *string `json:"email"`
	EmployeeID *string `json:"employeeId"`
}

type FieldAvailability struct {
	Available *bool `json:"available"`
}

type UserAvailabilityResponse struct {
	Email      FieldAvailability `json:"email"`
	EmployeeID FieldAvailability `json:"employeeId"`
}
