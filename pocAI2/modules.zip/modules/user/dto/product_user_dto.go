package dto

import (
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
)

// ProductUserDropdownQuery represents the request filters and authorization scope
// for GET /products/:product/users/dropdown.
type ProductUserDropdownQuery struct {
	ActivationStatus string `query:"activationStatus"`
	Status           *bool  `query:"status"`
	Product          model.Product
	AllowedGroupIDs  []int64
	IsAllGroups      bool
}

// AcUserListBody represents request payload for POST /v2/iam/products/admin_console/users/list
type AcUserListBody struct {
	Page              int      `json:"page"`
	Limit             int      `json:"limit"`
	Search            string   `json:"search"`
	SortBy            string   `json:"sortBy"`
	SortOrder         int      `json:"sortOrder"`
	Columns           []string `json:"columns"`
	Group             []string `json:"group"`
	Position          []string `json:"position"`
	Division          []string `json:"division"`
	Status            []string `json:"status"`
	ActivationStatus  []string `json:"activationStatus"`
	Role              []string `json:"role"`
	TemporaryStatus   []string `json:"temporaryStatus"`
	ActivePeriodUntil []int64  `json:"activePeriodUntil"`
	ModifiedBy        []string `json:"modifiedBy"`
	UpdatedAt         []int64  `json:"updatedAt"`

	// Internal server context
	ActorID         int64   `json:"-"`
	AllowedGroupIDs []int64 `json:"-"`
	IsAllGroups     bool    `json:"-"`
}

type CrudPermission struct {
	Create bool `json:"create"`
	Read   bool `json:"read"`
	Update bool `json:"update"`
	Delete bool `json:"delete"`
}

type SystemPermissions struct {
	ManageUserAndRole CrudPermission `json:"manageUserAndRole"`
}

type AcUserListItem struct {
	ID                string            `json:"_id"               column:"users.id::text"`
	IsActive          bool              `json:"isActive"          column:"ums.is_active"            export:"Active"`
	FullName          string            `json:"fullName"          column:"users.full_name"          export:"Full Name"`
	Email             string            `json:"email"             column:"users.email"              export:"Email"`
	Role              string            `json:"role"              column:"CASE WHEN ual.access_level = 'total_control' THEN 'Total Control' WHEN ual.access_level = 'read_only' THEN 'Read Only' ELSE (SELECT count(*)::text FROM user_system_roles usr WHERE usr.user_id = users.id AND usr.product = 'admin_console') END" export:"Role"`
	Position          *string           `json:"position"          column:"positions.name"           export:"Position"`
	Division          *string           `json:"division"          column:"divisions.name"           export:"Division"`
	EmployeeID        *string           `json:"employeeId"        column:"users.employee_id"        export:"Employee ID"`
	ModifiedBy        *string           `json:"modifiedBy"        column:"mod_users.full_name"      export:"Modified By"`
	UpdatedAt         *time.Time        `json:"updatedAt"         column:"ums.updated_at"           export:"Last Updated"`
	ActivationStatus  string            `json:"activationStatus"  column:"(CASE WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END)" export:"Activation Status"`
	TemporaryStatus   string            `json:"temporaryStatus"   column:"CASE WHEN COALESCE(users.is_temporary, false) THEN 'Yes' ELSE 'No' END" export:"Temporary Status"`
	ActivePeriodUntil *time.Time        `json:"activePeriodUntil" column:"users.active_period_until" export:"Active Period Until"`
	TagCode           *string           `json:"tagCode"           column:"users.tag_code"           export:"TAG"`
	ProfilePicture    *string           `json:"profilePicture"    column:"users.profile_picture"`
	IsActiveGlobal    bool              `json:"isActiveGlobal"    column:"users.is_global_active"`
	IsDefault         bool              `json:"isDefault"         column:"COALESCE(users.is_default, false)"`
	PendingEmail      *string           `json:"pendingEmail"      column:"uec.new_email"`
	EntityType        string            `json:"entityType"        column:"'principal'"`
	SystemPermissions SystemPermissions `json:"systemPermissions"`

	// Internal raw fields for service permissions resolution
	AccessLevel       *string `json:"-" column:"ual.access_level"`
	TargetGroupIDsStr *string `json:"-" column:"(SELECT string_agg(DISTINCT grp.gid::text, ',') FROM (SELECT admin_console_group_id AS gid FROM user_system_roles WHERE user_id = users.id AND product = 'admin_console' AND admin_console_group_id IS NOT NULL UNION SELECT admin_console_group_id AS gid FROM user_group_managers WHERE user_id = users.id AND product = 'admin_console' AND admin_console_group_id IS NOT NULL) grp)"`
}

// AcUserExportBody represents request payload for POST /v2/iam/products/admin_console/users/export
type AcUserExportBody struct {
	AcUserListBody
	Format string `json:"format"`
}

type AcUserListData struct {
	TotalRecords    int              `json:"totalRecords"`
	EntitySuspended bool             `json:"entitySuspended"`
	Data            []AcUserListItem `json:"data"`
}

// AcUserOptionsBody represents request payload for POST /v2/iam/products/admin_console/users/options
type AcUserOptionsBody struct {
	AcUserListBody

	PositionOptions         bool `json:"positionOptions"`
	DivisionOptions         bool `json:"divisionOptions"`
	StatusOptions           bool `json:"statusOptions"`
	ActivationStatusOptions bool `json:"activationStatusOptions"`
	RoleOptions             bool `json:"roleOptions"`
	TemporaryStatusOptions  bool `json:"temporaryStatusOptions"`
	ModifiedByOptions       bool `json:"modifiedByOptions"`
}

// AcUserOptionsResponse represents response payload for POST /v2/iam/products/admin_console/users/options
type AcUserOptionsResponse struct {
	PositionOptions         []OptionItem `json:"positionOptions,omitempty"`
	DivisionOptions         []OptionItem `json:"divisionOptions,omitempty"`
	StatusOptions           []OptionItem `json:"statusOptions,omitempty"`
	ActivationStatusOptions []OptionItem `json:"activationStatusOptions,omitempty"`
	RoleOptions             []OptionItem `json:"roleOptions,omitempty"`
	TemporaryStatusOptions  []OptionItem `json:"temporaryStatusOptions,omitempty"`
	ModifiedByOptions       []OptionItem `json:"modifiedByOptions,omitempty"`
}

type AcUserActiveRoleGroup struct {
	Role       string   `json:"role"`
	GroupCount int      `json:"groupCount"`
	Groups     []string `json:"groups"`
}

type AcUserActiveRolesResponse struct {
	ActiveRoles int                     `json:"activeRoles"`
	AccessLevel *string                 `json:"accessLevel,omitempty"`
	GlobalRoles []string                `json:"globalRoles"`
	GroupRoles  []AcUserActiveRoleGroup `json:"groupRoles"`
}

type AcUserActiveRolesRawRow struct {
	ScopeLevel            string  `json:"scope_level" column:"user_system_roles.scope_level"`
	Key                   string  `json:"key" column:"user_system_roles.key"`
	AdminConsoleGroupID   *int64  `json:"admin_console_group_id" column:"user_system_roles.admin_console_group_id"`
	AdminConsoleGroupName *string `json:"admin_console_group_name" column:"user_system_roles.admin_console_group_name"`
}
