package dto

import "time"

// UserListBody represents the payload for the POST /v2/iam/users/list endpoint.
type UserListBody struct {
	Page              int      `json:"page"`
	Limit             int      `json:"limit"`
	Search            string   `json:"search"`
	SortBy            string   `json:"sortBy"`
	SortOrder         int      `json:"sortOrder"`
	Columns           []string `json:"columns"`
	Access            []string `json:"access"`
	Position          []string `json:"position"`
	Division          []string `json:"division"`
	Status            []string `json:"status"`
	ActivationStatus  []string `json:"activationStatus"`
	TemporaryStatus   []string `json:"temporaryStatus"`
	ActivePeriodUntil []int64  `json:"activePeriodUntil"`
	ModifiedBy        []string `json:"modifiedBy"`
	UpdatedAt         []int64  `json:"updatedAt"`
}

// UserListItem is the minimal projection of the `users` table used by the list view.
// Only the columns needed for a list are mapped; extend as new use cases land.
type UserListItem struct {
	ID               int64  `json:"_id"               column:"users.id"`
	FirstName        string `json:"firstName"        column:"users.first_name"`
	LastName         string `json:"lastName"         column:"users.last_name"`
	Email            string `json:"email"            column:"users.email"`
	IsActive         bool   `json:"isActive"            column:"users.is_global_active"`
	ActivationStatus string `json:"activationStatus" column:"users.activation_status"`
	// Read by the Agreement gate (auth-foundation §11.1 triggers a and b) and
	// the MFA triggers. Polarity differs: nil FirstLoginAt fires the gate,
	// nil LastLogoutAt does not.
	FirstLoginAt            *time.Time `json:"firstLoginAt" column:"users.first_login_at"`
	LastLogoutAt            *time.Time `json:"lastLogoutAt" column:"users.last_logout_at"`
	CreatedAt               time.Time  `json:"createdAt"        column:"users.created_at"`
	UpdatedAt               time.Time  `json:"updatedAt"        column:"users.updated_at"`
	IsTemporary             *bool      `json:"isTemporary"      column:"users.is_temporary"`
	ActivePeriodUntil       *time.Time `json:"activePeriodUntil" column:"users.active_period_until"`
	IsDefault               *bool      `json:"isDefault"        column:"users.is_default"`
	ProfilePicture          *string    `json:"profilePicture"   column:"users.profile_picture"`
	IsAuthenticatorEnrolled bool       `json:"isAuthenticatorEnrolled" column:"users.is_authenticator_enrolled"`
}

// UserListResponseItem represents the object returned in the list response array.
// It maps directly to the API specification with string IDs.
type UserListResponseItem struct {
	ID                string     `json:"_id"                     column:"users.id::text"`
	FullName          string     `json:"fullName"                column:"users.full_name" export:"Full Name"`
	Email             string     `json:"email"                   column:"users.email" export:"Email"`
	EmployeeID        *string    `json:"employeeId"              column:"users.employee_id" export:"Employee ID"`
	Position          *string    `json:"position"                column:"positions.name" export:"Position"`
	Division          *string    `json:"division"                column:"divisions.name" export:"Division"`
	ActivationStatus  string     `json:"activationStatus"        column:"user_ext_cte.activation_status" export:"Activation Status"`
	IsActive          bool       `json:"isActive"                column:"COALESCE(user_ext_cte.is_active, false)" export:"Active"`
	TemporaryStatus   string     `json:"temporaryStatus"         column:"CASE WHEN users.is_temporary THEN 'Yes' ELSE 'No' END" export:"Temporary User"`
	PendingEmail      *string    `json:"pendingEmail"            column:"user_ext_cte.pending_email"`
	ProfilePicture    *string    `json:"profilePicture"          column:"users.profile_picture"`
	Access            []string   `json:"access"                  column:"COALESCE(user_ext_cte.access, '[]'::jsonb)" export:"Access"`
	TagCode           *string    `json:"tagCode"                 column:"users.tag_code" export:"TAG"`
	ActivePeriodUntil *time.Time `json:"activePeriodUntil"       column:"users.active_period_until" export:"Temporary Until"`
	ModifiedBy        *string    `json:"modifiedBy"              column:"mod_users.full_name" export:"Modified By"`
	UpdatedAt         *time.Time `json:"updatedAt"               column:"users.updated_at" export:"Last Update"`
	FirstLoginAt      *time.Time `json:"-"                       column:"users.first_login_at"`
	LastLogoutAt      *time.Time `json:"-"                       column:"users.last_logout_at"`
	CreatedAt         *time.Time `json:"-"                       column:"users.created_at"`
	IsDefault         bool       `json:"isDefault"               column:"COALESCE(users.is_default, false)"`
}

// UserListResponseData represents the data payload returned by the list endpoint.
type UserListResponseData struct {
	TotalRecords         int                    `json:"totalRecords"`
	TotalDisabledRecords int                    `json:"totalDisabledRecords"`
	Data                 []UserListResponseItem `json:"data"`
}
