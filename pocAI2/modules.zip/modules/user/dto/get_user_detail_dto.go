package dto

import "time"

// UserDetailItem represents the object returned in the detail response.
type UserDetailItem struct {
	ID                   string          `json:"_id"                     column:"users.id::text"`
	FirstName            string          `json:"firstName"               column:"users.first_name"`
	LastName             string          `json:"lastName"                column:"users.last_name"`
	FullName             string          `json:"fullName"                column:"users.full_name"`
	Email                string          `json:"email"                   column:"users.email"`
	EmployeeID           *string         `json:"employeeId"              column:"users.employee_id"`
	Position             *string         `json:"position"                column:"positions.name"`
	Division             *string         `json:"division"                column:"divisions.name"`
	DivisionID           string          `json:"divisionId"              column:"users.division_id::text"`
	PositionID           *string         `json:"positionId"              column:"users.position_id::text"`
	ActivationStatus     string          `json:"activationStatus"        column:"user_ext_cte.activation_status"`
	IsActive             bool            `json:"isActive"                column:"COALESCE(user_ext_cte.is_active, false)"`
	UserType             string          `json:"userType"                column:"COALESCE(user_ext_cte.user_type, 'basic')"`
	TemporaryStatus      string          `json:"temporaryStatus"         column:"CASE WHEN users.is_temporary THEN 'Yes' ELSE 'No' END"`
	ProfilePicture       *string         `json:"profilePicture"          column:"users.profile_picture"`
	ProfilePictureFileID *int64          `json:"-"                       column:"users.profile_picture_file_id"`
	Access               []string        `json:"access"                  column:"COALESCE(user_ext_cte.access, '[]'::jsonb)"`
	TagCode              *string         `json:"tagCode"                 column:"users.tag_code"`
	TagID                *int64          `json:"-"                       column:"users.tag_id"`
	AuthenticatorStatus  string          `json:"authenticatorStatus"     column:"CASE WHEN users.is_authenticator_enrolled THEN 'Enrolled' ELSE 'Not Enrolled' END"`
	ActivePeriodUntil    *time.Time      `json:"activePeriodUntil"       column:"users.active_period_until"`
	PendingEmail         *string         `json:"pendingEmail"            column:"user_ext_cte.pending_email"`
	CustomFields         *map[string]any `json:"customFields"            column:"users.custom_fields"`
	ModifiedBy           *string         `json:"modifiedBy"              column:"mod_users.full_name"`
	IsDefault            *bool           `json:"isDefault"               column:"users.is_default"`
	UpdatedAt            *time.Time      `json:"updatedAt"               column:"users.updated_at"`
}
