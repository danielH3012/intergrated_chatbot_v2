package dto

// UserExportBody represents the payload for the export endpoint.
type UserExportBody struct {
	UserListBody
	Format string `json:"format"`
}
