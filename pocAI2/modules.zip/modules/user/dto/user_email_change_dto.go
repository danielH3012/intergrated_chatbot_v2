package dto

import "time"

type UpdateUserEmailBody struct {
	NewEmail string `json:"newEmail" validate:"required,email"`
}

type InitiateEmailChangeResponse struct {
	ID        string    `json:"_id"`
	NewEmail  string    `json:"newEmail"`
	Status    string    `json:"status"`
	ExpiresAt time.Time `json:"expiresAt"`
	CreatedAt time.Time `json:"createdAt"`
}
