package dto

// UserOptionsBody represents the payload for the options endpoint.
type UserOptionsBody struct {
	PositionOptions         bool `json:"positionOptions"`
	DivisionOptions         bool `json:"divisionOptions"`
	StatusOptions           bool `json:"statusOptions"`
	ActivationStatusOptions bool `json:"activationStatusOptions"`
	AccessOptions           bool `json:"accessOptions"`
	ModifiedByOptions       bool `json:"modifiedByOptions"`
	TemporaryStatusOptions  bool `json:"temporaryStatusOptions"`
}

// OptionItem represents a standard dropdown option.
type OptionItem struct {
	Label string `json:"label"`
	Value string `json:"value"`
}

// UserOptionsItem represents a standard dropdown option.
type UserOptionsItem struct {
	ID       int64  `json:"id"`
	FullName string `json:"fullName"`
	Email    string `json:"email"`
}

// UserOptionsResponse represents the response for the options endpoint.
type UserOptionsResponse struct {
	PositionOptions         []OptionItem `json:"positionOptions,omitempty"`
	DivisionOptions         []OptionItem `json:"divisionOptions,omitempty"`
	StatusOptions           []OptionItem `json:"statusOptions,omitempty"`
	ActivationStatusOptions []OptionItem `json:"activationStatusOptions,omitempty"`
	AccessOptions           []OptionItem `json:"accessOptions,omitempty"`
	ModifiedByOptions       []OptionItem `json:"modifiedByOptions,omitempty"`
	TemporaryStatusOptions  []OptionItem `json:"temporaryStatusOptions,omitempty"`
}
