package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type CancelEmailChangeWorkflowParam struct {
	ClientCode                  string
	UserID                      int64
	CurrentUserID               int64
	CurrentUserName             string
	AnalyticsReportingTaskQueue string
}

func CancelEmailChangeWorkflow(ctx workflow.Context, param CancelEmailChangeWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	var result activity.CancelEmailChangeActivityResult
	_, err = temporal_helper.SafeRunner(func() (any, error) {
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityCancelEmailChange,
			activity.CancelEmailChangeActivityParam{
				ClientCode: param.ClientCode,
				UserID:     param.UserID,
			},
		).Get(activityCtx, &result); err != nil {
			return nil, err
		}

		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		logEntry := userChangelog(
			"Cancel Email Change",
			param.UserID, result.FullName,
			"Email", result.NewEmail+" (pending)", result.OldEmail, identity,
		)
		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{logEntry})

		return nil, nil
	})

	return nil, err
}
