package workflow_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/suite"
	"go.temporal.io/sdk/testsuite"
	temporalWorkflow "go.temporal.io/sdk/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type UserWorkflowTestSuite struct {
	suite.Suite
	testsuite.WorkflowTestSuite
	env      *testsuite.TestWorkflowEnvironment
	fakeRepo *repository.FakeUserRepository
	acts     *activity.Activities
}

func (s *UserWorkflowTestSuite) SetupTest() {
	coreDb.InitSnowflake()
	s.env = s.NewTestWorkflowEnvironment()

	// Initialize fake repository
	s.fakeRepo = repository.NewFakeUserRepository()

	// Initialize activities with the fake repository and fake DB service
	makeSvc := func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	}
	s.acts = activity.NewActivities("testdb", s.fakeRepo, makeSvc, nil, "http://ems", "token")

	// Register workflows
	s.env.RegisterWorkflow(workflow.CreateUserWorkflow)
	s.env.RegisterWorkflow(workflow.UpdateUserWorkflow)
	s.env.RegisterWorkflow(workflow.DeleteUsersWorkflow)
	s.env.RegisterWorkflow(workflow.UpdateUserStatusWorkflow)
	s.env.RegisterWorkflow(workflow.ResendEmailWorkflow)

	// Register all activities the workflows might call
	s.env.RegisterActivity(s.acts)

	// Mock external child workflows by registering dummies
	s.env.RegisterWorkflowWithOptions(func(ctx temporalWorkflow.Context, param interface{}) error { return nil }, temporalWorkflow.RegisterOptions{Name: "CascadePurgeUserFilesWorkflow"})
	s.env.RegisterWorkflowWithOptions(func(ctx temporalWorkflow.Context, param interface{}) error { return nil }, temporalWorkflow.RegisterOptions{Name: tsConstant.AnalyticsReportingRecordChangeLogsWorkflow})
	s.env.RegisterWorkflowWithOptions(func(ctx temporalWorkflow.Context, param interface{}) error { return nil }, temporalWorkflow.RegisterOptions{Name: "SendActivationEmailWorkflow"})
	s.env.RegisterWorkflowWithOptions(func(ctx temporalWorkflow.Context, param interface{}) error { return nil }, temporalWorkflow.RegisterOptions{Name: "SendEmailChangeWorkflow"})
}

func (s *UserWorkflowTestSuite) AfterTest(suiteName, testName string) {
	s.env.AssertExpectations(s.T())
}

func (s *UserWorkflowTestSuite) TestCreateUserWorkflow_Success() {
	param := workflow.CreateUserWorkflowParam{
		ClientCode:          "testclient",
		FirstName:           "Jane",
		LastName:            "Doe",
		Email:               "jane.doe@example.com",
		CurrentUserFullName: "Admin User",
		Access:              []string{"global_settings"},
	}

	s.env.ExecuteWorkflow(workflow.CreateUserWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.CreateUserWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.NotEmpty(result.ID)

	// Verify it was added to the fake repository
	user, err := s.fakeRepo.GetOneByEmail(context.Background(), nil, "jane.doe@example.com")
	s.NoError(err)
	s.Equal("Jane", user.FirstName)
}

func (s *UserWorkflowTestSuite) TestUpdateUserWorkflow_Success() {
	// Pre-seed user
	empID := "EMP-001"
	tagCode := "TAG-001"
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:               300,
		FirstName:        "John",
		LastName:         "Doe",
		Email:            "john.pending@example.com",
		EmployeeID:       &empID,
		TagCode:          &tagCode,
		ActivationStatus: "Pending Activation",
		DivisionID:       1,
	}, []string{"global_settings"})

	newEmpID := "EMP-002"
	newTagID := int64(99)
	param := workflow.UpdateUserWorkflowParam{
		ClientCode:          "testclient",
		UserID:              300,
		CurrentUserID:       1,
		CurrentUserFullName: "Admin User",
		FirstName:           "Johnny",
		LastName:            "Doe",
		Email:               "johnny.updated@example.com",
		EmployeeID:          &newEmpID,
		DivisionID:          1,
		TagID:               &newTagID,
		Access:              []string{"global_settings", "admin_console"},
		CustomFields: map[string]any{
			"Department": "Engineering",
		},
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	// Verify user is updated in repo
	updated, err := s.fakeRepo.GetDetail(context.Background(), nil, 300)
	s.NoError(err)
	s.Equal("Johnny", updated.FirstName)
	s.Equal("johnny.updated@example.com", updated.Email)
	s.Equal("EMP-002", *updated.EmployeeID)
}

func (s *UserWorkflowTestSuite) TestUpdateUserWorkflow_Activated_EmailStaged() {
	// Pre-seed user as Activated
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:               301,
		FirstName:        "Alice",
		LastName:         "",
		Email:            "alice.active@example.com",
		ActivationStatus: "Activated",
		DivisionID:       1,
	}, []string{"global_settings"})

	param := workflow.UpdateUserWorkflowParam{
		ClientCode:          "testclient",
		UserID:              301,
		CurrentUserID:       1,
		CurrentUserFullName: "Admin User",
		FirstName:           "Alice",
		LastName:            "",
		Email:               "alice.new@example.com",
		DivisionID:          1,
		Access:              []string{"global_settings"},
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	// Staged email change: existing user email remains old until confirmation
	updated, err := s.fakeRepo.GetDetail(context.Background(), nil, 301)
	s.NoError(err)
	s.Equal("alice.active@example.com", updated.Email)
}

func (s *UserWorkflowTestSuite) TestUpdateUserWorkflow_PhotoRemoval() {
	// Pre-seed user with photo
	oldPhoto := "https://cdn.example.com/photos/avatar.jpg"
	oldPhotoID := int64(888)
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:                   302,
		FirstName:            "Bob",
		LastName:             "Smith",
		Email:                "bob@example.com",
		ProfilePicture:       &oldPhoto,
		ProfilePictureFileID: &oldPhotoID,
		ActivationStatus:     "Activated",
		DivisionID:           1,
	}, []string{"global_settings"})

	param := workflow.UpdateUserWorkflowParam{
		ClientCode:          "testclient",
		UserID:              302,
		CurrentUserID:       1,
		CurrentUserFullName: "Admin User",
		FirstName:           "Bob",
		LastName:            "Smith",
		Email:               "bob@example.com",
		DivisionID:          1,
		ProfilePicture:      nil, // clearing photo
		Access:              []string{"global_settings"},
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())
}

func (s *UserWorkflowTestSuite) TestDeleteUsersWorkflow_Success() {
	// Pre-seed user in FakeRepo
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:        123,
		FirstName: "Target",
		Email:     "target@example.com",
	}, []string{})

	param := workflow.DeleteUsersWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"123"},
		CurrentUserID:       1,
		CurrentUserFullName: "Admin",
	}

	s.env.ExecuteWorkflow(workflow.DeleteUsersWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.DeleteUsersWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("deleted", result.Results[0].Status)
	s.Equal("123", result.Results[0].ID)
}

func (s *UserWorkflowTestSuite) TestUpdateUserStatusWorkflow_AdminConsole_Success() {
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:        100,
		FirstName: "John",
		LastName:  "Doe",
		Email:     "john@example.com",
	}, []string{})
	s.fakeRepo.SetUserModuleStatus(100, "global_settings", true)
	s.fakeRepo.SetUserModuleStatus(100, "admin_console", true)
	s.fakeRepo.SetUserAdminConsoleGroups(100, []int64{10})

	param := workflow.UpdateUserStatusWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"100"},
		IsActive:            false,
		ModuleKey:           "admin_console",
		CurrentUserID:       1,
		CurrentUserFullName: "Admin",
		IsAllGroups:         false,
		AllowedGroupIDs:     []int64{10},
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserStatusWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.UpdateUserStatusWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("updated", result.Results[0].Status)
	s.Equal("100", result.Results[0].ID)
}

func (s *UserWorkflowTestSuite) TestUpdateUserStatusWorkflow_AdminConsole_OutOfScope() {
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:        101,
		FirstName: "Jane",
		LastName:  "Doe",
		Email:     "jane@example.com",
	}, []string{})
	s.fakeRepo.SetUserModuleStatus(101, "global_settings", true)
	s.fakeRepo.SetUserModuleStatus(101, "admin_console", true)
	s.fakeRepo.SetUserAdminConsoleGroups(101, []int64{20}) // in group 20

	param := workflow.UpdateUserStatusWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"101"},
		IsActive:            false,
		ModuleKey:           "admin_console",
		CurrentUserID:       1,
		CurrentUserFullName: "Admin",
		IsAllGroups:         false,
		AllowedGroupIDs:     []int64{10}, // caller only has group 10
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserStatusWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.UpdateUserStatusWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("blocked", result.Results[0].Status)
	s.NotNil(result.Results[0].Reason)
	s.Equal("out_of_scope", *result.Results[0].Reason)
}

func (s *UserWorkflowTestSuite) TestUpdateUserStatusWorkflow_TCROTarget_Blocked() {
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:        102,
		FirstName: "Super",
		LastName:  "Admin",
		Email:     "super@example.com",
	}, []string{})
	s.fakeRepo.SetUserModuleStatus(102, "global_settings", true)
	s.fakeRepo.SetUserModuleStatus(102, "admin_console", true)
	s.fakeRepo.SetUserAccessLevel(102, "total_control")

	// Caller is custom role (not total_control)
	s.fakeRepo.SetUserAccessLevel(999, "custom")

	param := workflow.UpdateUserStatusWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"102"},
		IsActive:            false,
		ModuleKey:           "admin_console",
		CurrentUserID:       999,
		CurrentUserFullName: "Manager",
		IsAllGroups:         true,
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserStatusWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.UpdateUserStatusWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("blocked", result.Results[0].Status)
	s.NotNil(result.Results[0].Reason)
	s.Equal("tcro_target", *result.Results[0].Reason)
}

func (s *UserWorkflowTestSuite) TestUpdateUserStatusWorkflow_EntitySuspended() {
	s.fakeRepo.SetEntitySuspended(true)
	defer s.fakeRepo.SetEntitySuspended(false)

	param := workflow.UpdateUserStatusWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"100"},
		IsActive:            true,
		ModuleKey:           "admin_console",
		CurrentUserID:       1,
		CurrentUserFullName: "Admin",
		IsAllGroups:         true,
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserStatusWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.UpdateUserStatusWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("blocked", result.Results[0].Status)
	s.NotNil(result.Results[0].Reason)
	s.Equal("entity_suspended", *result.Results[0].Reason)
}

func (s *UserWorkflowTestSuite) TestResendEmailWorkflow_AdminConsole_Activation() {
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:               200,
		FirstName:        "Invited",
		LastName:         "User",
		Email:            "invited@example.com",
		ActivationStatus: "Pending Activation",
	}, []string{})
	s.fakeRepo.SetActivationToken(200, &model.ActivationToken{
		ID:        1,
		UserID:    200,
		Status:    model.TokenStatusActive,
		CreatedAt: time.Now().Add(-2 * time.Minute),
		ExpiresAt: time.Now().Add(24 * time.Hour),
	})

	param := workflow.ResendEmailWorkflowParam{
		ClientCode:      "testclient",
		IDs:             []string{"200"},
		CurrentUserID:   1,
		CurrentUserName: "Admin",
		Product:         "admin_console",
	}

	s.env.ExecuteWorkflow(workflow.ResendEmailWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.ResendEmailWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("sent", result.Results[0].Status)
	s.NotNil(result.Results[0].Type)
	s.Equal("activation", *result.Results[0].Type)
}

func (s *UserWorkflowTestSuite) TestResendEmailWorkflow_ConfirmationMultiIDs() {
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:               201,
		FirstName:        "User",
		LastName:         "One",
		Email:            "one@example.com",
		ActivationStatus: "Activated",
	}, []string{})
	s.fakeRepo.SetPendingEmailChange(201, &model.UserEmailChange{
		ID:        1,
		UserID:    201,
		NewEmail:  "new1@example.com",
		ExpiresAt: time.Now().Add(24 * time.Hour),
	})

	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:               202,
		FirstName:        "User",
		LastName:         "Two",
		Email:            "two@example.com",
		ActivationStatus: "Activated",
	}, []string{})
	s.fakeRepo.SetPendingEmailChange(202, &model.UserEmailChange{
		ID:        2,
		UserID:    202,
		NewEmail:  "new2@example.com",
		ExpiresAt: time.Now().Add(24 * time.Hour),
	})

	param := workflow.ResendEmailWorkflowParam{
		ClientCode:      "testclient",
		IDs:             []string{"201", "202"},
		CurrentUserID:   1,
		CurrentUserName: "Admin",
		Product:         "admin_console",
	}

	s.env.ExecuteWorkflow(workflow.ResendEmailWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.ResendEmailWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 2)
	s.Equal("sent", result.Results[0].Status)
	s.NotNil(result.Results[0].Type)
	s.Equal("confirmation", *result.Results[0].Type)
	s.Equal("sent", result.Results[1].Status)
	s.NotNil(result.Results[1].Type)
	s.Equal("confirmation", *result.Results[1].Type)
}

func (s *UserWorkflowTestSuite) TestUpdateUserStatusWorkflow_GlobalSettings_UserWithoutGlobalSettingsAccess_Deactivate() {
	// User only has fixed_asset access, NO global_settings access
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:        555,
		FirstName: "Fams",
		LastName:  "User",
		Email:     "famsuser@example.com",
	}, []string{"fixed_asset"})
	s.fakeRepo.SetUserModuleStatus(555, "fixed_asset", true)

	// Admin deactivates user globally via Global Settings
	param := workflow.UpdateUserStatusWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"555"},
		IsActive:            false,
		ModuleKey:           "global_settings",
		CurrentUserID:       1,
		CurrentUserFullName: "Admin",
		IsAllGroups:         true,
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserStatusWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.UpdateUserStatusWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("updated", result.Results[0].Status)
	s.Equal("555", result.Results[0].ID)

	u, err := s.fakeRepo.GetOneByID(context.Background(), nil, 555)
	s.NoError(err)
	s.False(u.IsActive)
}

func (s *UserWorkflowTestSuite) TestUpdateUserStatusWorkflow_GlobalSettings_UserWithoutGlobalSettingsAccess_Reactivate() {
	// User is currently Inactive globally and only has fixed_asset access
	s.fakeRepo.Create(context.Background(), nil, model.User{
		ID:        556,
		FirstName: "Fams",
		LastName:  "User2",
		Email:     "famsuser2@example.com",
	}, []string{"fixed_asset"})
	s.fakeRepo.SetUserModuleStatus(556, "fixed_asset", true)
	_ = s.fakeRepo.UpdateUserGlobalActive(context.Background(), nil, 556, false)

	// Admin activates user globally via Global Settings
	param := workflow.UpdateUserStatusWorkflowParam{
		ClientCode:          "testclient",
		IDs:                 []string{"556"},
		IsActive:            true,
		ModuleKey:           "global_settings",
		CurrentUserID:       1,
		CurrentUserFullName: "Admin",
		IsAllGroups:         true,
	}

	s.env.ExecuteWorkflow(workflow.UpdateUserStatusWorkflow, param)
	s.True(s.env.IsWorkflowCompleted())
	s.NoError(s.env.GetWorkflowError())

	var result workflow.UpdateUserStatusWorkflowResult
	err := s.env.GetWorkflowResult(&result)
	s.NoError(err)
	s.Len(result.Results, 1)
	s.Equal("updated", result.Results[0].Status)
	s.Equal("556", result.Results[0].ID)

	u, err := s.fakeRepo.GetOneByID(context.Background(), nil, 556)
	s.NoError(err)
	s.True(u.IsActive)
}

func TestUserWorkflowTestSuite(t *testing.T) {
	suite.Run(t, new(UserWorkflowTestSuite))
}
