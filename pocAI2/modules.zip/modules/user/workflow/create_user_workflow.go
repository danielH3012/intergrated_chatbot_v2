package workflow

import (
	"fmt"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	iamTemporal "gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type CreateUserWorkflowParam struct {
	ClientCode                  string
	CurrentUserID               int64
	CurrentUserFullName         string
	FirstName                   string
	LastName                    string
	Email                       string
	EmployeeID                  *string
	PositionID                  *int64
	DivisionID                  int64
	TagID                       *int64
	ActivePeriodUntil           *int64
	Access                      []string
	CustomFields                map[string]any
	ProfilePictureFileID        *int64
	ProfilePicture              *string
	AnalyticsReportingTaskQueue string
}

type CreateUserWorkflowResult struct {
	ID string
}

// CreateUserWorkflow inserts the user, then emits changelog rows (Full Name)
func CreateUserWorkflow(ctx workflow.Context, param CreateUserWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	compensation := coreService.NewWorkflowCompensation()
	defer func() {
		if err != nil {
			disconnectedCtx, cancel := workflow.NewDisconnectedContext(activityCtx)
			defer cancel()
			compensation.Compensate(disconnectedCtx, false)
		}
	}()

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserFullName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		var inserted activity.InsertUserActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityInsertUser,
			activity.InsertUserActivityParam{
				ClientCode:        param.ClientCode,
				CurrentUserID:     &param.CurrentUserID,
				FirstName:         param.FirstName,
				LastName:          param.LastName,
				Email:             param.Email,
				EmployeeID:        param.EmployeeID,
				PositionID:        param.PositionID,
				DivisionID:        param.DivisionID,
				TagID:             param.TagID,
				ActivePeriodUntil: param.ActivePeriodUntil,
				Access:            param.Access,
				CustomFields:      param.CustomFields,
				ProfilePictureID:  param.ProfilePictureFileID,
				ProfilePicture:    param.ProfilePicture,
			},
		).Get(activityCtx, &inserted); err != nil {
			return nil, err
		}

		compensation.AddCompensation(
			constant.ActivityDeleteUsers,
			activity.DeleteUsersActivityParam{
				ClientCode:    param.ClientCode,
				IDs:           []string{strconv.FormatInt(inserted.ID, 10)},
				CurrentUserID: param.CurrentUserID,
			},
		)

		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{
			userChangelog(
				arModel.ChangeLogActionCreate,
				inserted.ID, inserted.FullName, "Name",
				dash(), inserted.FullName, identity,
			),
		})

		// Trigger activation email workflow as a child workflow
		emailOpts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, fmt.Sprintf("activation-email-%s-%s", param.ClientCode, param.Email), "")
		childCtx := workflow.WithChildOptions(ctx, emailOpts)
		emailFuture := workflow.ExecuteChildWorkflow(
			childCtx,
			SendActivationEmailWorkflow,
			iamTemporal.SendActivationEmailParam{
				ClientID: param.ClientCode,
				Email:    param.Email,
			},
		)
		var childExecution workflow.Execution
		if err := emailFuture.GetChildWorkflowExecution().Get(ctx, &childExecution); err != nil {
			workflow.GetLogger(ctx).Error("failed to spawn SendActivationEmailWorkflow", "error", err)
		}

		return CreateUserWorkflowResult{ID: strconv.FormatInt(inserted.ID, 10)}, nil
	})
}
