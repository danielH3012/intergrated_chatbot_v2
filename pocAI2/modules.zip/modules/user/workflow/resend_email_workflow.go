package workflow

import (
	"fmt"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	iamTemporal "gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type ResendEmailWorkflowParam struct {
	ClientCode                  string
	IDs                         []string
	CurrentUserID               int64
	CurrentUserName             string
	Product                     string
	AnalyticsReportingTaskQueue string
}

type ResendEmailWorkflowResult struct {
	Results []userDto.ResendResult
	Emails  []activity.EmailDispatch
}

func ResendEmailWorkflow(ctx workflow.Context, param ResendEmailWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		var result activity.ResendEmailActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityResendEmail,
			activity.ResendEmailActivityParam{
				ClientCode:    param.ClientCode,
				IDs:           param.IDs,
				CurrentUserID: param.CurrentUserID,
				Product:       param.Product,
			},
		).Get(activityCtx, &result); err != nil {
			return nil, err
		}

		if len(result.Changelogs) > 0 {
			identity := changelogIdentity{
				ClientID:     param.ClientCode,
				UserID:       strconv.FormatInt(param.CurrentUserID, 10),
				UserFullName: param.CurrentUserName,
				TaskQueue:    param.AnalyticsReportingTaskQueue,
			}

			prod := arModel.Product(param.Product)
			if prod == "" {
				prod = arModel.ProductGlobalSettings
			}

			var changelogs []arModel.Changelog
			for _, cl := range result.Changelogs {
				changelogs = append(changelogs, userChangelog(
					arModel.ChangeLogAction(cl.Action),
					cl.UserID, cl.FullName,
					cl.Field, cl.OldValue, cl.NewValue, identity, prod,
				))
			}

			spawnChangeLogWorkflow(ctx, identity, changelogs)
		}

		// Fire off the emails
		for i, ed := range result.Emails {
			switch ed.Type {
			case "activation":
				// SendActivationEmailWorkflow
				opts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, fmt.Sprintf("activation-email-%s-%s-%d", param.ClientCode, ed.Email, i), "")
				childCtx := workflow.WithChildOptions(ctx, opts)
				future := workflow.ExecuteChildWorkflow(
					childCtx,
					SendActivationEmailWorkflow,
					iamTemporal.SendActivationEmailParam{
						ClientID: ed.ClientCode,
						Email:    ed.Email,
					},
				)
				var childExec workflow.Execution
				if err := future.GetChildWorkflowExecution().Get(ctx, &childExec); err != nil {
					workflow.GetLogger(ctx).Error("failed to spawn SendActivationEmailWorkflow in resend", "error", err)
				}
			case "confirmation":
				// SendEmailChangeWorkflow
				opts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, fmt.Sprintf("email-change-email-%s-%s-%d", param.ClientCode, ed.Email, i), "")
				childCtx := workflow.WithChildOptions(ctx, opts)
				future := workflow.ExecuteChildWorkflow(
					childCtx,
					SendEmailChangeWorkflow,
					activity.SendEmailChangeActivityParam{
						ClientCode: ed.ClientCode,
						UserID:     ed.UserID,
						NewEmail:   ed.Email,
						Token:      ed.Token,
					},
				)
				var childExec workflow.Execution
				if err := future.GetChildWorkflowExecution().Get(ctx, &childExec); err != nil {
					workflow.GetLogger(ctx).Error("failed to spawn SendEmailChangeWorkflow in resend", "error", err)
				}
			}
		}

		return ResendEmailWorkflowResult{
			Results: result.Results,
			Emails:  result.Emails,
		}, nil
	})
}
