package workflow

import (
	iamTemporal "gitea.tagsamurai.local/BETS-V2/service-contracts/services/iam/temporal"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

func SendActivationEmailWorkflow(ctx workflow.Context, param iamTemporal.SendActivationEmailParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		if err := iamTemporal.ExecuteSendActivationEmail(activityCtx, param); err != nil {
			return nil, err
		}
		return nil, nil
	})
}
