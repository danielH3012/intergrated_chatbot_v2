package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type ConfirmEmailChangeWorkflowParam struct {
	Token                       string
	AnalyticsReportingTaskQueue string
}

type ConfirmEmailChangeWorkflowResult struct {
	NewEmail string
}

func ConfirmEmailChangeWorkflow(ctx workflow.Context, param ConfirmEmailChangeWorkflowParam) (res ConfirmEmailChangeWorkflowResult, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	compensation := coreService.NewWorkflowCompensation()
	defer func() {
		if err != nil {
			disconnectedCtx, cancel := workflow.NewDisconnectedContext(activityCtx)
			defer cancel()
			compensation.Compensate(disconnectedCtx, false)
		}
	}()

	var newEmail string
	_, err = temporal_helper.SafeRunner(func() (any, error) {
		var publicRes activity.ConfirmEmailChangePublicActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityConfirmEmailChangePublic,
			activity.ConfirmEmailChangePublicActivityParam{
				Token: param.Token,
			},
		).Get(activityCtx, &publicRes); err != nil {
			return nil, err
		}

		compensation.AddCompensation(
			constant.ActivityUnconsumeEmailChangePublic,
			activity.UnconsumeEmailChangePublicActivityParam{
				TokenHash: publicRes.TokenHash,
			},
		)

		var tenantRes activity.ConfirmEmailChangeTenantActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityConfirmEmailChangeTenant,
			activity.ConfirmEmailChangeTenantActivityParam{
				ClientCode: publicRes.ClientCode,
				UserID:     publicRes.UserID,
				NewEmail:   publicRes.NewEmail,
			},
		).Get(activityCtx, &tenantRes); err != nil {
			return nil, err
		}

		newEmail = publicRes.NewEmail

		identity := changelogIdentity{
			ClientID:     publicRes.ClientCode,
			UserID:       strconv.FormatInt(publicRes.UserID, 10),
			UserFullName: tenantRes.FullName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		logEntry := userChangelog(
			"Email Confirmed",
			publicRes.UserID, tenantRes.FullName,
			"Email", tenantRes.OldEmail+" (pending)", publicRes.NewEmail, identity,
		)
		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{logEntry})

		return nil, nil
	})

	return ConfirmEmailChangeWorkflowResult{
		NewEmail: newEmail,
	}, err
}
