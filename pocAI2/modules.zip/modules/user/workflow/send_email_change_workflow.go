package workflow

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

func SendEmailChangeWorkflow(ctx workflow.Context, param activity.SendEmailChangeActivityParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		if err := workflow.ExecuteActivity(activityCtx, constant.ActivitySendEmailChange, param).Get(activityCtx, nil); err != nil {
			return nil, err
		}
		return nil, nil
	})
}
