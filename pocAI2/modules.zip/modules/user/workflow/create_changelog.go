package workflow

import (
	"strconv"

	tsConstant "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
	arDto "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type changelogIdentity struct {
	ClientID     string
	UserID       string
	UserFullName string
	TaskQueue    string
}

func userChangelog(
	action arModel.ChangeLogAction,
	objectID int64,
	objectName, field, oldValue, newValue string,
	identity changelogIdentity,
	product ...arModel.Product,
) arModel.Changelog {
	objectIDStr := strconv.FormatInt(objectID, 10)
	prod := arModel.ProductGlobalSettings
	if len(product) > 0 && product[0] != "" {
		prod = product[0]
	}
	return arModel.Changelog{
		Action:            action,
		Field:             &field,
		OldValue:          &oldValue,
		NewValue:          &newValue,
		LogTable:          "User",
		CreatedById:       identity.UserID,
		CreatedBySnapshot: identity.UserFullName,
		EntityID:          identity.ClientID,
		EntityType:        arModel.EntityTypeClient,
		Product:           &prod,
		Object:            "User",
		ObjectId:          &objectIDStr,
		ObjectName:        &objectName,
	}
}

func spawnChangeLogWorkflow(ctx workflow.Context, identity changelogIdentity, logs []arModel.Changelog) {
	if len(logs) == 0 {
		return
	}
	opts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, "", identity.TaskQueue)
	childCtx := workflow.WithChildOptions(ctx, opts)
	future := workflow.ExecuteChildWorkflow(
		childCtx,
		tsConstant.AnalyticsReportingRecordChangeLogsWorkflow,
		arDto.CreateChangeLogActivityParam{
			ClientID:   identity.ClientID,
			ChangeLogs: logs,
		},
	)
	var childExecution workflow.Execution
	if err := future.GetChildWorkflowExecution().Get(ctx, &childExecution); err != nil {
		workflow.GetLogger(ctx).Error("failed to spawn changelog child workflow", "error", err)
	}
}

func dash() string { return "-" }
