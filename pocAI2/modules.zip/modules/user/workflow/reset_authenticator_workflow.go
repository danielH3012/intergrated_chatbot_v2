package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type ResetAuthenticatorWorkflowParam struct {
	ClientCode                  string
	UserID                      int64
	CurrentUserID               int64
	CurrentUserName             string
	AnalyticsReportingTaskQueue string
}

func ResetAuthenticatorWorkflow(ctx workflow.Context, param ResetAuthenticatorWorkflowParam) (res string, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	var outcome string
	_, err = temporal_helper.SafeRunner(func() (any, error) {
		var validationResult activity.ValidateResetAuthenticatorActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityValidateResetAuthenticator,
			activity.ValidateResetAuthenticatorActivityParam{
				ClientCode:    param.ClientCode,
				UserID:        param.UserID,
				CurrentUserID: param.CurrentUserID,
			},
		).Get(activityCtx, &validationResult); err != nil {
			return nil, err
		}

		if !validationResult.Enrolled {
			outcome = "not_enrolled"
			return nil, nil
		}

		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityResetAuthenticatorPublic,
			activity.ResetAuthenticatorPublicActivityParam{
				ClientCode: param.ClientCode,
				UserID:     param.UserID,
			},
		).Get(activityCtx, nil); err != nil {
			return nil, err
		}

		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityUpdateResetAuthenticatorTenant,
			activity.UpdateResetAuthenticatorTenantActivityParam{
				ClientCode: param.ClientCode,
				UserID:     param.UserID,
			},
		).Get(activityCtx, nil); err != nil {
			return nil, err
		}

		outcome = "reset"

		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		logEntry := userChangelog(
			"Reset Authenticator",
			param.UserID, validationResult.FullName,
			"Authenticator Enrollment", "Enrolled", "Not Enrolled", identity,
		)

		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{logEntry})

		return nil, nil
	})

	return outcome, err
}
