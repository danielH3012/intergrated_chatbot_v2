package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type UpdateUserStatusWorkflowParam struct {
	ClientCode                  string
	IDs                         []string
	IsActive                    bool
	ModuleKey                   string
	CurrentUserID               int64
	CurrentUserFullName         string
	IsAllGroups                 bool
	AllowedGroupIDs             []int64
	AnalyticsReportingTaskQueue string
}

type UpdateUserStatusWorkflowResult struct {
	Results []userDto.BulkStatusResult
}

func UpdateUserStatusWorkflow(ctx workflow.Context, param UpdateUserStatusWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserFullName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		var updated activity.UpdateUserStatusActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityUpdateUserStatus,
			activity.UpdateUserStatusActivityParam{
				ClientCode:      param.ClientCode,
				IDs:             param.IDs,
				IsActive:        param.IsActive,
				ModuleKey:       param.ModuleKey,
				CurrentUserID:   param.CurrentUserID,
				IsAllGroups:     param.IsAllGroups,
				AllowedGroupIDs: param.AllowedGroupIDs,
			},
		).Get(activityCtx, &updated); err != nil {
			return nil, err
		}

		var changelogs []arModel.Changelog
		for _, cl := range updated.Changelogs {
			action := arModel.ChangeLogAction(cl.Action)
			prod := arModel.Product(cl.Product)
			if prod == "" {
				prod = arModel.ProductGlobalSettings
			}
			changelogs = append(changelogs, userChangelog(
				action,
				cl.UserID, cl.FullName,
				cl.Field, cl.OldValue, cl.NewValue, identity, prod,
			))
		}

		spawnChangeLogWorkflow(ctx, identity, changelogs)

		if updated.DBError != nil {
			return nil, coreEntity.InternalServerError(*updated.DBError)
		}

		// TODO: FAMS-SYNC: Trigger outbox or child workflow to sync approver pools on deactivation.
		// As per PRD §3, deactivating a user globally should disable the Approver badge and drop them from pickers.

		return UpdateUserStatusWorkflowResult{Results: updated.Results}, nil
	})
}
