package workflow

import (
	"time"

	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"go.temporal.io/sdk/workflow"
)

type AutoDeactivateTemporaryUsersWorkflowParam struct {
	AnalyticsReportingTaskQueue string
}

// AutoDeactivateTemporaryUsersWorkflow is a background job that runs daily.
// It fetches all active clients, and for each client, checks for temporary users
// whose active_period_until has passed, deactivates them, and logs the change.
func AutoDeactivateTemporaryUsersWorkflow(ctx workflow.Context, param AutoDeactivateTemporaryUsersWorkflowParam) error {
	activityCtx := workflow.WithActivityOptions(ctx, workflow.ActivityOptions{
		StartToCloseTimeout: 10 * time.Minute,
	})

	var clientIDs []string
	if err := workflow.ExecuteActivity(activityCtx, constant.ActivityFetchClients).Get(activityCtx, &clientIDs); err != nil {
		return err
	}

	for _, clientID := range clientIDs {
		var res activity.AutoDeactivateExpiredUsersActivityResult
		if err := workflow.ExecuteActivity(activityCtx, constant.ActivityAutoDeactivateExpiredUsers, clientID).Get(activityCtx, &res); err != nil {
			// Don't fail the entire workflow if one tenant fails, just log it.
			workflow.GetLogger(ctx).Warn("AutoDeactivate expired users failed for tenant", "client_id", clientID, "error", err.Error())
			continue
		}

		// Log changelogs to Analytics Reporting
		var logs []arModel.Changelog
		for _, cl := range res.Changelogs {
			logs = append(logs, userChangelog(
				arModel.ChangeLogAction(cl.Action),
				cl.UserID, cl.FullName, cl.Field,
				cl.OldValue, cl.NewValue,
				changelogIdentity{
					ClientID:     clientID,
					UserID:       "System",
					UserFullName: "System",
					TaskQueue:    param.AnalyticsReportingTaskQueue,
				},
			))
		}

		if len(logs) > 0 {
			spawnChangeLogWorkflow(ctx, changelogIdentity{
				ClientID:     clientID,
				UserID:       "System",
				UserFullName: "System",
				TaskQueue:    param.AnalyticsReportingTaskQueue,
			}, logs)
		}
	}

	return nil
}
