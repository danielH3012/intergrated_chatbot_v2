package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type DeleteUsersWorkflowParam struct {
	ClientCode                  string
	IDs                         []string
	CurrentUserID               int64
	CurrentUserFullName         string
	AnalyticsReportingTaskQueue string
}

type DeleteUsersWorkflowResult struct {
	Results []userDto.DeleteUserResult
}

func DeleteUsersWorkflow(ctx workflow.Context, param DeleteUsersWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserFullName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		var deleted activity.DeleteUsersActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityDeleteUsers,
			activity.DeleteUsersActivityParam{
				ClientCode:    param.ClientCode,
				IDs:           param.IDs,
				CurrentUserID: param.CurrentUserID,
			},
		).Get(activityCtx, &deleted); err != nil {
			return nil, err
		}

		var results []userDto.DeleteUserResult
		var changelogs []arModel.Changelog

		for _, item := range deleted.Results {
			results = append(results, userDto.DeleteUserResult{
				ID:     item.ID,
				Status: item.Status,
				Reason: item.Reason,
			})
			if item.Success {
				// Trigger CascadePurgeUserFilesWorkflow
				opts := temporal_helper.FireAndForgetChildWorkflowOptions(ctx, "", "file-manager-task-queue")
				childCtx := workflow.WithChildOptions(ctx, opts)
				future := workflow.ExecuteChildWorkflow(
					childCtx,
					"CascadePurgeUserFilesWorkflow", // Using string literal as it's external
					map[string]interface{}{
						"ClientID": param.ClientCode,
						"UserID":   item.ID,
					},
				)
				var childExecution workflow.Execution
				if err := future.GetChildWorkflowExecution().Get(ctx, &childExecution); err != nil {
					workflow.GetLogger(ctx).Error("failed to spawn CascadePurgeUserFilesWorkflow", "error", err)
				}
			}
		}

		for _, cl := range deleted.Changelogs {
			changelogs = append(changelogs, userChangelog(
				arModel.ChangeLogActionDelete,
				cl.UserID, cl.FullName,
				"Name", cl.FullName, dash(), identity,
			))
		}

		spawnChangeLogWorkflow(ctx, identity, changelogs)

		return DeleteUsersWorkflowResult{Results: results}, nil
	})
}
