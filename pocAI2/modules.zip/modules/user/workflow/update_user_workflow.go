package workflow

import (
	"strconv"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type UpdateUserWorkflowParam struct {
	ClientCode                  string
	UserID                      int64
	CurrentUserID               int64
	CurrentUserFullName         string
	FirstName                   string
	LastName                    string
	Email                       string
	EmployeeID                  *string
	PositionID                  *int64
	DivisionID                  int64
	TagID                       *int64
	ActivePeriodUntil           *int64
	Access                      []string
	CustomFields                map[string]any
	ProfilePictureFileID        *int64
	ProfilePicture              *string
	AnalyticsReportingTaskQueue string
}

func UpdateUserWorkflow(ctx workflow.Context, param UpdateUserWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserFullName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		var updated activity.UpdateUserActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityUpdateUser,
			activity.UpdateUserActivityParam{
				ClientCode:        param.ClientCode,
				UserID:            param.UserID,
				CurrentUserID:     &param.CurrentUserID,
				FirstName:         param.FirstName,
				LastName:          param.LastName,
				Email:             param.Email,
				EmployeeID:        param.EmployeeID,
				PositionID:        param.PositionID,
				DivisionID:        param.DivisionID,
				TagID:             param.TagID,
				ActivePeriodUntil: param.ActivePeriodUntil,
				Access:            param.Access,
				CustomFields:      param.CustomFields,
				ProfilePictureID:  param.ProfilePictureFileID,
				ProfilePicture:    param.ProfilePicture,
			},
		).Get(activityCtx, &updated); err != nil {
			return nil, err
		}

		objectName := strings.TrimSpace(param.FirstName + " " + param.LastName)

		var changelogs []arModel.Changelog
		for _, change := range updated.Changes {
			action := arModel.ChangeLogActionEdit
			if change.Action != "" {
				action = arModel.ChangeLogAction(change.Action)
			}
			changelogs = append(changelogs, userChangelog(
				action,
				param.UserID, objectName,
				change.Field, change.OldValue, change.NewValue, identity,
			))
		}

		if updated.StageEmailChange {
			var emailChangeRes activity.EmailChangeActivityResult
			if err = workflow.ExecuteActivity(
				activityCtx,
				constant.ActivityEmailChange,
				activity.EmailChangeActivityParam{
					ClientCode: param.ClientCode,
					UserID:     param.UserID,
					NewEmail:   updated.NewEmail,
				},
			).Get(activityCtx, &emailChangeRes); err != nil {
				// If email change fails, we should ideally rollback user edit.
				// For now, we log the error or return it.
				// A 409 from this activity bubbles up.
				return nil, err
			}

			changelogs = append(changelogs, userChangelog(
				arModel.ChangeLogAction("Pending Email Change"),
				param.UserID,
				objectName,
				"Email",
				emailChangeRes.OldEmail,
				updated.NewEmail+" (pending)",
				identity,
			))

			if err = workflow.ExecuteChildWorkflow(
				ctx,
				SendEmailChangeWorkflow,
				activity.SendEmailChangeActivityParam{
					ClientCode: param.ClientCode,
					UserID:     param.UserID,
					OldEmail:   emailChangeRes.OldEmail,
					NewEmail:   updated.NewEmail,
					Token:      emailChangeRes.ChangeRow.TokenHash,
				},
			).Get(ctx, nil); err != nil {
				return nil, err
			}
		}

		if updated.SendActivationEmail {
			// Assuming BaseURL should be passed, we might need to get it from context or hardcode for now if not available in param
			// In a real scenario, base_url is needed for resend email
			if err = workflow.ExecuteChildWorkflow(
				ctx,
				ResendEmailWorkflow,
				ResendEmailWorkflowParam{
					ClientCode:                  param.ClientCode,
					IDs:                         []string{strconv.FormatInt(param.UserID, 10)},
					CurrentUserID:               param.CurrentUserID,
					CurrentUserName:             param.CurrentUserFullName,
					AnalyticsReportingTaskQueue: param.AnalyticsReportingTaskQueue,
				},
			).Get(ctx, nil); err != nil {
				return nil, err
			}
		}

		spawnChangeLogWorkflow(ctx, identity, changelogs)

		return nil, nil
	})
}
