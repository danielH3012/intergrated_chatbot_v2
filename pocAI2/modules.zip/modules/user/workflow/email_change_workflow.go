package workflow

import (
	"fmt"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/workflow"
)

type EmailChangeWorkflowParam struct {
	ClientCode                  string
	UserID                      int64
	NewEmail                    string
	CurrentUserID               int64
	CurrentUserName             string
	AnalyticsReportingTaskQueue string
}

func EmailChangeWorkflow(ctx workflow.Context, param EmailChangeWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		var result activity.EmailChangeActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityEmailChange,
			activity.EmailChangeActivityParam{
				ClientCode: param.ClientCode,
				UserID:     param.UserID,
				NewEmail:   param.NewEmail,
			},
		).Get(activityCtx, &result); err != nil {
			return nil, err
		}

		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		logEntry := userChangelog(
			"Pending Email Change",
			param.UserID, result.FullName,
			"Email", result.OldEmail, param.NewEmail+" (pending)", identity,
		)
		spawnChangeLogWorkflow(ctx, identity, []arModel.Changelog{logEntry})

		workflow.ExecuteChildWorkflow(
			workflow.WithChildOptions(ctx, workflow.ChildWorkflowOptions{
				WorkflowID:        fmt.Sprintf("email-change-email-%s-%s", param.ClientCode, param.NewEmail),
				ParentClosePolicy: enums.PARENT_CLOSE_POLICY_ABANDON,
			}),
			SendEmailChangeWorkflow,
			activity.SendEmailChangeActivityParam{
				ClientCode: param.ClientCode,
				UserID:     param.UserID,
				NewEmail:   param.NewEmail,
				Token:      result.ChangeRow.TokenHash,
			},
		)

		return result.ChangeRow, nil
	})
}
