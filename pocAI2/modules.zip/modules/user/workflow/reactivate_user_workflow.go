package workflow

import (
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/activity"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	arModel "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/analytics_reporting_service/model"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/workflow"
)

type ReactivateUserWorkflowParam struct {
	ClientCode                  string
	UserID                      int64
	CurrentUserID               int64
	CurrentUserFullName         string
	Action                      string
	ActivePeriodUntil           *int64
	AnalyticsReportingTaskQueue string
}

type ReactivateUserWorkflowResult struct {
	Activated bool
}

func ReactivateUserWorkflow(ctx workflow.Context, param ReactivateUserWorkflowParam) (res any, err error) {
	activityCtx := workflow.WithActivityOptions(ctx, temporal_helper.DefaultActivityOptions())

	return temporal_helper.SafeRunner(func() (res any, err error) {
		identity := changelogIdentity{
			ClientID:     param.ClientCode,
			UserID:       strconv.FormatInt(param.CurrentUserID, 10),
			UserFullName: param.CurrentUserFullName,
			TaskQueue:    param.AnalyticsReportingTaskQueue,
		}

		var updated activity.ReactivateUserActivityResult
		if err = workflow.ExecuteActivity(
			activityCtx,
			constant.ActivityReactivateUser,
			activity.ReactivateUserActivityParam{
				ClientCode:        param.ClientCode,
				UserID:            param.UserID,
				CurrentUserID:     param.CurrentUserID,
				Action:            param.Action,
				ActivePeriodUntil: param.ActivePeriodUntil,
			},
		).Get(activityCtx, &updated); err != nil {
			return nil, err
		}

		var changelogs []arModel.Changelog

		changelogs = append(changelogs, userChangelog(
			arModel.ChangeLogActionEdit,
			param.UserID, updated.FullName,
			"Temporary Until", updated.OldDate, updated.NewDate, identity,
		))

		if updated.Activated {
			changelogs = append(changelogs, userChangelog(
				arModel.ChangeLogActionEdit, // Actually PRD says "Activate" / "Deactivate" as action for status? PRD for status says Action: "Activate". We can use arModel.ChangeLogAction("Activate")
				param.UserID, updated.FullName,
				"Status (Global)", "Inactive", "Active", identity,
			))
			// Need to override action to "Activate"
			changelogs[1].Action = arModel.ChangeLogAction("Activate")
		}

		// Fix the first action to be what was used in the old code
		changelogs[0].Action = arModel.ChangeLogAction(updated.PeriodAction)

		spawnChangeLogWorkflow(ctx, identity, changelogs)

		return ReactivateUserWorkflowResult{Activated: updated.Activated}, nil
	})
}
