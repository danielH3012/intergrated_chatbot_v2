package constant

const (
	MsgInternalServerError = "Something went wrong. Please try again."
	MsgUserNotFound        = "This user is no longer available."
	MsgForbidden           = "Forbidden"

	// Workflows
	WorkflowCreateUser       = "CreateUserWorkflow"
	WorkflowUpdateUser       = "UpdateUserWorkflow"
	WorkflowUpdateUserStatus = "UpdateUserStatusWorkflow"
	WorkflowDeleteUsers      = "DeleteUsersWorkflow"
	WorkflowReactivateUser   = "ReactivateUserWorkflow"

	WorkflowEmailChange                  = "EmailChangeWorkflow"
	WorkflowCancelEmailChange            = "CancelEmailChangeWorkflow"
	WorkflowConfirmEmailChange           = "ConfirmEmailChangeWorkflow"
	WorkflowResetAuthenticator           = "ResetAuthenticatorWorkflow"
	WorkflowSendActivationEmail          = "SendActivationEmailWorkflow"
	WorkflowSendEmailChange              = "SendEmailChangeWorkflow"
	WorkflowResendEmail                  = "ResendEmailWorkflow"
	WorkflowAutoDeactivateTemporaryUsers = "AutoDeactivateTemporaryUsersWorkflow"

	// Activities
	ActivityInsertUser                     = "InsertUserActivity"
	ActivityUpdateUser                     = "UpdateUserActivity"
	ActivityUpdateUserStatus               = "UpdateUserStatusActivity"
	ActivityDeleteUsers                    = "DeleteUsersActivity"
	ActivityReactivateUser                 = "ReactivateUserActivity"
	ActivityEmailChange                    = "EmailChangeActivity"
	ActivityCancelEmailChange              = "CancelEmailChangeActivity"
	ActivityConfirmEmailChangePublic       = "ConfirmEmailChangePublicActivity"
	ActivityConfirmEmailChangeTenant       = "ConfirmEmailChangeTenantActivity"
	ActivityUnconsumeEmailChangePublic     = "UnconsumeEmailChangePublicActivity"
	ActivityResendEmail                    = "ResendEmailActivity"
	ActivityValidateResetAuthenticator     = "ValidateResetAuthenticatorActivity"
	ActivityResetAuthenticatorPublic       = "ResetAuthenticatorPublicActivity"
	ActivityUpdateResetAuthenticatorTenant = "UpdateResetAuthenticatorTenantActivity"
	ActivitySendEmailChange                = "SendEmailChangeActivity"
	ActivityFetchClients                   = "FetchClientsActivity"
	ActivityAutoDeactivateExpiredUsers     = "AutoDeactivateExpiredUsersActivity"
)

// Profile picture upload: the file-manager-service row columns for a Global Settings user
// picture. PNG/JPG and 1 MB are the caps the Global Settings User PRD sets for the avatar.
const (
	ProfilePictureFolder   = "user"
	ProfilePictureType     = "global_settings"
	ProfilePictureModule   = "users"
	MaxProfilePictureBytes = 1 << 20
)
