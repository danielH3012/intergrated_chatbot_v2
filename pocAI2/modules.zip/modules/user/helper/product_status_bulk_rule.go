package helper

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
)

// ProductStatusBulkRule evaluates RBAC permission for POST /products/:productId/status/bulk
// based on the :productId path parameter.
func ProductStatusBulkRule(c fiber.Ctx, roles tsMiddleware.UserAccessCache) (bool, error) {
	productId := c.Params("productId")
	switch productId {
	case string(model.ProductAdminConsole):
		return rbac.Any(
			rbac.AdminConsoleSeeAll(),
			rbac.AdminConsoleSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole),
		)(c, roles)
	case string(model.ProductGlobalSettings):
		return rbac.Any(
			rbac.GlobalSettingsSeeAll(),
			rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole),
		)(c, roles)
	default:
		return false, nil
	}
}
