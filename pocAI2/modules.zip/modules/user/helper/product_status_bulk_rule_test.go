package helper_test

import (
	"net/http/httptest"
	"testing"

	"github.com/gofiber/fiber/v3"
	"github.com/stretchr/testify/assert"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/helper"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

func TestProductStatusBulkRule_AdminConsole(t *testing.T) {
	app := fiber.New()

	// 1. Total Control
	t.Run("TotalControl_Allowed", func(t *testing.T) {
		app.Post("/products/:productId/status/bulk", func(c fiber.Ctx) error {
			roles := tsMiddleware.UserAccessCache{
				ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
					enum.ModuleAccessAdminConsole: {IsTotalControl: true},
				},
			}
			allowed, err := helper.ProductStatusBulkRule(c, roles)
			assert.NoError(t, err)
			assert.True(t, allowed)
			return nil
		})

		req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/status/bulk", nil)
		_, err := app.Test(req)
		assert.NoError(t, err)
	})

	// 2. ManageUserAndRole Edit
	t.Run("ManageUserAndRole_Allowed", func(t *testing.T) {
		app.Post("/products/:productId/status/bulk-edit", func(c fiber.Ctx) error {
			roles := tsMiddleware.UserAccessCache{}
			roles.AdminConsoleSystemRole.GlobalRole = map[enum.SystemRoleKey]tsMiddleware.Permissions[bool]{
				enum.SystemRoleKeyManageUserAndRole: {Edit: true},
			}
			allowed, err := helper.ProductStatusBulkRule(c, roles)
			assert.NoError(t, err)
			assert.True(t, allowed)
			return nil
		})

		req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/status/bulk-edit", nil)
		_, err := app.Test(req)
		assert.NoError(t, err)
	})

	// 3. No permission
	t.Run("NoPermission_Denied", func(t *testing.T) {
		app.Post("/products/:productId/status/bulk-denied", func(c fiber.Ctx) error {
			roles := tsMiddleware.UserAccessCache{}
			allowed, err := helper.ProductStatusBulkRule(c, roles)
			assert.NoError(t, err)
			assert.False(t, allowed)
			return nil
		})

		req := httptest.NewRequest(fiber.MethodPost, "/products/admin_console/status/bulk-denied", nil)
		_, err := app.Test(req)
		assert.NoError(t, err)
	})
}

func TestProductStatusBulkRule_GlobalSettings(t *testing.T) {
	app := fiber.New()

	// 1. Total Control
	t.Run("TotalControl_Allowed", func(t *testing.T) {
		app.Post("/products/:productId/status/bulk", func(c fiber.Ctx) error {
			roles := tsMiddleware.UserAccessCache{
				ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
					enum.ModuleAccessGlobalSettings: {IsTotalControl: true},
				},
			}
			allowed, err := helper.ProductStatusBulkRule(c, roles)
			assert.NoError(t, err)
			assert.True(t, allowed)
			return nil
		})

		req := httptest.NewRequest(fiber.MethodPost, "/products/global_settings/status/bulk", nil)
		_, err := app.Test(req)
		assert.NoError(t, err)
	})

	// 2. No permission
	t.Run("NoPermission_Denied", func(t *testing.T) {
		app.Post("/products/:productId/status/bulk-denied", func(c fiber.Ctx) error {
			roles := tsMiddleware.UserAccessCache{}
			allowed, err := helper.ProductStatusBulkRule(c, roles)
			assert.NoError(t, err)
			assert.False(t, allowed)
			return nil
		})

		req := httptest.NewRequest(fiber.MethodPost, "/products/global_settings/status/bulk-denied", nil)
		_, err := app.Test(req)
		assert.NoError(t, err)
	})
}

func TestProductStatusBulkRule_UnknownProduct(t *testing.T) {
	app := fiber.New()

	app.Post("/products/:productId/status/bulk", func(c fiber.Ctx) error {
		roles := tsMiddleware.UserAccessCache{
			ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
				enum.ModuleAccessAdminConsole:   {IsTotalControl: true},
				enum.ModuleAccessGlobalSettings: {IsTotalControl: true},
			},
		}
		allowed, err := helper.ProductStatusBulkRule(c, roles)
		assert.NoError(t, err)
		assert.False(t, allowed)
		return nil
	})

	req := httptest.NewRequest(fiber.MethodPost, "/products/unknown_module/status/bulk", nil)
	_, err := app.Test(req)
	assert.NoError(t, err)
}
