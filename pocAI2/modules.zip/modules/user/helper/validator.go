package helper

import (
	"fmt"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/validator"
)

// ValidationError translates validator.ValidationErrors into a 422 HttpError
// with PRD-aligned messages. Body-bind failures stay 400; this handles only
// struct validation failures.
func ValidationError(err error) *coreEntity.HttpError {
	errs := validator.ParseValidationErrors(err)
	if len(errs) == 0 {
		return &coreEntity.HttpError{Code: 422, Message: err.Error()}
	}

	// Return the first error — the PRD messages are singular.
	v := errs[0]
	switch v.Field + "/" + v.Rule {
	case "first_name/required":
		return &coreEntity.HttpError{Code: 422, Message: "First Name must not be empty", Data: map[string]any{"field": "firstName"}}
	case "first_name/max":
		return &coreEntity.HttpError{Code: 422, Message: fmt.Sprintf("Max. %s characters for attribute 'firstName'", v.Param), Data: map[string]any{"field": "firstName"}}
	case "last_name/required":
		return &coreEntity.HttpError{Code: 422, Message: "Last Name must not be empty", Data: map[string]any{"field": "lastName"}}
	case "last_name/max":
		return &coreEntity.HttpError{Code: 422, Message: fmt.Sprintf("Max. %s characters for attribute 'lastName'", v.Param), Data: map[string]any{"field": "lastName"}}
	case "email/required":
		return &coreEntity.HttpError{Code: 422, Message: "Email must not be empty", Data: map[string]any{"field": "email"}}
	case "email/max":
		return &coreEntity.HttpError{Code: 422, Message: fmt.Sprintf("Max. %s characters for attribute 'email'", v.Param), Data: map[string]any{"field": "email"}}
	case "email/email":
		return &coreEntity.HttpError{Code: 422, Message: "Invalid email format", Data: map[string]any{"field": "email"}}
	case "division_i_d/required":
		return &coreEntity.HttpError{Code: 422, Message: "Division must not be empty", Data: map[string]any{"field": "divisionId"}}
	case "employee_i_d/max", "employee_id/max":
		return &coreEntity.HttpError{Code: 422, Message: fmt.Sprintf("Max. %s characters for attribute 'employeeId'", v.Param), Data: map[string]any{"field": "employeeId"}}
	default:
		return &coreEntity.HttpError{Code: 422, Message: err.Error()}
	}
}
