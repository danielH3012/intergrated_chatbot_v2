package helper_test

import (
	"testing"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/helper"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestHasEmoji(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected bool
	}{
		{"empty string", "", false},
		{"plain ASCII name", "John Doe", false},
		{"name with hyphens and apostrophes", "Mary-Jane O'Connor", false},
		{"name with accents", "René François Müller José", false},
		{"name with dots", "Dr. John Doe Jr.", false},
		{"name with simple emoji", "John 😀", true},
		{"name with party emoji", "🎉 Jane", true},
		{"name with thumbs up emoji", "Bob 👍", true},
		{"name with fire emoji", "Alice 🔥", true},
		{"name with office building emoji", "Building 🏢", true},
		{"name with compound emoji ZWJ", "Family 👨‍👩‍👧‍👦", true},
		{"name with flag emoji", "Flag 🇮🇩", true},
		{"employee id plain", "EMP-001", false},
		{"employee id with emoji", "EMP-001🔥", true},
		{"name with modern melting face emoji", "Jane 🫠", true},
		{"name with modern saluting face emoji", "🫡 Bob", true},
		{"name with modern heart hands emoji", "Alice 🫶", true},
		{"name with bubbles emoji", "Cleaning 🫧", true},
		{"name with star emoji", "Top ⭐ Team", true},
		{"name with colored circle emoji", "Status 🟢", true},
		{"name with hourglass emoji", "Pending ⏳", true},
		{"name with alarm clock emoji", "Shift ⏰", true},
		{"name with ok button emoji", "Approval 🆗", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.expected, helper.HasEmoji(tt.input))
		})
	}
}

func TestValidateUserEmojis(t *testing.T) {
	empIDValid := "EMP-100"
	empIDEmoji := "EMP-🔥"

	t.Run("all valid fields", func(t *testing.T) {
		err := helper.ValidateUserEmojis("John", "Doe", &empIDValid)
		assert.Nil(t, err)
	})

	t.Run("nil employeeID valid", func(t *testing.T) {
		err := helper.ValidateUserEmojis("John", "Doe", nil)
		assert.Nil(t, err)
	})

	t.Run("emoji in firstName", func(t *testing.T) {
		err := helper.ValidateUserEmojis("John 😀", "Doe", &empIDValid)
		require.NotNil(t, err)
		assert.Equal(t, 422, err.Code)
		assert.Equal(t, "First Name contains invalid characters", err.Message)
		data, ok := err.Data.(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "firstName", data["field"])
	})

	t.Run("emoji in lastName", func(t *testing.T) {
		err := helper.ValidateUserEmojis("John", "Doe 👍", &empIDValid)
		require.NotNil(t, err)
		assert.Equal(t, 422, err.Code)
		assert.Equal(t, "Last Name contains invalid characters", err.Message)
		data, ok := err.Data.(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "lastName", data["field"])
	})

	t.Run("emoji in employeeID", func(t *testing.T) {
		err := helper.ValidateUserEmojis("John", "Doe", &empIDEmoji)
		require.NotNil(t, err)
		assert.Equal(t, 422, err.Code)
		assert.Equal(t, "Employee ID contains invalid characters", err.Message)
		data, ok := err.Data.(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "employeeId", data["field"])
	})
}

func TestValidateEmployeeIDEmoji(t *testing.T) {
	t.Run("nil employeeID", func(t *testing.T) {
		assert.Nil(t, helper.ValidateEmployeeIDEmoji(nil))
	})

	t.Run("empty employeeID", func(t *testing.T) {
		empty := ""
		assert.Nil(t, helper.ValidateEmployeeIDEmoji(&empty))
	})

	t.Run("valid employeeID", func(t *testing.T) {
		valid := "EMP-001"
		assert.Nil(t, helper.ValidateEmployeeIDEmoji(&valid))
	})

	t.Run("emoji in employeeID", func(t *testing.T) {
		invalid := "EMP-😀"
		err := helper.ValidateEmployeeIDEmoji(&invalid)
		require.NotNil(t, err)
		assert.Equal(t, 422, err.Code)
		assert.Equal(t, "Employee ID contains invalid characters", err.Message)
		data, ok := err.Data.(map[string]any)
		require.True(t, ok)
		assert.Equal(t, "employeeId", data["field"])
	})
}
