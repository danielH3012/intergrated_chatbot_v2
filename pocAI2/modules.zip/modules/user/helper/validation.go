package helper

import (
	"regexp"
	"strings"

	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"github.com/gofiber/fiber/v3"
)

var emojiRegex = regexp.MustCompile(`[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{1F100}-\x{1F1FF}\x{1F200}-\x{1F2FF}\x{1F780}-\x{1F7FF}\x{1F900}-\x{1F9FF}\x{1FA00}-\x{1FAFF}\x{2300}-\x{23FF}\x{2600}-\x{26FF}\x{2700}-\x{27BF}\x{2B00}-\x{2BFF}\x{2190}-\x{21FF}\x{3200}-\x{32FF}\x{203C}\x{2049}\x{2122}\x{2139}\x{3030}\x{303D}\x{FE0F}]`)

// HasEmoji returns true if the input string contains any emoji character.
func HasEmoji(s string) bool {
	return emojiRegex.MatchString(s)
}

// ValidateUserEmojis checks firstName, lastName, and employeeID for emoji characters.
// Returns an HttpError with HTTP 422 if an emoji is found, otherwise nil.
func ValidateUserEmojis(firstName, lastName string, employeeID *string) *coreEntity.HttpError {
	if HasEmoji(strings.TrimSpace(firstName)) {
		return &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: "First Name contains invalid characters",
			Data:    map[string]any{"field": "firstName"},
		}
	}
	if HasEmoji(strings.TrimSpace(lastName)) {
		return &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: "Last Name contains invalid characters",
			Data:    map[string]any{"field": "lastName"},
		}
	}
	if employeeID != nil {
		trimmedEmpID := strings.TrimSpace(*employeeID)
		if trimmedEmpID != "" && HasEmoji(trimmedEmpID) {
			return &coreEntity.HttpError{
				Code:    fiber.StatusUnprocessableEntity,
				Message: "Employee ID contains invalid characters",
				Data:    map[string]any{"field": "employeeId"},
			}
		}
	}
	return nil
}

// ValidateEmployeeIDEmoji checks if an employee ID contains any emoji character.
func ValidateEmployeeIDEmoji(employeeID *string) *coreEntity.HttpError {
	if employeeID == nil {
		return nil
	}
	trimmed := strings.TrimSpace(*employeeID)
	if trimmed != "" && HasEmoji(trimmed) {
		return &coreEntity.HttpError{
			Code:    fiber.StatusUnprocessableEntity,
			Message: "Employee ID contains invalid characters",
			Data:    map[string]any{"field": "employeeId"},
		}
	}
	return nil
}
