package activity

import (
	"context"
	"errors"
	"log/slog"
	"strconv"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type ResendEmailActivityParam struct {
	ClientCode    string
	IDs           []string
	CurrentUserID int64
	Product       string
}

type EmailDispatch struct {
	Type       string // "activation" or "confirmation"
	UserID     int64
	Email      string
	ClientCode string
	Token      string
}

type ResendEmailActivityResult struct {
	Results    []userDto.ResendResult
	Changelogs []StatusChangelog
	Emails     []EmailDispatch
}

func (a *Activities) ResendEmailActivity(ctx context.Context, param ResendEmailActivityParam) (ResendEmailActivityResult, error) {
	results := []userDto.ResendResult{}
	changelogs := []StatusChangelog{}
	emails := []EmailDispatch{}

	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	product := param.Product
	if product == "" {
		product = string(model.ProductGlobalSettings)
	}

	for _, idStr := range param.IDs {
		id, err := strconv.ParseInt(idStr, 10, 64)
		if err != nil {
			continue
		}

		status := "blocked"
		var reason *string
		var emailType *string
		var retryAfterSeconds *int
		var cl *StatusChangelog
		var ed *EmailDispatch

		_, err = coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
			svc.SetTransaction(tx)
			defer svc.SetTransaction(nil)
			pubSvc.SetTransaction(tx)
			defer pubSvc.SetTransaction(nil)

			// 1. Entity suspension guard
			isSuspended, err := a.repo.IsEntitySuspended(ctx, svc, param.ClientCode)
			if err != nil {
				return nil, err
			}
			if isSuspended {
				r := "entity_suspended"
				reason = &r
				return nil, nil
			}

			targetUser, err := a.repo.GetOneByID(ctx, svc, id)
			if err != nil {
				return nil, err
			}

			if id == param.CurrentUserID {
				r := "self"
				reason = &r
				return nil, nil
			}
			if targetUser.IsDefault != nil && *targetUser.IsDefault {
				r := "default_user"
				reason = &r
				return nil, nil
			}

			hasTCRO, err := a.repo.IsTargetProtectedTCRO(ctx, svc, id, product)
			if err != nil {
				return nil, err
			}
			if hasTCRO {
				isActorTC, err := a.repo.IsActorTotalControl(ctx, svc, param.CurrentUserID, product)
				if err != nil {
					return nil, err
				}
				if !isActorTC {
					r := "tcro_target"
					reason = &r
					return nil, nil
				}
			}

			var branch string
			var lastActionTime time.Time
			var pendingEmailChange *model.UserEmailChange

			switch targetUser.ActivationStatus {
			case "Pending Activation":
				branch = "activation"
				activeToken, err := a.repo.GetActiveActivationToken(ctx, pubSvc, id)
				if err != nil {
					return nil, err
				}
				if activeToken != nil {
					lastActionTime = activeToken.CreatedAt
				}
			case "Activated":
				pendingEmailChange, err = a.repo.GetPendingEmailChange(ctx, pubSvc, id)
				if err != nil {
					return nil, err
				}
				if pendingEmailChange != nil {
					branch = "confirmation"
					if !pendingEmailChange.UpdatedAt.IsZero() {
						lastActionTime = pendingEmailChange.UpdatedAt
					} else {
						lastActionTime = pendingEmailChange.CreatedAt
					}
				}
			}

			if branch == "" {
				status = "skipped"
				r := "not_eligible"
				reason = &r
				return nil, nil
			}

			if !lastActionTime.IsZero() {
				elapsed := time.Since(lastActionTime)
				if elapsed < 60*time.Second {
					status = "skipped"
					r := "cooldown"
					reason = &r
					left := int(60 - elapsed.Seconds())
					retryAfterSeconds = &left
					return nil, nil
				}
			}

			var changelogAction string

			if branch == "activation" {
				// We just invalidate the token, and SendActivationEmailWorkflow will generate a new one!
				if err := a.repo.SupersedeActivationTokens(ctx, pubSvc, id); err != nil {
					return nil, err
				}

				changelogAction = "Resend Activation Email"

				ed = &EmailDispatch{
					Type:       "activation",
					UserID:     id,
					Email:      targetUser.Email,
					ClientCode: param.ClientCode,
					Token:      "", // Token not needed for SendActivationEmailWorkflow
				}

			} else {
				rawToken, err := a.repo.ExtendEmailChangeExpiry(ctx, pubSvc, pendingEmailChange.ID)
				if err != nil {
					return nil, err
				}

				changelogAction = "Resend Confirmation Email"

				ed = &EmailDispatch{
					Type:       "confirmation",
					UserID:     id,
					Email:      pendingEmailChange.NewEmail,
					ClientCode: param.ClientCode,
					Token:      rawToken,
				}
			}

			fullName := targetUser.FirstName
			if targetUser.LastName != "" {
				fullName += " " + targetUser.LastName
			}

			cl = &StatusChangelog{
				UserID:   id,
				FullName: fullName,
				Action:   changelogAction,
				Field:    "-",
				OldValue: "-",
				NewValue: "-",
				Product:  product,
			}

			status = "sent"
			emailType = &branch
			return nil, nil
		})

		if err != nil {
			if errors.Is(err, pgx.ErrNoRows) || coreEntity.ToHttpError(err).Code == 404 {
				r := "not_found"
				reason = &r
				status = "blocked"
			} else {
				slog.ErrorContext(ctx, "ResendEmailActivity", "err", err)
				return ResendEmailActivityResult{
					Results:    results,
					Changelogs: changelogs,
					Emails:     emails,
				}, err
			}
		}

		results = append(results, userDto.ResendResult{
			ID:                idStr,
			Status:            status,
			Type:              emailType,
			Reason:            reason,
			RetryAfterSeconds: retryAfterSeconds,
		})

		if cl != nil {
			changelogs = append(changelogs, *cl)
		}
		if ed != nil {
			emails = append(emails, *ed)
		}
	}

	return ResendEmailActivityResult{
		Results:    results,
		Changelogs: changelogs,
		Emails:     emails,
	}, nil
}
