package activity

import (
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type Activities struct {
	dbName       string
	repo         repository.UserRepositor
	makeSvc      func(schema string) coreService.PostgreSQLServicer
	emailSvc     coreService.EmailServicer
	emsBaseURL   string
	serviceToken string
}

func NewActivities(dbName string, repo repository.UserRepositor, makeSvc func(schema string) coreService.PostgreSQLServicer, emailSvc coreService.EmailServicer, emsBaseURL string, serviceToken string) *Activities {
	if makeSvc == nil {
		makeSvc = func(schema string) coreService.PostgreSQLServicer {
			return coreService.MakePostgreSQLService(schema + ":" + dbName)
		}
	}
	return &Activities{
		dbName:       dbName,
		repo:         repo,
		makeSvc:      makeSvc,
		emailSvc:     emailSvc,
		emsBaseURL:   emsBaseURL,
		serviceToken: serviceToken,
	}
}

func (a *Activities) tenantSvc(clientCode string) coreService.PostgreSQLServicer {
	return a.makeSvc(clientCode)
}

func (a *Activities) publicSvc() coreService.PostgreSQLServicer {
	return a.makeSvc("public")
}
