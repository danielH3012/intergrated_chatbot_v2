package activity

import (
	"context"
	"errors"
	"log/slog"
	"strconv"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type DeleteUsersActivityParam struct {
	ClientCode    string
	IDs           []string
	CurrentUserID int64
}

type DeleteChangelog struct {
	UserID   int64
	FullName string
}

type DeleteUserActivityResultItem struct {
	ID      string
	Status  string
	Reason  *string
	Success bool
}

type DeleteUsersActivityResult struct {
	Results    []DeleteUserActivityResultItem
	Changelogs []DeleteChangelog
}

func (a *Activities) DeleteUsersActivity(ctx context.Context, param DeleteUsersActivityParam) (DeleteUsersActivityResult, error) {
	results := []DeleteUserActivityResultItem{}
	changelogs := []DeleteChangelog{}
	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	for _, idStr := range param.IDs {
		id, err := strconv.ParseInt(idStr, 10, 64)
		if err != nil {
			results = append(results, DeleteUserActivityResultItem{ID: idStr, Status: "blocked", Reason: new("not_found"), Success: false})
			continue
		}

		reason := ""
		if id == param.CurrentUserID {
			reason = "self"
			results = append(results, DeleteUserActivityResultItem{ID: idStr, Status: "blocked", Reason: &reason, Success: false})
			continue
		}

		var cl *DeleteChangelog
		_, err = coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
			svc.SetTransaction(tx)
			defer svc.SetTransaction(nil)

			pubSvc.SetTransaction(tx)
			defer pubSvc.SetTransaction(nil)

			existingUser, err := a.repo.GetOneByID(ctx, svc, id)
			if err != nil {
				return nil, err
			}

			if existingUser.IsDefault != nil && *existingUser.IsDefault {
				return nil, coreEntity.Forbidden(constant.MsgForbidden)
			}

			// POV Matrix Check
			isTargetTCRO, err := a.repo.IsTargetProtectedTCRO(ctx, svc, id, "global_settings")
			if err != nil {
				return nil, err
			}
			if isTargetTCRO {
				isActorTC, err := a.repo.IsActorTotalControl(ctx, svc, param.CurrentUserID, "global_settings")
				if err != nil {
					return nil, err
				}
				if !isActorTC {
					return nil, coreEntity.Forbidden("tcro_target")
				}
			}

			if err := a.repo.Delete(ctx, svc, id); err != nil {
				return nil, err
			}

			if err := a.repo.DeleteUserCredentialPublic(ctx, pubSvc, existingUser.Email, param.ClientCode); err != nil {
				return nil, err
			}

			fullName := existingUser.FirstName
			if existingUser.LastName != "" {
				fullName += " " + existingUser.LastName
			}

			cl = &DeleteChangelog{
				UserID:   id,
				FullName: fullName,
			}

			return nil, nil
		})
		if err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				reason = "not_found"
				results = append(results, DeleteUserActivityResultItem{ID: idStr, Status: "blocked", Reason: &reason, Success: false})
			} else if httpErr, ok := err.(*coreEntity.HttpError); ok {
				switch httpErr.Code {
				case 404:
					reason = "not_found"
					results = append(results, DeleteUserActivityResultItem{ID: idStr, Status: "blocked", Reason: &reason, Success: false})
				case 403:
					reason = httpErr.Message
					if reason != "tcro_target" && reason != "self" {
						reason = "default_user"
					}
					results = append(results, DeleteUserActivityResultItem{ID: idStr, Status: "blocked", Reason: &reason, Success: false})
				default:
					slog.ErrorContext(ctx, "DeleteUsersActivity", "err", err)
					return DeleteUsersActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
				}
			} else {
				slog.ErrorContext(ctx, "DeleteUsersActivity", "err", err)
				return DeleteUsersActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
			}
			continue
		}

		results = append(results, DeleteUserActivityResultItem{ID: idStr, Status: "deleted", Reason: nil, Success: true})
		if cl != nil {
			changelogs = append(changelogs, *cl)
		}
	}

	return DeleteUsersActivityResult{
		Results:    results,
		Changelogs: changelogs,
	}, nil
}
