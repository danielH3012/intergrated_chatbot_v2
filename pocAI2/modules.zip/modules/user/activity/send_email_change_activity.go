package activity

import (
	"context"
	"log/slog"

	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type SendEmailChangeActivityParam struct {
	ClientCode string
	UserID     int64
	OldEmail   string
	NewEmail   string
	Token      string
}

func (a *Activities) SendEmailChangeActivity(ctx context.Context, param SendEmailChangeActivityParam) (any, error) {
	if a.emailSvc == nil {
		slog.Error("Email service not set")
		return nil, nil
	}

	slog.Info("DEV: Email Change Token (Use this for testing)", "email", param.NewEmail, "raw_token", param.Token)

	return nil, a.emailSvc.SendEmail(coreService.SendEmailProps{
		To:      param.NewEmail,
		Subject: "Your " + param.ClientCode + " email change confirmation",
		Body:    param.Token, // Sending raw token for now, following auth module convention
	})
}
