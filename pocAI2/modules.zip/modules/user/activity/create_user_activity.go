package activity

import (
	"context"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"
)

type InsertUserActivityParam struct {
	ClientCode        string
	CurrentUserID     *int64
	FirstName         string
	LastName          string
	Email             string
	EmployeeID        *string
	PositionID        *int64
	DivisionID        int64
	TagID             *int64
	ActivePeriodUntil *int64
	Access            []string
	CustomFields      map[string]any
	ProfilePicture    *string
	ProfilePictureID  *int64
}

type InsertUserActivityResult struct {
	ID       int64
	FullName string
}

// InsertUserActivity executes the database transaction for creating a user.
func (a *Activities) InsertUserActivity(ctx context.Context, param InsertUserActivityParam) (InsertUserActivityResult, error) {
	tenantSvc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	// 1. Email uniqueness check
	isUnique, err := a.repo.CheckEmailUniqueness(ctx, pubSvc, param.Email)
	if err != nil {
		slog.ErrorContext(ctx, "InsertUserActivity: CheckEmailUniqueness", "err", err)
		return InsertUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}
	if !isUnique {
		return InsertUserActivityResult{}, coreEntity.WrapHttpError(&coreEntity.HttpError{
			Code:    fiber.StatusConflict,
			Message: "Email already exists",
			Data: map[string]any{
				"field": "email",
			},
		})
	}

	// 1.5 Employee ID uniqueness check
	if param.EmployeeID != nil && *param.EmployeeID != "" {
		isUniqueEmp, err := a.repo.CheckEmployeeIDUniqueness(ctx, tenantSvc, *param.EmployeeID, nil)
		if err != nil {
			slog.ErrorContext(ctx, "InsertUserActivity: CheckEmployeeIDUniqueness", "err", err)
			return InsertUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
		}
		if !isUniqueEmp {
			return InsertUserActivityResult{}, coreEntity.WrapHttpError(&coreEntity.HttpError{
				Code:    422,
				Message: "Employee ID already exists",
				Data: map[string]any{
					"field": "employeeId",
				},
			})
		}
	}

	userID := coreDb.Node.Generate().Int64()

	var activePeriodUntil *time.Time
	if param.ActivePeriodUntil != nil {
		t := time.UnixMilli(*param.ActivePeriodUntil)
		activePeriodUntil = &t
	}

	user := model.User{
		ID:                   userID,
		FirstName:            param.FirstName,
		LastName:             param.LastName,
		Email:                param.Email,
		EmployeeID:           param.EmployeeID,
		PositionID:           param.PositionID,
		DivisionID:           param.DivisionID,
		ActivationStatus:     "Pending Activation",
		IsGlobalActive:       true,
		IsTemporary:          new(bool),
		TagID:                param.TagID,
		CustomFields:         &param.CustomFields,
		ProfilePicture:       param.ProfilePicture,
		ProfilePictureFileID: param.ProfilePictureID,
		CreatedBy:            param.CurrentUserID,
		ActivePeriodUntil:    activePeriodUntil,
	}

	if activePeriodUntil != nil {
		*user.IsTemporary = true
	} else {
		*user.IsTemporary = false
	}

	// Database Transaction
	_, err = coreService.UseTransactions(ctx, tenantSvc.GetPool(), func(tx pgx.Tx) (any, error) {
		tenantSvc.SetTransaction(tx)
		defer tenantSvc.SetTransaction(nil)

		pubSvc.SetTransaction(tx)
		defer pubSvc.SetTransaction(nil)

		// Insert tenant data
		if err := a.repo.Create(ctx, tenantSvc, user, param.Access); err != nil {
			return nil, err
		}

		if err := a.repo.InsertUserCredentialPublic(ctx, pubSvc, param.Email, param.ClientCode); err != nil {
			return nil, err
		}

		return nil, nil
	})
	if err != nil {
		if httpErr, isHttpError := err.(*coreEntity.HttpError); isHttpError {
			return InsertUserActivityResult{}, coreEntity.WrapHttpError(httpErr)
		}
		slog.ErrorContext(ctx, "CreateUserActivity: UseTransactions", "err", err)
		return InsertUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	fullName := param.FirstName
	if param.LastName != "" {
		fullName += " " + param.LastName
	}

	return InsertUserActivityResult{
		ID:       userID,
		FullName: fullName,
	}, nil
}
