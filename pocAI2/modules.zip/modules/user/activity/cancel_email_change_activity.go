package activity

import (
	"context"
	"errors"
	"log/slog"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type CancelEmailChangeActivityParam struct {
	ClientCode string
	UserID     int64
}

type CancelEmailChangeActivityResult struct {
	FullName string
	OldEmail string
	NewEmail string
}

func (a *Activities) CancelEmailChangeActivity(ctx context.Context, param CancelEmailChangeActivityParam) (CancelEmailChangeActivityResult, error) {
	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	var result CancelEmailChangeActivityResult

	_, err := coreService.UseTransactions(ctx, pubSvc.GetPool(), func(tx pgx.Tx) (any, error) {
		pubSvc.SetTransaction(tx)
		defer pubSvc.SetTransaction(nil)

		// Get pending email change first to record in changelog
		pending, err := a.repo.GetPendingEmailChange(ctx, pubSvc, param.UserID)
		if err != nil {
			return nil, err
		}
		if pending == nil {
			return nil, coreEntity.NotFound("No pending email change found for this user.")
		}

		result.NewEmail = pending.NewEmail

		if err := a.repo.CancelEmailChange(ctx, pubSvc, param.UserID); err != nil {
			return nil, err
		}

		return nil, nil
	})

	if err != nil {
		if httpErr, isHttpError := err.(*coreEntity.HttpError); isHttpError {
			return result, coreEntity.WrapHttpError(httpErr)
		}
		if errors.Is(err, pgx.ErrNoRows) {
			return result, coreEntity.WrapHttpError(coreEntity.NotFound("No pending email change found for this user."))
		}
		slog.ErrorContext(ctx, "CancelEmailChangeActivity", "err", err)
		return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	// Get user for changelog
	targetUser, err := a.repo.GetOneByID(ctx, svc, param.UserID)
	if err == nil {
		fullName := targetUser.FirstName
		if targetUser.LastName != "" {
			fullName += " " + targetUser.LastName
		}
		result.FullName = fullName
		result.OldEmail = targetUser.Email
	}

	return result, nil
}
