package activity

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/constant"
)

// FetchClientsActivity calls Enterprise Management to list all client IDs.
func (a *Activities) FetchClientsActivity(ctx context.Context) ([]string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, a.emsBaseURL+"/internal/clients", nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set(constant.HEADER_SERVICE_TOKEN, a.serviceToken)

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		responseBody, _ := io.ReadAll(resp.Body)
		slog.ErrorContext(
			ctx, "AutoDeactivate: unexpected response status fetching clients",
			"status", resp.StatusCode,
			"body", string(responseBody),
		)
		return nil, fmt.Errorf("unexpected status %d", resp.StatusCode)
	}

	var body struct {
		Data struct {
			ClientIDs []string `json:"clientCodes"`
		} `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return nil, fmt.Errorf("decode: %w", err)
	}
	return body.Data.ClientIDs, nil
}

// AutoDeactivateExpiredUsersActivityResult contains the generated changelogs to log
type AutoDeactivateExpiredUsersActivityResult struct {
	Changelogs []StatusChangelog
}

// AutoDeactivateExpiredUsersActivity finds expired temporary users for a given tenant
// and deactivates them by executing the same underlying logic as UpdateUserStatusActivity.
func (a *Activities) AutoDeactivateExpiredUsersActivity(ctx context.Context, clientCode string) (AutoDeactivateExpiredUsersActivityResult, error) {
	svc := a.tenantSvc(clientCode)
	now := time.Now()

	expiredUserIDs, err := a.repo.GetExpiredTemporaryUserIDs(ctx, svc, now)
	if err != nil {
		slog.ErrorContext(ctx, "AutoDeactivateExpiredUsersActivity: failed to get expired users", "client", clientCode, "err", err)
		return AutoDeactivateExpiredUsersActivityResult{}, err
	}

	if len(expiredUserIDs) == 0 {
		return AutoDeactivateExpiredUsersActivityResult{}, nil
	}

	var stringIDs []string
	for _, id := range expiredUserIDs {
		stringIDs = append(stringIDs, fmt.Sprintf("%d", id))
	}

	param := UpdateUserStatusActivityParam{
		ClientCode:    clientCode,
		IDs:           stringIDs,
		IsActive:      false,
		ModuleKey:     string(model.ProductGlobalSettings),
		CurrentUserID: 0, // 0 for System
	}

	res, err := a.UpdateUserStatusActivity(ctx, param)
	if err != nil {
		return AutoDeactivateExpiredUsersActivityResult{}, err
	}

	if res.DBError != nil {
		return AutoDeactivateExpiredUsersActivityResult{}, fmt.Errorf("database error updating statuses: %s", *res.DBError)
	}

	for i := range res.Changelogs {
		res.Changelogs[i].Action = "Auto-Deactivate"
	}

	return AutoDeactivateExpiredUsersActivityResult{
		Changelogs: res.Changelogs,
	}, nil
}
