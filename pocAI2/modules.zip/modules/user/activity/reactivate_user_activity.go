package activity

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type ReactivateUserActivityParam struct {
	ClientCode        string
	UserID            int64
	CurrentUserID     int64
	Action            string
	ActivePeriodUntil *int64
}

type ReactivateUserActivityResult struct {
	PeriodAction string
	OldDate      string
	NewDate      string
	Activated    bool
	FullName     string
}

func (a *Activities) ReactivateUserActivity(ctx context.Context, param ReactivateUserActivityParam) (ReactivateUserActivityResult, error) {
	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	var result ReactivateUserActivityResult

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)
		pubSvc.SetTransaction(tx)
		defer pubSvc.SetTransaction(nil)

		targetUser, err := a.repo.GetOneByID(ctx, svc, param.UserID)
		if err != nil {
			return nil, err
		}

		if targetUser.IsTemporary == nil || !*targetUser.IsTemporary {
			return nil, coreEntity.NotFound(constant.MsgUserNotFound)
		}

		if param.UserID == param.CurrentUserID {
			return nil, coreEntity.Forbidden(constant.MsgForbidden)
		}
		if targetUser.IsDefault != nil && *targetUser.IsDefault {
			return nil, coreEntity.Forbidden(constant.MsgForbidden)
		}

		hasTCRO, err := a.repo.IsTargetProtectedTCRO(ctx, svc, param.UserID, string(model.ProductGlobalSettings))
		if err != nil {
			return nil, err
		}
		if hasTCRO {
			isActorTC, err := a.repo.IsActorTotalControl(ctx, svc, param.CurrentUserID, string(model.ProductGlobalSettings))
			if err != nil {
				return nil, err
			}
			if !isActorTC {
				return nil, coreEntity.Forbidden("tcro_target")
			}
		}

		var isTemporary bool
		var activePeriodUntil *time.Time
		var periodAction string
		var oldDate string
		var newDate string

		switch param.Action {
		case "extend":
			parsed := time.UnixMilli(*param.ActivePeriodUntil).UTC().Truncate(24 * time.Hour)

			isTemporary = true
			activePeriodUntil = &parsed

			periodAction = "Set Temporary User"
			oldDate = "-"
			if targetUser.ActivePeriodUntil != nil {
				oldDate = targetUser.ActivePeriodUntil.Format("2006-01-02")
			}
			newDate = parsed.Format("2006-01-02")

		case "make_permanent":
			isTemporary = false
			activePeriodUntil = nil

			periodAction = "Remove Temporary User"
			oldDate = "-"
			if targetUser.ActivePeriodUntil != nil {
				oldDate = targetUser.ActivePeriodUntil.Format("2006-01-02")
			}
			newDate = "-"
		}

		if err := a.repo.UpdateUserReactivation(ctx, svc, param.UserID, isTemporary, activePeriodUntil); err != nil {
			return nil, err
		}

		result.PeriodAction = periodAction
		result.OldDate = oldDate
		result.NewDate = newDate

		fullName := targetUser.FirstName
		if targetUser.LastName != "" {
			fullName += " " + targetUser.LastName
		}
		result.FullName = fullName

		if !targetUser.IsActive {
			if err := a.repo.UpdateUserGlobalActive(ctx, svc, param.UserID, true); err != nil {
				return nil, err
			}
			result.Activated = true
		}

		return nil, nil
	})

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return ReactivateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.NotFound(constant.MsgUserNotFound))
		}
		if httpErr, isHttpError := err.(*coreEntity.HttpError); isHttpError {
			return ReactivateUserActivityResult{}, coreEntity.WrapHttpError(httpErr)
		}
		slog.ErrorContext(ctx, "ReactivateUserActivity", "err", err)
		return ReactivateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	return result, nil
}
