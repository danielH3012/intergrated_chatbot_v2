package activity

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"github.com/gofiber/fiber/v3"
	"github.com/jackc/pgx/v5"
)

type UpdateUserActivityParam struct {
	ClientCode        string
	UserID            int64
	CurrentUserID     *int64
	FirstName         string
	LastName          string
	Email             string
	EmployeeID        *string
	PositionID        *int64
	DivisionID        int64
	TagID             *int64
	ActivePeriodUntil *int64
	Access            []string
	CustomFields      map[string]any
	ProfilePicture    *string
	ProfilePictureID  *int64
}

type FieldChange struct {
	Action   string
	Field    string
	OldValue string
	NewValue string
}

type UpdateUserActivityResult struct {
	Changes             []FieldChange
	StageEmailChange    bool
	SendActivationEmail bool
	NewEmail            string
}

func (a *Activities) UpdateUserActivity(ctx context.Context, param UpdateUserActivityParam) (UpdateUserActivityResult, error) {
	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	existingUser, err := a.repo.GetDetail(ctx, svc, param.UserID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.NotFound(constant.MsgUserNotFound))
		}
		slog.ErrorContext(ctx, "UpdateUserActivity: GetDetail", "err", err)
		return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	if param.CurrentUserID != nil && param.UserID == *param.CurrentUserID {
		return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden(constant.MsgForbidden))
	}

	if param.CurrentUserID != nil {
		isTargetTCRO, err := a.repo.IsTargetProtectedTCRO(ctx, svc, param.UserID, "global_settings")
		if err != nil {
			slog.ErrorContext(ctx, "UpdateUserActivity: IsTargetProtectedTCRO", "err", err)
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
		}
		if isTargetTCRO {
			isActorTC, err := a.repo.IsActorTotalControl(ctx, svc, *param.CurrentUserID, "global_settings")
			if err != nil {
				slog.ErrorContext(ctx, "UpdateUserActivity: IsActorTotalControl", "err", err)
				return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
			}
			if !isActorTC {
				return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden("tcro_target"))
			}
		}
	}

	if existingUser.IsDefault != nil && *existingUser.IsDefault {
		// Default user guard: only removing module from access is blocked.
		removedCount, err := a.repo.CountActiveModulesRemoved(ctx, svc, param.UserID, param.Access)
		if err != nil {
			slog.ErrorContext(ctx, "UpdateUserActivity: CountActiveModulesRemoved", "err", err)
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
		}
		if removedCount > 0 {
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.Forbidden(constant.MsgForbidden))
		}
	}

	if param.Email != existingUser.Email {
		isUnique, err := a.repo.CheckEmailUniqueness(ctx, pubSvc, param.Email)
		if err != nil {
			slog.ErrorContext(ctx, "UpdateUserActivity: CheckEmailUniqueness", "err", err)
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
		}
		if !isUnique {
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(&coreEntity.HttpError{
				Code:    fiber.StatusConflict,
				Message: "Email already exists",
				Data: map[string]any{
					"field": "email",
				},
			})
		}
	}

	if param.EmployeeID != nil && *param.EmployeeID != "" {
		isUniqueEmp, err := a.repo.CheckEmployeeIDUniqueness(ctx, svc, *param.EmployeeID, &param.UserID)
		if err != nil {
			slog.ErrorContext(ctx, "UpdateUserActivity: CheckEmployeeIDUniqueness", "err", err)
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
		}
		if !isUniqueEmp {
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(&coreEntity.HttpError{
				Code:    422,
				Message: "Employee ID already exists",
				Data: map[string]any{
					"field": "employeeId",
				},
			})
		}
	}

	user := model.User{
		ID:                   param.UserID,
		FirstName:            param.FirstName,
		LastName:             param.LastName,
		Email:                param.Email,
		EmployeeID:           param.EmployeeID,
		PositionID:           param.PositionID,
		DivisionID:           param.DivisionID,
		TagID:                param.TagID,
		CustomFields:         &param.CustomFields,
		ProfilePicture:       param.ProfilePicture,
		ProfilePictureFileID: param.ProfilePictureID,
		ModifiedBy:           param.CurrentUserID,
	}

	user.IsTemporary = new(bool)
	if param.ActivePeriodUntil != nil {
		t := time.UnixMilli(*param.ActivePeriodUntil)
		user.ActivePeriodUntil = &t
		*user.IsTemporary = true
	} else {
		*user.IsTemporary = false
	}

	var stageEmailChange bool
	var sendActivationEmail bool
	if existingUser.Email != param.Email {
		if existingUser.ActivationStatus != "Pending Activation" {
			stageEmailChange = true
			user.Email = existingUser.Email // Keep old email for now
		} else {
			sendActivationEmail = true
			user.Email = param.Email
		}
	}

	oldFullName := existingUser.FirstName
	if existingUser.LastName != "" {
		oldFullName += " " + existingUser.LastName
	}
	newFullName := param.FirstName
	if param.LastName != "" {
		newFullName += " " + param.LastName
	}

	_, err = coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)

		pubSvc.SetTransaction(tx)
		defer pubSvc.SetTransaction(nil)

		if err := a.repo.Update(ctx, svc, user, param.Access); err != nil {
			return nil, err
		}

		if sendActivationEmail {
			if err := a.repo.UpdateUserCredentialEmailPublic(ctx, pubSvc, existingUser.Email, param.Email, param.ClientCode); err != nil {
				if !errors.Is(err, pgx.ErrNoRows) && !strings.Contains(err.Error(), "no rows in result set") {
					return nil, err
				}
			}
		}

		if oldFullName != newFullName {
			renameEvent := model.Outbox{
				ID:           coreDb.Node.Generate().Int64(),
				EventType:    "user.renamed",
				PartitionKey: fmt.Sprintf("%d", param.UserID),
				Payload: map[string]any{
					"userId":   fmt.Sprintf("%d", param.UserID),
					"clientId": param.ClientCode,
					"fullName": newFullName,
				},
				CreatedAt: time.Now(),
				UpdatedAt: time.Now(),
			}
			if _, err := pubSvc.InsertOneWithData(ctx, "outbox", renameEvent); err != nil {
				return nil, err
			}
		}

		return nil, nil
	})
	if err != nil {
		if httpErr, isHttpError := err.(*coreEntity.HttpError); isHttpError {
			return UpdateUserActivityResult{}, coreEntity.WrapHttpError(httpErr)
		}
		slog.ErrorContext(ctx, "UpdateUserActivity: UseTransactions", "err", err)
		return UpdateUserActivityResult{}, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	changes := []FieldChange{}
	if existingUser.FirstName != param.FirstName {
		oldFN := existingUser.FirstName
		if oldFN == "" {
			oldFN = "-"
		}
		newFN := param.FirstName
		if newFN == "" {
			newFN = "-"
		}
		changes = append(changes, FieldChange{Action: "Edit", Field: "First Name", OldValue: oldFN, NewValue: newFN})
	}
	if existingUser.LastName != param.LastName {
		oldLN := existingUser.LastName
		if oldLN == "" {
			oldLN = "-"
		}
		newLN := param.LastName
		if newLN == "" {
			newLN = "-"
		}
		changes = append(changes, FieldChange{Action: "Edit", Field: "Last Name", OldValue: oldLN, NewValue: newLN})
	}
	if existingUser.Email != param.Email && !stageEmailChange {
		changes = append(changes, FieldChange{Action: "Email Updated", Field: "Email", OldValue: existingUser.Email, NewValue: param.Email})
	}

	// Employee ID
	var oldEmp, newEmp string
	if existingUser.EmployeeID != nil {
		oldEmp = *existingUser.EmployeeID
	}
	if param.EmployeeID != nil {
		newEmp = *param.EmployeeID
	}
	if oldEmp != newEmp {
		oldVal := oldEmp
		if oldVal == "" {
			oldVal = "-"
		}
		newVal := newEmp
		if newVal == "" {
			newVal = "-"
		}
		changes = append(changes, FieldChange{Action: "Edit", Field: "Employee ID", OldValue: oldVal, NewValue: newVal})
	}

	// Position
	var oldPosID, newPosID string
	if existingUser.PositionID != nil {
		oldPosID = *existingUser.PositionID
	}
	if param.PositionID != nil {
		newPosID = fmt.Sprint(*param.PositionID)
	}
	if oldPosID != newPosID {
		oldPosName := "-"
		if existingUser.Position != nil && *existingUser.Position != "" {
			oldPosName = *existingUser.Position
		}
		newPosName := "-"
		if param.PositionID != nil {
			if name, err := a.repo.GetPositionNameByID(ctx, svc, *param.PositionID); err == nil && name != "" {
				newPosName = name
			}
		}
		changes = append(changes, FieldChange{Action: "Edit", Field: "Position", OldValue: oldPosName, NewValue: newPosName})
	}

	// Division
	oldDivID := existingUser.DivisionID
	newDivID := fmt.Sprint(param.DivisionID)
	if oldDivID != newDivID {
		oldDivName := "-"
		if existingUser.Division != nil && *existingUser.Division != "" {
			oldDivName = *existingUser.Division
		}
		newDivName := "-"
		if param.DivisionID != 0 {
			if name, err := a.repo.GetDivisionNameByID(ctx, svc, param.DivisionID); err == nil && name != "" {
				newDivName = name
			}
		}
		changes = append(changes, FieldChange{Action: "Edit", Field: "Division", OldValue: oldDivName, NewValue: newDivName})
	}

	// Photo
	var oldPhoto, newPhoto string
	if existingUser.ProfilePicture != nil {
		oldPhoto = *existingUser.ProfilePicture
	}
	if param.ProfilePicture != nil {
		newPhoto = *param.ProfilePicture
	}
	if oldPhoto != newPhoto || (param.ProfilePictureID != nil && (existingUser.ProfilePictureFileID == nil || *param.ProfilePictureID != *existingUser.ProfilePictureFileID)) {
		changes = append(changes, FieldChange{Action: "Edit", Field: "Photo", OldValue: "-", NewValue: "-"})
	}

	// TAG
	// TODO: When tag-service is integrated, resolve param.TagID into tagCode via TAG Service HTTP client.
	var oldTagID, newTagID *int64
	oldTagID = existingUser.TagID
	newTagID = param.TagID

	oldTagCode := "-"
	if existingUser.TagCode != nil && *existingUser.TagCode != "" {
		oldTagCode = *existingUser.TagCode
	} else if oldTagID != nil {
		oldTagCode = fmt.Sprint(*oldTagID)
	}

	hasOldTag := oldTagID != nil || oldTagCode != "-"
	hasNewTag := newTagID != nil

	if hasOldTag || hasNewTag {
		if !hasOldTag && hasNewTag {
			// Pair TAG
			newTagVal := fmt.Sprint(*newTagID)
			changes = append(changes, FieldChange{Action: "Pair TAG", Field: "TAG", OldValue: "-", NewValue: newTagVal})
		} else if hasOldTag && !hasNewTag {
			// Unpair TAG
			changes = append(changes, FieldChange{Action: "Unpair TAG", Field: "TAG", OldValue: oldTagCode, NewValue: "-"})
		} else if hasOldTag && hasNewTag {
			// Both present; compare IDs to prevent spurious changelog when TAG hasn't changed
			if (oldTagID != nil && *oldTagID != *newTagID) || (oldTagID == nil && oldTagCode != fmt.Sprint(*newTagID)) {
				newTagVal := fmt.Sprint(*newTagID)
				changes = append(changes, FieldChange{Action: "Edit", Field: "TAG", OldValue: oldTagCode, NewValue: newTagVal})
			}
		}
	}

	// Temporary Until
	var oldDateStr, newDateStr string
	if existingUser.ActivePeriodUntil != nil && !existingUser.ActivePeriodUntil.IsZero() {
		oldDateStr = existingUser.ActivePeriodUntil.Format("2006-01-02")
	}
	if param.ActivePeriodUntil != nil {
		newDateStr = time.UnixMilli(*param.ActivePeriodUntil).Format("2006-01-02")
	}
	if oldDateStr != newDateStr {
		if oldDateStr == "" && newDateStr != "" {
			changes = append(changes, FieldChange{Action: "Set Temporary User", Field: "Temporary Until", OldValue: "-", NewValue: newDateStr})
		} else if oldDateStr != "" && newDateStr == "" {
			changes = append(changes, FieldChange{Action: "Remove Temporary User", Field: "Temporary Until", OldValue: oldDateStr, NewValue: "-"})
		} else if oldDateStr != "" && newDateStr != "" {
			changes = append(changes, FieldChange{Action: "Edit", Field: "Temporary Until", OldValue: oldDateStr, NewValue: newDateStr})
		}
	}

	// Custom Fields
	oldCF := make(map[string]any)
	if existingUser.CustomFields != nil {
		oldCF = *existingUser.CustomFields
	}
	newCF := param.CustomFields
	if newCF == nil {
		newCF = make(map[string]any)
	}

	allKeys := make(map[string]bool)
	for k := range oldCF {
		allKeys[k] = true
	}
	for k := range newCF {
		allKeys[k] = true
	}

	formatCustomFieldValue := func(v any) string {
		if v == nil {
			return "-"
		}
		switch val := v.(type) {
		case string:
			if val == "" {
				return "-"
			}
			return val
		case bool:
			if val {
				return "true"
			}
			return "false"
		default:
			s := fmt.Sprint(val)
			if s == "" {
				return "-"
			}
			return s
		}
	}

	for k := range allKeys {
		oldV := formatCustomFieldValue(oldCF[k])
		newV := formatCustomFieldValue(newCF[k])
		if oldV != newV {
			changes = append(changes, FieldChange{
				Action:   "Edit",
				Field:    k,
				OldValue: oldV,
				NewValue: newV,
			})
		}
	}

	oldAccessMap := make(map[string]bool)
	for _, a := range existingUser.Access {
		oldAccessMap[a] = true
	}

	newAccessMap := make(map[string]bool)
	for _, a := range param.Access {
		newAccessMap[a] = true
		if !oldAccessMap[a] {
			changes = append(changes, FieldChange{
				Action:   "Add Access",
				Field:    "App Access",
				OldValue: "-",
				NewValue: a,
			})
		}
	}

	for _, a := range existingUser.Access {
		if !newAccessMap[a] {
			changes = append(changes, FieldChange{
				Action:   "Remove Access",
				Field:    "App Access",
				OldValue: a,
				NewValue: "-",
			})
		}
	}

	return UpdateUserActivityResult{
		Changes:             changes,
		StageEmailChange:    stageEmailChange,
		SendActivationEmail: sendActivationEmail,
		NewEmail:            param.Email,
	}, nil
}
