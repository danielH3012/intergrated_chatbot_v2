package activity

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"log/slog"
	"strings"
	"time"

	"github.com/gofiber/fiber/v3"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type ConfirmEmailChangePublicActivityParam struct {
	Token string
}

type ConfirmEmailChangePublicActivityResult struct {
	UserID     int64
	ClientCode string
	NewEmail   string
	TokenHash  string
}

func (a *Activities) ConfirmEmailChangePublicActivity(ctx context.Context, param ConfirmEmailChangePublicActivityParam) (ConfirmEmailChangePublicActivityResult, error) {
	pubSvc := a.publicSvc()
	var result ConfirmEmailChangePublicActivityResult

	h := sha256.New()
	h.Write([]byte(param.Token))
	tokenHash := hex.EncodeToString(h.Sum(nil))

	pending, err := a.repo.GetPendingEmailChangeByToken(ctx, pubSvc, tokenHash)
	if err != nil {
		slog.ErrorContext(ctx, "ConfirmEmailChangePublicActivity: GetPendingEmailChangeByToken", "err", err)
		return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	if pending == nil {
		return result, coreEntity.WrapHttpError(coreEntity.NotFound("This confirmation link is no longer valid."))
	}

	if pending.ConsumedAt != nil || pending.CanceledAt != nil || pending.ExpiresAt.Before(time.Now().UTC()) {
		return result, coreEntity.WrapHttpError(&coreEntity.HttpError{
			Code:    fiber.StatusGone,
			Message: "This confirmation link has expired or was already used.",
		})
	}

	_, err = coreService.UseTransactions(ctx, pubSvc.GetPool(), func(pubTx pgx.Tx) (any, error) {
		pubSvc.SetTransaction(pubTx)
		defer pubSvc.SetTransaction(nil)

		if err := a.repo.ConfirmEmailChangePublic(ctx, pubSvc, tokenHash); err != nil {
			return nil, err
		}
		return nil, nil
	})

	if err != nil {
		slog.ErrorContext(ctx, "ConfirmEmailChangePublicActivity: UseTransactions", "err", err)
		return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	result.UserID = pending.UserID
	result.ClientCode = pending.ClientCode
	result.NewEmail = pending.NewEmail
	result.TokenHash = tokenHash

	return result, nil
}

type ConfirmEmailChangeTenantActivityParam struct {
	ClientCode string
	UserID     int64
	NewEmail   string
}

type ConfirmEmailChangeTenantActivityResult struct {
	FullName string
	OldEmail string
}

func (a *Activities) ConfirmEmailChangeTenantActivity(ctx context.Context, param ConfirmEmailChangeTenantActivityParam) (ConfirmEmailChangeTenantActivityResult, error) {
	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()
	var result ConfirmEmailChangeTenantActivityResult

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)

		pubSvc.SetTransaction(tx)
		defer pubSvc.SetTransaction(nil)

		targetUser, err := a.repo.GetOneByID(ctx, svc, param.UserID)
		if err != nil {
			return nil, err
		}

		fullName := targetUser.FirstName
		if targetUser.LastName != "" {
			fullName += " " + targetUser.LastName
		}
		result.FullName = fullName
		result.OldEmail = targetUser.Email

		if err := a.repo.UpdateUserEmail(ctx, svc, param.UserID, param.NewEmail); err != nil {
			return nil, err
		}

		if err := a.repo.UpdateUserCredentialEmailPublic(ctx, pubSvc, targetUser.Email, param.NewEmail, param.ClientCode); err != nil {
			if !errors.Is(err, pgx.ErrNoRows) && !strings.Contains(err.Error(), "no rows in result set") {
				return nil, err
			}
		}

		return nil, nil
	})

	if err != nil {
		if _, isHttpError := err.(*coreEntity.HttpError); !isHttpError {
			slog.ErrorContext(ctx, "ConfirmEmailChangeTenantActivity: UseTransactions", "err", err)
			return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
		}
		return result, err
	}

	return result, nil
}

type UnconsumeEmailChangePublicActivityParam struct {
	TokenHash string
}

func (a *Activities) UnconsumeEmailChangePublicActivity(ctx context.Context, param UnconsumeEmailChangePublicActivityParam) (any, error) {
	pubSvc := a.publicSvc()

	_, err := coreService.UseTransactions(ctx, pubSvc.GetPool(), func(pubTx pgx.Tx) (any, error) {
		pubSvc.SetTransaction(pubTx)
		defer pubSvc.SetTransaction(nil)

		if err := a.repo.UnconsumeEmailChangePublic(ctx, pubSvc, param.TokenHash); err != nil {
			return nil, err
		}
		return nil, nil
	})

	if err != nil {
		slog.ErrorContext(ctx, "UnconsumeEmailChangePublicActivity: UseTransactions", "err", err)
		return nil, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	return nil, nil
}
