package activity

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
	"github.com/jackc/pgx/v5"
)

type EmailChangeActivityParam struct {
	ClientCode string
	UserID     int64
	NewEmail   string
}

type EmailChangeActivityResult struct {
	ChangeRow *model.UserEmailChange
	FullName  string
	OldEmail  string
}

func (a *Activities) EmailChangeActivity(ctx context.Context, param EmailChangeActivityParam) (EmailChangeActivityResult, error) {
	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()
	var result EmailChangeActivityResult

	isUnique, err := a.repo.CheckEmailUniqueness(ctx, pubSvc, param.NewEmail)
	if err != nil {
		slog.ErrorContext(ctx, "EmailChangeActivity: CheckEmailUniqueness", "err", err)
		return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}
	if !isUnique {
		return result, coreEntity.WrapHttpError(coreEntity.Conflict("email already exists"))
	}

	_, err = coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
		svc.SetTransaction(tx)
		defer svc.SetTransaction(nil)

		pubSvc.SetTransaction(tx)
		defer pubSvc.SetTransaction(nil)

		targetUser, err := a.repo.GetOneByID(ctx, svc, param.UserID)
		if err != nil {
			return nil, err
		}

		fullName := targetUser.FirstName
		if targetUser.LastName != "" {
			fullName += " " + targetUser.LastName
		}
		result.FullName = fullName
		result.OldEmail = targetUser.Email

		row, err := a.repo.StageEmailChange(ctx, pubSvc, param.UserID, param.NewEmail, param.ClientCode)
		if err != nil {
			return nil, err
		}
		result.ChangeRow = row

		return nil, nil
	})

	if err != nil {
		if httpErr, isHttpError := err.(*coreEntity.HttpError); isHttpError {
			return result, coreEntity.WrapHttpError(httpErr)
		}
		slog.ErrorContext(ctx, "EmailChangeActivity: UseTransactions", "err", err)
		return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	return result, nil
}
