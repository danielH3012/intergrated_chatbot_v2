package activity

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strconv"
	"time"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type UpdateUserStatusActivityParam struct {
	ClientCode      string
	IDs             []string
	IsActive        bool
	ModuleKey       string
	CurrentUserID   int64
	IsAllGroups     bool
	AllowedGroupIDs []int64
}

type StatusChangelog struct {
	UserID   int64
	FullName string
	Action   string
	Field    string
	OldValue string
	NewValue string
	Product  string
}

type UpdateUserStatusActivityResult struct {
	Results    []userDto.BulkStatusResult
	Changelogs []StatusChangelog
	DBError    *string
}

func (a *Activities) UpdateUserStatusActivity(ctx context.Context, param UpdateUserStatusActivityParam) (UpdateUserStatusActivityResult, error) {
	results := []userDto.BulkStatusResult{}
	changelogs := []StatusChangelog{}

	svc := a.tenantSvc(param.ClientCode)
	pubSvc := a.publicSvc()

	for _, idStr := range param.IDs {
		id, err := strconv.ParseInt(idStr, 10, 64)
		if err != nil {
			continue
		}

		status := "blocked"
		var reason *string
		var cl *StatusChangelog

		_, err = coreService.UseTransactions(ctx, svc.GetPool(), func(tx pgx.Tx) (any, error) {
			svc.SetTransaction(tx)
			defer svc.SetTransaction(nil)
			pubSvc.SetTransaction(tx)
			defer pubSvc.SetTransaction(nil)

			// 1. Entity suspension guard
			isSuspended, err := a.repo.IsEntitySuspended(ctx, svc, param.ClientCode)
			if err != nil {
				return nil, err
			}
			if isSuspended {
				r := "entity_suspended"
				reason = &r
				return nil, nil
			}

			// Load user
			targetUser, err := a.repo.GetOneByID(ctx, svc, id)
			if err != nil {
				return nil, err
			}

			if id == param.CurrentUserID {
				r := "self"
				reason = &r
				return nil, nil
			}
			if targetUser.IsDefault != nil && *targetUser.IsDefault {
				r := "default_user"
				reason = &r
				return nil, nil
			}

			hasTCRO, err := a.repo.IsTargetProtectedTCRO(ctx, svc, id, param.ModuleKey)
			if err != nil {
				return nil, err
			}
			if hasTCRO {
				if param.CurrentUserID != 0 {
					isActorTC, err := a.repo.IsActorTotalControl(ctx, svc, param.CurrentUserID, param.ModuleKey)
					if err != nil {
						return nil, err
					}
					if !isActorTC {
						r := "tcro_target"
						reason = &r
						return nil, nil
					}
				}
			}

			// Group scope overlap guard for admin_console
			if param.ModuleKey == string(model.ProductAdminConsole) && !param.IsAllGroups {
				if len(param.AllowedGroupIDs) == 0 {
					r := "out_of_scope"
					reason = &r
					return nil, nil
				}
				_, _, targetGroupIDs, err := a.repo.CheckAdminConsoleUserExists(ctx, svc, id)
				if err != nil {
					return nil, err
				}
				allowedMap := make(map[int64]bool, len(param.AllowedGroupIDs))
				for _, gid := range param.AllowedGroupIDs {
					allowedMap[gid] = true
				}
				hasOverlap := false
				for _, gid := range targetGroupIDs {
					if allowedMap[gid] {
						hasOverlap = true
						break
					}
				}
				if !hasOverlap {
					r := "out_of_scope"
					reason = &r
					return nil, nil
				}
			}

			if param.ModuleKey == string(model.ProductGlobalSettings) {
				if param.IsActive {
					if targetUser.IsTemporary != nil && *targetUser.IsTemporary {
						if targetUser.ActivePeriodUntil != nil {
							if targetUser.ActivePeriodUntil.Before(time.Now().UTC().Truncate(24 * time.Hour)) {
								status = "skipped"
								r := "temporary_expired"
								reason = &r
								return nil, nil
							}
						}
					}
				}

				if targetUser.IsActive == param.IsActive {
					status = "updated"
					return nil, nil
				}

				if err := a.repo.UpdateUserGlobalActive(ctx, svc, id, param.IsActive); err != nil {
					return nil, err
				}
				status = "updated"
			} else {
				if !targetUser.IsActive {
					r := "global_inactive"
					reason = &r
					return nil, nil
				}

				modStatus, err := a.repo.GetUserModuleStatus(ctx, svc, id, param.ModuleKey)
				if err != nil {
					return nil, err
				}

				if modStatus == nil {
					r := "no_access"
					reason = &r
					return nil, nil
				}

				if modStatus.IsActive == param.IsActive {
					status = "updated"
					return nil, nil
				}

				if err := a.repo.UpdateUserModuleStatus(ctx, svc, id, param.ModuleKey, param.IsActive); err != nil {
					return nil, err
				}
				status = "updated"
			}

			action := "Activate"
			newValue := "Active"
			oldValue := "Inactive"
			if !param.IsActive {
				action = "Deactivate"
				newValue = "Inactive"
				oldValue = "Active"
			}

			field := "Status (Global)"
			product := string(model.ProductGlobalSettings)
			if param.ModuleKey == string(model.ProductAdminConsole) {
				field = "Status"
				product = string(model.ProductAdminConsole)
			} else if param.ModuleKey != string(model.ProductGlobalSettings) {
				displayProduct := param.ModuleKey
				if param.ModuleKey == string(model.ProductFixedAsset) {
					displayProduct = "Fixed Asset"
				}
				field = fmt.Sprintf("Status (%s)", displayProduct)
				product = param.ModuleKey
			}

			fullName := targetUser.FirstName
			if targetUser.LastName != "" {
				fullName += " " + targetUser.LastName
			}

			cl = &StatusChangelog{
				UserID:   id,
				FullName: fullName,
				Action:   action,
				Field:    field,
				OldValue: oldValue,
				NewValue: newValue,
				Product:  product,
			}

			return nil, nil
		})

		if err != nil {
			if errors.Is(err, pgx.ErrNoRows) || coreEntity.ToHttpError(err).Code == 404 {
				r := "not_found"
				reason = &r
				status = "blocked"
			} else {
				slog.ErrorContext(ctx, "UpdateUserStatusActivity", "err", err)
				if len(results) == 0 {
					dbErrMsg := constant.MsgInternalServerError
					return UpdateUserStatusActivityResult{
						Results:    results,
						Changelogs: changelogs,
						DBError:    &dbErrMsg,
					}, nil
				}
				// If we already have partial successes, break out of the loop and return what we have.
				break
			}
		}

		results = append(results, userDto.BulkStatusResult{
			ID:     idStr,
			Status: status,
			Reason: reason,
		})

		if cl != nil {
			changelogs = append(changelogs, *cl)
		}
	}

	return UpdateUserStatusActivityResult{
		Results:    results,
		Changelogs: changelogs,
	}, nil
}
