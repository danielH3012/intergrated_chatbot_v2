package activity

import (
	"context"
	"errors"
	"log/slog"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type ValidateResetAuthenticatorActivityParam struct {
	ClientCode    string
	UserID        int64
	CurrentUserID int64
}

type ValidateResetAuthenticatorActivityResult struct {
	Enrolled bool
	FullName string
}

func (a *Activities) ValidateResetAuthenticatorActivity(ctx context.Context, param ValidateResetAuthenticatorActivityParam) (ValidateResetAuthenticatorActivityResult, error) {
	svc := a.tenantSvc(param.ClientCode)
	var result ValidateResetAuthenticatorActivityResult

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tenTx pgx.Tx) (any, error) {
		svc.SetTransaction(tenTx)
		defer svc.SetTransaction(nil)

		targetUser, err := a.repo.GetOneByID(ctx, svc, param.UserID)
		if err != nil {
			return nil, err
		}

		if param.UserID == param.CurrentUserID {
			return nil, coreEntity.Forbidden(constant.MsgForbidden)
		}
		if targetUser.IsDefault != nil && *targetUser.IsDefault {
			return nil, coreEntity.Forbidden(constant.MsgForbidden)
		}

		hasTCRO, err := a.repo.IsTargetProtectedTCRO(ctx, svc, param.UserID, string(model.ProductGlobalSettings))
		if err != nil {
			return nil, err
		}
		if hasTCRO {
			isActorTC, err := a.repo.IsActorTotalControl(ctx, svc, param.CurrentUserID, string(model.ProductGlobalSettings))
			if err != nil {
				return nil, err
			}
			if !isActorTC {
				return nil, coreEntity.Forbidden("tcro_target")
			}
		}

		enrolled, err := a.repo.IsAuthenticatorEnrolled(ctx, svc, param.UserID)
		if err != nil {
			return nil, err
		}

		result.Enrolled = enrolled

		fullName := targetUser.FirstName
		if targetUser.LastName != "" {
			fullName += " " + targetUser.LastName
		}
		result.FullName = fullName

		return nil, nil
	})

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return result, coreEntity.WrapHttpError(coreEntity.NotFound(constant.MsgUserNotFound))
		}
		if httpErr, isHttpError := err.(*coreEntity.HttpError); isHttpError {
			return result, coreEntity.WrapHttpError(httpErr)
		}
		slog.ErrorContext(ctx, "ValidateResetAuthenticatorActivity", "err", err)
		return result, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	return result, nil
}

type ResetAuthenticatorPublicActivityParam struct {
	ClientCode string
	UserID     int64
}

func (a *Activities) ResetAuthenticatorPublicActivity(ctx context.Context, param ResetAuthenticatorPublicActivityParam) (any, error) {
	pubSvc := a.publicSvc()

	_, err := coreService.UseTransactions(ctx, pubSvc.GetPool(), func(pubTx pgx.Tx) (any, error) {
		pubSvc.SetTransaction(pubTx)
		defer pubSvc.SetTransaction(nil)

		if err := a.repo.ResetAuthenticatorPublic(ctx, pubSvc, param.UserID, param.ClientCode); err != nil {
			return nil, err
		}

		return nil, nil
	})

	if err != nil {
		slog.ErrorContext(ctx, "ResetAuthenticatorPublicActivity", "err", err)
		return nil, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	return nil, nil
}

type UpdateResetAuthenticatorTenantActivityParam struct {
	ClientCode string
	UserID     int64
}

func (a *Activities) UpdateResetAuthenticatorTenantActivity(ctx context.Context, param UpdateResetAuthenticatorTenantActivityParam) (any, error) {
	svc := a.tenantSvc(param.ClientCode)

	_, err := coreService.UseTransactions(ctx, svc.GetPool(), func(tenTx pgx.Tx) (any, error) {
		svc.SetTransaction(tenTx)
		defer svc.SetTransaction(nil)

		if err := a.repo.ResetAuthenticatorTenant(ctx, svc, param.UserID); err != nil {
			return nil, err
		}
		return nil, nil
	})

	if err != nil {
		slog.ErrorContext(ctx, "UpdateResetAuthenticatorTenantActivity", "err", err)
		return nil, coreEntity.WrapHttpError(coreEntity.InternalServerError(constant.MsgInternalServerError))
	}

	return nil, nil
}
