package query_builder_test

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
)

func TestGetProductUserDropdownQuery_AllGroups(t *testing.T) {
	req := userDto.ProductUserDropdownQuery{
		Product:     model.ProductAdminConsole,
		IsAllGroups: true,
	}

	query, args, err := query_builder.GetProductUserDropdownQuery(req)
	assert.NoError(t, err)
	assert.NotEmpty(t, query)
	assert.Contains(t, query, `JOIN user_module_status ums ON ums.user_id = users.id`)
	assert.Contains(t, query, `"users"."deleted_at" IS NULL`)
	assert.Contains(t, query, `users.full_name COLLATE "en-US-x-icu" ASC`)
	assert.Contains(t, args, model.ProductAdminConsole)
	assert.NotContains(t, query, `user_group_managers`)
}

func TestGetProductUserDropdownQuery_WithFilters(t *testing.T) {
	isActive := true
	req := userDto.ProductUserDropdownQuery{
		Product:          model.ProductAdminConsole,
		ActivationStatus: "Activated",
		Status:           &isActive,
		IsAllGroups:      true,
	}

	query, args, err := query_builder.GetProductUserDropdownQuery(req)
	assert.NoError(t, err)
	assert.Contains(t, query, `"users"."activation_status" =`)
	assert.Contains(t, query, `"ums"."is_active" =`)
	assert.Contains(t, args, "Activated")
	assert.Contains(t, args, true)
}

func TestGetProductUserDropdownQuery_PendingEmail(t *testing.T) {
	req := userDto.ProductUserDropdownQuery{
		Product:          model.ProductAdminConsole,
		ActivationStatus: "Pending Email Confirmation",
		IsAllGroups:      true,
	}

	query, args, err := query_builder.GetProductUserDropdownQuery(req)
	assert.NoError(t, err)
	assert.Contains(t, query, `"users"."activation_status" =`)
	assert.Contains(t, query, `"uec"."new_email" IS NOT NULL`)
	assert.Contains(t, args, "Activated")
}

func TestGetProductUserDropdownQuery_GroupScoped(t *testing.T) {
	req := userDto.ProductUserDropdownQuery{
		Product:         model.ProductAdminConsole,
		AllowedGroupIDs: []int64{101, 102},
		IsAllGroups:     false,
	}

	query, args, err := query_builder.GetProductUserDropdownQuery(req)
	assert.NoError(t, err)
	assert.Contains(t, query, `EXISTS (`)
	assert.Contains(t, query, `usr.admin_console_group_id IN (101, 102)`)
	assert.Contains(t, query, `ugm.admin_console_group_id IN (101, 102)`)
	assert.Contains(t, args, model.ProductAdminConsole)
}

func TestGetProductUserDropdownQuery_GroupScoped_NoGroups(t *testing.T) {
	req := userDto.ProductUserDropdownQuery{
		Product:         model.ProductAdminConsole,
		AllowedGroupIDs: nil,
		IsAllGroups:     false,
	}

	query, _, err := query_builder.GetProductUserDropdownQuery(req)
	assert.NoError(t, err)
	assert.True(t, strings.Contains(query, `"1" = 0`) || strings.Contains(query, `1 = 0`))
}

func TestGetAdminConsoleUserListQuery_Basic(t *testing.T) {
	req := userDto.AcUserListBody{
		Page:        1,
		Limit:       10,
		IsAllGroups: true,
	}

	query, args, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
	assert.NoError(t, err)
	assert.NotEmpty(t, query)
	assert.Contains(t, query, `JOIN user_module_status ums ON ums.user_id = users.id`)
	assert.Contains(t, query, `"ums"."module_key" = $`)
	assert.Contains(t, query, `"users"."deleted_at" IS NULL`)
	assert.Contains(t, query, `LIMIT 10`)
	assert.Contains(t, query, `users.full_name COLLATE "en-US-x-icu"`)
	assert.Contains(t, args, model.ProductAdminConsole)
}

func TestGetAdminConsoleUserListQuery_Filters(t *testing.T) {
	req := userDto.AcUserListBody{
		Page:              1,
		Limit:             10,
		Search:            "john",
		SortBy:            "email",
		SortOrder:         -1,
		Group:             []string{"10", "20"},
		Position:          []string{"Dev"},
		Division:          []string{"IT"},
		Status:            []string{"Active"},
		ActivationStatus:  []string{"Pending Email Confirmation"},
		Role:              []string{"Manage distributor"},
		TemporaryStatus:   []string{"Yes"},
		ActivePeriodUntil: []int64{1749513600000},
		ModifiedBy:        []string{"Admin"},
		UpdatedAt:         []int64{1749513600000, 1749599999999},
		AllowedGroupIDs:   []int64{10, 20},
		IsAllGroups:       false,
	}

	query, args, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
	assert.NoError(t, err)
	assert.NotEmpty(t, query)
	assert.Contains(t, query, `usr.admin_console_group_id IN (10, 20)`)
	assert.Contains(t, query, `usr_filter.admin_console_group_id IN (10, 20)`)
	assert.Contains(t, query, `"positions"."name" IN ($`)
	assert.Contains(t, query, `"divisions"."name" IN ($`)
	assert.Contains(t, query, `"ums"."is_active" = $`)
	assert.Contains(t, query, `"uec"."new_email" IS NOT NULL`)
	assert.Contains(t, query, `manage_distributor`)
	assert.Contains(t, query, `"users"."is_temporary" = $`)
	assert.Contains(t, query, `COLLATE "en-US-x-icu" DESC`)
	assert.Contains(t, args, "%john%")
}

func TestGetAdminConsoleUserListFilterBuilder(t *testing.T) {
	req := userDto.AcUserListBody{
		IsAllGroups: true,
		Position:    []string{"Engineer"},
	}

	builder := query_builder.GetAdminConsoleUserListFilterBuilder[any](req)
	query, args, err := builder.Build()
	assert.NoError(t, err)
	assert.Contains(t, query, `JOIN user_module_status ums ON ums.user_id = users.id`)
	assert.Contains(t, query, `LEFT JOIN positions ON positions.id = users.position_id`)
	assert.Contains(t, query, `LEFT JOIN divisions ON divisions.id = users.division_id`)
	assert.Contains(t, query, `LEFT JOIN users mod_users ON mod_users.id = users.modified_by`)
	assert.Contains(t, query, `"positions"."name" IN ($2)`)
	assert.Contains(t, args, "Engineer")
}

func TestGetAdminConsoleUserListQuery_NonPaginate(t *testing.T) {
	req := userDto.AcUserListBody{
		IsAllGroups: true,
		SortBy:      "email",
		SortOrder:   1, // ASC
	}

	query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, false)
	assert.NoError(t, err)
	assert.Contains(t, query, `LIMIT 10000`)
	assert.Contains(t, query, `users.email COLLATE "en-US-x-icu" ASC`)
}

func TestGetAdminConsoleUserListOptionsQuery_AllOptions(t *testing.T) {
	req := userDto.AcUserOptionsBody{
		AcUserListBody: userDto.AcUserListBody{
			IsAllGroups: true,
			Search:      "alice",
			Position:    []string{"Engineer"},
		},
		PositionOptions:         true,
		DivisionOptions:         true,
		StatusOptions:           true,
		ActivationStatusOptions: true,
		RoleOptions:             true,
		TemporaryStatusOptions:  true,
		ModifiedByOptions:       true,
	}

	query, args, err := query_builder.GetAdminConsoleUserListOptionsQuery(req)
	assert.NoError(t, err)
	assert.NotEmpty(t, query)

	// CTE aliases generated by common_builders.GenerateCTEOption
	assert.Contains(t, query, `position_options AS (`)
	assert.Contains(t, query, `division_options AS (`)
	assert.Contains(t, query, `status_options AS (`)
	assert.Contains(t, query, `activation_status_options AS (`)
	assert.Contains(t, query, `temporary_status_options AS (`)
	assert.Contains(t, query, `modified_by_options AS (`)

	// Main SELECT aggregating JSON arrays
	assert.Contains(t, query, `"positionOptions"`)
	assert.Contains(t, query, `"divisionOptions"`)
	assert.Contains(t, args, "Engineer")
}

func TestGetAdminConsoleUserListOptionsQuery_NoOptions(t *testing.T) {
	req := userDto.AcUserOptionsBody{
		AcUserListBody: userDto.AcUserListBody{
			IsAllGroups: true,
		},
	}

	query, _, err := query_builder.GetAdminConsoleUserListOptionsQuery(req)
	assert.NoError(t, err)
	assert.NotEmpty(t, query)
	assert.NotContains(t, query, `"positionOptions" AS (`)
	assert.NotContains(t, query, `"divisionOptions" AS (`)
}

func TestGetAdminConsoleUserListOptionsQuery_NoOuterTablePrefixError(t *testing.T) {
	req := userDto.AcUserOptionsBody{
		AcUserListBody: userDto.AcUserListBody{
			IsAllGroups: true,
		},
		PositionOptions:         true,
		DivisionOptions:         true,
		StatusOptions:           true,
		ActivationStatusOptions: true,
		RoleOptions:             true,
		TemporaryStatusOptions:  true,
		ModifiedByOptions:       true,
	}

	query, _, err := query_builder.GetAdminConsoleUserListOptionsQuery(req)
	assert.NoError(t, err)
	// Outer SELECT jsonb_agg ORDER BY must NOT reference tables that only exist in CTE joins
	assert.NotContains(t, query, "ORDER BY positions.name")
	assert.NotContains(t, query, "ORDER BY divisions.name")
	assert.NotContains(t, query, "ORDER BY mod_users.full_name")
}

func TestGetAdminConsoleUserListQuery_SearchIncludesRole(t *testing.T) {
	req := userDto.AcUserListBody{
		Page:        1,
		Limit:       10,
		Search:      "Total Control",
		IsAllGroups: true,
	}

	query, args, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
	assert.NoError(t, err)
	assert.Contains(t, query, "ual.access_level = 'total_control'")
	assert.Contains(t, args, "%Total Control%")
}

func TestGetAdminConsoleUserListQuery_SQLInjectionSafety_RoleAndStatus(t *testing.T) {
	// Malicious role name outside catalog should not be injected into SQL
	reqMaliciousRole := userDto.AcUserListBody{
		IsAllGroups: true,
		Role:        []string{"' OR '1'='1' --"},
	}
	query1, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](reqMaliciousRole, false)
	assert.NoError(t, err)
	assert.NotContains(t, query1, "' OR '1'='1' --")
	assert.Contains(t, query1, "1 = 0")

	// Activation status with malicious input should escape quotes
	reqMaliciousStatus := userDto.AcUserListBody{
		IsAllGroups:      true,
		ActivationStatus: []string{"Pending Email Confirmation", "hack'status"},
	}
	query2, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](reqMaliciousStatus, false)
	assert.NoError(t, err)
	assert.Contains(t, query2, "'hack''status'")
	assert.NotContains(t, query2, "IN ('hack'status')")
}

func TestGetAdminConsoleUserListQuery_SortActivationStatus(t *testing.T) {
	req := userDto.AcUserListBody{
		Page:        1,
		Limit:       10,
		SortBy:      "activationStatus",
		SortOrder:   1,
		IsAllGroups: true,
	}

	query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
	assert.NoError(t, err)
	assert.Contains(t, query, "(CASE WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END) ASC")
}

func TestGetAdminConsoleUserListQuery_SortRole(t *testing.T) {
	req := userDto.AcUserListBody{
		Page:        1,
		Limit:       10,
		SortBy:      "role",
		SortOrder:   1,
		IsAllGroups: true,
	}

	query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
	assert.NoError(t, err)
	assert.Contains(t, query, "CASE WHEN ual.access_level = 'total_control' THEN 'Total Control'")
}

func TestGetAdminConsoleUserListQuery_Search_DynamicColumns(t *testing.T) {
	t.Run("specific column email only", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "alice",
			Columns:     []string{"email"},
			IsAllGroups: true,
		}
		query, args, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.email ILIKE")
		assert.NotContains(t, query, "users.full_name ILIKE")
		assert.NotContains(t, query, "positions.name ILIKE")
		assert.NotContains(t, query, "admin_console') END) ILIKE")
		assert.Contains(t, args, "%alice%")
		assert.Len(t, args, 2) // $1 = admin_console, $2 = %alice%
	})

	t.Run("specific column role only", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "Total Control",
			Columns:     []string{"role"},
			IsAllGroups: true,
		}
		query, args, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "ual.access_level = 'total_control'")
		assert.NotContains(t, query, "users.email ILIKE")
		assert.NotContains(t, query, "users.full_name ILIKE")
		assert.Contains(t, args, "%Total Control%")
	})

	t.Run("specific column name expands to first, last, full name", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "bob",
			Columns:     []string{"name"},
			IsAllGroups: true,
		}
		query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.first_name ILIKE")
		assert.Contains(t, query, "users.last_name ILIKE")
		assert.Contains(t, query, "users.full_name ILIKE")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("specific column tagCode", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "TAG-001",
			Columns:     []string{"tagCode"},
			IsAllGroups: true,
		}
		query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.tag_code ILIKE")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("specific column activationStatus", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "Pending",
			Columns:     []string{"activationStatus"},
			IsAllGroups: true,
		}
		query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END) ILIKE")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("specific column temporaryStatus", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "Yes",
			Columns:     []string{"temporaryStatus"},
			IsAllGroups: true,
		}
		query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "CASE WHEN COALESCE(users.is_temporary, false) THEN 'Yes' ELSE 'No' END")
		assert.Contains(t, query, "ILIKE $2")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("non-searchable columns fall back to default search columns", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "test",
			Columns:     []string{"updatedAt", "isActive", "unknownCol"},
			IsAllGroups: true,
		}
		query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.NotContains(t, query, "ums.updated_at ILIKE")
		assert.Contains(t, query, "users.full_name ILIKE")
		assert.Contains(t, query, "users.email ILIKE")
		assert.Contains(t, query, "positions.name ILIKE")
	})

	t.Run("empty or nil columns fall back to default search columns", func(t *testing.T) {
		req := userDto.AcUserListBody{
			Search:      "test",
			IsAllGroups: true,
		}
		query, _, err := query_builder.GetAdminConsoleUserListQuery[userDto.AcUserListItem](req, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.full_name ILIKE")
		assert.Contains(t, query, "users.email ILIKE")
		assert.Contains(t, query, "ual.access_level = 'total_control'")
	})
}
