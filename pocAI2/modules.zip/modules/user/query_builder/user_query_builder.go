package query_builder

import (
	"fmt"
	"strings"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query/common_builders"
)

var userSearchableColumns = map[string][]string{
	"name":             {"users.first_name", "users.last_name", "users.full_name"},
	"fullName":         {"users.first_name", "users.last_name", "users.full_name"},
	"email":            {"users.email"},
	"access":           {"user_ext_cte.access_search"},
	"position":         {"positions.name"},
	"division":         {"divisions.name"},
	"employeeId":       {"users.employee_id"},
	"modifiedBy":       {"mod_users.full_name"},
	"tagCode":          {"users.tag_code"},
	"activationStatus": {"user_ext_cte.activation_status"},
	"temporaryStatus":  {"(CASE WHEN users.is_temporary THEN 'Yes' ELSE 'No' END)"},
}

var defaultUserSearchColumns = []string{
	"users.first_name",
	"users.last_name",
	"users.full_name",
	"users.email",
	"user_ext_cte.access_search",
	"positions.name",
	"divisions.name",
	"users.employee_id",
	"mod_users.full_name",
}

func resolveUserSearchColumns(columns []string) []string {
	if len(columns) == 0 {
		return defaultUserSearchColumns
	}

	out := make([]string, 0, len(columns))
	seen := make(map[string]bool)
	for _, c := range columns {
		if exprs, ok := userSearchableColumns[c]; ok {
			for _, expr := range exprs {
				if !seen[expr] {
					seen[expr] = true
					out = append(out, expr)
				}
			}
		}
	}
	if len(out) == 0 {
		return defaultUserSearchColumns
	}
	return out
}

var userSortColumns = map[string]string{
	"fullName":          "users.full_name",
	"email":             "users.email",
	"employeeId":        "users.employee_id",
	"position":          "positions.name",
	"division":          "divisions.name",
	"activationStatus":  "user_ext_cte.activation_status",
	"isActive":          "users.is_global_active",
	"updatedAt":         "users.updated_at",
	"modifiedBy":        "mod_users.full_name",
	"tagCode":           "users.tag_code",
	"activePeriodUntil": "users.active_period_until",
}

func userExtCTE() *sql_query.SelectBuilder {
	builder := sql_query.NewSQLSelectBuilder[any]("users").
		LeftJoin("public.user_email_changes uec", "uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL", nil)

	accessCte := sql_query.NewSQLSelectBuilder[any]("user_module_status", "ums").
		Select(
			"ums.user_id",
			`jsonb_agg(ums.module_key ORDER BY (CASE 
				WHEN ums.module_key = 'global_settings' THEN 'Global Settings'
				WHEN ums.module_key = 'admin_console' THEN 'Admin Console'
				WHEN ums.module_key = 'fixed_asset' THEN 'Fixed Asset'
				ELSE ums.module_key 
			END) ASC) as access_arr`,
			`string_agg(CASE 
				WHEN ums.module_key = 'global_settings' THEN 'Global Settings'
				WHEN ums.module_key = 'admin_console' THEN 'Admin Console'
				WHEN ums.module_key = 'fixed_asset' THEN 'Fixed Asset'
				ELSE ums.module_key 
			END, ' ' ORDER BY (CASE 
				WHEN ums.module_key = 'global_settings' THEN 'Global Settings'
				WHEN ums.module_key = 'admin_console' THEN 'Admin Console'
				WHEN ums.module_key = 'fixed_asset' THEN 'Fixed Asset'
				ELSE ums.module_key 
			END) ASC) as access_search`,
		).
		GroupBy("ums.user_id")

	builder.WithCTEBuilder("access_cte", accessCte.(*sql_query.SelectBuilder).SQLEloquentQuery).
		LeftJoin("access_cte", "access_cte.user_id = users.id", nil).
		Select(
			"users.id AS id",
			"uec.new_email AS pending_email",
			"access_cte.access_arr AS access",
			"users.is_global_active AS is_active",
			"access_cte.access_search AS access_search",
			"COALESCE(jsonb_array_length(access_cte.access_arr), 0) AS access_count",
			`(CASE 
				WHEN EXISTS (SELECT 1 FROM user_access_levels ual WHERE ual.user_id = users.id AND ual.access_level = 'total_control') THEN 'total_control'
				WHEN EXISTS (SELECT 1 FROM user_access_levels ual WHERE ual.user_id = users.id AND ual.access_level = 'read_only') THEN 'read_only'
				WHEN EXISTS (SELECT 1 FROM user_system_roles usr WHERE usr.user_id = users.id) THEN 'admin'
				ELSE 'basic'
			END) AS user_type`,
			`(CASE 
				WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL 
				THEN 'Pending Email Confirmation' 
				ELSE users.activation_status 
			END) AS activation_status`,
		)

	return builder.(*sql_query.SelectBuilder)
}

func GetUserListFilterBuilder[T any](req userDto.UserListBody) *sql_query.SelectBuilder {
	builder := sql_query.NewSQLSelectBuilder[T]("users").
		WithCTEBuilder("user_ext_cte", userExtCTE().SQLEloquentQuery).
		LeftJoin("user_ext_cte", "user_ext_cte.id = users.id", nil).
		LeftJoin("positions", "positions.id = users.position_id", nil).
		LeftJoin("divisions", "divisions.id = users.division_id", nil).
		LeftJoin("users mod_users", "mod_users.id = users.modified_by", nil)

	where := sql_query.WhereQuery{
		"users.deleted_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
	}

	if len(req.Status) > 0 {
		hasActive := helper.Contains(req.Status, "Active") || helper.Contains(req.Status, "active")
		hasInactive := helper.Contains(req.Status, "Inactive") || helper.Contains(req.Status, "inactive")

		if hasActive && !hasInactive {
			where["users.is_global_active"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: true}
		} else if hasInactive && !hasActive {
			where["users.is_global_active"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: false}
		}
	}

	if len(req.Position) > 0 {
		where["positions.name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.Position}
	}
	if len(req.Division) > 0 {
		where["divisions.name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.Division}
	}
	if len(req.ActivationStatus) > 0 {
		var hasPendingEmail, hasOther bool
		var otherStatuses []string
		for _, s := range req.ActivationStatus {
			if s == "Pending Email Confirmation" {
				hasPendingEmail = true
			} else {
				hasOther = true
				otherStatuses = append(otherStatuses, s)
			}
		}

		if hasPendingEmail && !hasOther {
			where["users.activation_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "Activated"}
			where["user_ext_cte.pending_email"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNotNull}
		} else if hasPendingEmail && hasOther {
			inVals := "'" + strings.Join(otherStatuses, "','") + "'"
			where["users.activation_status"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value:    fmt.Sprintf("(users.activation_status IN (%s) OR (users.activation_status = 'Activated' AND user_ext_cte.pending_email IS NOT NULL))", inVals),
			}
		} else {
			where["users.activation_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.ActivationStatus}
		}
	}
	if len(req.ModifiedBy) > 0 {
		where["mod_users.full_name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.ModifiedBy}
	}
	if len(req.TemporaryStatus) > 0 {
		var hasYes, hasNo bool
		for _, s := range req.TemporaryStatus {
			switch s {
			case "Yes":
				hasYes = true
			case "No":
				hasNo = true
			}
		}
		if hasYes && !hasNo {
			where["users.is_temporary"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: true}
		} else if hasNo && !hasYes {
			where["users.is_temporary"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorRaw, Value: "(users.is_temporary IS NULL OR users.is_temporary = false)"}
		}
	}
	if len(req.ActivePeriodUntil) > 0 {
		where["users.active_period_until"] = sql_query.SQLCondition{
			Operator:    sql_query.SQLOperatorBetween,
			Value:       req.ActivePeriodUntil,
			IsEpochTime: true,
		}
	}
	if len(req.UpdatedAt) > 0 {
		where["users.updated_at"] = sql_query.SQLCondition{
			Operator:    sql_query.SQLOperatorBetween,
			Value:       req.UpdatedAt,
			IsEpochTime: true,
		}
	}
	if len(req.Access) > 0 {
		where["user_ext_cte.access"] = sql_query.SQLCondition{
			Operator: sql_query.SQLOperatorRaw,
			Value:    fmt.Sprintf("user_ext_cte.access ?| array['%s']", strings.Join(req.Access, "','")),
		}
	}

	builder.Where(where)
	return builder.(*sql_query.SelectBuilder)
}

func GetUserListQuery(req userDto.UserListBody, callerID int64, paginate bool) (string, []any, error) {
	builder := GetUserListFilterBuilder[userDto.UserListResponseItem](req)

	if req.Search != "" {
		builder.Search(req.Search, resolveUserSearchColumns(req.Columns))
	}

	if paginate {
		pagination := sql_query.Pagination{
			Page:                 req.Page,
			Limit:                req.Limit,
			ExtraFilteredColumns: []string{"COALESCE(users.is_default, false) AS is_default"},
			DefaultSort: []sql_query.Sort{{
				SortBy:    `users.full_name COLLATE "en-US-x-icu"`,
				SortOrder: 1,
			}},
		}
		if callerID > 0 {
			pagination.Aggregates = []sql_query.PaginationAggregate{
				{
					JSONKey:    "totalDisabledRecords",
					Expression: fmt.Sprintf("COUNT(id) FILTER (WHERE is_default = TRUE OR id = %d)", callerID),
				},
			}
		} else {
			pagination.Aggregates = []sql_query.PaginationAggregate{
				{
					JSONKey:    "totalDisabledRecords",
					Expression: "COUNT(id) FILTER (WHERE is_default = TRUE)",
				},
			}
		}
		if col, ok := userSortColumns[req.SortBy]; ok {
			sortCol := col
			if col == "users.full_name" || col == "users.email" || col == "users.employee_id" || col == "positions.name" || col == "divisions.name" || col == "mod_users.full_name" {
				sortCol = col + ` COLLATE "en-US-x-icu"`
			}
			pagination.SortBy = sortCol
			pagination.SortOrder = req.SortOrder
		} else if req.SortBy == "access" {
			pagination.MultiSort = []sql_query.Sort{
				{SortBy: "user_ext_cte.access_count", SortOrder: req.SortOrder},
				{SortBy: `user_ext_cte.access_search COLLATE "en-US-x-icu"`, SortOrder: req.SortOrder},
			}
		}
		builder.Paginate(pagination)
	} else {
		builder.SetLimit(10000)
		if col, ok := userSortColumns[req.SortBy]; ok {
			isAsc := req.SortOrder == 1
			sortCol := col
			if col == "users.full_name" || col == "users.email" || col == "users.employee_id" || col == "positions.name" || col == "divisions.name" || col == "mod_users.full_name" {
				sortCol = col + ` COLLATE "en-US-x-icu"`
			}
			builder.OrderBy([]string{sortCol}, isAsc)
		} else if req.SortBy == "access" {
			isAsc := req.SortOrder == 1
			builder.OrderBy([]string{`user_ext_cte.access_count`, `user_ext_cte.access_search COLLATE "en-US-x-icu"`}, isAsc)
		} else {
			builder.OrderBy([]string{`users.full_name COLLATE "en-US-x-icu"`}, true)
		}
	}

	return builder.Build()
}

func GetUserDropdownQuery(req userDto.UserDropdownQuery) (string, []any, error) {
	builder := sql_query.NewSQLSelectBuilder[userDto.UserDropdownItem]("users").
		LeftJoin("public.user_email_changes uec", "uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL", nil).
		Select(
			"users.id::text AS _id",
			"users.full_name",
		).
		Where(sql_query.WhereQuery{
			"users.deleted_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		})

	if req.ActivationStatus != "" {
		if req.ActivationStatus == "Pending Email Confirmation" {
			builder.Where(sql_query.WhereQuery{
				"users.activation_status": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "Activated"},
				"uec.new_email":           sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNotNull},
			})
		} else {
			builder.Where(sql_query.WhereQuery{
				"users.activation_status": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: req.ActivationStatus},
			})
		}
	}
	if req.Status != nil {
		builder.Where(sql_query.WhereQuery{
			"users.is_global_active": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: *req.Status},
		})
	}

	builder.OrderBy([]string{"users.full_name"}, false) // ASC

	return builder.Build()
}

func GetUserListOptionsQuery(
	query userDto.UserListBody,
	optionsReq userDto.UserOptionsBody,
) (string, []any, error) {
	optionsBuilder := sql_query.NewSQLSelectBuilder[userDto.UserOptionsResponse]("users")

	common_builders.GenerateCTEOption(
		GetUserListFilterBuilder[any](query),
		optionsBuilder.(*sql_query.SelectBuilder),
		"positionOptions",
		"users",
		optionsReq.PositionOptions,
		"positions.name",
		"positions.name",
	)

	common_builders.GenerateCTEOption(
		GetUserListFilterBuilder[any](query),
		optionsBuilder.(*sql_query.SelectBuilder),
		"divisionOptions",
		"users",
		optionsReq.DivisionOptions,
		"divisions.name",
		"divisions.name",
	)

	common_builders.GenerateCTEOption(
		GetUserListFilterBuilder[any](query),
		optionsBuilder.(*sql_query.SelectBuilder),
		"modifiedByOptions",
		"users",
		optionsReq.ModifiedByOptions,
		"mod_users.full_name",
		"mod_users.full_name",
	)

	accessOptionsSource := GetUserListFilterBuilder[any](query)
	accessOptionsSource.LeftJoin("user_module_status ums_opt", "ums_opt.user_id = users.id", nil)

	common_builders.GenerateCTEOption(
		accessOptionsSource,
		optionsBuilder.(*sql_query.SelectBuilder),
		"accessOptions",
		"users",
		optionsReq.AccessOptions,
		`(CASE 
			WHEN ums_opt.module_key = 'global_settings' THEN 'Global Settings'
			WHEN ums_opt.module_key = 'admin_console' THEN 'Admin Console'
			WHEN ums_opt.module_key = 'fixed_asset' THEN 'Fixed Asset'
			ELSE ums_opt.module_key 
		END)`,
		"ums_opt.module_key",
	)

	common_builders.GenerateCTEOption(
		GetUserListFilterBuilder[any](query),
		optionsBuilder.(*sql_query.SelectBuilder),
		"statusOptions",
		"users",
		optionsReq.StatusOptions,
		"(CASE WHEN users.is_global_active THEN 'Active' ELSE 'Inactive' END)",
		"(CASE WHEN users.is_global_active THEN 'Active' ELSE 'Inactive' END)",
	)

	common_builders.GenerateCTEOption(
		GetUserListFilterBuilder[any](query),
		optionsBuilder.(*sql_query.SelectBuilder),
		"activationStatusOptions",
		"users",
		optionsReq.ActivationStatusOptions,
		"user_ext_cte.activation_status",
		"user_ext_cte.activation_status",
	)

	common_builders.GenerateCTEOption(
		GetUserListFilterBuilder[any](query),
		optionsBuilder.(*sql_query.SelectBuilder),
		"temporaryStatusOptions",
		"users",
		optionsReq.TemporaryStatusOptions,
		"(CASE WHEN users.is_temporary = true THEN 'Yes' ELSE 'No' END)",
		"(CASE WHEN users.is_temporary = true THEN 'Yes' ELSE 'No' END)",
	)

	return optionsBuilder.Build()
}
