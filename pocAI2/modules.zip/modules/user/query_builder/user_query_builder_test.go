package query_builder_test

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/query_builder"
)

func TestGetUserListQuery_Paginated(t *testing.T) {
	req := userDto.UserListBody{
		Page:      1,
		Limit:     10,
		Search:    "john",
		SortBy:    "fullName",
		SortOrder: 1,
	}

	callerID := int64(12345)
	query, args, err := query_builder.GetUserListQuery(req, callerID, true)
	assert.NoError(t, err)
	assert.NotEmpty(t, query)
	assert.Contains(t, query, "WITH")
	assert.Contains(t, query, "user_ext_cte AS")
	assert.Contains(t, query, "filtered_ids AS")
	assert.Contains(t, query, "paginated_ids AS")
	assert.Contains(t, query, "total_query AS")
	assert.Contains(t, query, "data_query AS")
	assert.Contains(t, query, "totalDisabledRecords")
	assert.Contains(t, query, `COUNT(id) FILTER (WHERE is_default = TRUE OR id = 12345) AS "totalDisabledRecords"`)
	assert.Contains(t, query, `LIMIT 10 OFFSET 0`)
	assert.Contains(t, query, `users.full_name COLLATE "en-US-x-icu" ASC`)
	assert.NotEmpty(t, args)
}

func TestGetUserListQuery_PaginatedNoCaller(t *testing.T) {
	req := userDto.UserListBody{
		Page:  2,
		Limit: 20,
	}

	query, _, err := query_builder.GetUserListQuery(req, 0, true)
	assert.NoError(t, err)
	assert.Contains(t, query, `COUNT(id) FILTER (WHERE is_default = TRUE) AS "totalDisabledRecords"`)
	assert.Contains(t, query, `LIMIT 20 OFFSET 20`)
}

func TestGetUserListQuery_Unpaginated(t *testing.T) {
	req := userDto.UserListBody{
		SortBy:    "email",
		SortOrder: -1,
	}

	query, _, err := query_builder.GetUserListQuery(req, 0, false)
	assert.NoError(t, err)
	assert.NotContains(t, query, "filtered_ids AS")
	assert.Contains(t, query, `LIMIT 10000`)
	assert.Contains(t, query, `users.email COLLATE "en-US-x-icu" DESC`)
}

func TestGetUserListQuery_SortActivationStatus(t *testing.T) {
	req := userDto.UserListBody{
		Page:      1,
		Limit:     10,
		SortBy:    "activationStatus",
		SortOrder: 1,
	}

	query, _, err := query_builder.GetUserListQuery(req, 0, true)
	assert.NoError(t, err)
	assert.Contains(t, query, "user_ext_cte.activation_status ASC")
}

func TestGetUserListQuery_AccessArrSortedAlphabetically(t *testing.T) {
	req := userDto.UserListBody{
		Page:  1,
		Limit: 10,
	}

	query, _, err := query_builder.GetUserListQuery(req, 0, true)
	assert.NoError(t, err)
	assert.Contains(t, query, "jsonb_agg(ums.module_key ORDER BY")
	assert.Contains(t, query, "string_agg(CASE")
}

func TestGetUserListQuery_RemovedFieldsIgnored(t *testing.T) {
	var req userDto.UserListBody
	err := json.Unmarshal([]byte(`{"userType":["admin"],"authenticatorStatus":["Enrolled"],"sortBy":"userType"}`), &req)
	assert.NoError(t, err)

	query, args, err := query_builder.GetUserListQuery(req, 0, true)
	assert.NoError(t, err)
	assert.Empty(t, args)
	assert.Contains(t, query, `users.full_name COLLATE "en-US-x-icu" ASC`)
	assert.NotContains(t, query, "user_ext_cte.user_type IN")
	assert.NotContains(t, query, "users.is_authenticator_enrolled =")
	assert.NotContains(t, query, "ORDER BY user_ext_cte.user_type")
	assert.NotContains(t, query, "ORDER BY users.is_authenticator_enrolled")
}

func TestGetUserListOptionsQuery_RemovedOptionsIgnored(t *testing.T) {
	var req userDto.UserOptionsBody
	err := json.Unmarshal([]byte(`{"userTypeOptions":true,"authenticatorStatusOptions":true}`), &req)
	assert.NoError(t, err)

	query, _, err := query_builder.GetUserListOptionsQuery(userDto.UserListBody{}, req)
	assert.NoError(t, err)
	assert.NotContains(t, query, `"userTypeOptions" AS (`)
	assert.NotContains(t, query, `"authenticatorStatusOptions" AS (`)
}

func TestGetUserListQuery_Search_DynamicColumns(t *testing.T) {
	t.Run("specific column email only", func(t *testing.T) {
		req := userDto.UserListBody{
			Search:  "alice",
			Columns: []string{"email"},
		}
		query, args, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.email ILIKE")
		assert.NotContains(t, query, "users.full_name ILIKE")
		assert.NotContains(t, query, "positions.name ILIKE")
		assert.Contains(t, args, "%alice%")
	})

	t.Run("specific column name expands to first, last, full name", func(t *testing.T) {
		req := userDto.UserListBody{
			Search:  "bob",
			Columns: []string{"name"},
		}
		query, _, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.first_name ILIKE")
		assert.Contains(t, query, "users.last_name ILIKE")
		assert.Contains(t, query, "users.full_name ILIKE")
		assert.NotContains(t, query, "users.email ILIKE")
		assert.NotContains(t, query, "positions.name ILIKE")
	})

	t.Run("specific column tagCode", func(t *testing.T) {
		req := userDto.UserListBody{
			Search:  "TAG-001",
			Columns: []string{"tagCode"},
		}
		query, _, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.tag_code ILIKE")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("specific column activationStatus", func(t *testing.T) {
		req := userDto.UserListBody{
			Search:  "Pending",
			Columns: []string{"activationStatus"},
		}
		query, _, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "user_ext_cte.activation_status ILIKE")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("specific column temporaryStatus", func(t *testing.T) {
		req := userDto.UserListBody{
			Search:  "Yes",
			Columns: []string{"temporaryStatus"},
		}
		query, _, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "CASE WHEN users.is_temporary THEN 'Yes' ELSE 'No' END")
		assert.Contains(t, query, "ILIKE $1")
		assert.NotContains(t, query, "users.email ILIKE")
	})

	t.Run("non-searchable columns fall back to default search columns", func(t *testing.T) {
		req := userDto.UserListBody{
			Search:  "test",
			Columns: []string{"updatedAt", "isActive", "unknownCol"},
		}
		query, _, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.NotContains(t, query, "updated_at ILIKE")
		assert.Contains(t, query, "users.full_name ILIKE")
		assert.Contains(t, query, "users.email ILIKE")
		assert.Contains(t, query, "positions.name ILIKE")
	})

	t.Run("empty or nil columns fall back to default search columns", func(t *testing.T) {
		req := userDto.UserListBody{
			Search: "test",
		}
		query, _, err := query_builder.GetUserListQuery(req, 0, true)
		assert.NoError(t, err)
		assert.Contains(t, query, "users.full_name ILIKE")
		assert.Contains(t, query, "users.email ILIKE")
		assert.Contains(t, query, "user_ext_cte.access_search ILIKE")
	})
}
