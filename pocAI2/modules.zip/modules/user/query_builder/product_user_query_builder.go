package query_builder

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/sql_query/common_builders"
)

var acUserSearchableColumns = map[string][]string{
	"name":             {"users.first_name", "users.last_name", "users.full_name"},
	"fullName":         {"users.first_name", "users.last_name", "users.full_name"},
	"email":            {"users.email"},
	"employeeId":       {"users.employee_id"},
	"role":             {`(CASE WHEN ual.access_level = 'total_control' THEN 'Total Control' WHEN ual.access_level = 'read_only' THEN 'Read Only' ELSE (SELECT count(*)::text FROM user_system_roles usr WHERE usr.user_id = users.id AND usr.product = 'admin_console') END)`},
	"position":         {"positions.name"},
	"division":         {"divisions.name"},
	"modifiedBy":       {"mod_users.full_name"},
	"tagCode":          {"users.tag_code"},
	"activationStatus": {"(CASE WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END)"},
	"temporaryStatus":  {"(CASE WHEN COALESCE(users.is_temporary, false) THEN 'Yes' ELSE 'No' END)"},
}

var defaultAcUserSearchColumns = []string{
	"users.first_name",
	"users.last_name",
	"users.full_name",
	"users.email",
	"users.employee_id",
	"positions.name",
	"divisions.name",
	"mod_users.full_name",
	`(CASE WHEN ual.access_level = 'total_control' THEN 'Total Control' WHEN ual.access_level = 'read_only' THEN 'Read Only' ELSE (SELECT count(*)::text FROM user_system_roles usr WHERE usr.user_id = users.id AND usr.product = 'admin_console') END)`,
}

func resolveAcUserSearchColumns(columns []string) []string {
	if len(columns) == 0 {
		return defaultAcUserSearchColumns
	}

	out := make([]string, 0, len(columns))
	seen := make(map[string]bool)
	for _, c := range columns {
		if exprs, ok := acUserSearchableColumns[c]; ok {
			for _, expr := range exprs {
				if !seen[expr] {
					seen[expr] = true
					out = append(out, expr)
				}
			}
		}
	}
	if len(out) == 0 {
		return defaultAcUserSearchColumns
	}
	return out
}

var acUserSortColumns = map[string]string{
	"fullName":          "users.full_name",
	"email":             "users.email",
	"employeeId":        "users.employee_id",
	"position":          "positions.name",
	"division":          "divisions.name",
	"role":              `(CASE WHEN ual.access_level = 'total_control' THEN 'Total Control' WHEN ual.access_level = 'read_only' THEN 'Read Only' ELSE (SELECT count(*)::text FROM user_system_roles usr WHERE usr.user_id = users.id AND usr.product = 'admin_console') END)`,
	"activationStatus":  "(CASE WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END)",
	"isActive":          "ums.is_active",
	"activePeriodUntil": "users.active_period_until",
	"modifiedBy":        "mod_users.full_name",
	"updatedAt":         "ums.updated_at",
}

var adminConsoleRoleNameToKey = map[string]model.SystemRoleKey{
	string(model.SystemRoleNameManageUserAndRole):       model.SystemRoleKeyManageUserAndRole,
	string(model.SystemRoleNameManageGroup):             model.SystemRoleKeyManageGroup,
	string(model.SystemRoleNameManageDeviceMasterData):  model.SystemRoleKeyManageDeviceMasterData,
	string(model.SystemRoleNameManageTAGStock):          model.SystemRoleKeyManageTAGStock,
	string(model.SystemRoleNameManageHardwareStock):     model.SystemRoleKeyManageHardwareStock,
	string(model.SystemRoleNameManageLanguage):          model.SystemRoleKeyManageLanguage,
	string(model.SystemRoleNameManagePresetup):          model.SystemRoleKeyManagePresetup,
	string(model.SystemRoleNameManagePreload):           model.SystemRoleKeyManagePreload,
	string(model.SystemRoleNameManagePlansAndLicensing): model.SystemRoleKeyManagePlansAndLicensing,
	string(model.SystemRoleNameManagePrivacyPolicy):     model.SystemRoleKeyManagePrivacyPolicy,
	string(model.SystemRoleNameManageDistributor):       model.SystemRoleKeyManageDistributor,
	string(model.SystemRoleNameManagePartner):           model.SystemRoleKeyManagePartner,
	string(model.SystemRoleNameManageActiveClient):      model.SystemRoleKeyManageActiveClient,
	string(model.SystemRoleNameManageArchivedClient):    model.SystemRoleKeyManageArchivedClient,
	string(model.SystemRoleNameManageAllocation):        model.SystemRoleKeyManageAllocation,
	string(model.SystemRoleNameManageWalletAndPricing):  model.SystemRoleKeyManageWalletAndPricing,
}

// GetProductUserDropdownQuery builds the SQL query for GET /products/:product/users/dropdown.
// It joins user_module_status for the given product, filters out deleted users, applies activationStatus/status,
// restricts to permitted groups if actor is group-scoped, and orders by full_name ASC with ICU collation.
func GetProductUserDropdownQuery(req userDto.ProductUserDropdownQuery) (string, []any, error) {
	builder := sql_query.NewSQLSelectBuilder[userDto.UserDropdownItem]("users").
		Join("user_module_status ums", "ums.user_id = users.id", sql_query.WhereQuery{
			"ums.module_key": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: req.Product},
		}).
		LeftJoin("public.user_email_changes uec", "uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL", nil).
		Select(
			"users.id::text AS _id",
			`users.full_name COLLATE "en-US-x-icu" AS full_name`,
		).
		Where(sql_query.WhereQuery{
			"users.deleted_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
		})

	if req.ActivationStatus != "" {
		if req.ActivationStatus == "Pending Email Confirmation" {
			builder.Where(sql_query.WhereQuery{
				"users.activation_status": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "Activated"},
				"uec.new_email":           sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNotNull},
			})
		} else {
			builder.Where(sql_query.WhereQuery{
				"users.activation_status": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: req.ActivationStatus},
			})
		}
	}

	if req.Status != nil {
		builder.Where(sql_query.WhereQuery{
			"ums.is_active": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: *req.Status},
		})
	}

	if !req.IsAllGroups {
		if len(req.AllowedGroupIDs) == 0 {
			builder.Where(sql_query.WhereQuery{
				"users.id": sql_query.SQLCondition{
					Operator: sql_query.SQLOperatorRaw,
					Value:    "1 = 0",
				},
			})
		} else {
			ids := make([]string, len(req.AllowedGroupIDs))
			for i, id := range req.AllowedGroupIDs {
				ids[i] = strconv.FormatInt(id, 10)
			}
			idList := strings.Join(ids, ", ")
			builder.Where(sql_query.WhereQuery{
				"users.id": sql_query.SQLCondition{
					Operator: sql_query.SQLOperatorRaw,
					Value: fmt.Sprintf(`(
						EXISTS (
							SELECT 1 FROM user_system_roles usr
							WHERE usr.user_id = users.id
							  AND usr.product = '%s'
							  AND usr.admin_console_group_id IN (%s)
						)
						OR EXISTS (
							SELECT 1 FROM user_group_managers ugm
							WHERE ugm.user_id = users.id
							  AND ugm.product = '%s'
							  AND ugm.admin_console_group_id IN (%s)
						)
					)`, req.Product, idList, req.Product, idList),
				},
			})
		}
	}

	builder.OrderBy([]string{"full_name"}, true) // true = ASC

	return builder.Build()
}

// GetAdminConsoleUserListFilterBuilder builds the base SQL query with joins and where filters
// for POST /v2/iam/products/admin_console/users/list. Reusable for list, export, and options queries.
func GetAdminConsoleUserListFilterBuilder[T any](req userDto.AcUserListBody) *sql_query.SelectBuilder {
	builder := sql_query.NewSQLSelectBuilder[T]("users").
		Join("user_module_status ums", "ums.user_id = users.id", sql_query.WhereQuery{
			"ums.module_key": sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: model.ProductAdminConsole},
		}).
		LeftJoin("positions", "positions.id = users.position_id", nil).
		LeftJoin("divisions", "divisions.id = users.division_id", nil).
		LeftJoin("public.user_email_changes uec", "uec.user_id = users.id AND uec.consumed_at IS NULL AND uec.canceled_at IS NULL", nil).
		LeftJoin("user_access_levels ual", fmt.Sprintf("ual.user_id = users.id AND ual.product = '%s'", model.ProductAdminConsole), nil).
		LeftJoin("users mod_users", "mod_users.id = users.modified_by", nil)

	where := sql_query.WhereQuery{
		"users.deleted_at": sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNull},
	}

	// Actor group scoping
	if !req.IsAllGroups {
		if len(req.AllowedGroupIDs) == 0 {
			where["users.id"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value:    "1 = 0",
			}
		} else {
			ids := make([]string, len(req.AllowedGroupIDs))
			for i, id := range req.AllowedGroupIDs {
				ids[i] = strconv.FormatInt(id, 10)
			}
			idList := strings.Join(ids, ", ")
			where["actor_group_scope"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value: fmt.Sprintf(`(
					EXISTS (
						SELECT 1 FROM user_system_roles usr
						WHERE usr.user_id = users.id
						  AND usr.product = '%s'
						  AND usr.admin_console_group_id IN (%s)
					)
					OR EXISTS (
						SELECT 1 FROM user_group_managers ugm
						WHERE ugm.user_id = users.id
						  AND ugm.product = '%s'
						  AND ugm.admin_console_group_id IN (%s)
					)
				)`, model.ProductAdminConsole, idList, model.ProductAdminConsole, idList),
			}
		}
	}

	// Sidebar Group filter
	if len(req.Group) > 0 {
		var groupIDs []string
		for _, g := range req.Group {
			if id, err := strconv.ParseInt(g, 10, 64); err == nil {
				groupIDs = append(groupIDs, strconv.FormatInt(id, 10))
			}
		}
		if len(groupIDs) > 0 {
			gList := strings.Join(groupIDs, ", ")
			where["sidebar_group_filter"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value: fmt.Sprintf(`(
					EXISTS (
						SELECT 1 FROM user_system_roles usr_filter
						WHERE usr_filter.user_id = users.id
						  AND usr_filter.product = '%s'
						  AND usr_filter.admin_console_group_id IN (%s)
					)
					OR EXISTS (
						SELECT 1 FROM user_group_managers ugm_filter
						WHERE ugm_filter.user_id = users.id
						  AND ugm_filter.product = '%s'
						  AND ugm_filter.admin_console_group_id IN (%s)
					)
				)`, model.ProductAdminConsole, gList, model.ProductAdminConsole, gList),
			}
		}
	}

	if len(req.Position) > 0 {
		where["positions.name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.Position}
	}

	if len(req.Division) > 0 {
		where["divisions.name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.Division}
	}

	if len(req.Status) > 0 {
		hasActive := helper.Contains(req.Status, "Active") || helper.Contains(req.Status, "active")
		hasInactive := helper.Contains(req.Status, "Inactive") || helper.Contains(req.Status, "inactive")

		if hasActive && !hasInactive {
			where["ums.is_active"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: true}
		} else if hasInactive && !hasActive {
			where["ums.is_active"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: false}
		}
	}

	if len(req.ActivationStatus) > 0 {
		var hasPendingEmail, hasOther bool
		var otherStatuses []string
		for _, s := range req.ActivationStatus {
			if s == "Pending Email Confirmation" {
				hasPendingEmail = true
			} else {
				hasOther = true
				otherStatuses = append(otherStatuses, s)
			}
		}

		if hasPendingEmail && !hasOther {
			where["users.activation_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: "Activated"}
			where["uec.new_email"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIsNotNull}
		} else if hasPendingEmail && hasOther {
			escapedStatuses := make([]string, len(otherStatuses))
			for i, s := range otherStatuses {
				escapedStatuses[i] = fmt.Sprintf("'%s'", strings.ReplaceAll(s, "'", "''"))
			}
			inVals := strings.Join(escapedStatuses, ", ")
			where["activation_status_compound"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value:    fmt.Sprintf("(users.activation_status IN (%s) OR (users.activation_status = 'Activated' AND uec.new_email IS NOT NULL))", inVals),
			}
		} else {
			where["users.activation_status"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.ActivationStatus}
		}
	}

	if len(req.Role) > 0 {
		var roleKeys []string
		for _, r := range req.Role {
			if k, ok := adminConsoleRoleNameToKey[r]; ok {
				roleKeys = append(roleKeys, string(k))
			}
		}
		if len(roleKeys) > 0 {
			escaped := make([]string, len(roleKeys))
			for i, k := range roleKeys {
				escaped[i] = fmt.Sprintf("'%s'", strings.ReplaceAll(k, "'", "''"))
			}
			inKeys := strings.Join(escaped, ", ")
			where["role_filter"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value: fmt.Sprintf(`EXISTS (
					SELECT 1 FROM user_system_roles usr_r
					WHERE usr_r.user_id = users.id
					  AND usr_r.product = '%s'
					  AND usr_r.permission_view = true
					  AND usr_r.key IN (%s)
				)`, model.ProductAdminConsole, inKeys),
			}
		} else {
			where["role_filter"] = sql_query.SQLCondition{
				Operator: sql_query.SQLOperatorRaw,
				Value:    "1 = 0",
			}
		}
	}

	if len(req.TemporaryStatus) > 0 {
		var hasYes, hasNo bool
		for _, s := range req.TemporaryStatus {
			switch s {
			case "Yes":
				hasYes = true
			case "No":
				hasNo = true
			}
		}
		if hasYes && !hasNo {
			where["users.is_temporary"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorEqual, Value: true}
		} else if hasNo && !hasYes {
			where["users.is_temporary"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorRaw, Value: "(users.is_temporary IS NULL OR users.is_temporary = false)"}
		}
	}

	if len(req.ActivePeriodUntil) > 0 {
		if len(req.ActivePeriodUntil) == 1 {
			start := time.UnixMilli(req.ActivePeriodUntil[0]).UTC().Truncate(24 * time.Hour)
			end := start.Add(24*time.Hour - time.Millisecond)
			where["users.active_period_until"] = sql_query.SQLCondition{
				Operator:    sql_query.SQLOperatorBetween,
				Value:       []int64{start.UnixMilli(), end.UnixMilli()},
				IsEpochTime: true,
			}
		} else {
			where["users.active_period_until"] = sql_query.SQLCondition{
				Operator:    sql_query.SQLOperatorBetween,
				Value:       req.ActivePeriodUntil,
				IsEpochTime: true,
			}
		}
	}

	if len(req.ModifiedBy) > 0 {
		where["mod_users.full_name"] = sql_query.SQLCondition{Operator: sql_query.SQLOperatorIn, Value: req.ModifiedBy}
	}

	if len(req.UpdatedAt) > 0 {
		where["ums.updated_at"] = sql_query.SQLCondition{
			Operator:    sql_query.SQLOperatorBetween,
			Value:       req.UpdatedAt,
			IsEpochTime: true,
		}
	}

	builder.Where(where)
	return builder.(*sql_query.SelectBuilder)
}

// GetAdminConsoleUserListQuery builds the SQL query for POST /v2/iam/products/admin_console/users/list.
func GetAdminConsoleUserListQuery[T any](req userDto.AcUserListBody, paginate bool) (string, []any, error) {
	builder := GetAdminConsoleUserListFilterBuilder[T](req)

	if paginate {
		pagination := sql_query.Pagination{
			Page:  req.Page,
			Limit: req.Limit,
			DefaultSort: []sql_query.Sort{{
				SortBy:    `users.full_name COLLATE "en-US-x-icu"`,
				SortOrder: 1,
			}},
		}
		if col, ok := acUserSortColumns[req.SortBy]; ok {
			sortCol := col
			if col == "users.full_name" || col == "users.email" || col == "users.employee_id" || col == "positions.name" || col == "divisions.name" || col == "mod_users.full_name" {
				sortCol = col + ` COLLATE "en-US-x-icu"`
			}
			pagination.SortBy = sortCol
			pagination.SortOrder = req.SortOrder
		}
		builder.Paginate(pagination)
	} else {
		builder.SetLimit(10000)
		if col, ok := acUserSortColumns[req.SortBy]; ok {
			isAsc := req.SortOrder == 1
			sortCol := col
			if col == "users.full_name" || col == "users.email" || col == "users.employee_id" || col == "positions.name" || col == "divisions.name" || col == "mod_users.full_name" {
				sortCol = col + ` COLLATE "en-US-x-icu"`
			}
			builder.OrderBy([]string{sortCol}, isAsc)
		} else {
			builder.OrderBy([]string{`users.full_name COLLATE "en-US-x-icu"`}, true)
		}
	}

	if req.Search != "" {
		builder.Search(req.Search, resolveAcUserSearchColumns(req.Columns))
	}

	return builder.Build()
}

// GetAdminConsoleUserListOptionsQuery builds the SQL query for POST /v2/iam/products/admin_console/users/options.
func GetAdminConsoleUserListOptionsQuery(req userDto.AcUserOptionsBody) (string, []any, error) {
	optionsBuilder := sql_query.NewSQLSelectBuilder[userDto.AcUserOptionsResponse]("users")

	if req.PositionOptions {
		common_builders.GenerateCTEOption(
			GetAdminConsoleUserListFilterBuilder[any](req.AcUserListBody),
			optionsBuilder.(*sql_query.SelectBuilder),
			"positionOptions",
			"users",
			req.PositionOptions,
			"positions.name",
			"positions.name",
		)
	}

	if req.DivisionOptions {
		common_builders.GenerateCTEOption(
			GetAdminConsoleUserListFilterBuilder[any](req.AcUserListBody),
			optionsBuilder.(*sql_query.SelectBuilder),
			"divisionOptions",
			"users",
			req.DivisionOptions,
			"divisions.name",
			"divisions.name",
		)
	}

	if req.StatusOptions {
		common_builders.GenerateCTEOption(
			GetAdminConsoleUserListFilterBuilder[any](req.AcUserListBody),
			optionsBuilder.(*sql_query.SelectBuilder),
			"statusOptions",
			"users",
			req.StatusOptions,
			"(CASE WHEN ums.is_active = true THEN 'Active' ELSE 'Inactive' END)",
			"(CASE WHEN ums.is_active = true THEN 'Active' ELSE 'Inactive' END)",
		)
	}

	if req.ActivationStatusOptions {
		common_builders.GenerateCTEOption(
			GetAdminConsoleUserListFilterBuilder[any](req.AcUserListBody),
			optionsBuilder.(*sql_query.SelectBuilder),
			"activationStatusOptions",
			"users",
			req.ActivationStatusOptions,
			"(CASE WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END)",
			"(CASE WHEN users.activation_status = 'Activated' AND uec.new_email IS NOT NULL THEN 'Pending Email Confirmation' ELSE users.activation_status END)",
		)
	}

	if req.TemporaryStatusOptions {
		common_builders.GenerateCTEOption(
			GetAdminConsoleUserListFilterBuilder[any](req.AcUserListBody),
			optionsBuilder.(*sql_query.SelectBuilder),
			"temporaryStatusOptions",
			"users",
			req.TemporaryStatusOptions,
			"(CASE WHEN users.is_temporary = true THEN 'Yes' ELSE 'No' END)",
			"(CASE WHEN users.is_temporary = true THEN 'Yes' ELSE 'No' END)",
		)
	}

	if req.ModifiedByOptions {
		common_builders.GenerateCTEOption(
			GetAdminConsoleUserListFilterBuilder[any](req.AcUserListBody),
			optionsBuilder.(*sql_query.SelectBuilder),
			"modifiedByOptions",
			"users",
			req.ModifiedByOptions,
			"mod_users.full_name",
			"mod_users.full_name",
		)
	}

	return optionsBuilder.Build()
}
