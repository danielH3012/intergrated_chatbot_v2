package service

import (
	"bytes"
	"context"
	"encoding/csv"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"go.temporal.io/sdk/client"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

type FakeWorkflowRun struct {
	client.WorkflowRun
	resultFunc func(resultPtr interface{})
	runErr     error
}

func (f *FakeWorkflowRun) Get(ctx context.Context, valuePtr interface{}) error {
	if f.resultFunc != nil {
		f.resultFunc(valuePtr)
	}
	return f.runErr
}

type FakeTemporalClient struct {
	client.Client
	RunErr     error
	ResultFunc func(resultPtr interface{})
	CalledArgs []interface{}
}

func (f *FakeTemporalClient) ExecuteWorkflow(ctx context.Context, options client.StartWorkflowOptions, workflowType interface{}, args ...interface{}) (client.WorkflowRun, error) {
	f.CalledArgs = append(f.CalledArgs, workflowType)
	f.CalledArgs = append(f.CalledArgs, args...)

	run := &FakeWorkflowRun{
		resultFunc: f.ResultFunc,
		runErr:     f.RunErr,
	}
	return run, nil
}

func mockTemporal(workflowName string, runErr error, resultFunc func(resultPtr interface{})) (*coreService.TemporalService, *FakeTemporalClient) {
	c := &FakeTemporalClient{
		RunErr:     runErr,
		ResultFunc: resultFunc,
	}
	return &coreService.TemporalService{TaskQueue: "testq", Client: c}, c
}

func newSvc(temporalSvc *coreService.TemporalService, fakeRepo repository.UserRepositor) *UserService {
	if fakeRepo == nil {
		fakeRepo = repository.NewFakeUserRepository()
	}
	svc := &UserService{
		repo:        fakeRepo,
		temporalSvc: temporalSvc,
		arTaskQueue: "arTaskQueue",
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})
	return svc
}

func TestUserService_List(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	svc := newSvc(nil, fakeRepo)

	// Insert dummy
	user := model.User{
		ID:        1,
		FirstName: "John",
		LastName:  "Doe",
		Email:     "test@example.com",
	}
	fakeRepo.AddUser(&user)

	req := dto.UserListBody{
		Limit: 10,
		Page:  1,
	}

	callerID := int64(1) // matches user.ID = 1 created
	res, err := svc.List(context.Background(), "testclient", callerID, req)
	assert.NoError(t, err)
	assert.Equal(t, 1, res.TotalRecords)
	assert.Equal(t, 1, res.TotalDisabledRecords)
	assert.Len(t, res.Data, 1)
	assert.Equal(t, "test@example.com", res.Data[0].Email)
}

func TestUserService_ExportUsesCanonicalHeaders(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{ID: 1, FirstName: "John", LastName: "Doe", Email: "john@example.com"})
	svc := newSvc(nil, fakeRepo)

	res, err := svc.Export(context.Background(), "testclient", dto.UserExportBody{Format: "csv"})
	assert.NoError(t, err)

	header, err := csv.NewReader(bytes.NewReader(res.Data)).Read()
	assert.NoError(t, err)
	assert.Contains(t, header, "Temporary User")
	assert.Contains(t, header, "TAG")
	assert.Contains(t, header, "Temporary Until")
	assert.Contains(t, header, "Last Update")
}

func TestUserService_Create(t *testing.T) {
	coreDb.InitSnowflake()

	// 1. Success case
	temporalSvc, mockClient := mockTemporal(constant.WorkflowCreateUser, nil, func(resultPtr interface{}) {
		resPtr := resultPtr.(*workflow.CreateUserWorkflowResult)
		resPtr.ID = "12345"
	})
	svc := newSvc(temporalSvc, nil)

	param := CreateUserParam{
		ClientCode:          "testclient",
		FirstName:           "Jane",
		LastName:            "Doe",
		Email:               "new@example.com",
		CurrentUserFullName: "Admin",
		Access:              []string{"global_settings"},
	}

	idStr, err := svc.Create(context.Background(), param)
	assert.NoError(t, err)
	assert.Equal(t, "12345", idStr)
	assert.Equal(t, constant.WorkflowCreateUser, mockClient.CalledArgs[0])

	// 2. Duplicate email simulating Temporal Error
	temporalSvcErr, _ := mockTemporal(constant.WorkflowCreateUser, coreEntity.Conflict("email already exists"), nil)
	svcErr := newSvc(temporalSvcErr, nil)

	_, err = svcErr.Create(context.Background(), param)
	assert.Error(t, err)
	assert.Equal(t, "email already exists", err.Error())
}

func TestUserService_Update(t *testing.T) {
	// 1. Success case
	temporalSvc, mockClient := mockTemporal(constant.WorkflowUpdateUser, nil, nil)
	svc := newSvc(temporalSvc, nil)

	param := UpdateUserParam{
		ClientCode:          "testclient",
		UserID:              1,
		FirstName:           "Johnny",
		LastName:            "Doe",
		Email:               "user1@example.com",
		CurrentUserFullName: "Admin",
		Access:              []string{"global_settings"},
	}

	err := svc.Update(context.Background(), param)
	assert.NoError(t, err)
	assert.Equal(t, constant.WorkflowUpdateUser, mockClient.CalledArgs[0])

	// 2. Temporal Error
	temporalSvcErr, _ := mockTemporal(constant.WorkflowUpdateUser, errors.New("some error"), nil)
	svcErr := newSvc(temporalSvcErr, nil)

	err = svcErr.Update(context.Background(), param)
	assert.Error(t, err)
	assert.Equal(t, "some error", err.Error())
}

func TestUserService_Delete(t *testing.T) {
	temporalSvc, mockClient := mockTemporal(constant.WorkflowDeleteUsers, nil, func(resultPtr interface{}) {
		resPtr := resultPtr.(*workflow.DeleteUsersWorkflowResult)
		reason := "self_delete"
		resPtr.Results = []dto.DeleteUserResult{
			{ID: "1", Status: "blocked", Reason: &reason},
			{ID: "2", Status: "deleted", Reason: nil},
		}
	})
	svc := newSvc(temporalSvc, nil)

	req := dto.DeleteUsersBody{
		IDs: []string{"1", "2"},
	}

	res, err := svc.Delete(context.Background(), "testclient", req, 1, "Admin")
	assert.NoError(t, err)
	assert.Len(t, res, 2)
	assert.Equal(t, "blocked", res[0].Status)
	assert.Equal(t, "self_delete", *res[0].Reason)
	assert.Equal(t, "deleted", res[1].Status)

	assert.Equal(t, constant.WorkflowDeleteUsers, mockClient.CalledArgs[0])
}

func TestUserService_UpdateStatusBulk(t *testing.T) {
	temporalSvc, mockClient := mockTemporal(constant.WorkflowUpdateUserStatus, nil, func(resultPtr interface{}) {
		resPtr := resultPtr.(*workflow.UpdateUserStatusWorkflowResult)
		resPtr.Results = []dto.BulkStatusResult{
			{ID: "1", Status: "updated", Reason: nil},
		}
	})
	svc := newSvc(temporalSvc, nil)

	isActive := true
	req := dto.BulkStatusBody{
		IDs:      []string{"1"},
		IsActive: &isActive,
	}

	res, msg, err := svc.UpdateStatusBulk(context.Background(), "testclient", req, "moduleX", 2, "Admin", true, nil)
	assert.NoError(t, err)
	assert.Equal(t, "1 updated", msg)
	assert.Len(t, res.Results, 1)
	assert.Equal(t, "updated", res.Results[0].Status)

	assert.Equal(t, constant.WorkflowUpdateUserStatus, mockClient.CalledArgs[0])
}

func TestUserService_UpdateStatusBulk_AdminConsole_Scoped(t *testing.T) {
	temporalSvc, mockClient := mockTemporal(constant.WorkflowUpdateUserStatus, nil, func(resultPtr interface{}) {
		resPtr := resultPtr.(*workflow.UpdateUserStatusWorkflowResult)
		resPtr.Results = []dto.BulkStatusResult{
			{ID: "10", Status: "updated", Reason: nil},
		}
	})
	svc := newSvc(temporalSvc, nil)

	isActive := false
	req := dto.BulkStatusBody{
		IDs:      []string{"10"},
		IsActive: &isActive,
	}

	res, msg, err := svc.UpdateStatusBulk(context.Background(), "testclient", req, "admin_console", 2, "Admin", false, []int64{101, 102})
	assert.NoError(t, err)
	assert.Equal(t, "1 updated", msg)
	assert.Len(t, res.Results, 1)

	assert.Equal(t, constant.WorkflowUpdateUserStatus, mockClient.CalledArgs[0])
	param := mockClient.CalledArgs[1].(workflow.UpdateUserStatusWorkflowParam)
	assert.Equal(t, "admin_console", param.ModuleKey)
	assert.False(t, param.IsAllGroups)
	assert.Equal(t, []int64{101, 102}, param.AllowedGroupIDs)
}

func TestUserService_ResendEmailBulk_AdminConsole(t *testing.T) {
	temporalSvc, mockClient := mockTemporal(constant.WorkflowResendEmail, nil, func(resultPtr any) {
		resPtr := resultPtr.(*workflow.ResendEmailWorkflowResult)
		resPtr.Results = []dto.ResendResult{
			{ID: "1", Status: "sent", Type: new("activation")},
			{ID: "2", Status: "blocked", Reason: new("tcro_target")},
		}
	})
	svc := newSvc(temporalSvc, nil)

	req := dto.ResendEmailBody{
		IDs:     []string{"1", "2"},
		Product: "admin_console",
	}

	res, msg, err := svc.ResendEmailBulk(context.Background(), "testclient", req, 2, "Admin")
	assert.NoError(t, err)
	assert.Equal(t, "1 sent, 1 blocked", msg)
	assert.Len(t, res.Results, 2)

	assert.Equal(t, constant.WorkflowResendEmail, mockClient.CalledArgs[0])
	param := mockClient.CalledArgs[1].(workflow.ResendEmailWorkflowParam)
	assert.Equal(t, "admin_console", param.Product)
}

func TestUserService_AdminConsoleList_PermissionsAndScopes(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	// Target 1: Default user
	fakeRepo.AddUser(&model.User{
		ID:               1001,
		FirstName:        "Default",
		LastName:         "User",
		IsDefault:        func() *bool { b := true; return &b }(),
		ActivationStatus: "Activated",
	})
	// Target 2: Self
	fakeRepo.AddUser(&model.User{
		ID:               1002,
		FirstName:        "Actor",
		LastName:         "User",
		ActivationStatus: "Activated",
	})
	// Target 3: Normal user
	fakeRepo.AddUser(&model.User{
		ID:               1003,
		FirstName:        "Target",
		LastName:         "User",
		ActivationStatus: "Activated",
	})

	svc := newSvc(nil, fakeRepo)

	// Case 1: Total Control actor
	tcRoles := tsMiddleware.UserAccessCache{
		ID: 1002,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	res, err := svc.AdminConsoleList(context.Background(), "client_1", 1002, tcRoles, dto.AcUserListBody{Page: 1, Limit: 10})
	assert.NoError(t, err)
	assert.Equal(t, 3, res.TotalRecords)

	for _, item := range res.Data {
		switch item.ID {
		case "1001":
			assert.False(t, item.SystemPermissions.ManageUserAndRole.Update, "Default user should have update=false")
		case "1002":
			assert.False(t, item.SystemPermissions.ManageUserAndRole.Update, "Self target should have update=false")
		case "1003":
			assert.True(t, item.SystemPermissions.ManageUserAndRole.Update, "Normal target should have update=true for TC")
		}
	}

	// Case 2: Group Manager actor with out-of-scope group request -> 403
	gmRoles := tsMiddleware.UserAccessCache{
		ID: 1002,
	}
	gmRoles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"101"},
		},
	}
	_, err = svc.AdminConsoleList(context.Background(), "client_1", 1002, gmRoles, dto.AcUserListBody{
		Group: []string{"999"},
	})
	assert.Error(t, err)
}

func TestUserService_AdminConsoleOptions(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	svc := newSvc(nil, fakeRepo)

	// Case 1: TC actor requesting RoleOptions
	tcRoles := tsMiddleware.UserAccessCache{
		ID: 1002,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	res, err := svc.AdminConsoleOptions(context.Background(), "client_1", tcRoles, dto.AcUserOptionsBody{
		RoleOptions:   true,
		StatusOptions: true,
	})
	assert.NoError(t, err)
	assert.Equal(t, 15, len(res.RoleOptions))
	assert.Equal(t, 2, len(res.StatusOptions))

	// Case 2: Group-scoped actor with forbidden group filter
	gmRoles := tsMiddleware.UserAccessCache{
		ID: 1002,
	}
	gmRoles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"101"},
		},
	}
	_, err = svc.AdminConsoleOptions(context.Background(), "client_1", gmRoles, dto.AcUserOptionsBody{
		AcUserListBody: dto.AcUserListBody{
			Group: []string{"999"},
		},
	})
	assert.Error(t, err)

	// Case 3: Group-scoped actor with no allowed groups
	gmEmptyRoles := tsMiddleware.UserAccessCache{
		ID: 1002,
	}
	resEmpty, err := svc.AdminConsoleOptions(context.Background(), "client_1", gmEmptyRoles, dto.AcUserOptionsBody{
		RoleOptions: true,
	})
	assert.NoError(t, err)
	assert.Equal(t, 15, len(resEmpty.RoleOptions))
	assert.Nil(t, resEmpty.StatusOptions)
}

func TestUserService_AdminConsoleUserActiveRoles(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	svc := newSvc(nil, fakeRepo)

	targetID := int64(2001)
	fakeRepo.AddUser(&model.User{
		ID:        targetID,
		FirstName: "John",
		LastName:  "Doe",
	})
	fakeRepo.SetUserAdminConsoleGroups(targetID, []int64{101, 102})

	g1 := "Region B"
	g2 := "Region A"
	gid1 := int64(101)
	gid2 := int64(102)

	fakeRepo.SetUserActiveRoles(targetID, []dto.AcUserActiveRolesRawRow{
		{
			ScopeLevel: "global",
			Key:        "manage_device_master_data",
		},
		{
			ScopeLevel:            "group",
			Key:                   "manage_group",
			AdminConsoleGroupID:   &gid1,
			AdminConsoleGroupName: &g1,
		},
		{
			ScopeLevel:            "group",
			Key:                   "manage_group",
			AdminConsoleGroupID:   &gid2,
			AdminConsoleGroupName: &g2,
		},
	})

	// Case 1: Total Control actor
	tcRoles := tsMiddleware.UserAccessCache{
		ID: 1001,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}
	res, err := svc.AdminConsoleUserActiveRoles(context.Background(), "client_1", 1001, tcRoles, targetID)
	assert.NoError(t, err)
	assert.NotNil(t, res)
	assert.Equal(t, 3, res.ActiveRoles) // 1 global + 2 groups
	assert.Equal(t, 1, len(res.GlobalRoles))
	assert.Equal(t, "Manage device master data", res.GlobalRoles[0])

	assert.Equal(t, 1, len(res.GroupRoles))
	assert.Equal(t, "Manage group", res.GroupRoles[0].Role)
	assert.Equal(t, 2, res.GroupRoles[0].GroupCount)
	assert.Equal(t, []string{"Region A", "Region B"}, res.GroupRoles[0].Groups) // Sorted A-Z

	// Case 2: Group scoped actor with overlap (caller has 101, target has 101 & 102)
	gmRolesOverlap := tsMiddleware.UserAccessCache{ID: 1002}
	gmRolesOverlap.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"101"},
		},
	}
	resOverlap, err := svc.AdminConsoleUserActiveRoles(context.Background(), "client_1", 1002, gmRolesOverlap, targetID)
	assert.NoError(t, err)
	assert.Equal(t, 3, resOverlap.ActiveRoles)

	// Case 3: Group scoped actor with NO overlap (caller has 999, target has 101 & 102)
	gmRolesNoOverlap := tsMiddleware.UserAccessCache{ID: 1003}
	gmRolesNoOverlap.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"999"},
		},
	}
	_, err = svc.AdminConsoleUserActiveRoles(context.Background(), "client_1", 1003, gmRolesNoOverlap, targetID)
	assert.Error(t, err)

	// Case 4: Target user not found
	_, err = svc.AdminConsoleUserActiveRoles(context.Background(), "client_1", 1001, tcRoles, 99999)
	assert.Error(t, err)
}

func TestUserService_AdminConsoleExport(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	fakeRepo.AddUser(&model.User{
		ID:               1001,
		FirstName:        "John",
		LastName:         "Doe",
		Email:            "john.doe@example.com",
		ActivationStatus: "Activated",
	})
	fakeRepo.AddUser(&model.User{
		ID:               1002,
		FirstName:        "Jane",
		LastName:         "Smith",
		Email:            "jane.smith@example.com",
		ActivationStatus: "Activated",
	})

	svc := newSvc(nil, fakeRepo)
	tcRoles := tsMiddleware.UserAccessCache{
		ID: 1001,
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessAdminConsole: {IsTotalControl: true},
		},
	}

	// Test CSV export
	csvRes, err := svc.AdminConsoleExport(context.Background(), "client_1", 1001, tcRoles, dto.AcUserExportBody{
		Format: "csv",
	})
	assert.NoError(t, err)
	assert.NotNil(t, csvRes)
	assert.Equal(t, "text/csv", csvRes.ContentType)
	assert.Equal(t, "Users.csv", csvRes.Filename)
	assert.True(t, len(csvRes.Data) > 0)
	csvContent := string(csvRes.Data)
	assert.Contains(t, csvContent, "Active,Full Name,Email,Role,Position,Division,Employee ID,Modified By,Last Updated,Activation Status,Temporary Status,Active Period Until,TAG")
	assert.Contains(t, csvContent, "John Doe")
	assert.Contains(t, csvContent, "john.doe@example.com")

	// Test XLSX export
	xlsxRes, err := svc.AdminConsoleExport(context.Background(), "client_1", 1001, tcRoles, dto.AcUserExportBody{
		Format: "xlsx",
	})
	assert.NoError(t, err)
	assert.NotNil(t, xlsxRes)
	assert.Equal(t, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xlsxRes.ContentType)
	assert.Equal(t, "Users.xlsx", xlsxRes.Filename)
	assert.True(t, len(xlsxRes.Data) > 0)

	// Test group scoping error
	gmRoles := tsMiddleware.UserAccessCache{ID: 1001}
	gmRoles.AdminConsoleSystemRole.GroupRoles = map[enum.SystemRoleKey]tsMiddleware.Permissions[[]string]{
		enum.SystemRoleKeyManageUserAndRole: {
			View: []string{"101"},
		},
	}
	_, err = svc.AdminConsoleExport(context.Background(), "client_1", 1001, gmRoles, dto.AcUserExportBody{
		AcUserListBody: dto.AcUserListBody{
			Group: []string{"999"},
		},
		Format: "csv",
	})
	assert.Error(t, err)
}
