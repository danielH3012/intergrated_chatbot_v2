package service

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func (s *UserService) List(ctx context.Context, clientCode string, callerID int64, req userDto.UserListBody) (userDto.UserListResponseData, error) {
	res, err := s.repo.List(ctx, s.tenantSvc(clientCode), callerID, req)
	if err != nil {
		slog.ErrorContext(ctx, "UserService.List", "err", err)
		return userDto.UserListResponseData{}, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	return res, nil
}
