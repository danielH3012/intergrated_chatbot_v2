package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
)

func (s *UserService) ResetAuthenticator(ctx context.Context, clientCode string, userID int64, currentUserID int64, currentUserFullName string) (string, error) {
	var result string

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowResetAuthenticator,
		TemporalService: s.temporalSvc,
		Param: workflow.ResetAuthenticatorWorkflowParam{
			ClientCode:                  clientCode,
			UserID:                      userID,
			CurrentUserID:               currentUserID,
			CurrentUserName:             currentUserFullName,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, &result, client.StartWorkflowOptions{})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.ResetAuthenticator: ExecuteWorkflow", "err", httpErr)
		return "", httpErr
	}

	if s.notifier != nil {
		if err := s.notifier.SendSSE(ctx, clientCode, []string{fmt.Sprintf("%d", userID)}, "user.authenticator_reset"); err != nil {
			slog.WarnContext(ctx, "reset authenticator: sse push failed", "error", err)
		}
	}

	return result, nil
}
