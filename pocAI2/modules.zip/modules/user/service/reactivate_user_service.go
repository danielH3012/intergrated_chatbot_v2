package service

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

func (s *UserService) ReactivateUser(ctx context.Context, clientCode string, userID int64, req userDto.ReactivateBody, currentUserID int64, currentUserFullName string) error {
	if req.Action == "extend" {
		if req.ActivePeriodUntil == nil {
			return &coreEntity.HttpError{
				Code:    422,
				Message: "Please select a valid date.",
				Err: map[string][]string{
					"activePeriodUntil": {"Please select a valid date."},
				},
			}
		}
		parsed := time.UnixMilli(*req.ActivePeriodUntil).UTC().Truncate(24 * time.Hour)
		if parsed.Before(time.Now().UTC().Truncate(24 * time.Hour)) {
			return &coreEntity.HttpError{
				Code:    422,
				Message: "Please select a future date.",
				Err: map[string][]string{
					"activePeriodUntil": {"Please select a future date."},
				},
			}
		}
	}

	var result workflow.ReactivateUserWorkflowResult
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowReactivateUser,
		TemporalService: s.temporalSvc,
		Param: workflow.ReactivateUserWorkflowParam{
			ClientCode:                  clientCode,
			UserID:                      userID,
			CurrentUserID:               currentUserID,
			CurrentUserFullName:         currentUserFullName,
			Action:                      req.Action,
			ActivePeriodUntil:           req.ActivePeriodUntil,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, &result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("user-reactivate-%s-%d", clientCode, userID),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1, // Let failures surface
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})

	if httpErr != nil {
		return httpErr
	}

	if result.Activated && s.notifier != nil {
		if err := s.notifier.SendSSE(ctx, clientCode, []string{fmt.Sprintf("%d", userID)}, "user.status_changed"); err != nil {
			slog.WarnContext(ctx, "reactivate user: sse push failed", "error", err)
		}
	}

	return nil
}
