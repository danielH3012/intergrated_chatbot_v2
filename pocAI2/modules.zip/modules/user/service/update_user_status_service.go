package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

// UpdateStatusBulk handles both global and per-product bulk status updates.
func (s *UserService) UpdateStatusBulk(ctx context.Context, clientCode string, req userDto.BulkStatusBody, moduleKey string, currentUserID int64, currentUserFullName string, isAllGroups bool, allowedGroupIDs []int64) (userDto.BulkStatusResponse, string, error) {
	// The caller (handler) must enforce bulk_action_checkbox_limit before this.

	result := &workflow.UpdateUserStatusWorkflowResult{}
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowUpdateUserStatus,
		TemporalService: s.temporalSvc,
		Param: workflow.UpdateUserStatusWorkflowParam{
			ClientCode:                  clientCode,
			IDs:                         req.IDs,
			IsActive:                    *req.IsActive,
			ModuleKey:                   moduleKey,
			CurrentUserID:               currentUserID,
			CurrentUserFullName:         currentUserFullName,
			IsAllGroups:                 isAllGroups,
			AllowedGroupIDs:             allowedGroupIDs,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		// Make workflow ID deterministic based on the batch of IDs
		// If there are many IDs, we can just hash them or use a random UUID, but generating a UUID is better to avoid clashes for different batches.
		// temporal_helper handles empty ID by auto-generating if we don't provide one, but let's provide a prefix.
		ID: fmt.Sprintf("user-status-update-%s", clientCode),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1, // Let failures surface
		},
		WorkflowIDReusePolicy: enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
	})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.UpdateStatusBulk: ExecuteWorkflow", "err", httpErr)
		return userDto.BulkStatusResponse{}, "", httpErr
	}

	// Create summary message
	updatedCount := 0
	skippedCount := 0
	blockedCount := 0
	var updatedIDs []string

	for _, r := range result.Results {
		switch r.Status {
		case "updated":
			updatedCount++
			updatedIDs = append(updatedIDs, r.ID)
		case "skipped":
			skippedCount++
		case "blocked":
			blockedCount++
		}
	}

	msgParts := []string{fmt.Sprintf("%d updated", updatedCount)}
	if skippedCount > 0 {
		msgParts = append(msgParts, fmt.Sprintf("%d skipped", skippedCount))
	}
	if blockedCount > 0 {
		msgParts = append(msgParts, fmt.Sprintf("%d blocked", blockedCount))
	}

	var msg string
	if len(msgParts) == 1 {
		msg = msgParts[0]
	} else if len(msgParts) == 2 {
		msg = fmt.Sprintf("%s, %s", msgParts[0], msgParts[1])
	} else {
		msg = fmt.Sprintf("%s, %s, %s", msgParts[0], msgParts[1], msgParts[2])
	}

	if len(updatedIDs) > 0 && s.notifier != nil {
		if err := s.notifier.SendSSE(ctx, clientCode, updatedIDs, "user.status_changed"); err != nil {
			slog.WarnContext(ctx, "update user status: sse push failed", "error", err)
		}
	}

	return userDto.BulkStatusResponse{
		Results: result.Results,
	}, msg, nil
}
