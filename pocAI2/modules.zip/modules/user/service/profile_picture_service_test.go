package service

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"net/textproto"
	"testing"

	"github.com/stretchr/testify/require"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	fileManagerClient "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/file_manager_service/client"
	coreDb "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/db"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

type fileManagerCapture struct {
	status       int
	uploads      int
	serviceToken string
	clientID     string
	userID       string
	fields       map[string]string
	filename     string
	contentType  string
	content      []byte
}

func newFakeFileManager(t *testing.T, status int) (*httptest.Server, *fileManagerCapture) {
	t.Helper()
	capture := &fileManagerCapture{status: status}

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		capture.uploads++
		capture.serviceToken = r.Header.Get("X-Service-Token")
		capture.clientID = r.Header.Get("X-Client-ID")
		capture.userID = r.Header.Get("X-User-ID")

		if err := r.ParseMultipartForm(2 << 20); err != nil {
			t.Errorf("parse multipart: %v", err)
			w.WriteHeader(http.StatusBadRequest)
			return
		}
		capture.fields = map[string]string{}
		for key, values := range r.MultipartForm.Value {
			capture.fields[key] = values[0]
		}

		file, header, err := r.FormFile("files")
		if err != nil {
			t.Errorf("form file: %v", err)
			w.WriteHeader(http.StatusBadRequest)
			return
		}
		defer file.Close()
		capture.filename = header.Filename
		capture.contentType = header.Header.Get("Content-Type")
		capture.content, _ = io.ReadAll(file)

		if capture.status != http.StatusCreated {
			w.WriteHeader(capture.status)
			_, _ = w.Write([]byte(`{"message":"upload failed"}`))
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		_ = json.NewEncoder(w).Encode(map[string]any{
			"message": "ok",
			"data": map[string]any{
				"_id":        "777",
				"publicPath": "encrypted-token",
				"fileName":   header.Filename,
			},
		})
	}))
	t.Cleanup(srv.Close)

	return srv, capture
}

func multipartFileHeader(t *testing.T, field, filename, contentType string, content []byte) *multipart.FileHeader {
	t.Helper()

	var body bytes.Buffer
	writer := multipart.NewWriter(&body)
	header := make(textproto.MIMEHeader)
	header.Set("Content-Disposition", fmt.Sprintf(`form-data; name=%q; filename=%q`, field, filename))
	header.Set("Content-Type", contentType)

	part, err := writer.CreatePart(header)
	require.NoError(t, err)
	_, err = part.Write(content)
	require.NoError(t, err)
	require.NoError(t, writer.Close())

	form, err := multipart.NewReader(&body, writer.Boundary()).ReadForm(int64(len(content)) + 1024)
	require.NoError(t, err)
	require.NotEmpty(t, form.File[field])

	return form.File[field][0]
}

func TestUserService_CreateUploadsProfilePicture(t *testing.T) {
	coreDb.InitSnowflake()
	srv, capture := newFakeFileManager(t, http.StatusCreated)

	temporalSvc, mockClient := mockTemporal(constant.WorkflowCreateUser, nil, func(resultPtr interface{}) {
		resultPtr.(*workflow.CreateUserWorkflowResult).ID = "12345"
	})
	svc := newSvc(temporalSvc, nil)
	svc.fileManager = fileManagerClient.NewFileManagerClient(srv.URL, "secret")

	id, err := svc.Create(context.Background(), CreateUserParam{
		ClientCode:          "testclient",
		CurrentUserID:       ptr(int64(9)),
		CurrentUserFullName: "Admin",
		FirstName:           "Jane",
		LastName:            "Doe",
		Email:               "new@example.com",
		DivisionID:          1,
		Access:              []string{"global_settings"},
		ProfilePicture:      multipartFileHeader(t, "profilePicture", "photo.png", "image/png", []byte("png-bytes")),
	})
	require.NoError(t, err)
	require.Equal(t, "12345", id)

	require.Equal(t, 1, capture.uploads)
	require.Equal(t, "secret", capture.serviceToken)
	require.Equal(t, "testclient", capture.clientID)
	require.Equal(t, "9", capture.userID)
	require.Equal(t, "user", capture.fields["folderName"])
	require.Equal(t, "global_settings", capture.fields["type"])
	require.Equal(t, "users", capture.fields["module"])
	require.Equal(t, "web", capture.fields["platform"])
	require.Equal(t, "9", capture.fields["modifiedById"])
	require.NotContains(t, capture.fields, "userId")
	require.Equal(t, "photo.png", capture.filename)
	require.Equal(t, "image/png", capture.contentType)
	require.Equal(t, []byte("png-bytes"), capture.content)

	param, ok := mockClient.CalledArgs[1].(workflow.CreateUserWorkflowParam)
	require.True(t, ok)
	require.NotNil(t, param.ProfilePictureFileID)
	require.Equal(t, int64(777), *param.ProfilePictureFileID)
	require.NotNil(t, param.ProfilePicture)
	require.Equal(t, "encrypted-token", *param.ProfilePicture)
}

func TestUserService_UpdateUploadsProfilePicture(t *testing.T) {
	srv, capture := newFakeFileManager(t, http.StatusCreated)

	temporalSvc, mockClient := mockTemporal(constant.WorkflowUpdateUser, nil, nil)
	svc := newSvc(temporalSvc, nil)
	svc.fileManager = fileManagerClient.NewFileManagerClient(srv.URL, "secret")

	err := svc.Update(context.Background(), UpdateUserParam{
		ClientCode:          "testclient",
		UserID:              42,
		CurrentUserID:       ptr(int64(9)),
		CurrentUserFullName: "Admin",
		FirstName:           "Johnny",
		LastName:            "Doe",
		Email:               "user1@example.com",
		DivisionID:          1,
		Access:              []string{"global_settings"},
		ProfilePicture:      multipartFileHeader(t, "profilePicture", "photo.jpg", "image/jpeg", []byte("jpg-bytes")),
	})
	require.NoError(t, err)

	require.Equal(t, 1, capture.uploads)
	require.Equal(t, "42", capture.fields["userId"])
	require.Equal(t, "9", capture.fields["modifiedById"])

	param, ok := mockClient.CalledArgs[1].(workflow.UpdateUserWorkflowParam)
	require.True(t, ok)
	require.NotNil(t, param.ProfilePictureFileID)
	require.Equal(t, int64(777), *param.ProfilePictureFileID)
	require.NotNil(t, param.ProfilePicture)
	require.Equal(t, "encrypted-token", *param.ProfilePicture)
}

func TestUserService_CreateAbortsWhenUploadFails(t *testing.T) {
	coreDb.InitSnowflake()
	srv, capture := newFakeFileManager(t, http.StatusInternalServerError)

	temporalSvc, mockClient := mockTemporal(constant.WorkflowCreateUser, nil, nil)
	svc := newSvc(temporalSvc, nil)
	svc.fileManager = fileManagerClient.NewFileManagerClient(srv.URL, "secret")

	_, err := svc.Create(context.Background(), CreateUserParam{
		ClientCode:          "testclient",
		CurrentUserID:       ptr(int64(9)),
		CurrentUserFullName: "Admin",
		FirstName:           "Jane",
		LastName:            "Doe",
		Email:               "new@example.com",
		DivisionID:          1,
		Access:              []string{"global_settings"},
		ProfilePicture:      multipartFileHeader(t, "profilePicture", "photo.png", "image/png", []byte("png-bytes")),
	})
	require.Error(t, err)

	require.Equal(t, 1, capture.uploads)
	require.Empty(t, mockClient.CalledArgs)
}

func TestUserService_CreateRejectsInvalidProfilePicture(t *testing.T) {
	cases := []struct {
		name        string
		filename    string
		contentType string
		content     []byte
	}{
		{
			name:        "gif is rejected",
			filename:    "photo.gif",
			contentType: "image/gif",
			content:     []byte("gif-bytes"),
		},
		{
			name:        "picture over 1 MB is rejected",
			filename:    "photo.png",
			contentType: "image/png",
			content:     bytes.Repeat([]byte("a"), constant.MaxProfilePictureBytes+1),
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			coreDb.InitSnowflake()
			srv, capture := newFakeFileManager(t, http.StatusCreated)

			temporalSvc, mockClient := mockTemporal(constant.WorkflowCreateUser, nil, nil)
			svc := newSvc(temporalSvc, nil)
			svc.fileManager = fileManagerClient.NewFileManagerClient(srv.URL, "secret")

			_, err := svc.Create(context.Background(), CreateUserParam{
				ClientCode:          "testclient",
				CurrentUserID:       ptr(int64(9)),
				CurrentUserFullName: "Admin",
				FirstName:           "Jane",
				LastName:            "Doe",
				Email:               "new@example.com",
				DivisionID:          1,
				Access:              []string{"global_settings"},
				ProfilePicture:      multipartFileHeader(t, "profilePicture", tc.filename, tc.contentType, tc.content),
			})
			require.Error(t, err)
			require.Equal(t, 422, coreEntity.ToHttpError(err).Code)

			require.Equal(t, 0, capture.uploads)
			require.Empty(t, mockClient.CalledArgs)
		})
	}
}
