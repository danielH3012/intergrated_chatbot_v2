package service

import (
	"context"
	"errors"
	"log/slog"

	"github.com/jackc/pgx/v5"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func (s *UserService) GetDetail(ctx context.Context, clientCode string, id int64) (*userDto.UserDetailItem, error) {
	res, err := s.repo.GetDetail(ctx, s.tenantSvc(clientCode), id)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, coreEntity.NotFound(constant.MsgUserNotFound)
		}
		slog.ErrorContext(ctx, "UserService.GetDetail", "err", err)
		return nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	return res, nil
}
