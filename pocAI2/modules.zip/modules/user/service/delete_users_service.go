package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

func (s *UserService) Delete(ctx context.Context, clientCode string, req userDto.DeleteUsersBody, currentUserID int64, currentUserFullName string) ([]userDto.DeleteUserResult, error) {
	result := &workflow.DeleteUsersWorkflowResult{}

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowDeleteUsers,
		TemporalService: s.temporalSvc,
		Param: workflow.DeleteUsersWorkflowParam{
			ClientCode:                  clientCode,
			IDs:                         req.IDs,
			CurrentUserID:               currentUserID,
			CurrentUserFullName:         currentUserFullName,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("user-delete-%s", clientCode), // temporal_helper adds UUID
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1, // Let failures surface
		},
		WorkflowIDReusePolicy: enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
	})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.Delete: ExecuteWorkflow", "err", httpErr)
		return nil, httpErr
	}

	return result.Results, nil
}
