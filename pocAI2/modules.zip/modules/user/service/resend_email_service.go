package service

import (
	"context"
	"fmt"
	"log/slog"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
)

func (s *UserService) ResendEmailBulk(ctx context.Context, clientCode string, req userDto.ResendEmailBody, currentUserID int64, currentUserFullName string) (userDto.ResendResponse, string, error) {
	product := req.Product
	if product == "" {
		product = string(model.ProductGlobalSettings)
	}

	result := &workflow.ResendEmailWorkflowResult{}

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowResendEmail,
		TemporalService: s.temporalSvc,
		Param: workflow.ResendEmailWorkflowParam{
			ClientCode:                  clientCode,
			IDs:                         req.IDs,
			CurrentUserID:               currentUserID,
			CurrentUserName:             currentUserFullName,
			Product:                     product,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.ResendEmailBulk: ExecuteWorkflow", "err", httpErr)
		// We could try to return partial results if available, but ExecuteWorkflow blocks until completion/failure.
		// If it fails midway, we can't easily retrieve partial results unless we return them via a query or side channel.
		// For now, return the error.
		return userDto.ResendResponse{}, "", httpErr
	}

	sentCount := 0
	skippedCount := 0
	blockedCount := 0
	for _, r := range result.Results {
		switch r.Status {
		case "sent":
			sentCount++
		case "skipped":
			skippedCount++
		case "blocked":
			blockedCount++
		}
	}

	var msgParts []string
	if sentCount > 0 || (skippedCount == 0 && blockedCount == 0) {
		msgParts = append(msgParts, fmt.Sprintf("%d sent", sentCount))
	}
	if skippedCount > 0 {
		msgParts = append(msgParts, fmt.Sprintf("%d skipped", skippedCount))
	}
	if blockedCount > 0 {
		msgParts = append(msgParts, fmt.Sprintf("%d blocked", blockedCount))
	}
	msg := strings.Join(msgParts, ", ")

	// Check if it was single id and returned cooldown
	if len(req.IDs) == 1 && len(result.Results) > 0 && result.Results[0].Status == "skipped" && result.Results[0].Reason != nil && *result.Results[0].Reason == "cooldown" {
		retrySec := 60
		if result.Results[0].RetryAfterSeconds != nil {
			retrySec = *result.Results[0].RetryAfterSeconds
		}
		return userDto.ResendResponse{}, "", fmt.Errorf("cooldown:%d", retrySec)
	}

	return userDto.ResendResponse{
		Results: result.Results,
	}, msg, nil
}
