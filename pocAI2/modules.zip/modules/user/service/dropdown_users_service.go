package service

import (
	"context"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
)

func (s *UserService) Dropdown(ctx context.Context, clientCode string, req dto.UserDropdownQuery) (dto.UserDropdownResponse, error) {
	svc := s.tenantSvc(clientCode)
	return s.repo.Dropdown(ctx, svc, req)
}
