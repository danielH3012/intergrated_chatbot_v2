package service

import (
	"context"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// ExportResult is the rendered file: bytes ready to stream, plus the
// content type and attachment filename the handler echoes.
type ExportResult = helper.ExportResult

func (s *UserService) Export(ctx context.Context, clientCode string, req userDto.UserExportBody) (*ExportResult, error) {
	// Query list for export
	req.Page = 0
	req.Limit = 0
	resList, err := s.List(ctx, clientCode, 0, req.UserListBody)
	if err != nil {
		return nil, err
	}

	return helper.Export(resList.Data, helper.ExportParam{
		Format:       req.Format,
		FallbackName: "User",
	})
}
