package service

import (
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/helper"
)

// ProductModule maps the product string/enum to enum.ModuleAccess.
func ProductModule(product model.Product) (enum.ModuleAccess, bool) {
	switch product {
	case model.ProductGlobalSettings:
		return enum.ModuleAccessGlobalSettings, true
	case model.ProductAdminConsole:
		return enum.ModuleAccessAdminConsole, true
	case model.ProductFixedAsset:
		return enum.ModuleAccessFixedAsset, true
	default:
		return "", false
	}
}

func (s *UserService) ProductDropdown(
	ctx context.Context,
	clientCode string,
	product model.Product,
	roles tsMiddleware.UserAccessCache,
	req dto.ProductUserDropdownQuery,
) (dto.UserDropdownResponse, error) {
	req.Product = product

	switch product {
	case model.ProductAdminConsole:
		isAll := roles.IsTotalControl(enum.ModuleAccessAdminConsole) ||
			roles.IsReadOnly(enum.ModuleAccessAdminConsole) ||
			roles.AdminConsoleSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].View
		req.IsAllGroups = isAll
		if !isAll {
			req.AllowedGroupIDs = extractGroupIDs(roles.AdminConsoleSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].View)
		}
	case model.ProductFixedAsset:
		isAll := roles.IsTotalControl(enum.ModuleAccessFixedAsset) ||
			roles.IsReadOnly(enum.ModuleAccessFixedAsset) ||
			roles.FixedAssetSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].View
		req.IsAllGroups = isAll
		if !isAll {
			req.AllowedGroupIDs = extractGroupIDs(roles.FixedAssetSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].View)
		}
	default: // Global Settings
		req.IsAllGroups = true
	}

	svc := s.tenantSvc(clientCode)
	return s.repo.ProductDropdown(ctx, svc, req)
}

func extractGroupIDs(raw []string) []int64 {
	var ids []int64
	seen := make(map[int64]bool)
	for _, s := range raw {
		if id, err := strconv.ParseInt(s, 10, 64); err == nil && !seen[id] {
			seen[id] = true
			ids = append(ids, id)
		}
	}
	return ids
}

func (s *UserService) AdminConsoleList(
	ctx context.Context,
	clientCode string,
	actorID int64,
	roles tsMiddleware.UserAccessCache,
	req dto.AcUserListBody,
) (*dto.AcUserListData, error) {
	isActorTC := roles.IsTotalControl(enum.ModuleAccessAdminConsole)
	isActorRO := roles.IsReadOnly(enum.ModuleAccessAdminConsole)

	isAll := isActorTC || isActorRO || roles.AdminConsoleSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].View
	req.IsAllGroups = isAll

	var allowedGroupIDs []int64
	if !isAll {
		allowedGroupIDs = extractGroupIDs(roles.AdminConsoleSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].View)
		req.AllowedGroupIDs = allowedGroupIDs
	}
	req.ActorID = actorID

	// Sidebar Group filter validation (403 if requested group is outside caller scope)
	if !isAll && len(req.Group) > 0 {
		allowedMap := make(map[int64]bool, len(allowedGroupIDs))
		for _, id := range allowedGroupIDs {
			allowedMap[id] = true
		}
		for _, g := range req.Group {
			gid, err := strconv.ParseInt(g, 10, 64)
			if err != nil || !allowedMap[gid] {
				return nil, coreEntity.Forbidden("Group filter contains groups outside actor scope")
			}
		}
	}

	svc := s.tenantSvc(clientCode)
	items, totalRecords, err := s.repo.AdminConsoleList(ctx, svc, req)
	if err != nil {
		return nil, err
	}

	hasGlobalEdit := roles.AdminConsoleSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].Edit
	groupRolesEdit := extractGroupIDs(roles.AdminConsoleSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].Edit)
	groupEditMap := make(map[int64]bool, len(groupRolesEdit))
	for _, gid := range groupRolesEdit {
		groupEditMap[gid] = true
	}

	for i := range items {
		targetID, _ := strconv.ParseInt(items[i].ID, 10, 64)
		items[i].SystemPermissions.ManageUserAndRole.Create = false
		items[i].SystemPermissions.ManageUserAndRole.Read = true
		items[i].SystemPermissions.ManageUserAndRole.Delete = false

		canUpdate := true
		if items[i].IsDefault {
			canUpdate = false
		} else if targetID == actorID {
			canUpdate = false
		} else if isActorRO {
			canUpdate = false
		} else if items[i].AccessLevel != nil && (*items[i].AccessLevel == "total_control" || *items[i].AccessLevel == "read_only") && !isActorTC {
			canUpdate = false
		} else if isActorTC || hasGlobalEdit {
			canUpdate = true
		} else {
			if len(groupEditMap) == 0 {
				canUpdate = false
			} else {
				hasOverlap := false
				if items[i].TargetGroupIDsStr != nil && *items[i].TargetGroupIDsStr != "" {
					gids := strings.Split(*items[i].TargetGroupIDsStr, ",")
					for _, g := range gids {
						if gid, err := strconv.ParseInt(strings.TrimSpace(g), 10, 64); err == nil {
							if groupEditMap[gid] {
								hasOverlap = true
								break
							}
						}
					}
				}
				canUpdate = hasOverlap
			}
		}
		items[i].SystemPermissions.ManageUserAndRole.Update = canUpdate
	}

	return &dto.AcUserListData{
		TotalRecords:    totalRecords,
		EntitySuspended: false,
		Data:            items,
	}, nil
}

func (s *UserService) AdminConsoleExport(
	ctx context.Context,
	clientCode string,
	actorID int64,
	roles tsMiddleware.UserAccessCache,
	req dto.AcUserExportBody,
) (*helper.ExportResult, error) {
	req.Page = 0
	req.Limit = 0

	res, err := s.AdminConsoleList(ctx, clientCode, actorID, roles, req.AcUserListBody)
	if err != nil {
		return nil, err
	}

	return helper.Export(res.Data, helper.ExportParam{
		Format:       req.Format,
		FallbackName: "Users",
	})
}

// AdminConsoleRoleOptions contains the 15 fixed roles (7 Global + 8 Group) for Admin Console.
var AdminConsoleRoleOptions = []dto.OptionItem{
	{Label: "Manage active client", Value: "Manage active client"},
	{Label: "Manage allocation", Value: "Manage allocation"},
	{Label: "Manage archived client", Value: "Manage archived client"},
	{Label: "Manage device master data", Value: "Manage device master data"},
	{Label: "Manage distributor", Value: "Manage distributor"},
	{Label: "Manage group", Value: "Manage group"},
	{Label: "Manage hardware stock", Value: "Manage hardware stock"},
	{Label: "Manage language", Value: "Manage language"},
	{Label: "Manage partner", Value: "Manage partner"},
	{Label: "Manage plans & licensing", Value: "Manage plans & licensing"},
	{Label: "Manage preload", Value: "Manage preload"},
	{Label: "Manage presetup", Value: "Manage presetup"},
	{Label: "Manage TAG stock", Value: "Manage TAG stock"},
	{Label: "Manage user and role", Value: "Manage user and role"},
	{Label: "Manage wallet & pricing", Value: "Manage wallet & pricing"},
}

func (s *UserService) AdminConsoleOptions(
	ctx context.Context,
	clientCode string,
	roles tsMiddleware.UserAccessCache,
	req dto.AcUserOptionsBody,
) (dto.AcUserOptionsResponse, error) {
	isActorTC := roles.IsTotalControl(enum.ModuleAccessAdminConsole)
	isActorRO := roles.IsReadOnly(enum.ModuleAccessAdminConsole)

	isAll := isActorTC || isActorRO || roles.AdminConsoleSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].View
	req.IsAllGroups = isAll

	var allowedGroupIDs []int64
	if !isAll {
		allowedGroupIDs = extractGroupIDs(roles.AdminConsoleSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].View)
		req.AllowedGroupIDs = allowedGroupIDs
	}

	// Group filter validation (403 if requested group is outside caller scope)
	if !isAll && len(req.Group) > 0 {
		allowedMap := make(map[int64]bool, len(allowedGroupIDs))
		for _, id := range allowedGroupIDs {
			allowedMap[id] = true
		}
		for _, g := range req.Group {
			gid, err := strconv.ParseInt(g, 10, 64)
			if err != nil || !allowedMap[gid] {
				return dto.AcUserOptionsResponse{}, coreEntity.Forbidden("Group filter contains groups outside actor scope")
			}
		}
	}

	if !isAll && len(allowedGroupIDs) == 0 {
		var resp dto.AcUserOptionsResponse
		if req.RoleOptions {
			resp.RoleOptions = AdminConsoleRoleOptions
		}
		return resp, nil
	}

	svc := s.tenantSvc(clientCode)
	res, err := s.repo.AdminConsoleOptions(ctx, svc, req)
	if err != nil {
		return dto.AcUserOptionsResponse{}, err
	}

	if req.RoleOptions {
		res.RoleOptions = AdminConsoleRoleOptions
	}

	return res, nil
}

var adminConsoleGlobalRolesCatalog = []struct {
	Key  string
	Name string
}{
	{string(model.SystemRoleKeyManageDeviceMasterData), string(model.SystemRoleNameManageDeviceMasterData)},
	{string(model.SystemRoleKeyManageTAGStock), string(model.SystemRoleNameManageTAGStock)},
	{string(model.SystemRoleKeyManageHardwareStock), string(model.SystemRoleNameManageHardwareStock)},
	{string(model.SystemRoleKeyManageLanguage), string(model.SystemRoleNameManageLanguage)},
	{string(model.SystemRoleKeyManagePresetup), string(model.SystemRoleNameManagePresetup)},
	{string(model.SystemRoleKeyManagePreload), string(model.SystemRoleNameManagePreload)},
	{string(model.SystemRoleKeyManagePlansAndLicensing), string(model.SystemRoleNameManagePlansAndLicensing)},
}

var adminConsoleGroupRolesCatalog = []struct {
	Key  string
	Name string
}{
	{string(model.SystemRoleKeyManageDistributor), string(model.SystemRoleNameManageDistributor)},
	{string(model.SystemRoleKeyManagePartner), string(model.SystemRoleNameManagePartner)},
	{string(model.SystemRoleKeyManageGroup), string(model.SystemRoleNameManageGroup)},
	{string(model.SystemRoleKeyManageUserAndRole), string(model.SystemRoleNameManageUserAndRole)},
	{string(model.SystemRoleKeyManageActiveClient), string(model.SystemRoleNameManageActiveClient)},
	{string(model.SystemRoleKeyManageArchivedClient), string(model.SystemRoleNameManageArchivedClient)},
	{string(model.SystemRoleKeyManageAllocation), string(model.SystemRoleNameManageAllocation)},
	{string(model.SystemRoleKeyManageWalletAndPricing), string(model.SystemRoleNameManageWalletAndPricing)},
}

func (s *UserService) AdminConsoleUserActiveRoles(
	ctx context.Context,
	clientCode string,
	actorID int64,
	roles tsMiddleware.UserAccessCache,
	targetID int64,
) (*dto.AcUserActiveRolesResponse, error) {
	isActorTC := roles.IsTotalControl(enum.ModuleAccessAdminConsole)
	isActorRO := roles.IsReadOnly(enum.ModuleAccessAdminConsole)
	isAll := isActorTC || isActorRO || roles.AdminConsoleSystemRole.GlobalRole[enum.SystemRoleKeyManageUserAndRole].View

	var allowedGroupIDs []int64
	if !isAll {
		allowedGroupIDs = extractGroupIDs(roles.AdminConsoleSystemRole.GroupRoles[enum.SystemRoleKeyManageUserAndRole].View)
		if len(allowedGroupIDs) == 0 {
			return nil, coreEntity.Forbidden("Target user is outside actor scope")
		}
	}

	svc := s.tenantSvc(clientCode)
	exists, accessLevel, targetGroupIDs, err := s.repo.CheckAdminConsoleUserExists(ctx, svc, targetID)
	if err != nil {
		return nil, err
	}
	if !exists {
		return nil, coreEntity.NotFound("User not found")
	}

	if !isAll {
		allowedMap := make(map[int64]bool, len(allowedGroupIDs))
		for _, id := range allowedGroupIDs {
			allowedMap[id] = true
		}
		hasOverlap := false
		for _, gid := range targetGroupIDs {
			if allowedMap[gid] {
				hasOverlap = true
				break
			}
		}
		if !hasOverlap {
			return nil, coreEntity.Forbidden("Target user is outside actor scope")
		}
	}

	rawRows, err := s.repo.GetAdminConsoleUserActiveRoles(ctx, svc, targetID)
	if err != nil {
		return nil, err
	}

	globalRoleNameMap := make(map[string]string, len(adminConsoleGlobalRolesCatalog))
	globalRoleOrderMap := make(map[string]int, len(adminConsoleGlobalRolesCatalog))
	for i, c := range adminConsoleGlobalRolesCatalog {
		globalRoleNameMap[c.Key] = c.Name
		globalRoleOrderMap[c.Key] = i
	}

	groupRoleNameMap := make(map[string]string, len(adminConsoleGroupRolesCatalog))
	groupRoleOrderMap := make(map[string]int, len(adminConsoleGroupRolesCatalog))
	for i, c := range adminConsoleGroupRolesCatalog {
		groupRoleNameMap[c.Key] = c.Name
		groupRoleOrderMap[c.Key] = i
	}

	var globalRoles []string
	seenGlobalKeys := make(map[string]bool)

	groupRoleGroupsMap := make(map[string][]string)
	seenGroupMap := make(map[string]map[string]bool)

	for _, row := range rawRows {
		if row.ScopeLevel == "global" {
			if seenGlobalKeys[row.Key] {
				continue
			}
			seenGlobalKeys[row.Key] = true
			name, ok := globalRoleNameMap[row.Key]
			if !ok {
				if gName, ok := groupRoleNameMap[row.Key]; ok {
					name = gName
				} else {
					name = row.Key
				}
			}
			globalRoles = append(globalRoles, name)
		} else if row.ScopeLevel == "group" {
			gName := ""
			if row.AdminConsoleGroupName != nil && *row.AdminConsoleGroupName != "" {
				gName = *row.AdminConsoleGroupName
			} else if row.AdminConsoleGroupID != nil {
				gName = fmt.Sprintf("Group %d", *row.AdminConsoleGroupID)
			}
			if gName == "" {
				continue
			}

			if seenGroupMap[row.Key] == nil {
				seenGroupMap[row.Key] = make(map[string]bool)
			}
			if !seenGroupMap[row.Key][gName] {
				seenGroupMap[row.Key][gName] = true
				groupRoleGroupsMap[row.Key] = append(groupRoleGroupsMap[row.Key], gName)
			}
		}
	}

	// Sort global roles by catalog order
	globalCatalogOrder := make(map[string]int, len(adminConsoleGlobalRolesCatalog))
	for i, c := range adminConsoleGlobalRolesCatalog {
		globalCatalogOrder[c.Name] = i
	}
	sort.Slice(globalRoles, func(i, j int) bool {
		ordI, okI := globalCatalogOrder[globalRoles[i]]
		ordJ, okJ := globalCatalogOrder[globalRoles[j]]
		if okI && okJ {
			return ordI < ordJ
		}
		if okI {
			return true
		}
		if okJ {
			return false
		}
		return globalRoles[i] < globalRoles[j]
	})

	// Format and consolidate group roles
	var groupRoles []dto.AcUserActiveRoleGroup
	totalGroupAssignments := 0

	for key, gNames := range groupRoleGroupsMap {
		// Sort group names alphabetically (case-insensitive)
		sort.Slice(gNames, func(i, j int) bool {
			return strings.ToLower(gNames[i]) < strings.ToLower(gNames[j])
		})

		rName, ok := groupRoleNameMap[key]
		if !ok {
			rName = key
		}

		count := len(gNames)
		totalGroupAssignments += count

		groupRoles = append(groupRoles, dto.AcUserActiveRoleGroup{
			Role:       rName,
			GroupCount: count,
			Groups:     gNames,
		})
	}

	// Sort group roles by catalog order
	groupCatalogOrder := make(map[string]int, len(adminConsoleGroupRolesCatalog))
	for i, c := range adminConsoleGroupRolesCatalog {
		groupCatalogOrder[c.Name] = i
	}
	sort.Slice(groupRoles, func(i, j int) bool {
		ordI, okI := groupCatalogOrder[groupRoles[i].Role]
		ordJ, okJ := groupCatalogOrder[groupRoles[j].Role]
		if okI && okJ {
			return ordI < ordJ
		}
		if okI {
			return true
		}
		if okJ {
			return false
		}
		return groupRoles[i].Role < groupRoles[j].Role
	})

	if globalRoles == nil {
		globalRoles = []string{}
	}
	if groupRoles == nil {
		groupRoles = []dto.AcUserActiveRoleGroup{}
	}

	return &dto.AcUserActiveRolesResponse{
		ActiveRoles: len(globalRoles) + totalGroupAssignments,
		AccessLevel: accessLevel,
		GlobalRoles: globalRoles,
		GroupRoles:  groupRoles,
	}, nil
}
