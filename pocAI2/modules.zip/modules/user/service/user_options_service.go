package service

import (
	"context"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

func (s *UserService) GenerateOptions(ctx context.Context, clientCode string, req userDto.UserOptionsBody) (userDto.UserOptionsResponse, error) {
	res, err := s.repo.GenerateOptions(ctx, s.tenantSvc(clientCode), req)
	if err != nil {
		slog.ErrorContext(ctx, "UserService.GenerateOptions", "err", err)
		return userDto.UserOptionsResponse{}, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	return res, nil
}
