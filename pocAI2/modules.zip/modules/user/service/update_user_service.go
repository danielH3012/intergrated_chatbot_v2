package service

import (
	"context"
	"fmt"
	"log/slog"
	"mime/multipart"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"
)

type UpdateUserParam struct {
	ClientCode          string
	UserID              int64
	CurrentUserID       *int64
	CurrentUserFullName string
	FirstName           string
	LastName            string
	Email               string
	EmployeeID          *string
	PositionID          *int64
	DivisionID          int64
	TagID               *int64
	ActivePeriodUntil   *int64
	Access              []string
	CustomFields        map[string]any
	ProfilePicture      *multipart.FileHeader
}

func (s *UserService) Update(ctx context.Context, param UpdateUserParam) error {
	// TODO: Add Client Access Validation
	// TODO: Add TAG Validation

	tenantSvc := s.tenantSvc(param.ClientCode)
	divExist, posExist, err := s.repo.CheckDivisionAndPositionExist(ctx, tenantSvc, param.DivisionID, param.PositionID)
	if err != nil {
		slog.ErrorContext(ctx, "UserService.Update: CheckDivisionAndPositionExist", "err", err)
		return coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if !divExist {
		return &coreEntity.HttpError{
			Code:    422,
			Message: "This division no longer exists. Please select another.",
			Data:    map[string]any{"field": "divisionId"},
		}
	}
	if !posExist {
		return &coreEntity.HttpError{
			Code:    422,
			Message: "This position no longer exists. Please select another.",
			Data:    map[string]any{"field": "positionId"},
		}
	}

	if len(param.Access) == 0 {
		return &coreEntity.HttpError{
			Code:    400,
			Message: "Access must not be empty",
			Data: map[string]any{
				"field": "access",
			},
		}
	}
	for _, acc := range param.Access {
		p := model.Product(acc)
		if p != model.ProductGlobalSettings && p != model.ProductAdminConsole && p != model.ProductFixedAsset {
			return coreEntity.BadRequest(fmt.Sprintf("Invalid access: %s", acc))
		}
	}

	if param.ActivePeriodUntil != nil {
		activeUntil := time.UnixMilli(*param.ActivePeriodUntil)
		if activeUntil.Before(time.Now().UTC().Truncate(24 * time.Hour)) {
			return &coreEntity.HttpError{
				Code:    422,
				Message: "Please select a future date.",
				Data: map[string]any{
					"field": "activePeriodUntil",
				},
			}
		}
	}

	var currentUserID int64
	if param.CurrentUserID != nil {
		currentUserID = *param.CurrentUserID
	}

	fileID, fileURL, err := s.uploadProfilePicture(ctx, param.ClientCode, currentUserID, param.UserID, param.ProfilePicture)
	if err != nil {
		return err
	}

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowUpdateUser,
		TemporalService: s.temporalSvc,
		Param: workflow.UpdateUserWorkflowParam{
			ClientCode:                  param.ClientCode,
			UserID:                      param.UserID,
			CurrentUserID:               currentUserID,
			CurrentUserFullName:         param.CurrentUserFullName,
			FirstName:                   param.FirstName,
			LastName:                    param.LastName,
			Email:                       param.Email,
			EmployeeID:                  param.EmployeeID,
			PositionID:                  param.PositionID,
			DivisionID:                  param.DivisionID,
			TagID:                       param.TagID,
			ActivePeriodUntil:           param.ActivePeriodUntil,
			Access:                      param.Access,
			CustomFields:                param.CustomFields,
			ProfilePictureFileID:        fileID,
			ProfilePicture:              fileURL,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, (*any)(nil), client.StartWorkflowOptions{
		ID: fmt.Sprintf("user-update-%s-%d", param.ClientCode, param.UserID),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1, // Let failures surface
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.Update: ExecuteWorkflow", "err", httpErr)
		return httpErr
	}

	return nil
}
