package service

import (
	"context"
	"strings"

	userDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/helper"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	"github.com/gofiber/fiber/v3"
)

func (s *UserService) CheckAvailability(ctx context.Context, clientCode string, req userDto.UserAvailabilityBody) (userDto.UserAvailabilityResponse, error) {
	var resp userDto.UserAvailabilityResponse

	if req.Email != nil {
		email := strings.TrimSpace(*req.Email)
		if email != "" {
			if helper.HasEmoji(email) {
				return resp, &coreEntity.HttpError{
					Code:    fiber.StatusUnprocessableEntity,
					Message: "Email contains invalid characters",
					Data:    map[string]any{"field": "email"},
				}
			}
			pubSvc := s.publicSvc()
			isUnique, err := s.repo.CheckEmailUniqueness(ctx, pubSvc, email)
			if err != nil {
				return resp, err
			}
			resp.Email.Available = &isUnique
		}
	}

	if req.EmployeeID != nil {
		empID := strings.TrimSpace(*req.EmployeeID)
		if empID != "" {
			if helper.HasEmoji(empID) {
				return resp, &coreEntity.HttpError{
					Code:    fiber.StatusUnprocessableEntity,
					Message: "Employee ID contains invalid characters",
					Data:    map[string]any{"field": "employeeId"},
				}
			}
			tenantSvc := s.tenantSvc(clientCode)
			isUnique, err := s.repo.CheckEmployeeIDUniqueness(ctx, tenantSvc, empID, nil)
			if err != nil {
				return resp, err
			}
			resp.EmployeeID.Available = &isUnique
		}
	}

	return resp, nil
}
