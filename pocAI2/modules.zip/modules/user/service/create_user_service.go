package service

import (
	"context"
	"fmt"
	"log/slog"
	"mime/multipart"
	"time"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"
	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/temporal"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

type CreateUserParam struct {
	ClientCode          string
	CurrentUserID       *int64
	CurrentUserFullName string
	FirstName           string
	LastName            string
	Email               string
	EmployeeID          *string
	PositionID          *int64
	DivisionID          int64
	TagID               *int64
	ActivePeriodUntil   *int64
	Access              []string
	CustomFields        map[string]any
	ProfilePicture      *multipart.FileHeader
}

func (s *UserService) Create(ctx context.Context, param CreateUserParam) (string, error) {
	// TODO: Add Client Access Validation
	// TODO: Add TAG Validation

	tenantSvc := s.tenantSvc(param.ClientCode)
	divExist, posExist, err := s.repo.CheckDivisionAndPositionExist(ctx, tenantSvc, param.DivisionID, param.PositionID)
	if err != nil {
		slog.ErrorContext(ctx, "UserService.Create: CheckDivisionAndPositionExist", "err", err)
		return "", coreEntity.InternalServerError(constant.MsgInternalServerError)
	}
	if !divExist {
		return "", &coreEntity.HttpError{
			Code:    422,
			Message: "This division no longer exists. Please select another.",
			Data:    map[string]any{"field": "divisionId"},
		}
	}
	if !posExist {
		return "", &coreEntity.HttpError{
			Code:    422,
			Message: "This position no longer exists. Please select another.",
			Data:    map[string]any{"field": "positionId"},
		}
	}

	if len(param.Access) == 0 {
		return "", &coreEntity.HttpError{
			Code:    400,
			Message: "Access must not be empty",
			Data: map[string]any{
				"field": "access",
			},
		}
	}
	for _, acc := range param.Access {
		p := model.Product(acc)
		if p != model.ProductGlobalSettings && p != model.ProductAdminConsole && p != model.ProductFixedAsset {
			return "", coreEntity.BadRequest(fmt.Sprintf("Invalid access: %s", acc))
		}
	}

	if param.ActivePeriodUntil != nil {
		activeUntil := time.UnixMilli(*param.ActivePeriodUntil)
		if activeUntil.Before(time.Now().UTC().Truncate(24 * time.Hour)) {
			return "", &coreEntity.HttpError{
				Code:    422,
				Message: "Please select a future date.",
				Data: map[string]any{
					"field": "activePeriodUntil",
				},
			}
		}
	}

	var currentUserID int64
	if param.CurrentUserID != nil {
		currentUserID = *param.CurrentUserID
	}

	fileID, fileURL, err := s.uploadProfilePicture(ctx, param.ClientCode, currentUserID, 0, param.ProfilePicture)
	if err != nil {
		return "", err
	}

	result := &workflow.CreateUserWorkflowResult{}

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowCreateUser,
		TemporalService: s.temporalSvc,
		Param: workflow.CreateUserWorkflowParam{
			ClientCode:                  param.ClientCode,
			CurrentUserID:               currentUserID,
			CurrentUserFullName:         param.CurrentUserFullName,
			FirstName:                   param.FirstName,
			LastName:                    param.LastName,
			Email:                       param.Email,
			EmployeeID:                  param.EmployeeID,
			PositionID:                  param.PositionID,
			DivisionID:                  param.DivisionID,
			TagID:                       param.TagID,
			ActivePeriodUntil:           param.ActivePeriodUntil,
			Access:                      param.Access,
			CustomFields:                param.CustomFields,
			ProfilePictureFileID:        fileID,
			ProfilePicture:              fileURL,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{
		ID: fmt.Sprintf("user-create-%s-%s", param.ClientCode, param.Email),
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 1, // Let failures surface
		},
		WorkflowIDReusePolicy:    enums.WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE,
		WorkflowIDConflictPolicy: enums.WORKFLOW_ID_CONFLICT_POLICY_FAIL,
	})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.Create: ExecuteWorkflow", "err", httpErr)
		return "", httpErr
	}

	return result.ID, nil
}
