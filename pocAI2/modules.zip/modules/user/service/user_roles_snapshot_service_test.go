package service

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	authDto "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/dto"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// fakeValkey is an in-memory stateful fake satisfying coreService.ValkeyServiceInterface (ADR 015).
type fakeValkey struct {
	coreService.ValkeyServiceInterface
	mu   sync.Mutex
	data map[string]string
}

func newFakeValkey() *fakeValkey {
	return &fakeValkey{data: make(map[string]string)}
}

func (f *fakeValkey) Get(_ context.Context, key string) (string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	val, ok := f.data[key]
	if !ok {
		return "", errors.New("valkey: key not found")
	}
	return val, nil
}

func (f *fakeValkey) Set(_ context.Context, key string, val any, _ time.Duration) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	switch v := val.(type) {
	case string:
		f.data[key] = v
	default:
		b, err := json.Marshal(v)
		if err != nil {
			return err
		}
		f.data[key] = string(b)
	}
	return nil
}

func (f *fakeValkey) Del(_ context.Context, keys ...string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	for _, k := range keys {
		delete(f.data, k)
	}
	return nil
}

// fakePermissionsRepo implements authRepository.UserPermissionsRepositor for unit tests.
type fakePermissionsRepo struct {
	mu            sync.Mutex
	rows          *authDto.UserPermissionRows
	err           error
	calledUserID  int64
	calledProduct *model.Product
	callCount     int
}

func (f *fakePermissionsRepo) GetPermissionRows(_ context.Context, _ coreService.PostgreSQLServicer, userID int64, product *model.Product) (*authDto.UserPermissionRows, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.callCount++
	f.calledUserID = userID
	f.calledProduct = product
	if f.err != nil {
		return nil, f.err
	}
	return f.rows, nil
}

func samplePermissionRows(userID int64) *authDto.UserPermissionRows {
	return &authDto.UserPermissionRows{
		Profile: authDto.UserProfileRow{
			ID:        userID,
			FirstName: "Budi",
			LastName:  "Santoso",
			Email:     "budi@example.com",
		},
		ModuleStatus: []model.UserModuleStatus{
			{ModuleKey: model.ProductGlobalSettings, IsActive: true},
			{ModuleKey: model.ProductFixedAsset, IsActive: true},
		},
		AccessLevels: []model.UserAccessLevel{
			{Product: model.ProductGlobalSettings, AccessLevel: model.AccessLevelTotalControl},
			{Product: model.ProductFixedAsset, AccessLevel: model.AccessLevelReadOnly},
		},
		SystemRoles: []model.UserSystemRole{
			{
				Product:          model.ProductGlobalSettings,
				Key:              model.SystemRoleKeyManageUserAndRole,
				ScopeLevel:       model.ScopeLevelGlobal,
				PermissionView:   true,
				PermissionCreate: true,
				PermissionUpdate: true,
				PermissionDelete: true,
			},
		},
	}
}

func TestRolesSnapshot_CacheHit(t *testing.T) {
	v := newFakeValkey()
	c := cache.NewWith(v)
	repo := &fakePermissionsRepo{}

	cachedSnapshot := tsMiddleware.UserAccessCache{
		ID:       42,
		FullName: "Cached User",
		ClientID: "client_acme",
		Email:    "cached@example.com",
		ModuleAccess: map[enum.ModuleAccess]tsMiddleware.ModuleFlags{
			enum.ModuleAccessGlobalSettings: {IsTotalControl: true},
		},
	}
	raw, err := json.Marshal(cachedSnapshot)
	require.NoError(t, err)
	_ = v.Set(context.Background(), tsMiddleware.UserRolesCacheKey("42"), string(raw), 0)

	svc := &UserService{
		perms: repo,
		cache: c,
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	got, err := svc.RolesSnapshot(context.Background(), 42, "client_acme")
	require.NoError(t, err)
	assert.Equal(t, cachedSnapshot.FullName, got.FullName)
	assert.Equal(t, cachedSnapshot.ID, got.ID)
	assert.True(t, got.IsTotalControl(enum.ModuleAccessGlobalSettings))
	assert.Equal(t, 0, repo.callCount, "repository must not be called on cache hit")
}

func TestRolesSnapshot_CacheMiss_Success(t *testing.T) {
	v := newFakeValkey()
	c := cache.NewWith(v)
	repo := &fakePermissionsRepo{rows: samplePermissionRows(42)}

	svc := &UserService{
		perms: repo,
		cache: c,
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	got, err := svc.RolesSnapshot(context.Background(), 42, "client_acme")
	require.NoError(t, err)
	assert.Equal(t, 42, got.ID)
	assert.Equal(t, "Budi Santoso", got.FullName)
	assert.Equal(t, "budi@example.com", got.Email)
	assert.Equal(t, "client_acme", got.ClientID)
	assert.True(t, got.IsTotalControl(enum.ModuleAccessGlobalSettings))
	assert.True(t, got.IsReadOnly(enum.ModuleAccessFixedAsset))
	assert.Equal(t, 1, repo.callCount)

	// Verify that Valkey cache was warmed
	cachedRaw, err := v.Get(context.Background(), tsMiddleware.UserRolesCacheKey("42"))
	require.NoError(t, err)
	var cached tsMiddleware.UserAccessCache
	require.NoError(t, json.Unmarshal([]byte(cachedRaw), &cached))
	assert.Equal(t, got.FullName, cached.FullName)
	assert.Equal(t, got.ID, cached.ID)
}

func TestRolesSnapshot_CacheMiss_NotFound(t *testing.T) {
	v := newFakeValkey()
	c := cache.NewWith(v)
	repo := &fakePermissionsRepo{err: coreEntity.NotFound("User not found")}

	svc := &UserService{
		perms: repo,
		cache: c,
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	got, err := svc.RolesSnapshot(context.Background(), 999, "client_acme")
	require.Error(t, err)
	assert.Equal(t, 0, got.ID)
	assert.Equal(t, 1, repo.callCount)

	// Verify nothing was written to cache
	_, err = v.Get(context.Background(), tsMiddleware.UserRolesCacheKey("999"))
	assert.Error(t, err)
}

func TestRolesSnapshot_CacheMiss_DBError(t *testing.T) {
	v := newFakeValkey()
	c := cache.NewWith(v)
	repo := &fakePermissionsRepo{err: coreEntity.InternalServerError("database connection failed")}

	svc := &UserService{
		perms: repo,
		cache: c,
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	got, err := svc.RolesSnapshot(context.Background(), 42, "client_acme")
	require.Error(t, err)
	assert.Equal(t, 0, got.ID)

	// Verify cache remains empty
	_, err = v.Get(context.Background(), tsMiddleware.UserRolesCacheKey("42"))
	assert.Error(t, err)
}

func TestRolesSnapshot_NilCache(t *testing.T) {
	repo := &fakePermissionsRepo{rows: samplePermissionRows(42)}

	svc := &UserService{
		perms: repo,
		cache: nil, // cache is nil / disabled
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	got, err := svc.RolesSnapshot(context.Background(), 42, "client_acme")
	require.NoError(t, err)
	assert.Equal(t, 42, got.ID)
	assert.Equal(t, "Budi Santoso", got.FullName)
	assert.Equal(t, 1, repo.callCount)
}

func TestFetchRolesSnapshot(t *testing.T) {
	repo := &fakePermissionsRepo{rows: samplePermissionRows(42)}
	svc := &UserService{
		perms: repo,
		cache: nil,
	}
	svc.SetServiceFactoryForTest(func(schema string) coreService.PostgreSQLServicer {
		return &coreService.FakePostgreSQLService{}
	})

	// Valid numeric string
	got, err := svc.FetchRolesSnapshot(context.Background(), "42", "client_acme")
	require.NoError(t, err)
	assert.Equal(t, 42, got.ID)

	// Invalid string
	_, err = svc.FetchRolesSnapshot(context.Background(), "not-a-number", "client_acme")
	require.Error(t, err)
	assert.Contains(t, err.Error(), fmt.Sprintf("invalid user id %q", "not-a-number"))
}
