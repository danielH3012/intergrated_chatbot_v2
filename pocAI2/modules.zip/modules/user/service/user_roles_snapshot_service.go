package service

import (
	"context"
	"strconv"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	authService "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/service"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
)

// RolesSnapshot builds the UserAccessCache ts-utils' LoadUserRoles serves to
// every consumer service, from this user's real rows.
//
// It fails closed: an error here means the caller cannot be authorized, and
// LoadUserRolesFrom turns that into a 401/503 rather than an empty snapshot
// that would read as "this user holds nothing" — or, as the placeholder this
// replaced did, as "this user holds everything".
func (s *UserService) RolesSnapshot(ctx context.Context, userID int64, clientCode string) (tsMiddleware.UserAccessCache, error) {
	key := tsMiddleware.UserRolesCacheKey(strconv.FormatInt(userID, 10))
	if hit, ok := cache.Get[tsMiddleware.UserAccessCache](ctx, s.cache, key); ok {
		return hit, nil
	}

	rows, err := s.perms.GetPermissionRows(ctx, s.tenantSvc(clientCode), userID, nil)
	if err != nil {
		return tsMiddleware.UserAccessCache{}, err
	}

	snapshot := authService.BuildSnapshot(rows, clientCode)
	if s.cache != nil {
		s.cache.Set(ctx, key, snapshot)
	}
	return snapshot, nil
}
