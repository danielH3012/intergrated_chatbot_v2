package service

import (
	"context"
	"fmt"
	"strconv"

	fileManagerClient "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/file_manager_service/client"
	notificationClient "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/notification_service/client"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/cache"
	authRepository "gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/auth/repository"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	coreService "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/service"
)

// UserService is a thin use-case layer. It has no framework knowledge — no
// fiber.Ctx below the handler layer.
type UserService struct {
	dbName      string
	repo        repository.UserRepositor
	perms       authRepository.UserPermissionsRepositor
	cache       *cache.Cache
	temporalSvc *coreService.TemporalService
	// makeSvc is the DB factory behind publicSvc/tenantSvc; swapped by
	// SetServiceFactoryForTest because the real one opens a pool and fatals
	// when Postgres is down.
	makeSvc     func(schema string) coreService.PostgreSQLServicer
	arTaskQueue string
	notifier    *notificationClient.NotificationClient
	fileManager *fileManagerClient.FileManagerClient
}

func NewUserService(
	dbName string,
	repo repository.UserRepositor,
	perms authRepository.UserPermissionsRepositor,
	c *cache.Cache,
	temporalSvc *coreService.TemporalService,
	arTaskQueue string,
	notifier *notificationClient.NotificationClient,
	fileManager *fileManagerClient.FileManagerClient,
) *UserService {
	return &UserService{
		dbName:      dbName,
		repo:        repo,
		perms:       perms,
		cache:       c,
		temporalSvc: temporalSvc,
		arTaskQueue: arTaskQueue,
		notifier:    notifier,
		fileManager: fileManager,
	}
}

func (s *UserService) tenantSvc(clientCode string) coreService.PostgreSQLServicer {
	return s.svcFor(clientCode)
}

func (s *UserService) publicSvc() coreService.PostgreSQLServicer {
	return s.svcFor("public")
}

// svcFor opens the schema's own servicer. The service holds dbName, never a
// live PostgreSQLService: that struct carries per-instance transaction state,
// so a shared instance would race across concurrent calls (ADR 004).
func (s *UserService) svcFor(schema string) coreService.PostgreSQLServicer {
	if s.makeSvc != nil {
		return s.makeSvc(schema)
	}
	return coreService.MakePostgreSQLService(schema + ":" + s.dbName)
}

// SetServiceFactoryForTest replaces the DB factory with a stub so unit tests
// never touch Postgres. schema is "public" or the tenant's client code.
func (s *UserService) SetServiceFactoryForTest(factory func(schema string) coreService.PostgreSQLServicer) {
	s.makeSvc = factory
}

func (s *UserService) SetPermissionsRepositoryForTest(perms authRepository.UserPermissionsRepositor) {
	s.perms = perms
}

func (s *UserService) SetCacheForTest(c *cache.Cache) {
	s.cache = c
}

// FetchRolesSnapshot adapts RolesSnapshot to the RolesFetcher contract of
// ts-utils' LoadUserRolesFrom: user id and tenant arrive as gateway-header
// strings, and iam reads its own database in-process instead of calling its
// own HTTP snapshot endpoint.
func (s *UserService) FetchRolesSnapshot(ctx context.Context, userID, clientID string) (tsMiddleware.UserAccessCache, error) {
	id, err := strconv.ParseInt(userID, 10, 64)
	if err != nil {
		return tsMiddleware.UserAccessCache{}, fmt.Errorf("user.FetchRolesSnapshot: invalid user id %q: %w", userID, err)
	}
	return s.RolesSnapshot(ctx, id, clientID)
}
