package service

import (
	"context"
	"fmt"
	"log/slog"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/workflow"

	"gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/temporal_helper"
	"go.temporal.io/sdk/client"
)

func (s *UserService) CancelEmailChange(ctx context.Context, clientCode string, userID int64, currentUserID int64, currentUserFullName string) error {
	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowCancelEmailChange,
		TemporalService: s.temporalSvc,
		Param: workflow.CancelEmailChangeWorkflowParam{
			ClientCode:                  clientCode,
			UserID:                      userID,
			CurrentUserID:               currentUserID,
			CurrentUserName:             currentUserFullName,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, (*any)(nil), client.StartWorkflowOptions{})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.CancelEmailChange: ExecuteWorkflow", "err", httpErr)
		return httpErr
	}

	return nil
}

func (s *UserService) ConfirmEmailChange(ctx context.Context, token string) (string, error) {
	result := &workflow.ConfirmEmailChangeWorkflowResult{}

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowConfirmEmailChange,
		TemporalService: s.temporalSvc,
		Param: workflow.ConfirmEmailChangeWorkflowParam{
			Token:                       token,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.ConfirmEmailChange: ExecuteWorkflow", "err", httpErr)
		return "", httpErr
	}

	return result.NewEmail, nil
}

func (s *UserService) InitiateEmailChange(ctx context.Context, clientCode string, userID int64, newEmail string, currentUserID int64, currentUserFullName string) (*dto.InitiateEmailChangeResponse, error) {
	result := &model.UserEmailChange{}

	httpErr := temporal_helper.ExecuteWorkflowWithContext(ctx, temporal_helper.ExecuteWorkflowConfig{
		WorkflowName:    constant.WorkflowEmailChange,
		TemporalService: s.temporalSvc,
		Param: workflow.EmailChangeWorkflowParam{
			ClientCode:                  clientCode,
			UserID:                      userID,
			NewEmail:                    newEmail,
			CurrentUserID:               currentUserID,
			CurrentUserName:             currentUserFullName,
			AnalyticsReportingTaskQueue: s.arTaskQueue,
		},
	}, result, client.StartWorkflowOptions{})

	if httpErr != nil {
		slog.ErrorContext(ctx, "UserService.InitiateEmailChange: ExecuteWorkflow", "err", httpErr)
		return nil, httpErr
	}

	return &dto.InitiateEmailChangeResponse{
		ID:        fmt.Sprintf("%d", result.ID),
		NewEmail:  result.NewEmail,
		Status:    "pending",
		ExpiresAt: result.ExpiresAt,
		CreatedAt: result.CreatedAt,
	}, nil
}
