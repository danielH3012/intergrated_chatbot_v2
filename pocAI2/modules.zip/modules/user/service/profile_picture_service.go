package service

import (
	"context"
	"log/slog"
	"mime"
	"mime/multipart"
	"path/filepath"
	"strconv"
	"strings"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/constant"
	fileManagerClient "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/module/file_manager_service/client"
	coreEntity "gitea.tagsamurai.local/Wangsit-Developer/be-core-utils/entity"
)

// uploadProfilePicture stores picture in file-manager-service and returns the file id and public
// path to persist on the user row. ownerID is the user the picture belongs to; it is zero on
// create, where the user row does not exist yet.
func (s *UserService) uploadProfilePicture(
	ctx context.Context,
	clientCode string,
	actorID, ownerID int64,
	picture *multipart.FileHeader,
) (*int64, *string, error) {
	if picture == nil {
		return nil, nil, nil
	}

	ext := strings.ToLower(filepath.Ext(picture.Filename))
	if ext != ".png" && ext != ".jpg" && ext != ".jpeg" {
		return nil, nil, &coreEntity.HttpError{
			Code:    422,
			Message: "Profile picture must be a PNG or JPG file.",
			Data:    map[string]any{"field": "profilePicture"},
		}
	}
	if picture.Size > constant.MaxProfilePictureBytes {
		return nil, nil, &coreEntity.HttpError{
			Code:    422,
			Message: "Profile picture must not exceed 1 MB.",
			Data:    map[string]any{"field": "profilePicture"},
		}
	}

	file, err := picture.Open()
	if err != nil {
		slog.ErrorContext(ctx, "UserService.uploadProfilePicture: open", "err", err)
		return nil, nil, coreEntity.BadRequest("Invalid profile picture")
	}
	defer file.Close()

	contentType := picture.Header.Get("Content-Type")
	if contentType == "" {
		contentType = mime.TypeByExtension(ext)
	}
	if contentType == "" {
		contentType = "application/octet-stream"
	}

	params := fileManagerClient.UploadParams{
		FolderName:   constant.ProfilePictureFolder,
		Type:         constant.ProfilePictureType,
		Module:       constant.ProfilePictureModule,
		Platform:     string(model.PlatformWeb),
		ModifiedByID: strconv.FormatInt(actorID, 10),
	}
	if ownerID > 0 {
		params.UserID = strconv.FormatInt(ownerID, 10)
	}

	res, err := s.fileManager.Upload(
		ctx,
		clientCode,
		strconv.FormatInt(actorID, 10),
		params,
		picture.Filename,
		contentType,
		file,
	)
	if err != nil {
		slog.ErrorContext(ctx, "UserService.uploadProfilePicture: Upload", "err", err)
		return nil, nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	fileID, err := strconv.ParseInt(res.ID, 10, 64)
	if err != nil {
		slog.ErrorContext(ctx, "UserService.uploadProfilePicture: parse file id", "id", res.ID, "err", err)
		return nil, nil, coreEntity.InternalServerError(constant.MsgInternalServerError)
	}

	return &fileID, &res.PublicPath, nil
}
