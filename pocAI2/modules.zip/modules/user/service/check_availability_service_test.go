package service

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/model"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/dto"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/repository"
)

func ptr[T any](v T) *T {
	return &v
}

func TestUserService_CheckAvailability(t *testing.T) {
	fakeRepo := repository.NewFakeUserRepository()
	svc := newSvc(nil, fakeRepo)

	empIDExisting := "EMP001"
	existingUser := model.User{
		ID:         100,
		FirstName:  "John",
		LastName:   "Doe",
		Email:      "john@example.com",
		EmployeeID: &empIDExisting,
	}
	fakeRepo.AddUser(&existingUser)

	ctx := context.Background()
	clientCode := "client1"

	t.Run("both available", func(t *testing.T) {
		req := dto.UserAvailabilityBody{
			Email:      ptr("available@example.com"),
			EmployeeID: ptr("EMP999"),
		}
		res, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.NoError(t, err)
		assert.NotNil(t, res.Email.Available)
		assert.True(t, *res.Email.Available)
		assert.NotNil(t, res.EmployeeID.Available)
		assert.True(t, *res.EmployeeID.Available)
	})

	t.Run("email taken and employeeId free", func(t *testing.T) {
		req := dto.UserAvailabilityBody{
			Email:      ptr("john@example.com"),
			EmployeeID: ptr("EMP999"),
		}
		res, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.NoError(t, err)
		assert.NotNil(t, res.Email.Available)
		assert.False(t, *res.Email.Available)
		assert.NotNil(t, res.EmployeeID.Available)
		assert.True(t, *res.EmployeeID.Available)
	})

	t.Run("email free and employeeId taken", func(t *testing.T) {
		req := dto.UserAvailabilityBody{
			Email:      ptr("free@example.com"),
			EmployeeID: ptr("EMP001"),
		}
		res, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.NoError(t, err)
		assert.NotNil(t, res.Email.Available)
		assert.True(t, *res.Email.Available)
		assert.NotNil(t, res.EmployeeID.Available)
		assert.False(t, *res.EmployeeID.Available)
	})

	t.Run("both omitted / nil", func(t *testing.T) {
		req := dto.UserAvailabilityBody{}
		res, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.NoError(t, err)
		assert.Nil(t, res.Email.Available)
		assert.Nil(t, res.EmployeeID.Available)
	})

	t.Run("empty strings and whitespace only", func(t *testing.T) {
		req := dto.UserAvailabilityBody{
			Email:      ptr("   "),
			EmployeeID: ptr(""),
		}
		res, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.NoError(t, err)
		assert.Nil(t, res.Email.Available)
		assert.Nil(t, res.EmployeeID.Available)
	})

	t.Run("emoji in email returns 422", func(t *testing.T) {
		req := dto.UserAvailabilityBody{
			Email: ptr("test😀@example.com"),
		}
		_, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "Email contains invalid characters")
	})

	t.Run("emoji in employeeId returns 422", func(t *testing.T) {
		req := dto.UserAvailabilityBody{
			EmployeeID: ptr("EMP-🔥"),
		}
		_, err := svc.CheckAvailability(ctx, clientCode, req)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "Employee ID contains invalid characters")
	})
}
