package user

import (
	"github.com/gofiber/fiber/v3"

	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/handler"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/helper"
	"gitea.tagsamurai.local/BETS-V2/iam-service/internal/modules/user/service"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/enum"
	tsMiddleware "gitea.tagsamurai.local/BETS-V2/ts-utils/v2/middleware"
	"gitea.tagsamurai.local/BETS-V2/ts-utils/v2/rbac"
)

func SetupRoutes(app *fiber.App, rolesFetcher tsMiddleware.RolesFetcher, svc *service.UserService) {
	h := handler.NewUserHandler(svc)

	userGroup := app.Group("/users")
	userGroup.Use(tsMiddleware.LoadUserRolesFrom(rolesFetcher))

	read := rbac.Any(rbac.GlobalSettingsSeeAll(), rbac.GlobalSettingsSystemRole(tsMiddleware.PermView, enum.SystemRoleKeyManageUserAndRole))

	userGroup.Post("/list", rbac.Require(read), h.HandleListUsers)
	userGroup.Post("/options", rbac.Require(read), h.HandleUserOptions)
	userGroup.Get("/dropdown", rbac.Require(read), h.HandleUserDropdown)
	userGroup.Post("/check-availability", rbac.Require(read), h.HandleCheckAvailability)
	userGroup.Get("/:id", rbac.Require(read), h.HandleGetUserDetail)

	userGroup.Post("/", rbac.Require(rbac.GlobalSettingsSystemRole(tsMiddleware.PermCreate, enum.SystemRoleKeyManageUserAndRole)), h.HandleCreateUser)
	userGroup.Patch("/:id", rbac.Require(rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole)), h.HandleUpdateUser)

	userGroup.Delete("/", rbac.Require(rbac.GlobalSettingsSystemRole(tsMiddleware.PermDelete, enum.SystemRoleKeyManageUserAndRole)), h.HandleDeleteUsers)

	userGroup.Post("/export", rbac.Require(read), h.HandleExportUsers)

	userGroup.Delete("/:id/email-change", rbac.Require(rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole)), h.HandleCancelEmailChange)

	updatePerm := rbac.Require(rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole))
	userGroup.Post("/products/:productId/status/bulk", rbac.Require(helper.ProductStatusBulkRule), h.HandleBulkProductStatus)
	userGroup.Post("/status/bulk", updatePerm, h.HandleBulkGlobalStatus)
	userGroup.Post("/:userId/reactivate", updatePerm, h.HandleReactivateUser)

	resendPerm := rbac.Any(
		rbac.GlobalSettingsSeeAll(),
		rbac.GlobalSettingsSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole),
		rbac.AdminConsoleSeeAll(),
		rbac.AdminConsoleSystemRole(tsMiddleware.PermEdit, enum.SystemRoleKeyManageUserAndRole),
	)
	userGroup.Post("/resend-email", rbac.Require(resendPerm), h.HandleResendEmail)
	userGroup.Post("/:id/reset-authenticator", updatePerm, h.HandleResetAuthenticator)

	// Admin Console User routes
	acGroup := app.Group("/products/admin_console/users")
	acGroup.Use(tsMiddleware.LoadUserRolesFrom(rolesFetcher))

	acRead := rbac.Any(
		rbac.AdminConsoleSeeAll(),
		rbac.AdminConsoleSystemRole(tsMiddleware.PermView, enum.SystemRoleKeyManageUserAndRole),
	)
	acGroup.Get("/dropdown", rbac.Require(acRead), h.HandleAdminConsoleUserDropdown)
	acGroup.Post("/list", rbac.Require(acRead), h.HandleAdminConsoleUserList)
	acGroup.Post("/options", rbac.Require(acRead), h.HandleAdminConsoleUserOptions)
	acGroup.Get("/:id/active-roles", rbac.Require(acRead), h.HandleAdminConsoleUserActiveRoles)
	acGroup.Post("/export", rbac.Require(acRead), h.HandleAdminConsoleUserExport)
}

// SetupInternalRoutes mounts the service-to-service surface.
func SetupInternalRoutes(app *fiber.App, serviceToken string, svc *service.UserService) {
	h := handler.NewUserHandler(svc)
	app.Get("/internal/users/:id/roles", tsMiddleware.RequireServiceToken(serviceToken), h.HandleUserRolesSnapshot)
	app.Post("/internal/users/:id/email-change", tsMiddleware.RequireServiceToken(serviceToken), h.HandleInitiateEmailChange)
}

// SetupPublicRoutes mounts public facing routes.
func SetupPublicRoutes(app *fiber.App, svc *service.UserService) {
	h := handler.NewUserHandler(svc)
	app.Post("/users/email-change/confirm", h.HandleEmailChangeConfirm)
}
